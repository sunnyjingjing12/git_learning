package com.itingbaby.app;


import android.content.SharedPreferences;

import com.itingbaby.baselib.commonutils.ApplicationContext;

/**
 * 应用程序配置
 */
public class AppConfig {

	public static final String ASSETS_DATABASE_NEED_RELOAD = "assets_database_need_reload";

	/**
	 * assets文件夹中数据库文件是否需要重新装载
	 *
	 * @return
	 */
	public static boolean isAssetsDatabaseNeedReload() {
		SharedPreferences sp = ApplicationContext.getContext().getSharedPreferences(ApplicationContext.getPreferencesName(), 0);
		return sp.getBoolean(ASSETS_DATABASE_NEED_RELOAD, false);//默认关闭
	}

	/**
	 * 设置assets文件夹中数据库文件是否需要重新装载
	 *
	 * @param isOn TRUE 表示开启
	 * @return
	 */
	public static void setAssetsDatabaseNeedReload(boolean isOn) {
		SharedPreferences sp = ApplicationContext.getContext().getSharedPreferences(ApplicationContext.getPreferencesName(), 0);
		sp.edit().putBoolean(ASSETS_DATABASE_NEED_RELOAD, isOn).apply();
	}

}
