package com.itingbaby.app;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.os.Environment;
import android.text.TextUtils;

import androidx.multidex.MultiDex;

import com.bumptech.glide.Glide;
import com.bumptech.glide.integration.okhttp3.OkHttpUrlLoader;
import com.bumptech.glide.load.model.GlideUrl;
import com.facebook.stetho.Stetho;
import com.itingbaby.app.command.HeadSetPluginChangedCommand;
import com.itingbaby.app.model.DaoMaster;
import com.itingbaby.app.model.DaoSession;
import com.itingbaby.app.model.User;
import com.itingbaby.app.upgrade.DbUpgradeHelper;
import com.itingbaby.app.utils.BroadcastWatcher;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.GsonHelper;
import com.itingbaby.app.utils.RemindNotificationUtil;
import com.itingbaby.app.utils.SharedPreferencesUtil;
import com.itingbaby.app.utils.SingleOkHttpClient;
import com.itingbaby.app.utils.db.AssetsDBUtil;
import com.itingbaby.baselib.commonutils.ApplicationContext;
import com.itingbaby.baselib.commonutils.ApplicationUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.ScreenAdapterUtil;
import com.itingbaby.baselib.manager.ActivityTaskManager;
import com.itingbaby.dev.iTingBabyBleDeviceManager;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.cache.CacheEntity;
import com.lzy.okgo.cache.CacheMode;
import com.lzy.okgo.cookie.CookieJarImpl;
import com.lzy.okgo.cookie.store.DBCookieStore;
import com.lzy.okgo.https.HttpsUtils;
import com.lzy.okgo.interceptor.HttpLoggingInterceptor;
import com.lzy.okgo.model.HttpHeaders;
import com.lzy.okgo.model.HttpParams;
import com.mob.MobSDK;
import com.tencent.smtt.sdk.QbSdk;
import com.umeng.commonsdk.UMConfigure;

import org.greenrobot.greendao.database.Database;

import java.io.File;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import okhttp3.OkHttpClient;

public class BabyVoiceApp extends Application {

	//private static final String TAG = BabyVoiceApp.class.getSimpleName();

	public static User mUserInfo;

	private static BabyVoiceApp instance = null;

	private static String cachePath;
	private static String musicPath;
	private static String firmwarePath;

	private boolean mScreenOn = false;

	private BroadcastWatcher mBroadcastWatcher;


	/**
	 * 耳机是否插入
	 */
	private boolean mIsPlugIn = false;
	private long exitTime;

	private DaoSession daoSession;

	public String getCachePath() {
		return cachePath;
	}

	public String getCacheMusicPath() {
		return musicPath;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		instance = this;

		SharedPreferences sharedPreferences = getSharedPreferences(SharedPreferencesUtil.USER_INFO_SHARED_PREFERENCES_FILE, MODE_PRIVATE);
		BabyVoiceApp.mUserInfo = GsonHelper.jsonToObject(sharedPreferences.getString(SharedPreferencesUtil.USER_INFO_DATA, ""), User.class);

		initDatabase();

		//Stetho
		Stetho.initializeWithDefaults(this);
		//Glide与OkHttpClient集成

		//Glide与OkHttpClient集成
		Glide.get(this).register(GlideUrl.class, InputStream.class, new OkHttpUrlLoader.Factory(SingleOkHttpClient.getInstance()));

		mBroadcastWatcher = new BroadcastWatcher(this);
		mBroadcastWatcher.startWatch();

		// ShareSDK初始化
		MobSDK.init(this);
		//友盟
		initUmeng();

		initOKGO();

		// 初始化缓存路径
		initPath();

		iTingBabyBleDeviceManager.getInstance().init(this);
		iTingBabyBleDeviceManager.getInstance().setFirmwareFilePath(firmwarePath);

		ApplicationUtils.IS_DEBUG = (ApplicationInfo.FLAG_DEBUGGABLE & getApplicationInfo().flags) != 0;

		if (BuildConfig.DEBUG) {
			Ln.getConfig().setLoggingLevel(2, true);
		} else {
			Ln.getConfig().setLoggingLevel(4, false);
		}


		// 适配方案
		ScreenAdapterUtil.setup(this);
		ScreenAdapterUtil.register(this, 720, ScreenAdapterUtil.MATCH_BASE_HEIGHT, ScreenAdapterUtil.MATCH_UNIT_DP);

		// 设置提醒
		setRemindData();

		initX5();

	}

	private void initX5() {
		//加载X5内核
		QbSdk.PreInitCallback cb = new QbSdk.PreInitCallback() {
			@Override
			public void onCoreInitFinished() {

			}

			@Override
			public void onViewInitFinished(boolean b) {
				//x5內核初始化完成的回调，为true表示x5内核加载成功，否则表示x5内核加载失败，会自动切换到系统内核。
				Ln.d("[tbs x5] X5加载结果 =%b ", b);
			}

		};
		QbSdk.setDownloadWithoutWifi(true);
		//x5内核初始化接口
		QbSdk.initX5Environment(getApplicationContext(), cb);
	}

	/**
	 * 设置提醒
	 */
	private void setRemindData() {
		Ln.d("[alarm] setRemindData");
		RemindNotificationUtil.getInstance().setNextExaminationNotification();
		RemindNotificationUtil.getInstance().setNextVaccineNotification();

	}

	@Override
	public void onTerminate() {
		super.onTerminate();

		iTingBabyBleDeviceManager.getInstance().release();

		if (mBroadcastWatcher != null) {
			mBroadcastWatcher.stopWatch();
			mBroadcastWatcher = null;
		}
	}

	private void initUmeng() {
		/**
		 * 注意: 即使您已经在AndroidManifest.xml中配置过appkey和channel值，也需要在App代码中调
		 * 用初始化接口（如需要使用AndroidManifest.xml中配置好的appkey和channel值，
		 * UMConfigure.init调用中appkey和channel参数请置为null）。
		 */
		String channel = "umeng";

		UMConfigure.init(this, "593ded9b4ad1565f30001d3a", TextUtils.isEmpty(channel) ? "umeng" : channel, UMConfigure.DEVICE_TYPE_PHONE, "");
//        UMConfigure.initWithUid(this, "593ded9b4ad1565f30001d3a", "umeng", UMConfigure.DEVICE_TYPE_PHONE, "");

		// 支持在子进程中统计自定义事件
		UMConfigure.setProcessEvent(true);

		// 打开统计SDK调试模式
		UMConfigure.setLogEnabled(true);


	}

	private void initOKGO() {
		//必须调用初始化
		HttpHeaders headers = new HttpHeaders();
//		headers.put("commonHeaderKey1", "commonHeaderValue1");    //header不支持中文，不允许有特殊字符
//		headers.put("commonHeaderKey2", "commonHeaderValue2");
		HttpParams params = new HttpParams();
//		params.put("commonParamsKey1", "commonParamsValue1");     //param支持中文,直接传,不要自己编码
//		params.put("commonParamsKey2", "这里支持中文参数");
		//----------------------------------------------------------------------------------------//

		OkHttpClient.Builder builder = new OkHttpClient.Builder();
		//log相关
		HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor("OkGo");
		loggingInterceptor.setPrintLevel(HttpLoggingInterceptor.Level.BODY);        //log打印级别，决定了log显示的详细程度
		loggingInterceptor.setColorLevel(Level.INFO);                               //log颜色级别，决定了log在控制台显示的颜色
		builder.addInterceptor(loggingInterceptor);                                 //添加OkGo默认debug日志
		//第三方的开源库，使用通知显示当前请求的log，不过在做文件下载的时候，这个库好像有问题，对文件判断不准确
		//builder.addInterceptor(new ChuckInterceptor(this));

		//超时时间设置，默认60秒
		builder.readTimeout(OkGo.DEFAULT_MILLISECONDS, TimeUnit.MILLISECONDS);      //全局的读取超时时间
		builder.writeTimeout(OkGo.DEFAULT_MILLISECONDS, TimeUnit.MILLISECONDS);     //全局的写入超时时间
		builder.connectTimeout(OkGo.DEFAULT_MILLISECONDS, TimeUnit.MILLISECONDS);   //全局的连接超时时间

		//自动管理cookie（或者叫session的保持），以下几种任选其一就行
		//builder.cookieJar(new CookieJarImpl(new SPCookieStore(this)));            //使用sp保持cookie，如果cookie不过期，则一直有效
		builder.cookieJar(new CookieJarImpl(new DBCookieStore(this)));              //使用数据库保持cookie，如果cookie不过期，则一直有效
		//builder.cookieJar(new CookieJarImpl(new MemoryCookieStore()));            //使用内存保持cookie，app退出后，cookie消失

		//https相关设置，以下几种方案根据需要自己设置
		//方法一：信任所有证书,不安全有风险
		HttpsUtils.SSLParams sslParams1 = HttpsUtils.getSslSocketFactory();
		//方法二：自定义信任规则，校验服务端证书
//		HttpsUtils.SSLParams sslParams2 = HttpsUtils.getSslSocketFactory(new SafeTrustManager());
		//方法三：使用预埋证书，校验服务端证书（自签名证书）
		//HttpsUtils.SSLParams sslParams3 = HttpsUtils.getSslSocketFactory(getAssets().open("srca.cer"));
		//方法四：使用bks证书和密码管理客户端证书（双向认证），使用预埋证书，校验服务端证书（自签名证书）
		//HttpsUtils.SSLParams sslParams4 = HttpsUtils.getSslSocketFactory(getAssets().open("xxx.bks"), "123456", getAssets().open("yyy.cer"));
		builder.sslSocketFactory(sslParams1.sSLSocketFactory, sslParams1.trustManager);
		//配置https的域名匹配规则，详细看demo的初始化介绍，不需要就不要加入，使用不当会导致https握手失败
//		builder.hostnameVerifier(new SafeHostnameVerifier());

		// 其他统一的配置
		// 详细说明看GitHub文档：https://github.com/jeasonlzy/
		OkGo.getInstance().init(this)                           //必须调用初始化
				.setOkHttpClient(builder.build())               //建议设置OkHttpClient，不设置会使用默认的
				.setCacheMode(CacheMode.NO_CACHE)               //全局统一缓存模式，默认不使用缓存，可以不传
				.setCacheTime(CacheEntity.CACHE_NEVER_EXPIRE)   //全局统一缓存时间，默认永不过期，可以不传
				.setRetryCount(3)                               //全局统一超时重连次数，默认为三次，那么最差的情况会请求4次(一次原始请求，三次重连请求)，不需要可以设置为0
				.addCommonHeaders(headers)                      //全局公共头
				.addCommonParams(params);                       //全局公共参数
	}


//			OkGo.getInstance()
//					//如果使用默认的 60秒,以下三行也不需要传
//					.setConnectTimeout(OkGo.DEFAULT_MILLISECONDS)  //全局的连接超时时间
//					.setReadTimeOut(OkGo.DEFAULT_MILLISECONDS)     //全局的读取超时时间
//					.setWriteTimeOut(OkGo.DEFAULT_MILLISECONDS)    //全局的写入超时时间
//
//					//可以全局统一设置缓存模式,默认是不使用缓存,可以不传,具体其他模式看 github 介绍 https://github.com/jeasonlzy/
//					.setCacheMode(CacheMode.NO_CACHE)
//
//					//可以全局统一设置缓存时间,默认永不过期,具体使用方法看 github 介绍
//					.setCacheTime(CacheEntity.CACHE_NEVER_EXPIRE)
//
//					//如果不想让框架管理cookie,以下不需要
//					//.setCookieStore(new MemoryCookieStore())                //cookie使用内存缓存（app退出后，cookie消失）
//					.setCookieStore(new PersistentCookieStore());          //cookie持久化存储，如果cookie不过期，则一直有效

			//可以设置https的证书,以下几种方案根据需要自己设置,不需要不用设置
//                    .setCertificates()                                  //方法一：信任所有证书
//                    .setCertificates(getAssets().open("srca.cer"))      //方法二：也可以自己设置https证书
//                    .setCertificates(getAssets().open("aaaa.bks"), "123456", getAssets().open("srca.cer"))//方法三：传入bks证书,密码,和cer证书,支持双向加密

			//可以添加全局拦截器,不会用的千万不要传,错误写法直接导致任何回调不执行
//                .addInterceptor(new Interceptor() {
//                    @Override
//                    public Response intercept(Chain chain) throws IOException {
//                        return chain.proceed(chain.request());
//                    }
//                })

			//这两行同上,不需要就不要传
//                    .addCommonHeaders(headers)                                         //设置全局公共头
//                    .addCommonParams(params);                                          //设置全局公共参数
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	public static BabyVoiceApp getInstance() {
		return instance;
	}

	public boolean isPlugIn() {
		return mIsPlugIn;
	}

	public void setPlugIn(boolean isPlugIn) {
		if (mIsPlugIn != isPlugIn) {
			mIsPlugIn = isPlugIn;
			HeadSetPluginChangedCommand.HeadSetPluginState headSetPluginState = HeadSetPluginChangedCommand.HeadSetPluginState.HEAD_SET_OUT;
			if (isPlugIn) {
				headSetPluginState = HeadSetPluginChangedCommand.HeadSetPluginState.HEAD_SET_IN;
			}
			HeadSetPluginChangedCommand headSetPluginChangedCommand = new HeadSetPluginChangedCommand(headSetPluginState);
//			RxBus.getDefault().post(headSetPluginChangedCommand);
		}
	}

	public void setScreenOn(boolean mScreenOn) {
		this.mScreenOn = mScreenOn;
	}

	public static void initPath() {
//		cachePath = instance.getCacheDir().getAbsolutePath() + "/";
//		if (FileUtils.canWriteExternal()) {
		String[] paths = new String[] {
			Environment.getExternalStorageDirectory().getAbsolutePath() + "/babyVoice/Caches/",
			Environment.getExternalStorageDirectory().getAbsolutePath() + "/babyVoice/firmware/"
		};
		cachePath = paths[0];
		firmwarePath = paths[1];
		musicPath = cachePath + "music/";
//		}
		Ln.d("[cache path] initWithUid cachePath is " + cachePath);
		for (String str : paths) {
			File f = new File(str);
			if (!f.exists())
				f.mkdirs();
		}
	}


	/**
	 * 退出程序
	 *
	 * @param context
	 */
	public void ExitAPP(Context context) {
		if ((System.currentTimeMillis() - exitTime) > 2000) {
			CommonToast.showShortToast(R.string.exit_tip);
			exitTime = System.currentTimeMillis();
		} else {
			mUserInfo = null;
			ActivityTaskManager.getInstance().removeAllActivity();
		}
	}

	@Override
	protected void attachBaseContext(Context base) {
		super.attachBaseContext(base);
		MultiDex.install(this);

		ApplicationContext.init(base);
		ApplicationContext.setApplication(this);
	}

	public DaoSession getDaoSession() {
		return daoSession;
	}

	private void initDatabase() {
		// regular SQLite database
		DbUpgradeHelper helper = new DbUpgradeHelper(this, "local.db");
		Database db = helper.getWritableDb();
		// encrypted SQLCipher database
		// note: you need to add SQLCipher to your dependencies, check the build.gradle file
		// DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(this, "notes-db-encrypted");
		// Database db = helper.getEncryptedWritableDb("encryption-key");
		daoSession = new DaoMaster(db).newSession();

		// 移动assets中的db文件
		AssetsDBUtil.getPath(getApplicationContext());
	}
}



