package com.itingbaby.app;

import com.itingbaby.app.model.AudioType;

public class DataManager {

	private int curRecordType; // 最小化时的 录音类型

	private boolean enableShowNetworkDialog = true; // 本次打开进程，是否显示流量弹窗

	private DataManager() {
	}
	private static class Holder {
		private static final DataManager INSTANCE = new DataManager();
	}
	public static DataManager getInstance() {
		return Holder.INSTANCE;
	}


	public void setCurRecordType(int curRecordType) {
		this.curRecordType = curRecordType;
	}
	public int getCurRecordType() {
		return curRecordType;
	}

	public void clearData() {
		curRecordType = AudioType.AUDIO_TYPE_BABY;
	}

	public boolean isEnableShowNetworkDialog() {
		return enableShowNetworkDialog;
	}

	public void setEnableShowNetworkDialog(boolean enableShowNetworkDialog) {
		this.enableShowNetworkDialog = enableShowNetworkDialog;
	}
}
