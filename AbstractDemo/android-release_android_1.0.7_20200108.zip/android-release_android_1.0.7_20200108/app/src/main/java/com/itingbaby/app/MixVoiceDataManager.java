package com.itingbaby.app;

import com.itingbaby.app.model.AudioPlayData;
import com.itingbaby.app.model.MixMusicSelectStatus;

import java.util.HashSet;
import java.util.Set;

/**
 * 混音数据管理类
 */
public class MixVoiceDataManager {

	private static class Holder {
		private static final MixVoiceDataManager INSTANCE = new MixVoiceDataManager();
	}

	public static MixVoiceDataManager getInstance() {
		return MixVoiceDataManager.Holder.INSTANCE;
	}


	// 选择的心音数据集合
	private HashSet<AudioPlayData> recordModelSet;

	// 选择的音乐数据集合
	private HashSet<AudioPlayData> musicSet;


	public HashSet<AudioPlayData> getRecordModelSet() {
		if (recordModelSet == null) {
			recordModelSet = new HashSet<>();
		}
		return recordModelSet;
	}

	public void setRecordModelSet(HashSet<AudioPlayData> dataList) {
		if (this.recordModelSet == null) {
			this.recordModelSet = new HashSet<>();
		}
		if (!this.recordModelSet.isEmpty()) {
			this.recordModelSet.clear();
		}
		this.recordModelSet.addAll(dataList);

	}

	public HashSet<AudioPlayData> getMusicSet() {
		if (musicSet == null) {
			musicSet = new HashSet<>();
		}
		return musicSet;
	}

	public void setMusicSet(HashSet<AudioPlayData> dataList) {
		if (this.musicSet == null) {
			this.musicSet = new HashSet<>();
		}
		if (!this.musicSet.isEmpty()) {
			this.musicSet.clear();
		}
		this.musicSet.addAll(dataList);
	}

	/**
	 * 添加数据，如果有相同id的数据，则不再添加
	 *
	 * @param data
	 * @param dataSet
	 */
	public void addData(AudioPlayData data, Set<AudioPlayData> dataSet) {
		for (AudioPlayData playData : dataSet) {
			if (playData.getId().equals(data.getId())) {
				// 已存在，直接返回
				return;
			}
		}
		// 不存在，添加进dataSet
		dataSet.add(data);
	}

	/**
	 * 移除数据
	 *
	 * @param data
	 * @param dataSet
	 */
	public void removeData(AudioPlayData data, Set<AudioPlayData> dataSet) {
		for (AudioPlayData playData : dataSet) {
			if (playData.getId().equals(data.getId())) {
				dataSet.remove(playData);
				break;
			}
		}
	}

	/**
	 * 获取选中的那条数据
	 *
	 * @param dataSet
	 * @return
	 */
	public AudioPlayData getPickedData(Set<AudioPlayData> dataSet) {
		for (AudioPlayData playData : dataSet) {
			if (playData.mixMusicSelectStatus == MixMusicSelectStatus.MUSIC_MIX_SELECTED) {
				return playData;
			}
		}
		return null;
	}

	/**
	 * 清除数据
	 */
	public void release() {
		if (recordModelSet != null) {
			recordModelSet.clear();
			recordModelSet = null;
		}
		if (musicSet != null) {
			musicSet.clear();
			musicSet = null;
		}
	}
}
