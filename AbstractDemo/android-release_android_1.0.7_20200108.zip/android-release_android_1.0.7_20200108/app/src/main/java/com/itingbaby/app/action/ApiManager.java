package com.itingbaby.app.action;

import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.app.model.HomeDataListCard;
import com.itingbaby.app.model.MusicClause;
import com.itingbaby.app.model.MusicGroup;
import com.itingbaby.app.model.ToolInfo;
import com.itingbaby.app.model.UpdateInfo;
import com.itingbaby.app.model.User;
import com.itingbaby.app.model.WaitTodoGoods;
import com.itingbaby.app.model.httpmodel.Data;
import com.itingbaby.app.model.httpmodel.HttpPageResponse;
import com.itingbaby.app.model.httpmodel.HttpResponse;
import com.itingbaby.app.model.pelvictrain.PelvicTrainRecord;
import com.itingbaby.app.model.pregnancycheck.PregnancyCheckItem;
import com.itingbaby.app.model.pregnancycheck.PregnancyCheckReportImg;

import java.util.List;

import io.reactivex.Observable;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

/**
 * Created by lhb on 2017/1/17.
 */

public interface ApiManager {

	/*-----------------------------------------------apk版本-------------------------------------*/
	@GET("/client_version_check")
	Observable<HttpResponse<UpdateInfo>> clientVersionCheck(
			@Query("uid") long uid,
			@Query("clt_type") int clientType// 0-unknown 1-android 2-ios
	);
	/*-----------------------------------------------注册登录-------------------------------------*/

	/**
	 * 新用户注册
	 *
	 * @param account
	 * @param password
	 * @return
	 */
	@Multipart
	@POST("/register")
	Observable<HttpResponse<User>> register(
			@Part("account") RequestBody account,
			@Part("password") RequestBody password
	);

	/**
	 * 手机或邮箱 + 密码登录
	 * @param account
	 * @param password
	 * @return
	 */
	@Multipart
	@POST("/login")
	Observable<HttpResponse<User>> loginByAccount(
			@Part("account") RequestBody account,
			@Part("password") RequestBody password
	);

	/**
	 * 验证码登录
	 *
	 * @param account
	 * @param smsCode
	 * @return
	 */
	@Multipart
	@POST("/login_by_sms_code")
	Observable<HttpResponse<User>> loginBySmsCode(
			@Part("account") RequestBody account,
			@Part("smscode") RequestBody smsCode);

	/**
	 * 第三方登陆
	 * @param params
	 * @return
	 */
	@Multipart
	@POST("/login_thirdparty")
	Observable<HttpResponse<User>> loginThirdParty(
			@Part("platform") RequestBody platform,
			@Part("params") RequestBody params
	);

	/**
	 * 获取验证码，包括手机或邮箱的
	 *
	 * @param account
	 * @return
	 */
	@GET("/get_sms_code")
	Observable<HttpResponse<Void>> getSmsCode(
			@Query("account") String account
	);

	/**
	 * 核实获取到的验证码
	 *
	 * @param account
	 * @param smsCode
	 * @return
	 */
	@GET("/verify_sms_code")
	Observable<HttpResponse<Void>> verifyCode(
			@Query("account") String account,
			@Query("smscode") String smsCode);

	/*-----------------------------------------------信息修改-------------------------------------*/

	/**
	 * 更新用户信息
	 * @param user
	 * @return
	 */
	@POST("/update_profile")
	Observable<HttpResponse<User>> updateUserInfo(
			@Body User user
	);


	/**
	 * 修改密码
	 *
	 * @param account
	 * @param newPassword
	 * @return
	 */
	@Multipart
	@POST("/change_password")
	Observable<HttpResponse<User>> changePassword(
			@Part("account") RequestBody account,
			@Part("password") RequestBody newPassword);

	/*-----------------------------------------------文件上传-------------------------------------*/

	/**
	 * 更新头像
	 * @param multipartBody
	 * @return
	 */
	@POST("/upload_avatar")
	Observable<HttpResponse<String>> uploadAvatar(
			@Body MultipartBody multipartBody);

	/**
	 * 上传声音文件到服务器
	 *
	 * @param multipartBody
	 * @return
	 */
	@POST("/upload_voice")
	Observable<HttpResponse<AudioRecordModel>> uploadVoiceFile(
			@Body MultipartBody multipartBody);

	/**
	 * 获取'我'上传的录音数据列表
	 * @param page
	 * @param pageSize
	 * @return
	 */
	@GET("/get_user_records")
	Observable<HttpPageResponse<List<AudioRecordModel>>> getUserRecords(
			@Query("uid") long uid,
			@Query("record_type") long recordType,
			@Query("page") int page,
			@Query("pageSize") int pageSize
	);

	/**
	 * 获取音乐组列表数据
	 * @return
	 */
	@GET("/get_music_group")
	Observable<HttpResponse<List<MusicGroup>>> getMusicGroup();

	/**
	 * 根据音乐类别ID获取音乐条目数据列表
	 *
	 * @param cid 音乐类别ID
	 * @param page 分页ID
	 * @param pageSize 每页数据数量
	 * @return
	 */
	@GET("/get_music_clauses")
	Observable<HttpPageResponse<List<MusicClause>>> getMusicClause(
			@Query("cid") int cid,
			@Query("page") int page,
			@Query("pageSize") int pageSize
	);

	/*-----------------------------------------------训练仪-------------------------------------*/

	/**
	 * 获取评估的肌力数据
	 *
	 * @param uId
	 * @return
	 */
	@GET("/get_muscle_test")
	Observable<HttpPageResponse<List<PelvicTrainRecord>>> getPelvicExamineData(
			@Query("uid") long uId,
			@Query("page") int page,
			@Query("pageSize") int pageSize
	);

	/**
	 * 保存评估的肌力数据
	 *
	 * @param uId
	 * @param oneMuscle
	 * @param twoMuscle
	 * @param maxPower
	 * @param actonDataListStr
	 * @return
	 */
	@POST("/add_muscle_test")
	Observable<HttpResponse<PelvicTrainRecord>> savePelvicExamineData(
			@Query("uid") long uId,
			@Query("muscle_lv1") int oneMuscle,
			@Query("muscle_lv2") int twoMuscle,
			@Query("max_power") float maxPower,
			@Query("child") String actonDataListStr
	);

	//http://119.23.248.54/Ls_Server_web/MsTrain/save?uId=1&caseCode=31&trainTime=10&trainLevel=3&trainScore=84&idealTime=15&trainMode=1

	/**
	 * 保存训练的肌力数据
	 *
	 * @param uId
	 * @param trainTime
	 * @param trainLevel
	 * @param trainScore
	 * @param trainMode
	 * @return
	 */
	@POST("/add_muscle_train")
	Observable<HttpResponse<Data>> savePelvicTrainData(
			@Query("uid") long uId,
			@Query("train_time") int trainTime,
			@Query("train_level") int trainLevel,
			@Query("train_score") int trainScore,
			@Query("ideal_time") int idealTime,
			@Query("train_mode") int trainMode
	);

	/**
	 * 获取首页数据
	 *
	 * @param uid 用户uid
	 * @return
	 */
	@GET("/get_home_data")
	Observable<HttpResponse<List<HomeDataListCard>>> getHomeDataListCards(
			@Query("uid") long uid
	);

	/**
	 * 上报用户设备
	 *
	 * @param uid 用户
	 * @param devType 设备类型
	 * @param mac 设备MAC地址
	 * @return
	 */
	@Multipart
	@POST("/report_device")
	Observable<HttpResponse<Void>> reportUserDevice(
			@Part("uid") RequestBody uid,
			@Part("dev_type") RequestBody devType,
			@Part("mac") RequestBody mac
	);

	/**
	 * 获取所有工具集合
	 *
	 * @param uid 用户uid
	 * @return
	 */
	@GET("/get_tools")
	Observable<HttpResponse<List<ToolInfo>>> getToolList(
			@Query("uid") long uid
	);

	/**
	 * 获取所有需准备商品
	 *
	 * @param uid  用户uid
	 * @param type 商品类型，0为妈妈  1为宝贝
	 * @return
	 */
	@GET("/get_todo_goods")
	Observable<HttpResponse<List<WaitTodoGoods>>> getTodoGoodsList(
			@Query("uid") long uid,
			@Query("type") int type
	);

	/**
	 * 更新准备商品的标记
	 *
	 * @return
	 */
	@Multipart
	@POST("/update_todo_goods")
	Observable<HttpResponse<Void>> updateTodoGoods(
			@Part("uid") RequestBody uid,
			@Part("gid") RequestBody goodsId,
			@Part("flag") RequestBody flag
	);

	/**
	 * 用户反馈接口
	 *
	 * @param uid
	 * @param clientType
	 * @param appVersion
	 * @param deviceModel
	 * @param osVersion
	 * @param feedbackType
	 * @param content
	 * @param picfile
	 * @return
	 */
	@POST("/upload_feedback")
	Observable<HttpResponse<Void>> uploadFeedback(
			@Query("uid") long uid,
			@Query("clt_type") String clientType,
			@Query("clt_version") String appVersion,
			@Query("device_model") String deviceModel,
			@Query("os_version") String osVersion,
			@Query("type") String feedbackType,
			@Query("content") String content,
			@Body MultipartBody picfile
	);

	/**
	 * 获取产检详细信息数据
	 *
	 * @param
	 * @return
	 */
	@GET("/get_examination_detail")
	Observable<HttpResponse<PregnancyCheckItem>> getPregnancyCheckDetail(
			@Query("uid") long uid,
			@Query("eid") int examinationId
	);

	/**
	 * 上传产检图片
	 *
	 * @param
	 * @return
	 */
	@POST("/upload_examination_img")
	Observable<HttpResponse<List<PregnancyCheckReportImg>>> reportExaminationImg(
			@Body MultipartBody multipartBody
	);

	/**
	 * 刪除产检图片
	 *
	 * @param
	 * @return
	 */
	@POST("/del_examination_img")
	Observable<HttpResponse<Void>> delExaminationImg(
			@Query("uid") long uid,
			@Query("ids") List<Integer> picIds
	);

	/**
	 * 增加用户定制心音次数
	 */
	@POST("/custom_voice")
	Observable<HttpResponse<Integer>> customVoice(
			@Query("uid") long uid
	);

}
