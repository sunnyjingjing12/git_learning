package com.itingbaby.app.action;

/**
 * Created by lihb on 2018/4/7.
 */

public class ResponseCode {

	public static final int RESPONSE_OK = 0;

	// register
	public static final int ErrCodeRegisterError              = 1001;
	public static final int ErrCodeRegisterAddNewUserByMobile = 1101;
	public static final int ErrCodeRegisterUserExist		   = 1102;
	public static final int ErrCodeRegisterAddNewUserByEmail   = 1103;
	public static final int ErrCodeRegisterUnknownAccountType  = 1199;

	// login
	public static final int ErrCodeLoginErrorByAccount  = 2001;
	public static final int ErrCodeLoginQueryByAccount  = 2101;

	// login_by_sms_code
	public static final int ErrCodeLoginErrorBySmsCode   = 2002;
	public static final int ErrCodeLoginParseSmsCode     = 2201;
	public static final int ErrCodeLoginRetrieveSmsCode  = 2202;
	public static final int ErrCodeLoginCodeNonMatching  = 2203;
	public static final int ErrCodeLoginQueryByMobile    = 2204;

	// login_thirdparty
	public static final int ErrCodeLoginErrorByThirdParty  = 2003;
	public static final int ErrCodeLoginParseShareSDKData  = 2301;
	public static final int ErrCodeLoginAuthorizeUser      = 2302;

	// get_sms_code
	public static final int ErrCodeLoginErrorGetSmsCode       = 2004;
	public static final int ErrCodeLoginUnknownSmsCodeType    = 2401;
	public static final int ErrCodeLoginFailSendSmsCode       = 2402;
	public static final int ErrCodeLoginInvalidAccountFormat  = 2403;

	// update_profile
	public static final int ErrCodeProfileErrorUpdateProfile  = 3001;
	public static final int ErrCodeProfileReadBody            = 3101;
	public static final int ErrCodeProfileParseBody           = 3102;
	public static final int ErrCodeProfileUpdateProfile       = 3103;

	// change_password
	public static final int ErrCodeProfileChangePassword      = 3002;
	public static final int ErrCodeProfileUpdateUserPassword  = 3201;

	// upload_avatar
	public static final int ErrCodeProfileUploadAvatar      = 3003;
	public static final int ErrCodeProfileReadMultipart     = 3301;
	public static final int ErrCodeProfileReadForm          = 3302;
	public static final int ErrCodeProfileGetUIDFail        = 3303;
	public static final int ErrCodeProfileConvertUID        = 3304;
	public static final int ErrCodeProfileGetAvatar         = 3305;
	public static final int ErrCodeProfileUpdateFile        = 3306;
	public static final int ErrCodeProfileParseFastDFSResp  = 3307;
	public static final int ErrCodeProfileFastDFSRespError  = 3308;
	public static final int ErrCodeProfileUpdateUserAvatar  = 3309;

	// get_music_group
	public static final int ErrCodeMusicGetGroup       = 4001;
	public static final int ErrCodeMusicGetCategories  = 4100;

	// get_music_clause
	public static final int ErrCodeMusicGetClause       = 4002;
	public static final int ErrCodeMusicParseCID        = 4201;
	public static final int ErrCodeMusicParsePage       = 4202;
	public static final int ErrCodeMusicParseRows       = 4203;
	public static final int ErrCodeMusicRetrieveClause  = 4204;

	// upload_voice
	public static final int ErrCodeUploadVoice               = 5001;
	public static final int ErrCodeUploadReadMultipart       = 5101;
	public static final int ErrCodeUploadReadForm            = 5102;
	public static final int ErrCodeUploadGetUIDFail          = 5103;
	public static final int ErrCodeUploadConvertUID          = 5104;
	public static final int ErrCodeUploadGetTitleFail        = 5105;
	public static final int ErrCodeUploadGetTitleType        = 5106;
	public static final int ErrCodeUploadConvertType         = 5107;
	public static final int ErrCodeUploadGetFileFail         = 5108;
	public static final int ErrCodeUploadRecordFile          = 5109;
	public static final int ErrCodeUploadParseFastDFSResp    = 5110;
	public static final int ErrCodeUploadFastDFSRespError    = 5111;
	public static final int ErrCodeUploadAddUserAudioRecord  = 5112;

	// get_user_records
	public static final int ErrCodeAudioGetRecords       = 5002;
	public static final int ErrCodeUploadParseCID        = 5201;
	public static final int ErrCodeUploadParsePage       = 5202;
	public static final int ErrCodeUploadParseRows       = 5203;
	public static final int ErrCodeUploadGetUserRecords  = 5204;

	// add_muscle_test
	public static final int ErrCodeMuscleAddNew          = 6001;
	public static final int ErrCodeMuscleAddNewParseUID  = 6101;
	public static final int ErrCodeMuscleParseLv1        = 6102;
	public static final int ErrCodeMuscleParseLv2        = 6103;
	public static final int ErrCodeMuscleParseMaxPower   = 6104;
	public static final int ErrCodeMuscleAddMuscleTest   = 6105;

	// get_muscle_test
	public static final int ErrCodeMuscleGetTest              = 6002;
	public static final int ErrCodeMuscleGetTestParseUID      = 6201;
	public static final int ErrCodeMuscleGetTestParsePage     = 6202;
	public static final int ErrCodeMuscleGetTestParseRows     = 6203;
	public static final int ErrCodeMuscleRetrieveTestRecords  = 6204;

	// add_muscle_train
	public static final int ErrCodeMuscleGetTrain          = 6003;
	public static final int ErrCodeMuscleGetTrainParseUID  = 6301;
	public static final int ErrCodeMuscleParseTrainTime    = 6302;
	public static final int ErrCodeMuscleParseTrainLevel   = 6303;
	public static final int ErrCodeMuscleParseTrainScore   = 6304;
	public static final int ErrCodeMuscleParseIdealTime    = 6305;
	public static final int ErrCodeMuscleParseTrainMode    = 6306;
	public static final int ErrCodeMuscleAddMuscleTrain    = 6307;
}
