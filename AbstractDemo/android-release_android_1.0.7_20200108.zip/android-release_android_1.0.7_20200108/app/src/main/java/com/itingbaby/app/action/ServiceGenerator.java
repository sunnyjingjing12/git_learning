package com.itingbaby.app.action;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.itingbaby.app.action.gsonTypeAdapter.IntTypeAdapter;
import com.itingbaby.app.utils.SharedPreferencesUtil;
import com.itingbaby.app.utils.SingleOkHttpClient;
import com.itingbaby.baselib.commonutils.ApplicationContext;
import com.itingbaby.baselib.commonutils.ApplicationUtils;

import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;


/**
 * Created by lhb on 2017/1/17.
 */

public class ServiceGenerator {

	public static final String API_BASE_URL = ApplicationUtils.IS_DEBUG ?
			SharedPreferencesUtil.getCurrentServerURL(ApplicationContext.getContext()) : "http://app.itingbaby.com/";

	// 图片服务器URL基础头
	public static final String URL_IMG_SERVER = "http://app.itingbaby.com:8080";
//	public static final String URL_IMG_SERVER = "http://192.168.0.103:8080";

	// 分享服务器
	public static final String URL_SHARE_SERVER = "http://app.itingbaby.com:8008";

	// 下拉刷新
	public static final int TYPE_FRESH = 1;
	public static final int TYPE_LOAD_MORE = 2;


	private static Gson gson = new GsonBuilder()
			.registerTypeAdapter(int.class, new IntTypeAdapter())
			.registerTypeAdapter(Integer.class, new IntTypeAdapter()).create();

	private static Retrofit.Builder builder =
			new Retrofit.Builder()
					.baseUrl(API_BASE_URL)
					.client(SingleOkHttpClient.getInstance())
					.addConverterFactory(GsonConverterFactory.create(gson))
					.addCallAdapterFactory(RxJava2CallAdapterFactory.create());

	public static <T> T createService(Class<T> serviceClass) {

		Retrofit retrofit = builder.build();
		return retrofit.create(serviceClass);
	}
}
