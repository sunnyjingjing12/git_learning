package com.itingbaby.app.activity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.itingbaby.app.BuildConfig;
import com.itingbaby.app.R;
import com.itingbaby.app.customview.CommonItem;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;

import butterknife.BindView;
import butterknife.ButterKnife;

public class AboutActivity extends BaseFragmentActivity {

	private final String TELEPHONE = "020-39910873";
	private final String WEBSITE = "http://www.tbaiwell.com";
	private final String OFFICIAL_EMAIL = "info@itingbaby.com";
	private final String ADV_EMAIL = "pr@itingbaby.com";
	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.img_app_logo)
	ImageView imgAppLogo;
	@BindView(R.id.txt_app_name)
	TextView txtAppName;
	@BindView(R.id.txt_app_version)
	TextView txtAppVersion;
	@BindView(R.id.txt_app_branch)
	TextView txtAppBranch;
	@BindView(R.id.about_wechat_public)
	CommonItem aboutWechatPublic;
	@BindView(R.id.about_contact_phone)
	CommonItem aboutContactPhone;
	@BindView(R.id.about_email)
	CommonItem aboutEmail;
	@BindView(R.id.about_official_website)
	CommonItem aboutOfficialWebsite;
	@BindView(R.id.about_adv)
	CommonItem aboutAdv;
	@BindView(R.id.company_name)
	TextView companyName;

	public static void navigate(Context context) {
		Intent intent = new Intent();
		intent.setClass(context, AboutActivity.class);
		context.startActivity(intent);
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_about);
		ButterKnife.bind(this);
		initView();
	}

	private void initView() {

		String versionName = BuildConfig.VERSION_NAME;
		txtAppVersion.setText("V".concat(versionName) + " - " + BuildConfig.GIT_COMMIT_SHA);
		txtAppBranch.setVisibility(BuildConfig.DEBUG ? View.VISIBLE : View.GONE);
		if (BuildConfig.DEBUG) {
			txtAppBranch.setText(BuildConfig.GIT_BRANCH);
		}

		aboutWechatPublic.setItemValue(getString(R.string.wechat_itingbaby));
		aboutContactPhone.setItemValue(TELEPHONE);
		aboutEmail.setItemValue(OFFICIAL_EMAIL);
		aboutOfficialWebsite.setItemValue(WEBSITE);
		aboutAdv.setItemValue(ADV_EMAIL);

		StatusBarUtil.StatusBarLightMode(this);

		titleBar.setLeftOnClickListener(v->{
			finish();
		});
		aboutWechatPublic.setOnLongClickListener(v->{
			copyValue(aboutWechatPublic);
			return false;
		});

		aboutContactPhone.setOnLongClickListener(v->{
			copyValue(aboutContactPhone);
			return false;
		});

		aboutEmail.setOnLongClickListener(v->{
			copyValue(aboutEmail);
			return false;
		});

		aboutOfficialWebsite.setOnLongClickListener(v->{
			copyValue(aboutOfficialWebsite);
			return false;
		});

		aboutAdv.setOnLongClickListener(v->{
			copyValue(aboutAdv);
			return false;
		});
	}

	private void copyValue(CommonItem item) {
		ClipboardManager cmb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
		ClipData clipData = ClipData.newPlainText(null,item.getItemValue().trim());
		cmb.setPrimaryClip(clipData);
		CommonToast.showShortToast("已复制到剪切板");
	}
}
