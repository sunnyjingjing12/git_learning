package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bigkoo.pickerview.builder.OptionsPickerBuilder;
import com.bigkoo.pickerview.listener.OnOptionsSelectListener;
import com.bigkoo.pickerview.view.OptionsPickerView;
import com.google.gson.Gson;
import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.components.IProfileSettingComponent;
import com.itingbaby.app.components.presenter.ProfileSettingPresenter;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.event.EventMusicDot;
import com.itingbaby.app.model.JsonBean;
import com.itingbaby.app.model.User;
import com.itingbaby.app.model.UserExtension;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.GetJsonDataUtil;
import com.itingbaby.app.utils.SharedPreferencesUtil;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class AddressActivity extends BaseFragmentActivity implements IProfileSettingComponent.IView {

	public static final String DIVIDER_CHARS = "##";

	public static final int FROM_TYPE_SETTING = 0;
	public static final int FROM_TYPE_APPLY_SD = 1;
	public static final int FROM_TYPE_OTHER = 2;

	public static final String KEY_FROM_TYPE = "key_from_type";

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.label_city)
	TextView labelCity;
	@BindView(R.id.text_city)
	TextView textCity;
	@BindView(R.id.divider_line_city)
	View dividerLineCity;
	@BindView(R.id.city_layout)
	RelativeLayout cityLayout;
	@BindView(R.id.label_address_detail)
	TextView labelAddressDetail;
	@BindView(R.id.edit_address_detail)
	EditText editAddressDetail;
	@BindView(R.id.img_clear_address_detail)
	ImageView imgClearAddressDetail;
	@BindView(R.id.divider_line_detail)
	View dividerLineDetail;
	@BindView(R.id.address_detail_layout)
	RelativeLayout addressDetailLayout;
	@BindView(R.id.label_name)
	TextView labelName;
	@BindView(R.id.name_edit_tv)
	EditText nameEditTv;
	@BindView(R.id.img_clear_name)
	ImageView imgClearName;
	@BindView(R.id.divider_line_name)
	View dividerLineName;
	@BindView(R.id.name_layout)
	RelativeLayout nameLayout;
	@BindView(R.id.label_phone)
	TextView labelPhone;
	@BindView(R.id.phone_edit_tv)
	EditText phoneEditTv;
	@BindView(R.id.img_clear_phone)
	ImageView imgClearPhone;
	@BindView(R.id.divider_line_phone)
	View dividerLinePhone;
	@BindView(R.id.phone_layout)
	RelativeLayout phoneLayout;
	@BindView(R.id.txt_address_tips)
	TextView txtAddressTips;


	private List<JsonBean> options1Items = new ArrayList<>();
	private ArrayList<ArrayList<String>> options2Items = new ArrayList<>();
	private ArrayList<ArrayList<ArrayList<String>>> options3Items = new ArrayList<>();

	private ProfileSettingPresenter mProfileSettingPresenter;
	private int mFromType = FROM_TYPE_SETTING;


	public static void navigate(Context context, int fromType) {
		Intent intent = new Intent();
		intent.setClass(context, AddressActivity.class);
		intent.putExtra(KEY_FROM_TYPE, fromType);
		context.startActivity(intent);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_address);
		ButterKnife.bind(this);
		initView();

		initListener();

		initData();

	}

	private void initView() {
		StatusBarUtil.StatusBarLightMode(this);
		mProfileSettingPresenter = new ProfileSettingPresenter(this);
	}

	private void initData() {

		initJsonData();

		Intent intent = getIntent();
		if (intent != null && intent.hasExtra(KEY_FROM_TYPE)) {
			mFromType = intent.getIntExtra(KEY_FROM_TYPE, FROM_TYPE_SETTING);
		}
		User user = BabyVoiceApp.mUserInfo;
		if (user != null) {
			nameEditTv.setText(user.realname);
			phoneEditTv.setText(user.getTelephoneNum());

			if(!StringUtils.isEmpty(user.address)){
				String[] addressArr = user.address.split(DIVIDER_CHARS);
				if (addressArr.length > 1) {
					textCity.setText(addressArr[0]);
					editAddressDetail.setText(addressArr[1]);
				}else {
					textCity.setText(addressArr[0]);
				}
			}
		}
		txtAddressTips.setVisibility(mFromType == FROM_TYPE_APPLY_SD ? View.VISIBLE : View.GONE);

	}


	private void initListener() {
		titleBar.setLeftOnClickListener(v -> {
			finish();
		});

		titleBar.setRightOnClickListener(v -> {
			// 保存
			validToSubmit();
		});


		imgClearAddressDetail.setOnClickListener(v -> {
			editAddressDetail.setText("");
		});

		imgClearName.setOnClickListener(v -> {
			nameEditTv.setText("");
		});

		imgClearPhone.setOnClickListener(v -> {
			phoneEditTv.setText("");
		});

		editAddressDetail.setOnFocusChangeListener((v, hasFocus) ->
				dividerLineDetail.setBackgroundColor(hasFocus ? getResources().getColor(R.color.color_00b8d0) : getResources().getColor(R.color.color_f5f5f5)));

		nameEditTv.setOnFocusChangeListener((v, hasFocus) ->
				dividerLineName.setBackgroundColor(hasFocus ? getResources().getColor(R.color.color_00b8d0) : getResources().getColor(R.color.color_f5f5f5)));

		phoneEditTv.setOnFocusChangeListener((v, hasFocus) ->
				dividerLinePhone.setBackgroundColor(hasFocus ? getResources().getColor(R.color.color_00b8d0) : getResources().getColor(R.color.color_f5f5f5)));

		cityLayout.setOnClickListener(v -> {
			showPickerView();
		});
	}


	/**
	 * 验证输入的信息
	 */
	private void validToSubmit() {
		String name = nameEditTv.getText().toString();
		String phone = phoneEditTv.getText().toString();
		String cityAddress = textCity.getText().toString();
		String detailAddress = editAddressDetail.getText().toString();
		if (StringUtils.isEmpty(name)) {
			CommonToast.showShortToast("收件人姓名为空");
		} else if (StringUtils.isEmpty(phone) || !StringUtils.checkPhoneNumber(phone)) {
			CommonToast.showShortToast("收件人手机号格式不正确");
		} else if (StringUtils.isEmpty(cityAddress)) {
			CommonToast.showShortToast("收件人省市区地址为空");
		} else if (StringUtils.isEmpty(detailAddress)) {
			CommonToast.showShortToast("收件人详细地址为空");
		} else {
			// 发送保存请求
			if (mProfileSettingPresenter != null) {
				showProgressDialog(null, true, null);
				User user = new User();
				long userId = BabyVoiceApp.mUserInfo.id;
				user.id = userId;
				user.realname = name;
				user.mobile = phone;
				user.address = cityAddress + DIVIDER_CHARS + detailAddress;
				mProfileSettingPresenter.updateProfile(user);

				updateUserExtension(userId);
			}
		}
	}


	private void showPickerView() {// 弹出选择器

		OptionsPickerView pvOptions = new OptionsPickerBuilder(this, new OnOptionsSelectListener() {
			@Override
			public void onOptionsSelect(int options1, int options2, int options3, View v) {
				//返回的分别是三个级别的选中位置
				String opt1tx = options1Items.size() > 0 ?
						options1Items.get(options1).getPickerViewText() : "";

				String opt2tx = options2Items.size() > 0
						&& options2Items.get(options1).size() > 0 ?
						options2Items.get(options1).get(options2) : "";

				String opt3tx = options2Items.size() > 0
						&& options3Items.get(options1).size() > 0
						&& options3Items.get(options1).get(options2).size() > 0 ?
						options3Items.get(options1).get(options2).get(options3) : "";

				String tx = opt1tx + opt2tx + opt3tx;
				textCity.setText(tx);
			}
		})

				.setTitleText("请选择城市")
				.setCancelColor(getResources().getColor(R.color.color_00bed7))
				.setSubmitColor(getResources().getColor(R.color.color_00bed7))
				.setDividerColor(Color.BLACK)
				.setTextColorCenter(Color.BLACK) //设置选中项文字颜色
				.setContentTextSize(18)
				.build();

		pvOptions.setPicker(options1Items, options2Items, options3Items);//三级选择器
		pvOptions.show();
	}

	private void initJsonData() {//解析数据

		/**
		 * 注意：assets 目录下的Json文件仅供参考，实际使用可自行替换文件
		 * 关键逻辑在于循环体
		 *
		 * */
		String JsonData = new GetJsonDataUtil().getJson(this, "province.json");//获取assets目录下的json文件数据

		ArrayList<JsonBean> jsonBean = parseData(JsonData);//用Gson 转成实体

		/**
		 * 添加省份数据
		 *
		 * 注意：如果是添加的JavaBean实体，则实体类需要实现 IPickerViewData 接口，
		 * PickerView会通过getPickerViewText方法获取字符串显示出来。
		 */
		options1Items = jsonBean;

		for (int i = 0; i < jsonBean.size(); i++) {//遍历省份
			ArrayList<String> cityList = new ArrayList<>();//该省的城市列表（第二级）
			ArrayList<ArrayList<String>> province_AreaList = new ArrayList<>();//该省的所有地区列表（第三极）

			for (int c = 0; c < jsonBean.get(i).getCityList().size(); c++) {//遍历该省份的所有城市
				String cityName = jsonBean.get(i).getCityList().get(c).getName();
				cityList.add(cityName);//添加城市
				ArrayList<String> city_AreaList = new ArrayList<>();//该城市的所有地区列表

				//如果无地区数据，建议添加空字符串，防止数据为null 导致三个选项长度不匹配造成崩溃
                /*if (jsonBean.get(i).getCityList().get(c).getArea() == null
                        || jsonBean.get(i).getCityList().get(c).getArea().size() == 0) {
                    city_AreaList.add("");
                } else {
                    city_AreaList.addAll(jsonBean.get(i).getCityList().get(c).getArea());
                }*/
				city_AreaList.addAll(jsonBean.get(i).getCityList().get(c).getArea());
				province_AreaList.add(city_AreaList);//添加该省所有地区数据
			}

			/**
			 * 添加城市数据
			 */
			options2Items.add(cityList);

			/**
			 * 添加地区数据
			 */
			options3Items.add(province_AreaList);
		}
	}


	private ArrayList<JsonBean> parseData(String result) {//Gson 解析
		ArrayList<JsonBean> detail = new ArrayList<>();
		try {
			JSONArray data = new JSONArray(result);
			Gson gson = new Gson();
			for (int i = 0; i < data.length(); i++) {
				JsonBean entity = gson.fromJson(data.optJSONObject(i).toString(), JsonBean.class);
				detail.add(entity);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return detail;
	}

	@Override
	public void updateAvatarSuccess(String substring) {

	}

	@Override
	public void updateProfileSuccess(User userInfo) {
		if (mFromType == FROM_TYPE_APPLY_SD) {
			CommonToast.showShortToast("提交成功, 客服会尽快联系您");
		} else {
			CommonToast.showShortToast("更新成功");
		}
		BabyVoiceApp.mUserInfo = userInfo;
		SharedPreferencesUtil.saveToPreferences(this, userInfo);
		dismissProgressDialog();

		EventBus.getDefault().post(new EventMusicDot());
		finish();
	}

	@Override
	public void handleFailed() {

	}

	@Override
	public void showToast(String msg) {
		CommonToast.showShortToast(msg);
	}


	/**
	 * 更新userExtension的值
	 *
	 * @param userId
	 */
	public void updateUserExtension(long userId) {
		// 登录时，需要先设置预产期
		ServiceGenerator.createService(ApiManager.class)
				.customVoice(userId)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(httpResponse -> {
					Ln.i("lihb", httpResponse.toString());
					if (ResponseCode.RESPONSE_OK == httpResponse.code) {
						User user = BabyVoiceApp.mUserInfo;
						UserExtension userExtension = user.userExtension;
						if (userExtension != null) {
							userExtension.custCount = httpResponse.data;
						}
						SharedPreferencesUtil.saveToPreferences(AddressActivity.this, user);
					} else {
						CommonToast.showShortToast(httpResponse.msg);
					}
				}, throwable -> {
					Ln.i(throwable.getMessage());
					CommonToast.showShortToast("修改UserExtension失败");
				});
	}

}
