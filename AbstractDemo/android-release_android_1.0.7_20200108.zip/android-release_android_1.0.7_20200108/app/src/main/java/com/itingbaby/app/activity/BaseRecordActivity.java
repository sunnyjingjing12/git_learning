package com.itingbaby.app.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.DataManager;
import com.itingbaby.app.R;
import com.itingbaby.app.customview.RecordingAndPlayVoiceView;
import com.itingbaby.app.customview.SearchingAudioView;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.app.model.AudioRecordModelDao;
import com.itingbaby.app.model.AudioType;
import com.itingbaby.app.model.DaoSession;
import com.itingbaby.app.utils.CobubConfigUtil;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.FileUtils;
import com.itingbaby.app.utils.FlagUtil;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.PermissionCheckUtil;
import com.itingbaby.baselib.commonutils.SVGAUtil;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.CommonDialog;
import com.itingbaby.dev.events.EventAudioRecordComplete;
import com.itingbaby.dev.events.EventAudioRecordDuration;
import com.itingbaby.dev.iTingBabyBleDeviceManager;
import com.opensource.svgaplayer.SVGAImageView;
import com.umeng.analytics.MobclickAgent;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * 录制的baseActivity
 * 只管
 */
public abstract class BaseRecordActivity extends BaseFragmentActivity {

	private static final String TAG = BaseRecordActivity.class.getSimpleName();

	protected static final String KEY_RECORD_TYPE = "key_record_type";
	public static final int MIN_RECORD_TIME = 15;  // 最短录制时长

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.bluetooth_signal_layout)
	LinearLayout bluetoothSignalLayout;
	@BindView(R.id.txt_record)
	TextView txtRecord;
	@BindView(R.id.txt_record_done)
	TextView txtRecordDone;
	@BindView(R.id.txt_record_again)
	TextView txtRecordAgain;
	@BindView(R.id.recording_and_play_view)
	RecordingAndPlayVoiceView recordingAndPlayVoiceView;
	@BindView(R.id.root_record_layout)
	ConstraintLayout rootRecordLayout;

	protected int mRecordType = AudioType.AUDIO_TYPE_BABY;

	protected boolean isSelectSave = false; // 保存文件flag，默认保存

	protected final int BYTE_RATE = iTingBabyBleDeviceManager.MY_SAMPLE_RATE *
			iTingBabyBleDeviceManager.NUM_CHANNELS *
			iTingBabyBleDeviceManager.BITS_PER_SAMPLE /
			iTingBabyBleDeviceManager.BITS_PER_BYTE;
	protected AudioRecordModelDao audioRecordModelDao;
	@BindView(R.id.svga_searching)
	SVGAImageView svgaSearching;
	@BindView(R.id.view_searching_audio)
	SearchingAudioView viewSearchingAudio;
	@BindView(R.id.txt_voice_effect_switch)
	TextView txtVoiceEffectSwitch;

	private CommonDialog exitDlg;

	protected int[] batteryIcons;

	private int[] rootBackgroundIds;

	private String[] titleStrArray;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		DaoSession daoSession = ((BabyVoiceApp) (getApplication())).getDaoSession();
		audioRecordModelDao = daoSession.getAudioRecordModelDao();
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_record);
		ButterKnife.bind(this);
		initView();
		initListener();
	}

	@Override
	protected void onResume() {
		super.onResume();
		updateRecordingUI();
		// 原声、降噪按钮ui
		boolean enable = iTingBabyBleDeviceManager.getInstance().getFIRFilterFlag();
		Ln.d("[filter] onResume =%b", enable);
		txtVoiceEffectSwitch.setText(enable ? "降噪" : "原声");

		if (!iTingBabyBleDeviceManager.getInstance().isRecording()) {
			if (!iTingBabyBleDeviceManager.getInstance().isComplete()) {// idle
				svgaSearching.setVisibility(View.VISIBLE);
				recordingAndPlayVoiceView.setVisibility(View.GONE);
				txtRecordAgain.setVisibility(View.GONE);
				SVGAUtil.loadSvgaAnimation(svgaSearching, "svga/searching.svga", true);
			} else {// 已完成最小化时录音
				showSaveFileDialog(false);
			}
		} else {
			recordingAndPlayVoiceView.setVisibility(View.VISIBLE);
			if (!iTingBabyBleDeviceManager.getInstance().isComplete()) {
				svgaSearching.setVisibility(View.GONE);
			} else {
				boolean connectFlag = iTingBabyBleDeviceManager.getInstance().isConnected();
				showSaveFileDialog(!connectFlag);
			}
		}
	}

	@Override
	protected void onPause() {
		super.onPause();
	}

	/**
	 * 物理返回按钮
	 *
	 * @param keyCode
	 * @param event
	 * @return
	 */
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if (iTingBabyBleDeviceManager.getInstance().isRecording()) {
				// 弹出退出弹窗
				showExitDialog();
			} else {
				finish();
			}
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	private void initView() {
		Intent intent = getIntent();
		if (intent.hasExtra(KEY_RECORD_TYPE)) {
			mRecordType = intent.getIntExtra(KEY_RECORD_TYPE, AudioType.AUDIO_TYPE_BABY);
		}
		batteryIcons = new int[]{R.drawable.ic_lowpower, R.drawable.ic_mediumpower, R.drawable.ic_highpower};
		rootBackgroundIds = new int[]{R.drawable.shape_01e2d3_00b8d0_bg, R.drawable.shape_ffafc9_ff87c8_bg, R.drawable.shape_b690ff_7986ff_bg};
		titleStrArray = getResources().getStringArray(R.array.voice_type);

		recordingAndPlayVoiceView.initSrcType(RecordingAndPlayVoiceView.TYPE_RECORDING_VOICE, iTingBabyBleDeviceManager.getInstance().getRecordDuration());
		recordingAndPlayVoiceView.updateRecordType(mRecordType);
		int index = FlagUtil.getFirstOneIndexFromBits(mRecordType);
		if (index >= 0) {
			rootRecordLayout.setBackgroundResource(rootBackgroundIds[index]);
			titleBar.setTitle(titleStrArray[index]);
		}
		renderRecordBtnTextColor();

	}

	private void initListener() {
		titleBar.setLeftOnClickListener(v -> {
			if (iTingBabyBleDeviceManager.getInstance().isRecording()) {
				// 弹出退出弹窗
				showExitDialog();
			} else {
				finish();
			}
		});
		titleBar.setRightOnClickListener(v -> {
			viewSearchingAudio.setAudioType(mRecordType);
			viewSearchingAudio.show();
		});

		// 开始录制
		txtRecord.setOnClickListener(v -> {
			checkPermission();
		});

		// 结束录制
		txtRecordDone.setOnClickListener(v -> {
			onBtnClickStopRecordVoice();
		});

		// 重新录制
		txtRecordAgain.setOnClickListener(v -> {
			onBtnClickRedo();
		});

		// 切换原生、降噪
		txtVoiceEffectSwitch.setOnClickListener(v -> {
			boolean enable = iTingBabyBleDeviceManager.getInstance().getFIRFilterFlag();
			Ln.d("[filter] click enable =%b", enable);
			iTingBabyBleDeviceManager.getInstance().enableFIRFilter(!enable);

			txtVoiceEffectSwitch.setText(!enable ? "降噪" : "原声");
		});
	}

	/**
	 * 检查权限
	 */
	private void checkPermission() {
		// 第 1 步: 检查是否有相应的权限

		boolean isAllGranted = PermissionCheckUtil.checkPermissionAllGranted(this,
				new String[]{
						Manifest.permission.READ_EXTERNAL_STORAGE,
						Manifest.permission.WRITE_EXTERNAL_STORAGE
				}
		);
		// 如果权限全都拥有, 则直接返回
		if (isAllGranted) {
			startRecordVoice();
			return;
		}


		// 第 2 步: 请求权限
		// 一次请求多个权限, 如果其他有权限是已经授予的将会自动忽略掉
		PermissionCheckUtil.requestPermission(this, new String[]{
				Manifest.permission.READ_EXTERNAL_STORAGE,
				Manifest.permission.WRITE_EXTERNAL_STORAGE
		});
	}


	/**
	 * 开始录制
	 */
	private void startRecordVoice() {
		onBtnClickStartRecordVoice();
		svgaSearching.stopAnimation(true);
		svgaSearching.setVisibility(View.GONE);
		recordingAndPlayVoiceView.setVisibility(View.VISIBLE);
		txtRecordAgain.setVisibility(View.VISIBLE);
	}


	/**
	 * 渲染3个录制按钮的文字颜色
	 */
	private void renderRecordBtnTextColor() {
		int color = (mRecordType == AudioType.AUDIO_TYPE_MOM || mRecordType == AudioType.AUDIO_TYPE_LUNG) ? R.color.color_ff87c8 : R.color.color_00bed7;
		txtRecord.setTextColor(getResources().getColor(color));
		txtRecordAgain.setTextColor(getResources().getColor(color));
		txtRecordDone.setTextColor(getResources().getColor(color));
		txtVoiceEffectSwitch.setTextColor(getResources().getColor(color));
	}


	// 用户点击开始录制按钮
	protected void onBtnClickStartRecordVoice() {
		audioRecordClickStarted();
		updateRecordingUI();
		// 打点
		postRecordBtnClickEvent(getString(R.string.txt_start));
	}

	// 用户点击录制完成按钮
	protected void onBtnClickStopRecordVoice() {
		//Ln.d("isTimeExpired = %b", isTimeExpired);
		if (iTingBabyBleDeviceManager.getInstance().getRecordDuration() < MIN_RECORD_TIME) {
			CommonToast.showShortToast(R.string.txt_min_record_time);
		} else {
			audioRecordClickEnded();
			updateRecordingUI();

			showSaveFileDialog(false);

			// 打点
			postRecordBtnClickEvent(getString(R.string.title_complete));
		}
	}

	// 用户点击重录按钮
	protected void onBtnClickRedo() {
		// 只有录制中，点了才有反应
		if (iTingBabyBleDeviceManager.getInstance().isRecording()) {
			audioReRecord();
			updateRecordingUI();
		}
	}

	/**
	 * 更新 录制 和 完成 两个按钮
	 */
	private void updateRecordingUI() {
		boolean recording = iTingBabyBleDeviceManager.getInstance().isRecording();
		txtRecord.setVisibility(recording ? View.INVISIBLE : View.VISIBLE);
		txtRecordDone.setVisibility(recording ? View.VISIBLE : View.GONE);
		if (recording) {
			int duration = iTingBabyBleDeviceManager.getInstance().getRecordDuration();
			recordingAndPlayVoiceView.onRecordDurationEvent(new EventAudioRecordDuration(duration));
		} else {
			recordingAndPlayVoiceView.onRecordDurationEvent(null);
		}
	}


	/**
	 * 退出弹窗
	 */
	private void showExitDialog() {
		exitDlg = CommonDialog.createDialog(this)
				.setTitleText(getString(R.string.title_tips))
				.setText(getString(R.string.exit_record_tips))
				.setLeftButtonText(getString(R.string.profile_exit))
				.setRightButtonText(getString(R.string.minmum_tips))
				.setRightButtonAction(v -> {// 最小化操作
//					NewMainActivity.navigate(this);
					finish();
					// 最小化时，保存此次录音类型
					DataManager.getInstance().setCurRecordType(mRecordType);

				})
				.setLeftButtonAction(v -> {// 退出操作
					iTingBabyBleDeviceManager.getInstance().stopSaveToLocal();
					if (isSelectSave) {
						// 弹出保存文件弹窗
						showSaveFileDialog(true);
					} else {
						// 删除此次文件，完全退出录音页面
						deleteRecordFile();
						iTingBabyBleDeviceManager.getInstance().resetComplete();
//						NewMainActivity.navigate(this);
						finish();
					}
				})
				.setCloseOnTouchOutside(true)
				.setCancelable(true);

		if (iTingBabyBleDeviceManager.getInstance().getRecordDuration() >= MIN_RECORD_TIME) {
			isSelectSave = true;
			exitDlg.setTipsText(getString(R.string.exit_save_file_tips))
					.setIconVisible(CommonDialog.Visible.Show)
					.setIconButtonAction(v -> {
						isSelectSave = !isSelectSave;
					});
		} else {
			isSelectSave = false;
		}

		exitDlg.show();
	}

	// 保存文件弹窗
	private void showSaveFileDialog(boolean isQuit) {
		String oldFileName = iTingBabyBleDeviceManager.getInstance().getRecordFileName();
		CommonDialog dialog = CommonDialog.createDialog(this)
				.setTitleText(getString(R.string.voice_save))
				.setEditText(oldFileName)
				.setEditHint(R.string.txt_input_file_name)
				.setLeftButtonText(getString(R.string.btn_txt_cancel))
				.setLeftButtonAction(v -> {
					deleteRecordFile();
					if (isQuit) {
						finish();
//						NewMainActivity.navigate(this);
					}
				})
				.setRightButtonText(getString(R.string.btn_txt_confirm))
				.setCloseOnTouchOutside(false)
				.setCancelable(false);

		dialog.setRightButtonAction(v -> {
			String newFileName = dialog.getEditText().trim();
			if (StringUtils.isEmpty(newFileName)) {
				CommonToast.showShortToast("文件名称不能为空");
				return;
			}
			if (newFileName.contains(".")) {
				newFileName = newFileName.substring(0, newFileName.indexOf("."));
			}

			String newFilePath = FileUtils.getVoiceFilePath(newFileName);
			String oldFilePath = FileUtils.getVoiceFilePath(oldFileName);
			FileUtils.renameFile(oldFilePath, newFilePath);
			iTingBabyBleDeviceManager.getInstance().setRecordFileName(newFileName);
			CommonToast.showShortToast(getString(R.string.save_success_tips));
			// 保存到本地数据库
			saveToDatabase(newFileName);
			if (isQuit) {
				finish();
//				NewMainActivity.navigate(this);
			}
		});

		dialog.show();
		iTingBabyBleDeviceManager.getInstance().resetComplete();
	}


	/**
	 * 本地删除此次录音文件
	 */
	private void deleteRecordFile() {
		String recordFilePath = FileUtils.getRecordDir() + iTingBabyBleDeviceManager.getInstance().getRecordFileName();
		File file = new File(recordFilePath);
		if (file.exists()) {
			file.delete();
		}
		iTingBabyBleDeviceManager.getInstance().setStateIdle();
	}

	// 保存录音记录到本地
	private void saveToDatabase(String newFileName) {
		AudioRecordModel audioRecordModel = new AudioRecordModel();
		audioRecordModel.setUid(BabyVoiceApp.mUserInfo.id);
		audioRecordModel.setName(newFileName);
		audioRecordModel.setType(mRecordType);
		audioRecordModel.setUrl(FileUtils.getRecordDir() + newFileName);
		// 计算文件时长
		int totalSize = 0;
		String fullFilePath = FileUtils.getRecordDir() + newFileName;
		try {
			FileInputStream fileInputStream = new FileInputStream(fullFilePath);
			totalSize = fileInputStream.available();
		} catch (FileNotFoundException e) {
			Log.e(TAG, e.getMessage());
		} catch (IOException e) {
			Log.e(TAG, e.getMessage());
		}
		int duration = FileUtils.getPcmDuration(totalSize, BYTE_RATE);
		audioRecordModel.setDuration(duration);

		audioRecordModel.setTimestamp(System.currentTimeMillis() / 1000);
		audioRecordModelDao.insertOrReplaceInTx(audioRecordModel);
		iTingBabyBleDeviceManager.getInstance().setStateIdle();
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == PermissionCheckUtil.REQUEST_PERMISSION) {
			boolean isAllGranted = true;

			// 判断是否所有的权限都已经授予了
			for (int grant : grantResults) {
				if (grant != PackageManager.PERMISSION_GRANTED) {
					isAllGranted = false;
					break;
				}
			}
			if (isAllGranted) {
				// 如果所有的权限都授予了, 则开始录音
				startRecordVoice();

			} else {
				// 弹出对话框告诉用户需要权限的原因, 并引导用户去应用权限管理中手动打开权限按钮
				PermissionCheckUtil.showGrantFailDialog(this);
			}
		}
	}


	//region 抽象函数

	// 录制开始
	protected abstract void audioRecordClickStarted();

	// 录制结束
	protected abstract void audioRecordClickEnded();

	// 重录
	protected abstract void audioReRecord();

	// 录制超过允许的最大时间
	protected abstract void audioRecordTimeOvered();

	//endregion


	/**
	 * 设备连接成功上报打点
	 */
	private void postRecordBtnClickEvent(String clickType) {
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("clickType", clickType);
		MobclickAgent.onEvent(this, CobubConfigUtil.EVENT_RECORD_BTN_CLICKED, map);
	}

	// region EventBus事件

	// 录音完成事件
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onAudioRecordComplete(EventAudioRecordComplete event) {
		int state = event.getState();
		if (EventAudioRecordComplete.STATE_NORMAL == state) {
			updateRecordingUI();
			if (null != exitDlg) {
				exitDlg.dismiss();
				exitDlg = null;
			}

			showSaveFileDialog(false);
		} else if (EventAudioRecordComplete.STATE_DISCONNECT == state) {
			dismissProgressDialog();
			showSaveFileDialog(true);
		} else {
			Ln.e("未知录音完成状态");
		}
	}

	// endregion EventBus事件
}
