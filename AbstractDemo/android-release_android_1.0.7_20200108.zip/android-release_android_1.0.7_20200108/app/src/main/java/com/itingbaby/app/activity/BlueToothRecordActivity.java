package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.itingbaby.app.Constant;
import com.itingbaby.app.R;
import com.itingbaby.app.model.AudioType;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.FileUtils;
import com.itingbaby.app.utils.FlagUtil;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.dev.events.EventAudioData;
import com.itingbaby.dev.events.EventBleDeviceBatteryInfo;
import com.itingbaby.dev.events.EventBleDeviceConnectStatus;
import com.itingbaby.dev.events.EventBleDeviceHeartRate;
import com.itingbaby.dev.events.EventBleDeviceRssi;
import com.itingbaby.dev.events.EventBleDeviceStatus;
import com.itingbaby.dev.iTingBabyBleDeviceManager;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class BlueToothRecordActivity extends BaseRecordActivity {

	private static final String TAG = "iTingBaby";

	// 静态常量
	private static final int LOW_SIGNAL = -100;  // 待定
	private static final int DEVICE_STATUS_CHARGING = -1;// 设备充电状态


	public static void navigate(Context context, int recordType) {
		Intent intent = new Intent();
		intent.putExtra(KEY_RECORD_TYPE, recordType);
		intent.setClass(context, BlueToothRecordActivity.class);
		context.startActivity(intent);
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// 设置最大录制时长
		setMaxDurationTime();
		EventBus.getDefault().register(this);
	}


	@Override
	protected void onDestroy() {
		if (!iTingBabyBleDeviceManager.getInstance().isRecording()) {
			// 非录制状态就干掉实时AudioTrack
			iTingBabyBleDeviceManager.getInstance().disconnect();
		}
		EventBus.getDefault().unregister(this);
		super.onDestroy();
	}

	private void setMaxDurationTime() {
		int maxDuration = 60;
		if (mRecordType == AudioType.AUDIO_TYPE_BABY) {
			maxDuration = Constant.TYPE_HEART_TIME;
		}else if (mRecordType == AudioType.AUDIO_TYPE_MOM){
			maxDuration = Constant.TYPE_MOM_TIME;
		}
		else if (mRecordType == AudioType.AUDIO_TYPE_LUNG){
			maxDuration = Constant.TYPE_LUNG_TIME;
		}
		iTingBabyBleDeviceManager.getInstance().setRecordTimeout(maxDuration);
	}

	@Override
	protected void audioRecordClickStarted() {
		String[] items = getResources().getStringArray(R.array.voice_type);
		String fileName = items[FlagUtil.getFirstOneIndexFromBits(mRecordType)] + new SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault()).format(new Date())/* + Constant.FILE_WAV_SUFFIX*/;// 取消.wav后缀
		iTingBabyBleDeviceManager.getInstance().setRecordFileName(fileName);
		String recordFilePath = FileUtils.getRecordDir() + fileName;

		iTingBabyBleDeviceManager.getInstance().startSaveToLocal(recordFilePath);
	}

	@Override
	protected void audioRecordClickEnded() {
		iTingBabyBleDeviceManager.getInstance().stopSaveToLocal();
//		FileUtils.scanFile(this, Constant.DATA_DIRECTORY);
	}

	@Override
	protected void audioRecordTimeOvered() {
		iTingBabyBleDeviceManager.getInstance().stopSaveToLocal();
//		FileUtils.scanFile(this, Constant.DATA_DIRECTORY);
	}

	@Override
	protected void audioReRecord() {
		iTingBabyBleDeviceManager.getInstance().stopSaveToLocal();
		iTingBabyBleDeviceManager.getInstance().resetComplete();
	}

	// region EventBus事件

	// BLE设备连接状态
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onBleDeviceConnectionStatus(EventBleDeviceConnectStatus event) {
		Ln.d("lihb " + event.toString());
		int status = event.getStatus();
		if (EventBleDeviceConnectStatus.CONNECTION_STATUS_CONNECTING == status) {
			showProgressDialog(getString(R.string.txt_ble_connecting), true, () -> {
				iTingBabyBleDeviceManager.getInstance().disconnect();
			});
		} else if (EventBleDeviceConnectStatus.CONNECTION_STATUS_CONNECTED == status) {
			dismissProgressDialog();
		} else if (EventBleDeviceConnectStatus.CONNECTION_STATUS_DISCONNECTED == status) {
			dismissProgressDialog();
			finish();
//			CommonDialog.createDialog(this)
//				.setTitleText(getString(R.string.title_tips))
//				.setText(getResources().getString(R.string.txt_ble_disconnect))
//				.setIconVisible(CommonDialog.Visible.Gone)
//				.setLeftButtonText(getString(R.string.btn_txt_cancel))
//				.setLeftButtonAction(v->{
//					finish();
//				})
//				.setRightButtonText(getString(R.string.btn_txt_reconnect))
//				.setRightButtonAction(v->{
//					iTingBabyBleDeviceManager.getInstance().reconnect();
//				})
//				.setCloseOnTouchOutside(true)
//				.setCancelable(true)
//				.show();
			CommonToast.showLongToast(getString(R.string.txt_ble_disconnect));
		}
	}

	// BLE设备rssi事件
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onBleDeviceRssi(EventBleDeviceRssi event) {
		bluetoothSignalLayout.setVisibility(event.getRssi() < LOW_SIGNAL ? View.VISIBLE : View.GONE);
	}

	// BLE设备状态信息事件
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onBleDeviceStatus(EventBleDeviceStatus event) {
		Ln.i(event.toString());
	}

	// BLE电量信息事件
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onBleDeviceBatteryInfo(EventBleDeviceBatteryInfo event) {
		Ln.i(event.toString());
		int percent = event.getLeftPercent();

		int index = Math.min(percent / 34, batteryIcons.length - 1);
		titleBar.setSecondRightDrawable(getResources().getDrawable(batteryIcons[index]));
	}

	// BLE心率事件
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onBleDeviceHeartRate(EventBleDeviceHeartRate event) {
		recordingAndPlayVoiceView.updateHeartRatio(event.getHeartRate());
	}

	// BLE音频数据推送事件(实时性不是十分好，仅用作刷新)
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onBleDeviceAudioData(EventAudioData event) {
		recordingAndPlayVoiceView.updateAudioData(event.getData());
	}

	// endregion eventbus事件

	// 测试相关
//    private int totalBytesPerSec;// 统计每秒收的数据
//    private Timer timerBytesPerSec;
//    private void test_receive_speed() {
//        timerBytesPerSec = new Timer();
//        timerBytesPerSec.schedule(new TimerTask() {
//            @Override
//            public void run() {
//                Log.e(TAG, "每秒收到的数据：" + totalBytesPerSec);
//                totalBytesPerSec = 0;
//            }
//        }, 1000, 1000);
//    }
//    private void test_send_signal() {
//        byte[] data = StringUtils.shortArrayToByteArray(testShortData);
//        Log.e(TAG, "转换后的字节数组" + StringUtils.bytesToHexString(data));
//
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                while (true) {
//                    audioTrack.write(data, 0, data.length);
//                    audioTrack.flush();
//                    try {
//                        Thread.sleep(5);
//                    } catch (InterruptedException e) {
//                        Log.e(TAG, e.getMessage());
//                    }
//                }
//            }
//        }).start();
//    }
}
