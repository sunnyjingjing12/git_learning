package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.itingbaby.app.R;
import com.itingbaby.app.customview.CardiographView;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.dev.events.EventBleDeviceBatteryInfo;
import com.itingbaby.dev.events.EventBleDeviceConnectStatus;
import com.itingbaby.dev.events.EventBleDeviceRssi;
import com.itingbaby.dev.events.EventBleDeviceStatus;
import com.itingbaby.dev.events.EventEhgData;
import com.itingbaby.dev.iTingBabyBleDeviceManager;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

/**
 * 示波器页面
 */
public class CardiographActivity extends BaseFragmentActivity {

	private final String TAG = CardiographActivity.class.getSimpleName();

	private EditText editText;
	private Button btnSet;
	private Button btnClear;
	//private ZoomControls zctlX;// 调整纵线间距
	//private ZoomControls zctlY;// 调整横线间距

	private CardiographView cv0;
	private CardiographView cv1;
	private CardiographView cv2;
	private CardiographView cv3;


	public static void navigate(Context context) {
		Intent intent = new Intent();
		//intent.putExtra("recordType", recordType);
		//intent.putExtra(KEY_DATA, bleDevice);
		intent.setClass(context, CardiographActivity.class);
		context.startActivity(intent);
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_cls_oscilloscope);

		initViews();
		//getWidthHeight();

		EventBus.getDefault().register(this);
	}

	@Override
	protected void onDestroy() {
		iTingBabyBleDeviceManager.getInstance().disconnect();
		EventBus.getDefault().unregister(this);
		super.onDestroy();
	}

	private void initViews() {
		editText = findViewById(R.id.edit_txt_sample_rate);
		btnSet = findViewById(R.id.btn_ctl);
		btnClear = findViewById(R.id.btn_clear);
		//zctlX = findViewById(R.id.zoom_ctl_x);
		//zctlY = findViewById(R.id.zoom_ctl_y);
		cv0 = findViewById(R.id.layout_chart0);
		cv1 = findViewById(R.id.layout_chart1);
		cv2 = findViewById(R.id.layout_chart2);
		cv3 = findViewById(R.id.layout_chart3);

		cv0.setTitle("ch0");
		cv1.setTitle("ch1");
		cv2.setTitle("ch2");
		cv3.setTitle("ch3");

		initListeners();
		//initZoomCtls();
	}

	private void initListeners() {
		btnSet.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if ("开始".equals(btnSet.getText())) {

					//startTestTimer();

					btnSet.setText("停止");
					cv0.startRefresh();
					cv1.startRefresh();
					cv2.startRefresh();
					cv3.startRefresh();

				} else if ("停止".equals(btnSet.getText())) {

					//stopTestTimer();

					btnSet.setText("开始");
					cv0.stopRefresh();
					cv1.stopRefresh();
					cv2.stopRefresh();
					cv3.stopRefresh();

				}
			}
		});
		btnClear.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				cv0.clear();
				cv1.clear();
				cv2.clear();
				cv3.clear();
			}
		});
	}

//    private void initZoomCtls() {
//        zctlX.setOnZoomInClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//            }
//        });
//        zctlX.setOnZoomOutClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//            }
//        });
//        zctlY.setOnZoomInClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//            }
//        });
//        zctlY.setOnZoomOutClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//            }
//        });
//    }

//    private void getWidthHeight() {
//        WindowManager wm = (WindowManager) this.getSystemService(Context.WINDOW_SERVICE);
//        DisplayMetrics dm = new DisplayMetrics();
//        wm.getDefaultDisplay().getMetrics(dm);
//        float width = dm.widthPixels;         // 屏幕宽度（像素）
//        float height = dm.heightPixels;       // 屏幕高度（像素）
//        float density = dm.density;         // 屏幕密度（0.75 / 1.0 / 1.5）
//        int densityDpi = dm.densityDpi;     // 屏幕密度dpi（120 / 160 / 240）
//        // 屏幕宽度算法:屏幕宽度（像素）/ 屏幕密度
//        float screenWidth = width / density;  // 屏幕宽度(dp)
//        float screenHeight = height / density;// 屏幕高度(dp)
//    }

	// region EventBus事件

	// BLE设备连接状态
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onBleDeviceConnectionStatus(EventBleDeviceConnectStatus event) {
		int status = event.getStatus();
		if (EventBleDeviceConnectStatus.CONNECTION_STATUS_CONNECTING == status) {
			showProgressDialog(getString(R.string.txt_ble_connecting), true, () -> {
				iTingBabyBleDeviceManager.getInstance().disconnect();
			});
		} else if (EventBleDeviceConnectStatus.CONNECTION_STATUS_CONNECTED == status) {
			dismissProgressDialog();
		} else if (EventBleDeviceConnectStatus.CONNECTION_STATUS_DISCONNECTED == status) {
			dismissProgressDialog();
			finish();
//			CommonDialog.createDialog(this)
//				.setTitleText(getString(R.string.title_tips))
//				.setText(getResources().getString(R.string.txt_ble_disconnect))
//				.setIconVisible(CommonDialog.Visible.Gone)
//				.setLeftButtonText(getString(R.string.btn_txt_cancel))
//				.setLeftButtonAction(v->{
//					finish();
//				})
//				.setRightButtonText(getString(R.string.btn_txt_reconnect))
//				.setRightButtonAction(v->{
//					iTingBabyBleDeviceManager.getInstance().reconnect();
//				})
//				.setCloseOnTouchOutside(true)
//				.setCancelable(true)
//				.show();
			CommonToast.showLongToast(getString(R.string.txt_ble_disconnect));
		}
	}

	// BLE设备rssi事件
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onBleDeviceRssi(EventBleDeviceRssi event) {
//		bluetoothSignalLayout.setVisibility(event.getRssi() < LOW_SIGNAL ? View.VISIBLE : View.GONE);
	}

	// BLE设备状态信息事件
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onBleDeviceStatus(EventBleDeviceStatus event) {
		Ln.i(event.toString());
	}

	// BLE电量信息事件
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onBleDeviceBatteryInfo(EventBleDeviceBatteryInfo event) {
		int percent = event.getLeftPercent();

//		int index = Math.min(percent / 34, batteryIcons.length - 1);
//		titleBar.setSecondRightDrawable(getResources().getDrawable(batteryIcons[index]));
	}

	// EHG实时数据推送
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onEhgRTData(EventEhgData event) {
		cv0.updateData(event.getChannelData0());
		cv1.updateData(event.getChannelData1());
		cv2.updateData(event.getChannelData2());
		cv3.updateData(event.getChannelData3());
	}

	// endregion EventBus事件

	// region 测试
/*
	private int pointCount = 0;
	private void updateXByAxis(float[] data) {
		for (float y : data) {
			series.add(pointInterval * pointCount++, y);
		}
		if (pointScreen > pointCount) {
			renderer.setXAxisMin(0);
			renderer.setXAxisMax(X_AXIS_AVERAGE);
		} else {
			int secInterval = series.getItemCount() - pointScreen;
			double offsetX = secInterval * pointInterval;
			renderer.setXAxisMin(offsetX);
			renderer.setXAxisMax(series.getItemCount() * pointInterval);
		}
		chart.postInvalidate();
	}
*/

/*
	private final float[] EHG_TEST_SIN_DATA = {
			(float)0.000000, (float)1.294041, (float)2.499962, (float)3.535367,
			(float)4.329873, (float)4.829407, (float)4.999924, (float)4.829407,
			(float)4.329873, (float)3.535367, (float)2.499962, (float)1.294041,
			(float)0.000000, (float)-1.294041, (float)-2.499962, (float)-3.535367,
			(float)-4.329873, (float)-4.829407, (float)-4.999924, (float)-4.829407,
			(float)-4.329873, (float)-3.535367, (float)-2.499962, (float)-1.294041,
	};
	private final float[] EHG_TEST_SIN_DATA1 = {
			(float)0.000000, (float)0.000000, (float)0.000000, (float)0.000000,
			(float)0.000000, (float)0.000000, (float)0.000000, (float)0.000000,
			(float)0.000000, (float)0.000000, (float)0.000000, (float)0.000000,
			(float)0.000000, (float)0.000000, (float)0.000000, (float)0.000000,
			(float)0.000000, (float)0.000000, (float)0.000000, (float)0.000000,
			(float)0.000000, (float)0.000000, (float)0.000000, (float)0.000000,

			(float)0.000000, (float)0.000000, (float)0.000000, (float)0.000000,
			(float)0.000000, (float)0.000000, (float)0.000000, (float)0.000000,
			(float)0.000000, (float)0.000000, (float)0.000000, (float)0.000000,
			(float)0.000000, (float)0.000000, (float)0.000000, (float)0.000000,
			(float)0.000000, (float)0.000000, (float)0.000000, (float)0.000000,
			(float)0.000000, (float)0.000000, (float)0.000000, (float)0.000000,
	};

	private Timer testTimer;
	private boolean flag;
	private void startTestTimer() {
		if (null == testTimer) {
			testTimer = new Timer();
			TimerTask task = new TimerTask() {
				@Override
				public void run() {
					if (!flag) {
						updateData(EHG_TEST_SIN_DATA);
					} else {
						updateData(EHG_TEST_SIN_DATA1);
					}
					flag = !flag;
				}
			};
			testTimer = new Timer();
			// 计算定时加入测试数据的时间间隔
			int count = sampleRate / EHG_TEST_SIN_DATA.length;
			long freq = 1000 / count;
			testTimer.schedule(task, 0, freq);
		}
	}

	private void stopTestTimer() {
		if (null != testTimer) {
			testTimer.cancel();
			testTimer = null;
		}
	}
*/
	// endregion 测试
}
