package com.itingbaby.app.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Process;

import com.itingbaby.app.R;
import com.itingbaby.app.customview.CommonItem;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.upgrade.UpgradeService;
import com.itingbaby.app.utils.SharedPreferencesUtil;
import com.itingbaby.baselib.commonutils.ApplicationUtils;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;

import butterknife.BindView;
import butterknife.ButterKnife;

public class DebugSettingActivity extends BaseFragmentActivity {


	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.item_change_server)
	CommonItem itemChangeServer;
	@BindView(R.id.item_manufacture)
	CommonItem itemManufacture;
	@BindView(R.id.item_firmware_upgrade)
	CommonItem itemFirmwareUpgrade;
	@BindView(R.id.item_lsdev)
	CommonItem itemLSDev;


	public static void navigate(Context context) {
		Intent intent = new Intent();
		intent.setClass(context, DebugSettingActivity.class);
		context.startActivity(intent);
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_debug_setting);
		ButterKnife.bind(this);

		initView();
		initListener();
	}

	private void initView() {
		StatusBarUtil.StatusBarLightMode(this);
		itemChangeServer.setItemValue(SharedPreferencesUtil.getCurrentServerURL(this));
	}

	private void initListener() {
		titleBar.setLeftOnClickListener(v -> {
			finish();
		});

		// 切换服务器
		itemChangeServer.setOnClickListener(v -> {
			// 弹出选择服务器弹窗
			showPickupServerDialog();
		});

		// 设备出厂改名
		itemManufacture.setOnClickListener(v -> {
			ManufactureActivity.navigate(this, ManufactureActivity.MANUFACTURE_TYPE_RENAME);
		});

		// 听贝贝固件升级
		itemFirmwareUpgrade.setOnClickListener(v -> {
			ManufactureActivity.navigate(this, ManufactureActivity.MANUFACTURE_TYPE_FIRMWARE_UPGRADE);
		});

		// 测试训练仪
		itemLSDev.setOnClickListener(v -> {
			TestActivity.navigate(this);
		});
	}

	private void showPickupServerDialog() {
		int checkItem = 0;

		String[] stringArray = getResources().getStringArray(R.array.server_address);
		for (int i = 0; i < stringArray.length; i++) {
			if (StringUtils.areEqual(itemChangeServer.getItemValue(), stringArray[i])) {
				checkItem = i;
				break;
			}
		}

		AlertDialog.Builder alert = new AlertDialog.Builder(this);
		alert.setTitle("切换环境")
				.setSingleChoiceItems(stringArray, checkItem, (dialog, which) -> {
					changeServer(stringArray[which]);
				});
		alert.create();
		alert.show();

	}

	private void changeServer(String serverUrl) {
		SharedPreferencesUtil.setCurrentServerURL(this, serverUrl);

		ApplicationUtils.mMainHandler.postDelayed(() -> {
			stopService(new Intent(DebugSettingActivity.this, UpgradeService.class));
			Intent intent = new Intent(DebugSettingActivity.this, EntryPointActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent);
			Process.killProcess(Process.myPid());
		},500);
	}
}
