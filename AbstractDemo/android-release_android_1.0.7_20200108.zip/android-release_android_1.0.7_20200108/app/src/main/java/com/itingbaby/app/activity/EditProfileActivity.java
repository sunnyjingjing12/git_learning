package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.User;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.SharedPreferencesUtil;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.CommonDialog;
import com.itingbaby.baselib.views.widget.FixBytesEditText;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class EditProfileActivity extends BaseFragmentActivity {


	public static final String KEY_EDIT_CONTENT = "edit_content";
	public static final String KEY_EDIT_TYPE = "edit_type";

	public static final int KEY_NICKNAME = 1000;
	public static final int KEY_QQ = 1001;
	public static final int KEY_EMAIL = 1002;
	public static final int KEY_MOBILE_PHONE = 1003;
	public static final int KEY_ADDRESS = 1004;
	public static final int KEY_REAL_NAME = 1005;
	public static final int KEY_SEX = 1006;
	public static final int KEY_WEIGHT = 1007;


	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.edit_content)
	FixBytesEditText editContent;

	private String mPreContent;
	private int mEditType;
	private User user;

	public static Intent intentFor(Context context, String content, int editType) {
		Intent intent = new Intent();
		intent.putExtra(KEY_EDIT_CONTENT, content);
		intent.putExtra(KEY_EDIT_TYPE, editType);
		intent.setClass(context, EditProfileActivity.class);
		return intent;
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_edit_profile);
		ButterKnife.bind(this);
		initData();
		initView();
		initListener();
	}

	private void initView() {
		StatusBarUtil.StatusBarLightMode(this);
		editContent.setText(mPreContent);
		initTitle();
	}


	private void initData() {
		Intent intent = getIntent();
		if (intent != null) {
			if (intent.hasExtra(KEY_EDIT_CONTENT)) {
				mPreContent = intent.getStringExtra(KEY_EDIT_CONTENT);
			}
			if (intent.hasExtra(KEY_EDIT_TYPE)) {
				mEditType = intent.getIntExtra(KEY_EDIT_TYPE, KEY_NICKNAME);
			}
		}
	}

	@Override
	public void onBackPressed() {
		if (!StringUtils.areEqual(editContent.getText().toString(), mPreContent)) {
			// 弹出确认放弃弹窗
			showExitEditDialog();
		} else {
			finish();
		}
	}

	private void initListener() {

		titleBar.setLeftOnClickListener(v -> {
			onBackPressed();
		});

		titleBar.setRightOnClickListener(v -> {
			if (checkEditContent(editContent.getText().toString())) {
				showProgressDialog(null, true, null);
				sendUpdateUserInfoRequest();
			}

		});
	}

	private void initTitle() {
		switch (mEditType) {
			case KEY_NICKNAME:
				titleBar.setTitle("修改昵称");
				break;
			case KEY_QQ:
				titleBar.setTitle("修改QQ号");
				break;
			case KEY_EMAIL:
				titleBar.setTitle("修改邮箱");
				break;
			case KEY_MOBILE_PHONE:
				titleBar.setTitle("修改手机号");
				break;
			case KEY_REAL_NAME:
				titleBar.setTitle("修改名字");
				break;
			case KEY_ADDRESS:
				titleBar.setTitle("修改地址");
				break;
			case KEY_SEX:
				titleBar.setTitle("修改性别");
				break;
			case KEY_WEIGHT:
				titleBar.setTitle("修改体重");
				break;
		}
	}

	private boolean checkEditContent(String content) {
		user = new User();
		user.id = BabyVoiceApp.mUserInfo.id;
		boolean isValid = true;
		switch (mEditType) {
			case KEY_NICKNAME:
				isValid = true;
				user.nickname = content;
				break;
			case KEY_QQ:
				if (!StringUtils.checkPureNumer(content)) {
					CommonToast.showShortToast("QQ号格式不正确");
					isValid = false;
				} else {
					user.qq = content;
				}
				break;
			case KEY_EMAIL:
				if (!StringUtils.checkMail(content)) {
					CommonToast.showShortToast("邮箱号格式不正确");
					isValid = false;
				} else {
					user.email = content;
				}
				break;
			case KEY_MOBILE_PHONE:
				if (!StringUtils.checkPhoneNumber(content)) {
					CommonToast.showShortToast("手机号格式不正确");
					isValid = false;
				} else {
					user.mobile = content;
				}
				break;
			case KEY_REAL_NAME:
				isValid = true;
				user.realname = content;
				break;
			case KEY_ADDRESS:
				isValid = true;
				user.address = content;
				break;
			case KEY_SEX:
				isValid = true;
				if (StringUtils.areEqual(getString(R.string.txt_gender_male), content.trim())){
					user.gender = 1;
				} else if (StringUtils.areEqual(getString(R.string.txt_gender_female), content.trim())) {
					user.gender = 2;
				} else {
					CommonToast.showShortToast("性别不正确");
					isValid = false;
				}

				break;
			case KEY_WEIGHT:
				try {
					int weight = Integer.valueOf(content);
					if (StringUtils.checkUserWeight(weight)) {
						user.weight = weight;
					} else {
						CommonToast.showShortToast("体重值不正确");
						isValid = false;
					}
				} catch (Exception e) {
					CommonToast.showShortToast("体重值不正确");
					isValid = false;
				}


				break;
		}
		return isValid;
	}

	/**
	 * 显示退出编辑的弹窗
	 */
	private void showExitEditDialog() {
		CommonDialog.createDialog(this)
				.setTitleText(getString(R.string.txt_exit_edit))
				.setText(getString(R.string.txt_not_save_tips))
				.setIconVisible(CommonDialog.Visible.Gone)
				.setLeftButtonText(getString(R.string.btn_txt_cancel))
				.setRightButtonText(getString(R.string.btn_txt_confirm))
				.setRightButtonAction(which -> {
					finish();
				})
				.setCancelable(true)
				.show();
	}

	/**
	 * 更新个人信息
	 *
	 */
	private void sendUpdateUserInfoRequest() {
		ServiceGenerator.createService(ApiManager.class)
				.updateUserInfo(user)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(httpResponse -> {
					Ln.i("lihb", httpResponse.toString());
					dismissProgressDialog();
					if (ResponseCode.RESPONSE_OK == httpResponse.code) {
						// 成功
						CommonToast.showShortToast("更新成功");

						BabyVoiceApp.mUserInfo = httpResponse.data;
						SharedPreferencesUtil.saveToPreferences(EditProfileActivity.this, httpResponse.data);

						finish();
					} else {
						CommonToast.showShortToast(httpResponse.msg);
					}
				}, throwable -> {
					dismissProgressDialog();
					CommonToast.showShortToast("修改失败");
				});
	}

}
