package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.google.gson.reflect.TypeToken;
import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.WaitTodoGoods;
import com.itingbaby.app.model.httpmodel.HttpResponse;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.GsonHelper;
import com.itingbaby.app.viewbinder.WaitTodoGoodsViewBinder;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.ItbEmptyViewLayout;
import com.itingbaby.baselib.views.widget.swipeviews.RefreshLoadRecyclerLayout;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import me.drakeet.multitype.MultiTypeAdapter;
import okhttp3.MediaType;
import okhttp3.RequestBody;

public class EditTodoGoodsActivity extends BaseFragmentActivity {

	public static final String KEY_TODO_GOODS_LIST = "key_todo_goods_list";

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.swipe_refresh_layout)
	RefreshLoadRecyclerLayout swipeRefreshLayout;
	@BindView(R.id.view_empty_layout)
	ItbEmptyViewLayout viewEmptyLayout;

	private SwipeRecyclerView recyclerView;
	private MultiTypeAdapter mAdapter;

	private List mItems = new ArrayList<>();

	private List<WaitTodoGoods> optionList = new ArrayList<>();
	private WaitTodoGoodsViewBinder waitTodoGoodsViewBinder;

	public static void navigate(Context context, String dataListStr) {
		Intent intent = new Intent();
		intent.putExtra(KEY_TODO_GOODS_LIST, dataListStr);
		intent.setClass(context, EditTodoGoodsActivity.class);
		context.startActivity(intent);
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);


		setContentView(R.layout.activity_edit_todo_goods);
		ButterKnife.bind(this);

		initView();
		initData();
		initListener();

	}

	@Override
	protected void onDestroy() {
		EventBus.getDefault().unregister(this);
		super.onDestroy();
	}

	private void initView() {
		initRefreshLayout();

		// 设置无数据页面
		viewEmptyLayout.setEmptyViewMarginTopPercentHeight(0.3f);
		viewEmptyLayout.setEmptyMessage(getString(R.string.load_empty_msg));
		viewEmptyLayout.setEmptyImageRes(R.drawable.empty_data);

		StatusBarUtil.StatusBarLightMode(this);

	}

	private void initData() {
		Intent intent = getIntent();
		if (intent != null && intent.hasExtra(KEY_TODO_GOODS_LIST)) {
			optionList = GsonHelper.jsonToObject(intent.getStringExtra(KEY_TODO_GOODS_LIST), new TypeToken<List<WaitTodoGoods>>() {
			}.getType());
			Ln.d("optionList=%s", optionList);
		}
		setRecyclerViewData();
	}

	private void setRecyclerViewData() {
		if (!optionList.isEmpty()) {
			viewEmptyLayout.hideAllView();
			mItems.clear();
			mItems.addAll(optionList);
			mAdapter.notifyDataSetChanged();
		} else {
			viewEmptyLayout.showEmpty();
		}
	}

	private void initListener() {
		titleBar.setLeftOnClickListener(v -> {
			finish();
		});

		if (waitTodoGoodsViewBinder != null) {
			waitTodoGoodsViewBinder.setListener(new WaitTodoGoodsViewBinder.OnWaitTodoGoodsBinderListener() {
				@Override
				public void onItemClick(int pos, WaitTodoGoods goods) {
					goods.expanded = !goods.expanded;
					mAdapter.notifyDataSetChanged();
				}

				@Override
				public void onItemStatusClicked(int pos, WaitTodoGoods goods) {
					if ((goods.flag & WaitTodoGoods.FLAG_ADD) == WaitTodoGoods.FLAG_ADD) {
						goods.flag = 0;
					} else {
						goods.flag = 1;
					}
					goods.expanded = false;
					int index = optionList.indexOf(goods);
					if (index >= 0 && index < optionList.size()) {
						optionList.set(index, goods);
						setRecyclerViewData();
						// 更新flag数据
						updateTodoGoods(BabyVoiceApp.mUserInfo.id, goods);
					}
				}
			});
		}
	}

	private void initRefreshLayout() {


		recyclerView = swipeRefreshLayout.getSwipeRecyclerView();
		mAdapter = new MultiTypeAdapter(mItems);

		swipeRefreshLayout.setAdapter(mAdapter);
		swipeRefreshLayout.setCanRefresh(false);
		swipeRefreshLayout.setCanLoadMore(false);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
		recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

		waitTodoGoodsViewBinder = new WaitTodoGoodsViewBinder(WaitTodoGoodsViewBinder.SRC_FROM_EDIT);
		mAdapter.register(WaitTodoGoods.class, waitTodoGoodsViewBinder);

	}

	public void updateTodoGoods(long uid, WaitTodoGoods goods) {
		RequestBody reqUid = RequestBody.create(MediaType.parse("multipart/form-data"), Long.toString(uid));
		RequestBody reqGid = RequestBody.create(MediaType.parse("multipart/form-data"), Integer.toString(goods.id));
		RequestBody reqFlag = RequestBody.create(MediaType.parse("multipart/form-data"), Integer.toString(goods.flag));
		ServiceGenerator.createService(ApiManager.class)
				.updateTodoGoods(reqUid, reqGid, reqFlag)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(new Consumer<HttpResponse<Void>>() {
					@Override
					public void accept(HttpResponse<Void> httpResponse) {
						if (httpResponse.code == ResponseCode.RESPONSE_OK) {
							Ln.d("更新成功");
						} else {
							CommonToast.showShortToast(httpResponse.msg);
						}
					}
				}, new Consumer<Throwable>() {
					@Override
					public void accept(Throwable throwable) {
						Ln.e(throwable.toString());
					}
				});
	}
}
