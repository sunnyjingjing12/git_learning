package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;

import com.itingbaby.app.R;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.Vaccine;
import com.itingbaby.app.model.VaccineGroupDataModel;
import com.itingbaby.app.utils.GsonHelper;
import com.itingbaby.app.utils.SimpleDatePickerDialog;
import com.itingbaby.app.utils.db.VaccineManager;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.FixBytesEditText;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;

public class EditVaccineInfoActivity extends BaseFragmentActivity {


	public static final String KEY_VACCINE_GROUP_MODEL = "key_vaccine_group_model";
	public static final int REQUEST_EDIT_VACCINE_INFO = 1001;

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.edit_vc_nurse)
	FixBytesEditText editVcNurse;
	@BindView(R.id.edit_vc_time)
	FixBytesEditText editVcTime;
	@BindView(R.id.vc_edit_time_layout)
	LinearLayout editTimeLayout;


	private VaccineGroupDataModel mModel;


	private SimpleDatePickerDialog datePickerDialog;

	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

	public static Intent intentFor(Context context, String modelStr) {
		Intent intent = new Intent();
		intent.putExtra(KEY_VACCINE_GROUP_MODEL, modelStr);
		intent.setClass(context, EditVaccineInfoActivity.class);
		return intent;
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_edit_vaccine_info);
		ButterKnife.bind(this);
		initData();
		initView();
		initListener();
	}

	private void initView() {
		StatusBarUtil.StatusBarLightMode(this);
		if (mModel != null) {
			editVcNurse.setText(mModel.injectNurse);
			editVcTime.setText(mModel.realInjectDate);
		}

		editVcNurse.setMaxBytes(30);
		editVcNurse.setShowLeftWords(false);
		editVcTime.setMaxBytes(50);
		editVcTime.setShowLeftWords(false);
	}


	private void initData() {
		Intent intent = getIntent();
		if (intent != null) {
			if (intent.hasExtra(KEY_VACCINE_GROUP_MODEL)) {
				mModel = GsonHelper.jsonToObject(intent.getStringExtra(KEY_VACCINE_GROUP_MODEL), VaccineGroupDataModel.class);
			}
		}
	}


	private void initListener() {

		titleBar.setLeftOnClickListener(v -> {
			finish();
		});

		titleBar.setRightOnClickListener(v -> {
			showProgressDialog(null, true, null);
			// 保存信息到数据库
			String nurseName = Objects.requireNonNull(editVcNurse.getText()).toString().trim();
			String realInjectDate = Objects.requireNonNull(editVcTime.getText()).toString().trim();
			saveModelToDB(nurseName, realInjectDate);

			Intent mIntent = new Intent();
			// 设置结果，并进行传送
			this.setResult(RESULT_OK, mIntent);
			finish();
		});

		editTimeLayout.setOnClickListener(v -> {
			showSelectDateDialog();
		});
		editVcTime.setOnClickListener(v -> {
			showSelectDateDialog();
		});
	}

	private void saveModelToDB(String nurseName, String realInjectDate) {
		if (mModel == null) {
			return;
		}
		mModel.injectNurse = nurseName;
		mModel.realInjectDate = realInjectDate;
		List<Vaccine> vaccineList = mModel.vaccineList;
		for (Vaccine vaccine : vaccineList) {
			vaccine.realTime = realInjectDate;
			vaccine.nurse = nurseName;
		}
		VaccineManager.getInstance().batchReplace(vaccineList);
	}


	/**
	 * 设置日期
	 */
	private void showSelectDateDialog() {

		String curDateStr = sdf.format(new Date());
		if (mModel != null && !StringUtils.isEmpty(mModel.realInjectDate)) {
			curDateStr = mModel.realInjectDate;
		}
		datePickerDialog = new SimpleDatePickerDialog.Builder()
				.setContext(EditVaccineInfoActivity.this)
				.setTitleId(R.string.txt_select_date)
				.setYYYYMMDD(curDateStr, "yyyy-MM-dd")
				.setConfirmListener(which -> {
					String date = datePickerDialog.getYYYYMMDD("%04d-%02d-%02d");
					editVcTime.setText(date);

				})
				.build();
		datePickerDialog.show();

	}


}
