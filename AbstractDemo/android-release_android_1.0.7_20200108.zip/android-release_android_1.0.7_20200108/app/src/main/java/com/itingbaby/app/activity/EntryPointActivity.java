package com.itingbaby.app.activity;

import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.model.User;
import com.itingbaby.app.utils.GsonHelper;
import com.itingbaby.app.utils.IntentPrintUtil;
import com.itingbaby.app.utils.SharedPreferencesUtil;
import com.itingbaby.baselib.commonutils.ApplicationUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.manager.ActivityTaskManager;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;

/**
 * Created by lihb on 2018/2/3.
 */

public class EntryPointActivity extends BaseFragmentActivity {

	public static final String KEY_COMPONENT_NAME = "component_name";
	public static final String KEY_NEED_LOGIN = "need_login";
	private static final String KEY_INTENT = "key";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		overridePendingTransition(R.anim.fade_in, 0);
		setContentView(R.layout.activity_entry_point);

	}

	@Override
	protected void onResume() {
		super.onResume();
		Intent intent = getIntent();
		String strScheme = intent.getScheme();
		if (null != strScheme) {
			Ln.e("lihb intent scheme: " + strScheme);
			Uri uri = intent.getData();
			if (null != uri) {
				Ln.e("lihb uri scheme: " + uri.getScheme());
				Ln.e("lihb uri host: " + uri.getHost());
				Ln.e("lihb uri port: " + uri.getPort());
				Ln.e("lihb uri path: " + uri.getPath());
				Ln.e("lihb uri queryString: " + uri.getQuery());
				Ln.e("lihb uri queryParameter: " + uri.getQueryParameter(KEY_INTENT));
			}
		}
		SharedPreferences sharedPreferences = getSharedPreferences(SharedPreferencesUtil.USER_INFO_SHARED_PREFERENCES_FILE, MODE_PRIVATE);
		BabyVoiceApp.mUserInfo = GsonHelper.jsonToObject(sharedPreferences.getString(SharedPreferencesUtil.USER_INFO_DATA, ""), User.class);

		Ln.d("intent = %s", IntentPrintUtil.intentToString(intent));
		if (intent.hasExtra(KEY_NEED_LOGIN) && intent.getBooleanExtra(KEY_NEED_LOGIN, true) && BabyVoiceApp.mUserInfo == null) {
			Ln.d("EntryPointActivity KEY_NEED_LOGIN");
			intent.removeExtra(KEY_NEED_LOGIN);
			Intent intent1 = new Intent(EntryPointActivity.this, StartupActivity.class);
			startActivity(intent1);
		} else if (intent.getParcelableExtra(KEY_COMPONENT_NAME) != null) {
			gotoIntentComponent();
		} else if (ActivityTaskManager.getInstance().containsActivity(NewMainActivity.class.getName())) {
			Ln.d("EntryPointActivity FINISH_SELF");
			finish();
		} else {
			Ln.d("EntryPointActivity delayStartActivity");
			delayStartActivity();
		}
	}

	/**
	 * 跳转到通知携带参数的activity
	 */
	private void gotoIntentComponent() {
		Ln.d("EntryPointActivity gotoIntentComponent=%s", ((ComponentName) getIntent().getParcelableExtra(KEY_COMPONENT_NAME)).getClassName());
		Intent intent = new Intent();
		intent.setComponent(getIntent().getParcelableExtra(KEY_COMPONENT_NAME));
		getIntent().removeExtra(KEY_COMPONENT_NAME);
		getIntent().removeExtra(KEY_NEED_LOGIN);
		startActivity(intent);
	}

	/**
	 * 延迟启动
	 */
	private void delayStartActivity() {
		ApplicationUtils.mMainHandler.postDelayed(() -> {

			if (!SharedPreferencesUtil.isCurrentGuideShowed(EntryPointActivity.this)) {
				Intent intent = new Intent(EntryPointActivity.this, GuideActivity.class);
				startActivity(intent);

			} else if (!SharedPreferencesUtil.isFirstLaunch(EntryPointActivity.this)) {
				Intent intent = new Intent(EntryPointActivity.this, NewMainActivity.class);
				startActivity(intent);
			} else {
				Intent intent = new Intent(EntryPointActivity.this, StartupActivity.class);
				startActivity(intent);
			}

		}, 1500);
	}
}
