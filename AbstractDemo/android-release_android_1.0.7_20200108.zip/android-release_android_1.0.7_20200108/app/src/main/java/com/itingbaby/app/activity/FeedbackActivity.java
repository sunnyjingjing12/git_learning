package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.BuildConfig;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.camera.PhotoHelper;
import com.itingbaby.baselib.commonutils.ApplicationContext;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.CommonListDialog;
import com.itingbaby.baselib.views.widget.SafeDialog;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

/**
 * 用户反馈activity
 */
public class FeedbackActivity extends BaseFragmentActivity {

	private static final int AVATAR_WIDTH_HEIGHT = 480;

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.tv_feedback_type)
	TextView tvFeedbackType;
	@BindView(R.id.select_type_layout)
	LinearLayout selectTypeLayout;
	@BindView(R.id.tv_feedback_submit)
	TextView tvFeedbackSubmit;
	@BindView(R.id.img_feedback_add)
	ImageView imgFeedbackAdd;
	@BindView(R.id.edit_feedback_content)
	EditText editFeedbackContent;

	private String picturePath;
	private String[] mItems;
	private int selectIndex = -1;


	public static void navigate(Context context) {
		Intent intent = new Intent();
		intent.setClass(context, FeedbackActivity.class);
		context.startActivity(intent);
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_feedback);
		ButterKnife.bind(this);

		initListener();

		mItems = ApplicationContext.getContext().getResources().getStringArray(R.array.feedback_type);

		StatusBarUtil.StatusBarLightMode(this);
	}


	public void initListener() {
		titleBar.setLeftOnClickListener(v -> {
			finish();
		});

		selectTypeLayout.setOnClickListener(v -> {
			showSelectFeedbackTypeDialog();
		});

		imgFeedbackAdd.setOnClickListener(v -> {
			selectImageFromAlbum();
		});

		tvFeedbackSubmit.setOnClickListener(v -> {
			if (selectIndex < 0) {
				CommonToast.showShortToast("请选择反馈类型");
				return;
			}

			String content = editFeedbackContent.getText().toString();
			if (StringUtils.isEmpty(content)) {
				CommonToast.showShortToast("反馈内容不能为空");
				return;
			}

			String feedbackType = mItems[selectIndex];
			long uid = BabyVoiceApp.mUserInfo.id;
			String clientType = "Android";
			String appVersion = BuildConfig.VERSION_NAME;
			String deviceModel = Build.BRAND + "-" + Build.MODEL;
			String osVersion = Build.VERSION.RELEASE;
			sendUploadFeedbackRequest(uid, clientType, appVersion, deviceModel, osVersion, feedbackType, content, picturePath);

		});
	}

	/**
	 * 选择反馈类型
	 */
	private void showSelectFeedbackTypeDialog() {
		new SafeDialog(this,
				CommonListDialog.listDialog(this,
						"反馈类型",
						mItems, (dialog, which) -> {
							selectIndex = which;
							String selectItem = mItems[which];
							tvFeedbackType.setText(selectItem);
						})
		).show();
	}

	/**
	 * 选择图片
	 */
	private void selectImageFromAlbum() {
		PhotoHelper.create(this)
				.setPreferredSize(AVATAR_WIDTH_HEIGHT, AVATAR_WIDTH_HEIGHT)
				.start();
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == RESULT_OK) {
			switch (requestCode) {
			case PhotoHelper.REQUEST_TAKE_PICTURE:
				picturePath = data.getStringExtra(PhotoHelper.OUTPUT_PATH);

				Glide.with(this)
					.load(picturePath)
					.placeholder(R.drawable.ic_default_avatar)
					.error(R.drawable.ic_default_avatar)
					.dontAnimate()
					.into(imgFeedbackAdd);
			break;
			}
		}
	}

	private void sendUploadFeedbackRequest(long uid, String clientType, String appVersion, String deviceModel, String osVersion, String feedbackType, String content, String picturePath) {
		List<File> fileList = new ArrayList<>();
		File file = null;
		if (!StringUtils.isBlank(picturePath)) {
			file = new File(picturePath);
		}

		if (file == null || !file.exists()) {
			Ln.i("no pic to upload!!");
		} else {
			fileList.add(file);
		}
		MultipartBody body = filesToMultipartBody(fileList);
		showProgressDialog("提交中...", true, null);
		ServiceGenerator.createService(ApiManager.class)
				.uploadFeedback(uid, clientType, appVersion, deviceModel, osVersion, feedbackType, content, body)
				.observeOn(AndroidSchedulers.mainThread())
				.doOnTerminate(() -> {
					dismissProgressDialog();
					finish();
				})
				.subscribeOn(Schedulers.io())
				.subscribe(httpResponse -> {
					Ln.i("lihb", httpResponse.toString());
					if (ResponseCode.RESPONSE_OK == httpResponse.code) {
						// 成功
						CommonToast.showShortToast("感谢您的反馈!!");
					} else {
						CommonToast.showShortToast(httpResponse.msg);
					}
				}, throwable -> Ln.e(throwable.toString()));
	}


	private MultipartBody filesToMultipartBody(List<File> files) {
		MultipartBody.Builder builder = new MultipartBody.Builder();
		if (files.size() > 0) {
			for (File file : files) {
				RequestBody requestBody = RequestBody.create(MediaType.parse(""), file);
				builder.addFormDataPart("picfile", file.getName(), requestBody);
				//builder.addFormDataPart("fileName", file.getName());
			}
		} else {
			builder.addFormDataPart("", "");
		}
		builder.setType(MultipartBody.FORM);
		MultipartBody multipartBody = builder.build();
		return multipartBody;
	}
}
