package com.itingbaby.app.activity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.itingbaby.app.R;
import com.itingbaby.app.customview.NumberProgressBar;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.baselib.commonutils.PermissionCheckUtil;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.dev.events.EventBleDeviceConnectStatus;
import com.itingbaby.dev.events.EventBleDeviceFirmwareUpgrade;
import com.itingbaby.dev.iTingBabyBleDevice;
import com.itingbaby.dev.iTingBabyBleDeviceManager;
import com.tbruyelle.rxpermissions2.RxPermissions;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * BLE设备固件升级操作页面
 */
public class FirmwareUpgradeActivity extends BaseFragmentActivity {

	private static final String KEY_BLE_DEVICE = "key_ble_device";
	private static final String KEY_DEVICE_TYPE = "key_device_type";
	private static final String KEY_FIRMWARE_FILE_NAME = "key_firmware_file_name";

	@BindView(R.id.title_bar)
	TitleBar titleBar;

	@BindView(R.id.btnBegin)
	Button btnBegin;

	@BindView(R.id.btnStartup)
	Button btnStartup;

	@BindView(R.id.pbUpload)
	NumberProgressBar pbUpload;

	@BindView(R.id.tvProductNumber)
	TextView tvProductNumber;
	@BindView(R.id.tvSoftVersion)
	TextView tvSoftVersion;
	@BindView(R.id.tvHardVersion)
	TextView tvHardVersion;
	@BindView(R.id.tvProtocolVersion)
	TextView tvProtocolVersion;

	private iTingBabyBleDevice bleDevice;
	private int deviceType;
	private String firmwareFileName;


	public static void navigate(Context context, iTingBabyBleDevice device, int type, String fileName) {
		Intent intent = new Intent();
		intent.putExtra(KEY_BLE_DEVICE, device);
		intent.putExtra(KEY_DEVICE_TYPE, type);
		intent.putExtra(KEY_FIRMWARE_FILE_NAME, fileName);
		intent.setClass(context, FirmwareUpgradeActivity.class);
		context.startActivity(intent);
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_firmware_upgrade);

		ButterKnife.bind(this);
		TextView titleTV = titleBar.getCenterText();
		titleTV.setText("未连接");
		initView();
		initListener();

		Intent intent = getIntent();
		bleDevice = intent.getParcelableExtra(KEY_BLE_DEVICE);
		deviceType = intent.getIntExtra(KEY_DEVICE_TYPE, 0);
		firmwareFileName = intent.getStringExtra(KEY_FIRMWARE_FILE_NAME);

		EventBus.getDefault().register(this);

		final RxPermissions rxPermissions = new RxPermissions(this);
		rxPermissions.request(Manifest.permission.ACCESS_FINE_LOCATION).subscribe(granted -> {
			if (granted) {
				iTingBabyBleDeviceManager.getInstance().connect(bleDevice);
			} else {
				PermissionCheckUtil.showGrantFailDialog(this, R.string.grant_location_permission);
			}
		});
	}

	@Override
	protected void onDestroy() {
		iTingBabyBleDeviceManager.getInstance().disconnect();
		EventBus.getDefault().unregister(this);
		super.onDestroy();
	}

	private void initView() {
		StatusBarUtil.StatusBarLightMode(this);
		pbUpload.setProgress(0);
	}

	private void initListener() {
		titleBar.setLeftOnClickListener(v -> {
			finish();
		});

		titleBar.setRightOnClickListener(v -> {
		});

		btnBegin.setOnClickListener(v -> {
			iTingBabyBleDeviceManager.getInstance().requestEnterBootloader(deviceType, firmwareFileName);
		});

		btnStartup.setOnClickListener(v -> {
			iTingBabyBleDeviceManager.getInstance().requestFirmwareUpgradeStartup(deviceType, firmwareFileName);
		});
	}

	// region EventBus事件

	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onBleDeviceConnectionStatus(EventBleDeviceConnectStatus event) {
		int status = event.getStatus();
		if (EventBleDeviceConnectStatus.CONNECTION_STATUS_CONNECTING == status) {
			titleBar.setTitle("正在连接" + event.getDevName());
			tvProductNumber.setText("");
			tvSoftVersion.setText("");
			tvHardVersion.setText("");
			tvProtocolVersion.setText("");
			pbUpload.setProgress(0);
			showProgressDialog(getString(R.string.txt_ble_connecting), true, ()->{
				iTingBabyBleDeviceManager.getInstance().disconnect();
			});
		} else if (EventBleDeviceConnectStatus.CONNECTION_STATUS_CONNECTED == status) {
			dismissProgressDialog();
			titleBar.setTitle("已连接" + event.getDevName());
			tvProductNumber.setText(event.getDevProductNumber());
			tvSoftVersion.setText(event.getDevSoftVersion());
			tvHardVersion.setText(event.getDevHardVersion());
			tvProtocolVersion.setText(event.getDevProtocolVersion());
		} else if (EventBleDeviceConnectStatus.CONNECTION_STATUS_DISCONNECTED == status) {
			dismissProgressDialog();
			finish();
//			CommonDialog.createDialog(this)
//				.setTitleText(getString(R.string.title_tips))
//				.setText(getResources().getString(R.string.txt_ble_disconnect))
//				.setIconVisible(CommonDialog.Visible.Gone)
//				.setLeftButtonText(getString(R.string.btn_txt_cancel))
//				.setLeftButtonAction(v->{
//				})
//				.setRightButtonText(getString(R.string.btn_txt_reconnect))
//				.setRightButtonAction(v->{
//					iTingBabyBleDeviceManager.getInstance().reconnect();
//				})
//				.setCloseOnTouchOutside(true)
//				.setCancelable(true)
//				.show();
			//CommonToast.showLongToast(getString(R.string.txt_ble_disconnect));
		}
	}

	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onBleDeviceFirmwareUpgrade(EventBleDeviceFirmwareUpgrade event) {
		switch (event.getType()) {
		case EventBleDeviceFirmwareUpgrade.EVENT_REQUEST_ENTER_FIRMWARE_UPGRADE:
		break;
		case EventBleDeviceFirmwareUpgrade.EVENT_ENTER_FIRMWARE_UPGRADE_SUCCESS:
		break;
		case EventBleDeviceFirmwareUpgrade.EVENT_ENTER_FIRMWARE_UPGRADE_FAIL:
		break;

		case EventBleDeviceFirmwareUpgrade.EVENT_REQUEST_FIRMWARE_UPGRADE_STARTUP:
		break;
		case EventBleDeviceFirmwareUpgrade.EVENT_FIRMWARE_UPGRADE_STARTUP_SUCCESS:
		break;
		case EventBleDeviceFirmwareUpgrade.EVENT_FIRMWARE_UPGRADE_STARTUP_FAIL:
		break;

		case EventBleDeviceFirmwareUpgrade.EVENT_SEND_FIRMWARE_PACKAGE: {

		}
		break;
		case EventBleDeviceFirmwareUpgrade.EVENT_FIRMWARE_PACKAGE_RECV_SUCCESS: {
			pbUpload.setProgress(event.getUploadPercentage());
		}
		break;
		case EventBleDeviceFirmwareUpgrade.EVENT_FIRMWARE_PACKAGE_RECV_FAIL: {
			//int packSeq = event.getPackSeq();
			//Ln.i("发送失败的分包序号:" + packSeq);
		}
		break;

		case EventBleDeviceFirmwareUpgrade.EVENT_SEND_FIRMWARE_PACKAGE_FINISH:
		break;
		case EventBleDeviceFirmwareUpgrade.EVENT_FIRMWARE_UPGRADE_FINISH_SUCCESS:
			pbUpload.setProgress(100);
		break;
		case EventBleDeviceFirmwareUpgrade.EVENT_FIRMWARE_UPGRADE_FINISH_FAIL:
		break;
		}
	}

	// endregion
}
