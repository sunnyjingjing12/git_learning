package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.itingbaby.app.R;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.httpmodel.HttpResponse;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class ForgetPwdActivity extends BaseFragmentActivity {

	private static final String TAG = ForgetPwdActivity.class.getSimpleName();

	private static final String KEY_ACCOUNT = "key_account";

	private static final int COUNT_DOWN_TIME = 60 * 1000; // 单位：毫秒

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.edit_account)
	EditText editAccount;
	@BindView(R.id.img_clear_account)
	ImageView imgClearAccount;
	@BindView(R.id.divider_line_account)
	View dividerLineAccount;
	@BindView(R.id.edit_password)
	EditText editPassword;
	@BindView(R.id.txt_get_code)
	TextView txtGetCode;
	@BindView(R.id.divider_line_password)
	View dividerLinePassword;
	@BindView(R.id.txt_confirm_btn)
	TextView txtConfirmBtn;


	private CountDownTimer mCountDownTimer;
	private String mAccountStr = "";

	public static void navigate(Context context, String account) {
		Intent intent = new Intent();
		intent.putExtra(KEY_ACCOUNT, account);
		intent.setClass(context, ForgetPwdActivity.class);
		context.startActivity(intent);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_forget_pwd);
		ButterKnife.bind(this);
		initData();
		initViews();
		initListener();

	}

	private void initData() {
		Intent intent = getIntent();
		if (intent != null) {
			if (intent.hasExtra(KEY_ACCOUNT)) {
				mAccountStr = intent.getStringExtra(KEY_ACCOUNT);
			}
		}
	}

	private void initViews() {

		editAccount.setText(mAccountStr);
		txtGetCode.setEnabled(mAccountStr.length() > 0);
		imgClearAccount.setVisibility(mAccountStr.length() > 0 ? View.VISIBLE : View.GONE);
	}

	private void initListener() {
		titleBar.setLeftOnClickListener(v -> {
			finish();
		});

		editAccount.setOnFocusChangeListener((v, hasFocus) ->
				dividerLineAccount.setBackgroundColor(hasFocus ? getResources().getColor(R.color.white) : getResources().getColor(R.color.color_ffffff_10)));

		editPassword.setOnFocusChangeListener((v, hasFocus) ->
				dividerLinePassword.setBackgroundColor(hasFocus ? getResources().getColor(R.color.white) : getResources().getColor(R.color.color_ffffff_10)));


		editAccount.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {


			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void afterTextChanged(Editable s) {

				if (mCountDownTimer == null) {
					txtGetCode.setEnabled(s.length() > 0);
				}

				if (s.length() > 0) {
					imgClearAccount.setVisibility(View.VISIBLE);
					if (editPassword.getText().length() > 0 && txtGetCode.getText().length() > 0) {
						txtConfirmBtn.setEnabled(true);
					}
				} else {
					imgClearAccount.setVisibility(View.GONE);
					txtConfirmBtn.setEnabled(false);
				}
				Ln.d("[lihb update pwd] 账户文字改变, txtConfirmBtn enable = %b", txtConfirmBtn.isEnabled());


			}
		});

		editPassword.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {

			}

			@Override
			public void afterTextChanged(Editable s) {
				if (s.length() > 0) {
					if (editAccount.getText().length() > 0) {
						txtConfirmBtn.setEnabled(true);
					}
				} else {
					txtConfirmBtn.setEnabled(false);
				}

				Ln.d("[lihb update pwd] 密码文字改变, txtConfirmBtn enable = %b", txtConfirmBtn.isEnabled());
			}
		});
	}

	@OnClick({R.id.img_clear_account, R.id.txt_get_code, R.id.txt_confirm_btn})
	public void onViewClicked(View view) {
		String account = editAccount.getText().toString();
		switch (view.getId()) {
			case R.id.img_clear_account:
				editAccount.setText("");
				break;
			case R.id.txt_get_code:
				// 手机号或者邮箱号是否合法
				validateAccountToGetCode(account);
				break;
			case R.id.txt_confirm_btn:
				String code = editPassword.getText().toString();
				validateAccountToLogin(account, code);

				break;

		}
	}

	private void getCountDownTimer() {
		mCountDownTimer = new CountDownTimer(COUNT_DOWN_TIME, 1000) {
			@Override
			public void onTick(long millisUntilFinished) {
				txtGetCode.setEnabled(false);
				txtGetCode.setText(getString(R.string.resend_sms_code, millisUntilFinished / 1000));
			}

			@Override
			public void onFinish() {
				txtGetCode.setEnabled(true);
				txtGetCode.setText(getString(R.string.send_verify_code));
				mCountDownTimer.cancel();
				mCountDownTimer = null;
			}
		};
	}

	/**
	 * 获取验证码验证逻辑
	 *
	 * @param account
	 */
	private void validateAccountToGetCode(String account) {
		if (StringUtils.checkPhoneNumber(account)|| StringUtils.checkMail(account)) {
			if (null == mCountDownTimer) {
				getCountDownTimer();
			}
			mCountDownTimer.start();

			sendGetSmsCodeRequest(account);
			// 光标移动到输入验证码view
			editPassword.requestFocus();
		} else {
			if (StringUtils.isEmpty(account)) {
				CommonToast.showShortToast(getString(R.string.the_phone_number_is_empty));
			} else {
				CommonToast.showShortToast(getString(R.string.account_is_not_valid));
			}
		}
	}

	/**
	 * 登录验证逻辑
	 * 1、先验证勾选协议
	 * 2、账户是否合法
	 * 3、密码是否为空
	 *
	 * @param account
	 * @param code
	 */
	private void validateAccountToLogin(String account, String code) {
		if (!StringUtils.checkMail(account) && !StringUtils.checkPhoneNumber(account)) {
			CommonToast.showShortToast(getString(R.string.account_is_not_valid));
		} else if (StringUtils.isEmpty(code)) {
			CommonToast.showShortToast(getString(R.string.password_is_empty));
		} else {
			verifyCode(account, code);
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (null != mCountDownTimer) {
			mCountDownTimer.cancel();
			mCountDownTimer = null;
		}
	}


	/**
	 * 获取验证码,修改密码
	 *
	 * @param account
	 */
	private void sendGetSmsCodeRequest(String account) {
		ServiceGenerator.createService(ApiManager.class)
				.getSmsCode(account)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(new Consumer<HttpResponse<Void>>() {
					@Override
					public void accept(HttpResponse<Void> httpResponse) {
						Ln.i("lihb", httpResponse.toString());
						if (httpResponse.code == ResponseCode.RESPONSE_OK) {
							CommonToast.showShortToast(R.string.sms_to_your_phone);
						} else {
							CommonToast.showShortToast(httpResponse.msg);
						}
					}
				}, new Consumer<Throwable>() {
					@Override
					public void accept(Throwable throwable) {
						Ln.e("error-->" + throwable.toString());
						CommonToast.showShortToast("发送失败。");
					}
				});
	}


	/**
	 * 核实验证码
	 * @param account
	 * @param code
	 */
	private void verifyCode(String account, String code) {
		ServiceGenerator.createService(ApiManager.class)
				.verifyCode(account, code)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(new Consumer<HttpResponse<Void>>() {
					@Override
					public void accept(HttpResponse<Void> httpResponse) {
						Ln.i("lihb", httpResponse.toString());
						if (httpResponse.code == ResponseCode.RESPONSE_OK) {
							PasswordChangeActivity.navigate(ForgetPwdActivity.this, account, PasswordChangeActivity.TYPE_MODIFY_PWD);
						}else {
							CommonToast.showShortToast(httpResponse.msg);
						}
					}
				}, new Consumer<Throwable>() {
					@Override
					public void accept(Throwable throwable) {
						Ln.e("error-->" + throwable.toString());
						CommonToast.showShortToast("操作失败。");
					}
				});
	}
}
