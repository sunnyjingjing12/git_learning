package com.itingbaby.app.activity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.viewpager.widget.ViewPager;

import com.itingbaby.app.R;
import com.itingbaby.app.utils.SharedPreferencesUtil;
import com.itingbaby.baselib.commonutils.DimensionUtil;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.FixedIndicatorView;
import com.itingbaby.baselib.views.widget.IndicatorViewPager;

public class GuideActivity extends BaseFragmentActivity {

	private IndicatorViewPager mIndicatorViewPager;
	private LayoutInflater mInflate;

	private FixedIndicatorView mIndicator;
	private int[] mImages;
	private boolean mIsFirst;

	@Override
	protected void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		setContentView(R.layout.activity_guide);

		mImages = new int[]{R.drawable.guide01, R.drawable.guide02, R.drawable.guide03, R.drawable.guide04};
		initView();
		initUiEventHandle();

		SharedPreferencesUtil.setCurrentGuideShowed(this, true);

	}


	private void initView() {


		ViewPager viewPager = findViewById(R.id.guide_viewPager);
		mIndicator = findViewById(R.id.guide_indicator);

		mIndicatorViewPager = new IndicatorViewPager(GuideActivity.this, mIndicator, viewPager);
		mInflate = LayoutInflater.from(getApplicationContext());
		mIndicatorViewPager.setAdapter(adapter);

		if (mImages.length > 1) {
			mIndicator.setVisibility(View.VISIBLE);
		} else {
			mIndicator.setVisibility(View.GONE);
		}
	}

	private void initUiEventHandle() {
		mIndicatorViewPager.setOnIndicatorPageChangeListener(new IndicatorViewPager.OnIndicatorPageChangeListener() {
			boolean mIsScrolled;

			@Override
			public void onIndicatorPageChange(int preItem, int currentItem) {
				if (!mIsFirst) {
					mIsFirst = true;

				}
			}

			@Override
			public void onPageScrollStateChanged(int state) {
				switch (state) {
					case ViewPager.SCROLL_STATE_DRAGGING:
						mIsScrolled = false;
						break;
					case ViewPager.SCROLL_STATE_SETTLING:
						mIsScrolled = true;
						break;
					case ViewPager.SCROLL_STATE_IDLE:
						if (mIndicator.getCurrentItem() == mIndicator.getAdapter().getCount() - 1 && !mIsScrolled) {
							StartupActivity.navigate(GuideActivity.this);
							finish();
						}
						mIsScrolled = true;
						break;
					default:
						break;
				}
			}

			@Override
			public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

			}
		});


	}

	private IndicatorViewPager.IndicatorPagerAdapter adapter = new IndicatorViewPager.IndicatorViewPagerAdapter() {

		@Override
		public View getViewForTab(int position, View convertView, ViewGroup container) {
			if (convertView == null) {
				convertView = mInflate.inflate(R.layout.view_tab_guide, container, false);
			}
			ImageView indicatorView = convertView.findViewById(R.id.indicator_view);
			RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) indicatorView.getLayoutParams();
			params.width = DimensionUtil.dipToPx(GuideActivity.this, 6);
			params.height = DimensionUtil.dipToPx(GuideActivity.this, 6);
			indicatorView.setLayoutParams(params);
			indicatorView.setImageResource(R.drawable.tab_guide_indicator_selector);
			return convertView;
		}

		@Override
		public View getViewForPage(final int position, View convertView, ViewGroup container) {
			if (convertView == null) {
				convertView = mInflate.inflate(R.layout.view_guide, container, false);
			}
			((ImageView) convertView.findViewById(R.id.guide_image)).setImageResource(mImages[position]);

			TextView txtGoToAPP = convertView.findViewById(R.id.txt_go_to_app);
			txtGoToAPP.setVisibility((position == mIndicator.getAdapter().getCount() - 1) ? View.VISIBLE : View.GONE);
			txtGoToAPP.setOnClickListener(v -> {
				StartupActivity.navigate(GuideActivity.this);
				finish();
			});
			return convertView;
		}

		@Override
		public Object getItemForTab(int position) {
			Ln.d("getItemForTab position=%s", position);
			if (position >= 0 && mImages != null && position < mImages.length) {
				Ln.e("getItemForTab position=%s,getCount=%s", position, getCount());

				return mImages[position];
			} else
				return null;
		}

		@Override
		public int getCount() {
			return mImages.length;
		}
	};
}
