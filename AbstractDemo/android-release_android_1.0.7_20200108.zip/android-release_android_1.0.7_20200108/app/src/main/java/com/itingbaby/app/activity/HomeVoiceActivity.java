package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.itingbaby.app.R;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.fragment.HomeVoiceFragment;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.ScrollableViewPager;
import com.itingbaby.baselib.views.widget.tablayout.TabViewPagerAdapter;

import butterknife.BindView;
import butterknife.ButterKnife;

public class HomeVoiceActivity extends BaseFragmentActivity {


	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.main_view_pager)
	ScrollableViewPager mViewPager;

	private HomeVoiceFragment mRecordVoiceFragment;
	private HomeVoiceFragment mMixedVoiceFragment;

	private TabViewPagerAdapter pagerAdapter;
	private int mCurrTab = 0;


	public static void navigate(Context context) {
		Intent intent = new Intent();
		intent.setClass(context, HomeVoiceActivity.class);
		context.startActivity(intent);
	}

	@Override
	protected void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		setContentView(R.layout.activity_home_voice);
		ButterKnife.bind(this);

		initView();

		initListener();

	}


	private void initView() {

		titleBar.setLeftOnClickListener(v -> {
			onBackPressed();
		});

		mViewPager.setCanScroll(false);

		pagerAdapter = new TabViewPagerAdapter(getSupportFragmentManager());

		mRecordVoiceFragment = HomeVoiceFragment.create(HomeVoiceFragment.VOICE_TYPE_RECORD);
		mMixedVoiceFragment = HomeVoiceFragment.create(HomeVoiceFragment.VOICE_TYPE_MIXED);
		pagerAdapter.addFrag(mRecordVoiceFragment, "");
		pagerAdapter.addFrag(mMixedVoiceFragment, "");

		mViewPager.setOffscreenPageLimit(2);
		mViewPager.setAdapter(pagerAdapter);

		mViewPager.setCurrentItem(mCurrTab, false);
	}

	private void initListener() {
		if (mRecordVoiceFragment != null) {
			mRecordVoiceFragment.setOnTabSelectListener(index -> {
				mViewPager.setCurrentItem(index, false);
			});
		}
		if (mMixedVoiceFragment != null) {
			mMixedVoiceFragment.setOnTabSelectListener(index -> {
				mViewPager.setCurrentItem(index, false);
			});
		}
	}
}
