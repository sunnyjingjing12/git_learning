package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.itingbaby.app.R;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.customview.X5WebView;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.tencent.smtt.sdk.WebChromeClient;
import com.tencent.smtt.sdk.WebView;
import com.tencent.smtt.sdk.WebViewClient;

import butterknife.BindView;
import butterknife.ButterKnife;

public class HtmlActivity extends BaseFragmentActivity {


	private static final String KEY_HTML_TITLE = "key_html_title";
	private static final String KEY_HTML_CONTENT = "key_html_content";
	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.webView)
	X5WebView mWebView;


	public static void navigate(Context context, String title, String content) {
		Intent intent = new Intent();
		intent.putExtra(KEY_HTML_TITLE, title);
		intent.putExtra(KEY_HTML_CONTENT, content);
		intent.setClass(context, HtmlActivity.class);
		context.startActivity(intent);
	}


	@Override
	protected void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		setContentView(R.layout.activity_html);
		ButterKnife.bind(this);
		initView();
		initData();
	}

	private void initView() {
		StatusBarUtil.StatusBarLightMode(this);
		titleBar.setLeftOnClickListener(v -> {
			finish();
		});

		mWebView.setWebChromeClient(new WebChromeClient() {
			@Override
			public void onProgressChanged(WebView view, int newProgress) {
				super.onProgressChanged(view, newProgress);
			}

			@Override
			public void onReceivedTitle(WebView view, String title) {
				super.onReceivedTitle(view, title);
//				if (TextUtils.isEmpty(mTitleText)) { // 如果没给标题，就从网页中获取标题
//					titleBar.setTitle(title);
//				}
			}
		});
		mWebView.setWebViewClient(new WebViewClient() {
			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				view.loadUrl(url);
				return true;
			}
		});

	}


	private void initData() {
		Intent intent = getIntent();
		if (intent.hasExtra(KEY_HTML_TITLE)) {
			String title = intent.getStringExtra(KEY_HTML_TITLE);
			titleBar.setTitle(title);
		}
		if (intent.hasExtra(KEY_HTML_CONTENT)) {
			String content = intent.getStringExtra(KEY_HTML_CONTENT);
			mWebView.loadDataWithBaseURL(null, content, "text/html", "uft-8", null);
		}
	}

}
