package com.itingbaby.app.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.viewpager.widget.ViewPager;

import com.itingbaby.app.R;
import com.itingbaby.app.adapter.ViewPageAdapter;
import com.itingbaby.app.presenter.ImageBrowsePresenter;
import com.itingbaby.app.view.ImageBrowseView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Created by Jelly on 2016/9/3.
 */
public class ImageBrowseActivity extends Activity implements ViewPager.OnPageChangeListener, ImageBrowseView {

    private ViewPager vp;
    private TextView hint;
    private TextView delImg;
    private ImageView imgBack;
    private ViewPageAdapter adapter;
    private ImageBrowsePresenter presenter;
    private ArrayList<String> images = new ArrayList<>();
    private int curPos;


    public static Intent intentFor(Context context, ArrayList<String> images, int position) {
        Intent intent = new Intent(context, ImageBrowseActivity.class);
        intent.putStringArrayListExtra("images", images);
        intent.putExtra("position", position);
        return intent;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //设置无标题
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        //设置全屏
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_image_browse);
        vp = this.findViewById(R.id.viewPager);
        hint = this.findViewById(R.id.hint);
        delImg = (TextView) this.findViewById(R.id.tv_delete);
        imgBack = (ImageView) this.findViewById(R.id.img_back);

        initData();
        initPresenter();
        presenter.loadImage(images, curPos);

        delImg.setOnClickListener(v -> {
            int pos = presenter.deleteImage();
            if (images.size() == 0) {
                finish();
            } else {
                if (pos == images.size()) {
                    pos -= 1;
                }
                presenter.loadImage(images, pos);
            }

        });
        imgBack.setOnClickListener(v -> {
            finish();
        });
    }


    @Override
    public void finish() {
        Intent intent = new Intent();
        // 设置结果，并进行传送
        intent.putStringArrayListExtra("images", images);
        setResult(RESULT_OK, intent);
        super.finish();
    }

    public void initPresenter() {
        presenter = new ImageBrowsePresenter(this);
    }

    private void initData() {
        Intent i = getIntent();
        if (i != null) {
            if (i.hasExtra("images")) {
                images = i.getStringArrayListExtra("images");
            }
            if (i.hasExtra("position")) {
                curPos = i.getIntExtra("position", 0);
            }
        }
    }

    @Override
    public Context getMyContext() {
        return this;
    }

    @Override
    public void setImageBrowse(List<String> images, int position) {
        if (images != null && images.size() != 0) {
            if (adapter == null) {
                adapter = new ViewPageAdapter(this);
            }
            adapter.setImages(images);
            vp.setAdapter(adapter);
            vp.setCurrentItem(position);
            vp.addOnPageChangeListener(this);
            hint.setText(String.format(Locale.getDefault(), "%d/%d", position + 1, images.size()));
        }

    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        presenter.setPosition(position);
        hint.setText(position + 1 + "/" + presenter.getImages().size());
    }

    @Override
    public void onPageScrollStateChanged(int state) {
    }

}
