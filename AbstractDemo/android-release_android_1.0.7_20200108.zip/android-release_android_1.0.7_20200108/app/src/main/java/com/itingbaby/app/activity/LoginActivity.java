/*
 * 文 件 名:  LoginActivity.java
 * 描    述:  <描述>
 * 修 改 人:  liuxinyang
 * 修改时间:  2015年4月1日
 * 跟踪单号:  <跟踪单号>
 * 修改单号:  <修改单号>
 * 修改内容:  <修改内容>
 */
package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.Constant;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.User;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.GsonHelper;
import com.itingbaby.app.utils.SharedPreferencesUtil;
import com.itingbaby.app.utils.SoftInputUtil;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.jakewharton.rxbinding3.view.RxView;
import com.umeng.analytics.MobclickAgent;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.sharesdk.framework.Platform;
import cn.sharesdk.framework.PlatformActionListener;
import cn.sharesdk.framework.PlatformDb;
import cn.sharesdk.framework.ShareSDK;
import cn.sharesdk.tencent.qq.QQ;
import cn.sharesdk.wechat.friends.Wechat;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.RequestBody;

/**
 * Created by lhb on 2017/4/1.
 */
public class LoginActivity extends BaseFragmentActivity {


	@BindView(R.id.title_bar)
	TitleBar titleBar;

	@BindView(R.id.edit_account)
	EditText editAccount;
	@BindView(R.id.img_clear_account)
	ImageView imgClearAccount;
	@BindView(R.id.divider_line_account)
	View dividerLineAccount;
	@BindView(R.id.account_layout)
	RelativeLayout accountLayout;
	@BindView(R.id.edit_password)
	EditText editPassword;
	@BindView(R.id.img_clear_password)
	ImageView imgClearPassword;
	@BindView(R.id.img_open_password)
	ImageView imgOpenPassword;
	@BindView(R.id.divider_line_password)
	View dividerLinePassword;
	@BindView(R.id.password_layout)
	RelativeLayout passwordLayout;
	@BindView(R.id.txt_login_btn)
	TextView txtLoginBtn;
	@BindView(R.id.sms_check_box)
	CheckBox smsCheckBox;
	@BindView(R.id.txt_sms_protocol)
	TextView txtSmsProtocol;
	@BindView(R.id.txt_forget_pwd)
	TextView txtForgetPwd;

	private boolean mIsPwdVisible = false;


	public static void navigate(Context context) {
		Intent intent = new Intent();
		intent.setClass(context, LoginActivity.class);
		context.startActivity(intent);
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		ButterKnife.bind(this);
		initView();

		initListener();
	}

	@Override
	protected void onResume() {
		super.onResume();
		MobclickAgent.onPageStart("LoginActivity");
		MobclickAgent.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPageEnd("LoginActivity");
		MobclickAgent.onPause(this);
	}

	private void initView() {
		txtLoginBtn.setEnabled(false);
		txtSmsProtocol.setText(Html.fromHtml(getString(R.string.txt_agree_protocol)));
	}


	private void initListener() {
		titleBar.setLeftOnClickListener(v -> finish());

		txtLoginBtn.setOnClickListener(v -> {
			validateToLogin();
			SoftInputUtil.hideSoftInput(LoginActivity.this);
		});

		imgClearAccount.setOnClickListener(v -> editAccount.setText(""));
		imgClearPassword.setOnClickListener(v -> editPassword.setText(""));

		// 忘记密码
		RxView.clicks(txtForgetPwd)
				.throttleFirst(1, TimeUnit.SECONDS)
				.subscribe(aVoid -> ForgetPwdActivity.navigate(this, editAccount.getText().toString()));

		editAccount.setOnFocusChangeListener((v, hasFocus) ->
				dividerLineAccount.setBackgroundColor(hasFocus ? getResources().getColor(R.color.white) : getResources().getColor(R.color.color_ffffff_10)));

		editPassword.setOnFocusChangeListener((v, hasFocus) ->
				dividerLinePassword.setBackgroundColor(hasFocus ? getResources().getColor(R.color.white) : getResources().getColor(R.color.color_ffffff_10)));


		imgOpenPassword.setOnClickListener(v -> {
			if (!mIsPwdVisible) {
				editPassword.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
				imgOpenPassword.setImageResource(R.drawable.ic_display);
				mIsPwdVisible = true;
			} else {
				editPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
				imgOpenPassword.setImageResource(R.drawable.ic_not_display);
				mIsPwdVisible = false;
			}
			// 光标移到最后
			editPassword.setSelection(editPassword.getText().length());
		});

		editAccount.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {

			}

			@Override
			public void afterTextChanged(Editable s) {
				if (s.length() > 0) {
					imgClearAccount.setVisibility(View.VISIBLE);
					if (editPassword.getText().length() > 0) {
						txtLoginBtn.setEnabled(true);
					}
				} else {
					imgClearAccount.setVisibility(View.GONE);
					txtLoginBtn.setEnabled(false);
				}
				Ln.d("[lihb login] 账户文字改变, txtLoginBtn enable = %b", txtLoginBtn.isEnabled());

			}
		});

		editPassword.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {

			}

			@Override
			public void afterTextChanged(Editable s) {
				if (s.length() > 0) {
					imgClearPassword.setVisibility(View.VISIBLE);
					imgOpenPassword.setVisibility(View.VISIBLE);
					if (editAccount.getText().length() > 0) {
						txtLoginBtn.setEnabled(true);
					}
				} else {
					imgClearPassword.setVisibility(View.GONE);
					imgOpenPassword.setVisibility(View.GONE);
					txtLoginBtn.setEnabled(false);
				}

				Ln.d("[lihb login] 密码文字改变, txtLoginBtn enable = %b", txtLoginBtn.isEnabled());
			}
		});
	}

	@OnClick({R.id.phone_layout, R.id.qq_layout, R.id.wechat_layout, R.id.txt_protocol, R.id.txt_privacy})
	public void onViewClicked(View view) {
		switch (view.getId()) {
			case R.id.phone_layout:
				VerifyLoginActivity.navigate(this);
				break;
			case R.id.qq_layout:
				//CommonToast.showShortToast("该功能正在开发中，敬请期待~");
				Platform qqPlatform = ShareSDK.getPlatform(QQ.NAME);
				authorize(qqPlatform);
				break;
			case R.id.wechat_layout:
				//CommonToast.showShortToast("该功能正在开发中，敬请期待~");
				Platform wechat = ShareSDK.getPlatform(Wechat.NAME);
				authorize(wechat);
				break;
			case R.id.txt_protocol:
				WebViewActivity.navigate(this, Constant.USER_AGREEMENT, getString(R.string.txt_app_service_protocol));
				break;
			case R.id.txt_privacy:
				WebViewActivity.navigate(this, Constant.PRIVACY_WEB_SITE, getString(R.string.txt_app_privacy));
				break;
		}
	}

	/**
	 * 登录验证逻辑
	 * 1、先检查验证码
	 * 2、账户是否合法
	 * 3、密码是否为空
	 */
	private void validateToLogin() {
		String account = editAccount.getText().toString();
		String password = editPassword.getText().toString();

		if (!smsCheckBox.isChecked()) {
			CommonToast.showShortToast(getString(R.string.agree_protocol));
		} else if (!StringUtils.checkMail(account) && !StringUtils.checkPhoneNumber(account)) {
			CommonToast.showShortToast(getString(R.string.input_correct_phone_or_email_account));
		} else if (password.length() < 6 || password.length() > 16) {
			CommonToast.showShortToast("请输入6-16位的密码");
		} else {
			login(account, StringUtils.stringToMd5(password));
		}
	}

	private void login(final String userAccount, final String password) {
		showProgressDialog(getString(R.string.txt_login_now), false, null);
		ServiceGenerator.createService(ApiManager.class)
				.loginByAccount(RequestBody.create(MediaType.parse("multipart/form-data"), userAccount), RequestBody.create(MediaType.parse("multipart/form-data"), password))
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(httpResponse -> {
					Ln.d("lihbxxxxx = %s", httpResponse.toString());
					dismissProgressDialog();
					if (ResponseCode.RESPONSE_OK != httpResponse.code) {
						CommonToast.showShortToast(httpResponse.msg);
						return;
					}

					CommonToast.showShortToast(getString(R.string.txt_login_success));

					User userInfo = httpResponse.data;

					SharedPreferencesUtil.saveToPreferences(LoginActivity.this, userInfo);
					//BabyVoiceApp.getInstance().setLogin(true);
					BabyVoiceApp.mUserInfo = userInfo;

					NewMainActivity.navigate(LoginActivity.this);

					finish();
				}, throwable -> {
					dismissProgressDialog();
					CommonToast.showShortToast(getString(R.string.txt_login_fail));
					Ln.e("lihb %s", throwable.toString());
				});
	}

	// 第三方平台登录
	private void loginByThirdParty(String platform, String expData) {
		showProgressDialog(getString(R.string.txt_login_now), false, null);
		ServiceGenerator.createService(ApiManager.class)
				.loginThirdParty(RequestBody.create(MediaType.parse("multipart/form-data"), platform), RequestBody.create(MediaType.parse("multipart/form-data"), expData))
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(httpResponse -> {
					Ln.d("lihbxxxxx = %s", httpResponse.toString());
					dismissProgressDialog();
					if (httpResponse.code != ResponseCode.RESPONSE_OK) {
						CommonToast.showShortToast(httpResponse.msg);
						return;
					}

					CommonToast.showShortToast(getString(R.string.txt_login_success));

					User userInfo = httpResponse.data;

					SharedPreferencesUtil.saveToPreferences(LoginActivity.this, userInfo);
					BabyVoiceApp.mUserInfo = userInfo;

					NewMainActivity.navigate(LoginActivity.this);
					finish();
				}, throwable -> {
					dismissProgressDialog();
					CommonToast.showShortToast(getString(R.string.txt_login_fail));
					Ln.e("lihb %s", throwable.toString());
				});
	}

	// 使用第三方平台授权
	private void authorize(Platform plat) {
		if (null == plat) {
			return;
		}

		// 0.先判断是否有安装平台的客户端APP
		if (!plat.isClientValid()) {
			CommonToast.showShortToast("请先安装客户端");
			return;
		}

		// 1.检查是否存在已授权的数据
		if (plat.isAuthValid()) {
			// 如果已经存在授权状态，则通过授权数据进行登录
			//CommonToast.showShortToast("已经授权过了");
			PlatformDb pdb = plat.getDb();
			String userId = pdb.getUserId();
			long expiresTime = pdb.getExpiresTime();
			String strExpiresTime = StringUtils.TimeStamp2Date(expiresTime, "yyyy-MM-dd HH:mm:ss");
			Ln.i(strExpiresTime);
			if (null != userId) {
				try {
					JSONObject json = new JSONObject(pdb.exportData());
					loginByThirdParty(plat.getName(), json.toString());
				} catch (JSONException e) {
					Ln.e(e.getMessage());
				}
				return;
			}
		}

		//plat.removeAccount(true);

		// SSO授权，传false默认是客户端授权，没有客户端授权或者不支持客户端授权会跳web授权；设置成true是关闭SSO授权(关闭客户端授权)
		plat.SSOSetting(false);
		plat.setPlatformActionListener(platformlistener);
		ShareSDK.setActivity(this);		// 抖音登录适配安卓9.0
		plat.showUser(null);	// 要数据不要功能，主要体现在不会重复出现授权界面
	}

	// region 平台回调监听
	private PlatformActionListener platformlistener = new PlatformActionListener() {
		@Override
		public void onComplete(Platform platform, int i, HashMap<String, Object> hashMap) {
			Ln.i("onComplete");
			String jsonStr = GsonHelper.objectToJson(hashMap);
			loginByThirdParty(platform.getName(), jsonStr);
		}

		@Override
		public void onError(Platform platform, int i, Throwable throwable) {
			Ln.i("onError");
		}

		@Override
		public void onCancel(Platform platform, int i) {
			CommonToast.showLongToast("取消了" + platform.getName() + "登录");
		}
	};
	// endregion 平台回调监听
}
