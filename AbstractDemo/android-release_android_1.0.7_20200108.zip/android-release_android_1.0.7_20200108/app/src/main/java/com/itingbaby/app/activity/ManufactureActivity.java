package com.itingbaby.app.activity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.itingbaby.app.R;
import com.itingbaby.app.components.ISearchDeviceComponent;
import com.itingbaby.app.components.presenter.SearchDevicePresenter;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.BleDeviceWrapper;
import com.itingbaby.app.model.HistoryBleDeviceModel;
import com.itingbaby.app.model.SimpleTextItem;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.viewbinder.BluetoothDeviceViewBinder;
import com.itingbaby.app.viewbinder.SimpleTextItemViewBinder;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.PermissionCheckUtil;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.ItbEmptyViewLayout;
import com.itingbaby.baselib.views.widget.swipeviews.RefreshLoadRecyclerLayout;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;
import com.itingbaby.dev.iTingBabyBleDevice;
import com.itingbaby.dev.iTingBabyBleDeviceManager;
import com.tbruyelle.rxpermissions2.RxPermissions;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.drakeet.multitype.MultiTypeAdapter;

/**
 * 工厂调试页面（设备搜索）
 */
public class ManufactureActivity extends BaseFragmentActivity implements ISearchDeviceComponent.IView {

	public static final String KEY_MANUFACTURE_TYPE = "key_manufacture_type";
	public static final int MANUFACTURE_TYPE_UNKNOWN = 0;
	public static final int MANUFACTURE_TYPE_RENAME = 1;
	public static final int MANUFACTURE_TYPE_FIRMWARE_UPGRADE = 2;

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.swipe_refresh_layout)
	RefreshLoadRecyclerLayout swipeRefreshLayout;
	@BindView(R.id.view_empty_layout)
	ItbEmptyViewLayout viewEmptyLayout;
	@BindView(R.id.radioGroup)
	RadioGroup radioGroup;
	@BindView(R.id.rb_tbb)
	RadioButton rbTbb;
	@BindView(R.id.rb_ehg)
	RadioButton rbEhg;

	private boolean isScanning;
	private Animation operatingAnim;
	private SwipeRecyclerView recyclerView;
	private MultiTypeAdapter mAdapter;
	private BluetoothDeviceViewBinder mBluetoothDeviceViewBinder;
	private List mItems = new ArrayList<>();
	private SearchDevicePresenter mPresenter;

	private int manufactureType;// 出厂调试类型 0 未知类型 1 听贝贝设备改名 2 听贝贝固件升级
	private int deviceType;
	private String firmwareFileName;


	public static void navigate(Context context, int type) {
		Intent intent = new Intent();
		intent.putExtra(KEY_MANUFACTURE_TYPE, type);
		intent.setClass(context, ManufactureActivity.class);
		context.startActivity(intent);
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_manufacture);
		ButterKnife.bind(this);

		initView();
		initData();
		initListener();

		iTingBabyBleDeviceManager.getInstance().setBleDeviceNameFilter(null);// 工程模式不需要过滤设备名称

		Intent intent = getIntent();
		manufactureType = intent.getIntExtra(KEY_MANUFACTURE_TYPE, MANUFACTURE_TYPE_UNKNOWN);

		if (MANUFACTURE_TYPE_UNKNOWN == manufactureType) {
			Log.e("出厂设置", "传入未知类型:" + manufactureType);
		} else if (MANUFACTURE_TYPE_RENAME == manufactureType) {
			iTingBabyBleDeviceManager.getInstance().setATMode(true);
		}
	}

	@Override
	protected void onDestroy() {
		if (MANUFACTURE_TYPE_RENAME == manufactureType) {
			iTingBabyBleDeviceManager.getInstance().setATMode(false);
		}
		super.onDestroy();
	}

	private void initView() {
		initRefreshLayout();
		// 设置无数据页面
		viewEmptyLayout.setEmptyViewMarginTopPercentHeight(0.3f);
		viewEmptyLayout.setEmptyMessage(getString(R.string.load_empty_msg));
		viewEmptyLayout.setEmptyImageRes(R.drawable.empty_data);

		operatingAnim = AnimationUtils.loadAnimation(this, R.anim.rotate);
		operatingAnim.setInterpolator(new LinearInterpolator());

		StatusBarUtil.StatusBarLightMode(this);
	}

	private void initRefreshLayout() {
		viewEmptyLayout.setOnErrorBtnClickListener(v -> {
			if (mPresenter != null) {
				mPresenter.getBleDeviceData();
			}
		});

		recyclerView = swipeRefreshLayout.getSwipeRecyclerView();
		mAdapter = new MultiTypeAdapter(mItems);

		swipeRefreshLayout.setAdapter(mAdapter);
		swipeRefreshLayout.setCanRefresh(false);
		swipeRefreshLayout.setCanLoadMore(false);
		swipeRefreshLayout.setToggleLoadCount(4);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
		recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

		mAdapter.register(SimpleTextItem.class, new SimpleTextItemViewBinder());
		mBluetoothDeviceViewBinder = new BluetoothDeviceViewBinder();
		mAdapter.register(BleDeviceWrapper.class, mBluetoothDeviceViewBinder);
	}

	private void initData() {
		mPresenter = new SearchDevicePresenter(this);
		mPresenter.getBleDeviceData();
	}

	private void initListener() {
		titleBar.setLeftOnClickListener(v -> {
			finish();
		});

		titleBar.setRightOnClickListener(v -> {
			final RxPermissions rxPermissions = new RxPermissions(this);
			rxPermissions.request(Manifest.permission.ACCESS_FINE_LOCATION).subscribe(granted -> {
				if (granted) { // Always true pre-M
					if (isScanning) {
						iTingBabyBleDeviceManager.getInstance().stopScan();
						initLoadingView(false);
					} else {
						clearBleDeviceView();
						iTingBabyBleDeviceManager.getInstance().scan(6000, scanCallback);
					}
				} else {
					PermissionCheckUtil.showGrantFailDialog(this, R.string.grant_location_permission);
				}
			});
		});

		mBluetoothDeviceViewBinder.setOnDeviceClickListener(new BluetoothDeviceViewBinder.OnDeviceClickListener() {
			@Override
			public void onConnect(iTingBabyBleDevice device) {
				if (MANUFACTURE_TYPE_RENAME == manufactureType) {
					ParamsModifyInfoActivity.navigate(ManufactureActivity.this, device, deviceType);
				} else if (MANUFACTURE_TYPE_FIRMWARE_UPGRADE == manufactureType) {
					FirmwareUpgradeActivity.navigate(ManufactureActivity.this, device, deviceType, firmwareFileName);
				} else {
					CommonToast.showShortToast("不支持的出厂功能:" + manufactureType);
				}
			}

			@Override
			public void onDisConnect(String mac) {
			}

			@Override
			public void onDetail(String mac) {
			}
		});

		radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
			switch (checkedId){
			case R.id.rb_tbb:
				if (rbTbb.isChecked()) {
					deviceType = iTingBabyBleDeviceManager.DEVICE_TYPE_STETHOSCOPE;
					firmwareFileName = iTingBabyBleDeviceManager.TBB_FIRMWARE_FILE_NAME;
				}
			break;
			case R.id.rb_ehg:
				if (rbEhg.isChecked()) {
					deviceType = iTingBabyBleDeviceManager.DEVICE_TYPE_EHG;
					firmwareFileName = iTingBabyBleDeviceManager.EHG_FIRMWARE_FILE_NAME;
				}
			break;
			}
		});
		rbTbb.setChecked(true);
	}

	private void initLoadingView(boolean flag) {
		isScanning = flag;
		TextView rightText = titleBar.getRightText();
		if (isScanning) {
			rightText.startAnimation(operatingAnim);
		} else {
			rightText.clearAnimation();
		}
	}

	private void clearBleDeviceView() {
		if (mPresenter != null) {
			mPresenter.clearNearbyDeviceList();
			mPresenter.getBleDeviceData();
		}
	}

	// region ISearchDeviceComponent事件
	@Override
	public void handleFailed() {
		if (mAdapter.getItemCount() > 0) {
			CommonToast.showShortToast(getString(R.string.list_empty_net_error));
			return;
		}

		if (ListUtils.isEmpty(mItems) && viewEmptyLayout != null) {
			viewEmptyLayout.showError();
		}
	}

	@Override
	public void handleEmpty() {
		Ln.d("lihb handleEmpty");
		if (mAdapter.getItemCount() > 0) {
			return;
		}

		if (viewEmptyLayout != null) {
			viewEmptyLayout.setEmptyImageRes(R.drawable.empty_data);
			viewEmptyLayout.showEmpty();
		}
	}

	@Override
	public void updateDataList(List<HistoryBleDeviceModel> dataList, List<iTingBabyBleDevice> bleDevices) {
		mItems.clear();
		if (!ListUtils.isEmpty(bleDevices)) {
			SimpleTextItem simpleTextItem = new SimpleTextItem.Builder()
					.title(getString(R.string.nearby_device))
					.textColor(R.color.color_000000_30)
					.background(R.drawable.bg_bluetooth_text_shape)
					.build();

			mItems.add(simpleTextItem);
			for (iTingBabyBleDevice device : bleDevices) {
				BleDeviceWrapper wrapper = new BleDeviceWrapper();
				wrapper.bleDevice = device;
				mItems.add(wrapper);
			}
		}
		viewEmptyLayout.hideAllView();
		mAdapter.notifyDataSetChanged();
	}

	@Override
	public void showToast(String msg) {
		//CommonToast.showShortToast(msg);
	}
	// endregion

	private iTingBabyBleDeviceManager.ScanCallback scanCallback = new iTingBabyBleDeviceManager.ScanCallback() {
		@Override
		public void scanStarted() {
			initLoadingView(true);
		}

		@Override
		public void scanTimeout() {
			initLoadingView(false);
		}

		@Override
		public void scanFound(iTingBabyBleDevice device) {
			Ln.d("lihb EventBleDeviceScanFound ,event=%s", device.toString());
			// 拿数据
			if (mPresenter != null) {
				mPresenter.addNearbyDeviceList(device);
				mPresenter.getBleDeviceData();
			}
		}
	};
}
