package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.FrameLayout;

import com.itingbaby.app.R;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.fragment.HomeMusicFragment;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.CommonDialog;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * 宝宝音乐
 */
public class MusicActivity extends BaseFragmentActivity {


	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.fragment_layout)
	FrameLayout fragmentLayout;

	private HomeMusicFragment mHomeMusicFragment;


	public static void navigate(Context context) {
		Intent intent = new Intent();
		intent.setClass(context, MusicActivity.class);
		context.startActivity(intent);
	}

	@Override
	protected void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		setContentView(R.layout.activity_music);
		ButterKnife.bind(this);

		initView();

	}


	private void initView() {
		StatusBarUtil.StatusBarLightMode(this);
		if (mHomeMusicFragment == null) {
			mHomeMusicFragment = HomeMusicFragment.create();
		}
		getSupportFragmentManager().beginTransaction().add(fragmentLayout.getId(), mHomeMusicFragment, "HomeMusicFragment").commitAllowingStateLoss();

		titleBar.setLeftOnClickListener(v -> {
			onBackPressed();
		});
		titleBar.setRightOnClickListener(v -> {
			showSettingBluetoothDailog();
		});
	}

	private void showSettingBluetoothDailog() {
		CommonDialog.createDialog(this)
				.setTitleText(getString(R.string.title_tips))
				.setText(getString(R.string.txt_bluetooth_pair))
				.setIconVisible(CommonDialog.Visible.Gone)
				.setLeftButtonText(getString(R.string.cancel))
				.setLeftButtonAction(vdlg -> {
				})
				.setRightButtonText(getString(R.string.setting))
				.setRightButtonAction(vdlg -> {
					startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
				})
				.setCloseOnTouchOutside(true)
				.setCancelable(true)
				.show();
	}
}
