package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.itingbaby.app.R;
import com.itingbaby.app.components.IMusicListComponent;
import com.itingbaby.app.components.presenter.MusicListPresenter;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.app.model.AudioType;
import com.itingbaby.app.model.MusicCategory;
import com.itingbaby.app.model.MusicClause;
import com.itingbaby.app.model.MusicGroup;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.GsonHelper;
import com.itingbaby.app.viewbinder.AudioRecordModelViewBinder;
import com.itingbaby.app.viewbinder.MusicViewBinder;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.ItbEmptyViewLayout;
import com.itingbaby.baselib.views.widget.swipeviews.RefreshLoadRecyclerLayout;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.drakeet.multitype.MultiTypeAdapter;

/**
 * 点击宝宝音乐的精选模块进入的页面
 */
public class MusicListActivity extends BaseFragmentActivity implements IMusicListComponent.IView {

	private static final String KEY_MUSIC_TYPE = "key_music_type";
	private static final String KEY_MUSIC_INDEX = "key_music_index";
	private static final int COUNT = 10;
	private int mCurrPage = 1; // 请求数据的页数

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.txt_desc_title)
	TextView txtDescTitle;
	@BindView(R.id.txt_desc_detail)
	TextView txtDescDetail;
	@BindView(R.id.swipe_refresh_layout)
	RefreshLoadRecyclerLayout swipeRefreshLayout;
	@BindView(R.id.view_empty_layout)
	ItbEmptyViewLayout viewEmptyLayout;
	@BindView(R.id.music_list_bg)
	ConstraintLayout musicListBg;

	private MusicCategory musicCategory;
	private int index;

	private SwipeRecyclerView recyclerView;
	private MultiTypeAdapter mAdapter;

	private List mItems = new ArrayList<>();
	private MusicViewBinder musicViewBinder;
	private AudioRecordModelViewBinder audioRecordModelViewBinder;
	private MusicListPresenter mPresenter;

	private boolean mIsLastPage;
	private boolean mIsLoadingMore = false;
	private boolean mIsRefreshing = false;

	private int[] ids;


	public static void navigate(Context context, String musicTypeStr, int index) {
		Intent intent = new Intent();
		intent.putExtra(KEY_MUSIC_TYPE, musicTypeStr);
		intent.putExtra(KEY_MUSIC_INDEX, index);
		intent.setClass(context, MusicListActivity.class);
		context.startActivity(intent);
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_music_list);
		ButterKnife.bind(this);

		initData();
		initView();
		initListener();
	}

	private void initData() {
		Intent intent = getIntent();
		if (intent != null) {
			if (intent.hasExtra(KEY_MUSIC_TYPE)) {
				musicCategory = GsonHelper.jsonToObject(intent.getStringExtra(KEY_MUSIC_TYPE), MusicCategory.class);
			}
			if (intent.hasExtra(KEY_MUSIC_INDEX)) {
				index = intent.getIntExtra(KEY_MUSIC_INDEX, 0);
			}
		}

		ids = new int[] {
				R.drawable.music_list_shape_bg_1, R.drawable.music_list_shape_bg_2, R.drawable.music_list_shape_bg_3,
				R.drawable.music_list_shape_bg_4, R.drawable.music_list_shape_bg_5, R.drawable.music_list_shape_bg_6
		};

		mPresenter = new MusicListPresenter(this);

		mCurrPage = 1;
		if (MusicGroup.MUSIC_GROUP_ID_MY_VOICE == musicCategory.gid) {
			long recordType = AudioType.AUDIO_TYPE_BABY | AudioType.AUDIO_TYPE_MOM | AudioType.AUDIO_TYPE_LUNG | AudioType.AUDIO_TYPE_MIXED;
			mPresenter.getUserAudioRecordData(recordType, mCurrPage, COUNT);
		} else {
			mPresenter.getMusicClauseListData(musicCategory.id, mCurrPage, COUNT);
		}
	}

	private void initView() {
		if (musicCategory != null) {
			txtDescTitle.setText(musicCategory.title);
			txtDescDetail.setText(musicCategory.description);
		}

		initRefreshLayout();

		// 设置无数据页面
		viewEmptyLayout.setEmptyViewMarginTopPercentHeight(0.3f);
		viewEmptyLayout.setEmptyMessage(getString(R.string.load_empty_msg));
		viewEmptyLayout.setEmptyImageRes(R.drawable.empty_data);

		// 设置背景
		if (index >=0 && index < ids.length) {
			musicListBg.setBackgroundResource(ids[index]);
		}

		StatusBarUtil.StatusBarLightMode(this);
	}

	private void initRefreshLayout() {
		viewEmptyLayout.setOnErrorBtnClickListener(v -> {
			mCurrPage = 1;
			if (MusicGroup.MUSIC_GROUP_ID_MY_VOICE == musicCategory.gid) {
				long recordType = AudioType.AUDIO_TYPE_BABY | AudioType.AUDIO_TYPE_MOM | AudioType.AUDIO_TYPE_LUNG | AudioType.AUDIO_TYPE_MIXED;
				mPresenter.getUserAudioRecordData(recordType, mCurrPage, COUNT);
			} else {
				mPresenter.getMusicClauseListData(musicCategory.id, mCurrPage, COUNT);
			}
		});

		recyclerView = swipeRefreshLayout.getSwipeRecyclerView();
		mAdapter = new MultiTypeAdapter(mItems);

		swipeRefreshLayout.setAdapter(mAdapter);
		swipeRefreshLayout.setCanRefresh(true);
		swipeRefreshLayout.setCanLoadMore(true);
		swipeRefreshLayout.setToggleLoadCount(4);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
		recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

		registerMultiType();
	}

	/**
	 * 注册recrclerView类型
	 */
	private void registerMultiType() {
		if (MusicGroup.MUSIC_GROUP_ID_MY_VOICE == musicCategory.gid) {
			audioRecordModelViewBinder = new AudioRecordModelViewBinder(AudioRecordModelViewBinder.SRC_TYPE_MUSIC_LIST);
			mAdapter.register(AudioRecordModel.class, audioRecordModelViewBinder);
			audioRecordModelViewBinder.setOnAudioRecordModelViewBinderListener(new AudioRecordModelViewBinder.OnAudioRecordModelViewBinderListener() {
				@Override
				public void onItemClick(int pos) {  // 跳转到播放页
					if (pos < 0 || pos >= mItems.size()) {
						return;
					}
					AudioRecordModel model = (AudioRecordModel) mItems.get(pos);
					VoicePlayActivity.navigate(MusicListActivity.this, model, musicCategory);
				}

				@Override
				public void onItemMoreOperClick(int position) {
				}

				@Override
				public void onPlayImgClick(int position) {
				}

				@Override
				public void onPlaySvgaClick(int position) {

				}
			});
		} else {
			musicViewBinder = new MusicViewBinder(MusicViewBinder.SRC_TYPE_DEFAULT);
			mAdapter.register(MusicClause.class, musicViewBinder);
			musicViewBinder.setListener(new MusicViewBinder.OnMusicViewBinderListener() {
				@Override
				public void onItemClick(int pos) {
					if (pos < 0 || pos >= mItems.size()) {
						return;
					}
					MusicClause model = (MusicClause) mItems.get(pos);
					VoicePlayActivity.navigate(MusicListActivity.this, model, musicCategory);
				}

				@Override
				public void onMusicPlayImgClick(int position) {

				}

				@Override
				public void onMusicPlaySvgaClick(int position) {

				}
			});
		}
	}

	private void initListener() {
		titleBar.setLeftOnClickListener(v -> {
			finish();
		});
		swipeRefreshLayout.setOnRefreshLoadListener(new RefreshLoadRecyclerLayout.OnRefreshLoadListener() {
			@Override
			public boolean isLoading() {
				return mIsLoadingMore | mIsRefreshing;
			}

			@Override
			public boolean isLastPage() {
				return mIsLastPage;
			}

			@Override
			public void onLoadMore() {
				if (mIsLoadingMore || mIsRefreshing) {
					return;
				}
				viewEmptyLayout.hideAllView();

				mIsLoadingMore = true;

				mCurrPage++;
				if (MusicGroup.MUSIC_GROUP_ID_MY_VOICE == musicCategory.gid) {
					long recordType = AudioType.AUDIO_TYPE_BABY | AudioType.AUDIO_TYPE_MOM | AudioType.AUDIO_TYPE_LUNG | AudioType.AUDIO_TYPE_MIXED;
					mPresenter.getUserAudioRecordData(recordType, mCurrPage, COUNT);
				} else {
					mPresenter.getMusicClauseListData(musicCategory.id, mCurrPage, COUNT);
				}
			}

			@Override
			public void onRefresh(boolean auto) {
				if (mIsRefreshing) {
					return;
				}
				viewEmptyLayout.hideAllView();

				mIsRefreshing = true;

				mCurrPage = 1;
				if (MusicGroup.MUSIC_GROUP_ID_MY_VOICE == musicCategory.gid) {
					long recordType = AudioType.AUDIO_TYPE_BABY | AudioType.AUDIO_TYPE_MOM | AudioType.AUDIO_TYPE_LUNG | AudioType.AUDIO_TYPE_MIXED;
					mPresenter.getUserAudioRecordData(recordType, mCurrPage, COUNT);
				} else {
					mPresenter.getMusicClauseListData(musicCategory.id, mCurrPage, COUNT);
				}
			}

			@Override
			public void showResult() {

			}
		});
	}


	// region mvp view 方法
	@Override
	public void stopRefresh() {
		Ln.d("lihb stopRefresh");
		mIsRefreshing = false;
		swipeRefreshLayout.stopRefresh();
	}

	@Override
	public void stopLoadMore() {
		Ln.d("lihb stopLoadMore");
		mIsLoadingMore = false;
		swipeRefreshLayout.stopLoadMore();
	}

	@Override
	public void handleFailed() {
		Ln.d("lihb handleFailed");
		if (mAdapter.getItemCount() > 0) {
			CommonToast.showShortToast(getString(R.string.list_empty_net_error));
			return;
		}

		if (ListUtils.isEmpty(mItems) && viewEmptyLayout != null) {
			viewEmptyLayout.showError();
		}
	}

	@Override
	public void handleEmpty() {
		Ln.d("lihb handleEmpty");
		if (mAdapter.getItemCount() > 0) {
			return;
		}

		if (viewEmptyLayout != null) {
			viewEmptyLayout.showEmpty();
		}
	}

	@Override
	public void setIsLastPage(boolean isLastPage) {
		Ln.d("lihb setIsLastPage %b", isLastPage);
		mIsLastPage = isLastPage;
		swipeRefreshLayout.setCanLoadMore(!isLastPage);
		swipeRefreshLayout.setIsLastPage(isLastPage);
	}

	@Override
	public void updateDataList(List dataList) {
		Ln.d("lihb updateDataList, list size =%d, mIsLastPage=%b", dataList.size(), mIsLastPage);
		if (ListUtils.isEmpty(dataList)) {
			viewEmptyLayout.showEmpty();
			return;
		}

		viewEmptyLayout.hideAllView();
		mItems.clear();
		mItems.addAll(dataList);

		mAdapter.notifyDataSetChanged();
	}

	@Override
	public void addMoreDataList(List dataList) {
		Ln.d("lihb addMoreDataList, list size =%d, mIsLastPage=%b", dataList.size(), mIsLastPage);

		viewEmptyLayout.hideAllView();
		if (!ListUtils.isEmpty(dataList)) {
			mItems.addAll(dataList);
		}

		mAdapter.notifyDataSetChanged();
	}

	@Override
	public void showToast(String msg) {
		CommonToast.showShortToast(msg);
	}
	// endregion
}
