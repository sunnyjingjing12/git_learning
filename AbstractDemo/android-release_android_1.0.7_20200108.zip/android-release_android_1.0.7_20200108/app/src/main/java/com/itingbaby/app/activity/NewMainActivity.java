package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.Constant;
import com.itingbaby.app.DataManager;
import com.itingbaby.app.R;
import com.itingbaby.app.components.IOldVoiceComponent;
import com.itingbaby.app.components.presenter.OldVoicePresenter;
import com.itingbaby.app.customview.HomeTitleBar;
import com.itingbaby.app.customview.MainTabCustomView;
import com.itingbaby.app.event.EventMusicDot;
import com.itingbaby.app.fragment.HomeMeFragment;
import com.itingbaby.app.fragment.HomeTbaiFragment;
import com.itingbaby.app.fragment.HomeToolsFragment;
import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.app.model.AudioType;
import com.itingbaby.app.model.User;
import com.itingbaby.app.upgrade.UpgradeUtil;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.ItbClickSpannable;
import com.itingbaby.app.utils.SharedPreferencesUtil;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.manager.ActivityTaskManager;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.CommonDialog;
import com.itingbaby.baselib.views.widget.ScrollableViewPager;
import com.itingbaby.baselib.views.widget.tablayout.TabLayout;
import com.itingbaby.baselib.views.widget.tablayout.TabViewPagerAdapter;
import com.itingbaby.dev.iTingBabyBleDeviceManager;
import com.umeng.analytics.MobclickAgent;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

import butterknife.ButterKnife;

public class NewMainActivity extends BaseFragmentActivity implements IOldVoiceComponent.IView {

	private static final String TAG = "NewMainActivity";

	public final static long CHECK_VERSION_DURATION_3_DAY = 3 * 24 * 60 * 60000L;// 3天

	private static final int TBAI_TAB = 0;
	private static final int TOOLS_TAB = 1;
	private static final int ME_TAB = 2;

	private HomeTbaiFragment mHomeTbaiFragment;
	private HomeToolsFragment mHomeToolsFragment;
	private HomeMeFragment mHomeMeFragment;
	//ui
	private HomeTitleBar mHomeTitleBar;
	private ImageView mHeadBg;
	private ConstraintLayout mRootLayout;

	private TabLayout mTabLayout;
	private TabViewPagerAdapter mTabViewPagerAdapter;
	private ScrollableViewPager mViewPager;

	private int mCurrTab = TBAI_TAB;

	private long time;
	private int showCounts;
	private String[] mTabArrays;
	private int[] mTabIconArrays;

	private OldVoicePresenter mOldVoicePresenter;


	public static void navigate(Context context) {
		Intent intent = new Intent();
		intent.setClass(context, NewMainActivity.class);
		context.startActivity(intent);
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_main_new);
		ButterKnife.bind(this);

		initViews();
		UpgradeUtil.checkUpgrade(NewMainActivity.this, UpgradeUtil.FROM_MAIN_ACTIVITY);

		if(!EventBus.getDefault().isRegistered(this)){
			EventBus.getDefault().register(this);
		}

		SharedPreferencesUtil.setFirstLaunch(NewMainActivity.this, false);

		if (SharedPreferencesUtil.isNeedShowPrivacyDialog(NewMainActivity.this)) {
			showPrivacyDialog();
		} else {
			checkOldVoiceData();
		}
	}

	@Override
	public void onResume() {
		super.onResume();
		MobclickAgent.onResume(this);
	}

	@Override
	public void onPause() {
		super.onPause();
		MobclickAgent.onPause(this);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		DataManager.getInstance().clearData();
		if(EventBus.getDefault().isRegistered(this)){
			EventBus.getDefault().unregister(this);
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if ((requestCode & 0xffff) == IntentIntegrator.REQUEST_CODE) {
			IntentResult result = IntentIntegrator.parseActivityResult(IntentIntegrator.REQUEST_CODE, resultCode, data);
			if (result != null) {
				String contents = result.getContents();
				Ln.d("[scan] contents = %s", contents);
				if (TextUtils.isEmpty(contents)) {
					Toast.makeText(this, "Cancelled", Toast.LENGTH_LONG).show();
				} else {
					if (contents.startsWith("http")) {
						WebViewActivity.navigate(this, contents, "");
					}
				}
			}
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			if (iTingBabyBleDeviceManager.getInstance().isRecording() || iTingBabyBleDeviceManager.getInstance().isComplete()) {
				CommonDialog.createDialog(this)
						.setTitleText(getString(R.string.title_tips))
						.setText(getResources().getString(R.string.txt_exit_tips))
						.setIconVisible(CommonDialog.Visible.Gone)
						.setLeftButtonText(getString(R.string.btn_txt_exit))
						.setLeftButtonAction(v -> {
							// TODO 直接退出程序比较暴力，没想好
							System.exit(0);
							//ActivityTaskManager.getInstance().removeAllActivity();
						})
						.setRightButtonText(getString(R.string.btn_txt_to))
						.setRightButtonAction(v -> {
							BlueToothRecordActivity.navigate(this, DataManager.getInstance().getCurRecordType());
						})
						.setCloseOnTouchOutside(true)
						.setCancelable(true)
						.show();
			} else {
				BabyVoiceApp.getInstance().ExitAPP(getApplicationContext());
			}

			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	private void initViews() {

		mOldVoicePresenter = new OldVoicePresenter(this);

		mViewPager = findViewById(R.id.main_view_pager);
		mTabLayout = findViewById(R.id.tab_layout);
		mHomeTitleBar = findViewById(R.id.home_title_bar);
		mHeadBg = findViewById(R.id.head_img_bg);
		mRootLayout = findViewById(R.id.home_root_layout);


		mHomeTbaiFragment = HomeTbaiFragment.create();
		mHomeToolsFragment = HomeToolsFragment.create();
		mHomeMeFragment = HomeMeFragment.create();

		mHomeTbaiFragment.setUserVisibleHint(false);
		mHomeToolsFragment.setUserVisibleHint(false);
		mHomeMeFragment.setUserVisibleHint(false);

		mTabArrays = getResources().getStringArray(R.array.main_tabs);
		mTabIconArrays = new int[]{R.drawable.tab_tbai_img_selector, R.drawable.tab_tools_img_selector, R.drawable.tab_me_img_selector};

		// 加入fragment,显示爱听贝tab
//		initFragments();

		mViewPager.setCanScroll(false);

		mTabViewPagerAdapter = new TabViewPagerAdapter(getSupportFragmentManager());
		mTabViewPagerAdapter.addFrag(mHomeTbaiFragment, mTabArrays[0]);
		mTabViewPagerAdapter.addFrag(mHomeToolsFragment, mTabArrays[1]);
		mTabViewPagerAdapter.addFrag(mHomeMeFragment, mTabArrays[2]);


		mViewPager.setOffscreenPageLimit(2);
		mViewPager.setAdapter(mTabViewPagerAdapter);

		mTabLayout.setupWithViewPager(mViewPager);

		for (int i = 0; i < mTabViewPagerAdapter.getCount(); i++) {
			MainTabCustomView customView = new MainTabCustomView(this);
			customView.initData(mTabArrays[i], mTabIconArrays[i]);
			mTabLayout.getTabAt(i).setCustomView(customView);
		}


		mTabLayout.getTabAt(mCurrTab).getCustomView().setSelected(true);
		mViewPager.setCurrentItem(mCurrTab, false);

		changeHomeTitleBar(TBAI_TAB);

		renderMusicDotView();

		initListener();

	}

	private void initListener() {
		mTabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
			@Override
			public void onTabSelected(TabLayout.Tab tab) {
				if (tab.getPosition() != mCurrTab) {
					mCurrTab = tab.getPosition();
					changeHomeTitleBar(mCurrTab);
				}
				mViewPager.setCurrentItem(tab.getPosition(), true);
				tab.getCustomView().setSelected(true);

			}

			@Override
			public void onTabUnselected(TabLayout.Tab tab) {
				tab.getCustomView().setSelected(false);
			}

			@Override
			public void onTabReselected(TabLayout.Tab tab) {

			}
		});
	}



	/**
	 * 更新首页标题栏
	 * 0. 修改状态栏字体颜色
	 * 1. 首页背景色，听贝贝-青色，其他两个-白色
	 * 2. 右侧大波浪线图标,听贝贝-白色，其他两个-蓝色
	 * 3. 标题以及右边添加设备图标以及点击事件
	 *
	 * @param index 索引
	 */
	private void changeHomeTitleBar(int index) {
		switch (index) {
			case TOOLS_TAB:
			StatusBarUtil.StatusBarLightMode(this);
			mRootLayout.setBackgroundColor(getResources().getColor(R.color.white));
			mHeadBg.setImageResource(R.drawable.home_voiceline_blue_bg);

			mHomeTitleBar.setVisibility(View.VISIBLE);
			mHomeTitleBar.setLeftText(getString(R.string.tab_tools));
			mHomeTitleBar.setLeftTextColor(getResources().getColor(R.color.color_00bed7));
			mHomeTitleBar.setRightTextColor(getResources().getColor(R.color.color_00bed7));
			mHomeTitleBar.setRightDrawable(null);
			mHomeTitleBar.setRightOnClickListener(null);

			break;
//		case MARKET_TAB:
//			WebViewActivity.navigate(this, Constant.MARKET_WEBSITE, getString(R.string.item_market));
//			break;
		case ME_TAB:
			StatusBarUtil.StatusBarLightMode(this);
			mRootLayout.setBackgroundColor(getResources().getColor(R.color.white));
			mHeadBg.setImageResource(R.drawable.home_voiceline_blue_bg);

			mHomeTitleBar.setVisibility(View.VISIBLE);
			mHomeTitleBar.setLeftText(getString(R.string.tab_baby_me));
			mHomeTitleBar.setLeftTextColor(getResources().getColor(R.color.color_00bed7));
			mHomeTitleBar.setRightTextColor(getResources().getColor(R.color.color_00bed7));
			mHomeTitleBar.setRightDrawable(null);
			mHomeTitleBar.setRightOnClickListener(null);
			break;
			case TBAI_TAB:
				StatusBarUtil.StatusBarWhiteMode(this);
				mRootLayout.setBackgroundResource(R.drawable.shape_01e2d3_00b8d0_bg);
				mHeadBg.setImageResource(R.drawable.home_voiceline_white_bg);

				mHomeTitleBar.setVisibility(View.VISIBLE);
				mHomeTitleBar.setLeftText(getString(R.string.tab_tbai));
				mHomeTitleBar.setLeftTextColor(getResources().getColor(R.color.white));
				mHomeTitleBar.setRightTextColor(getResources().getColor(R.color.white));
				mHomeTitleBar.setRightDrawable(getResources().getDrawable(R.drawable.ic_add_dev));
				mHomeTitleBar.setRightOnClickListener(v -> {
					if (!iTingBabyBleDeviceManager.getInstance().isRecording()) {
						SearchDevicesActivity.navigate(this, AudioType.AUDIO_TYPE_BABY);
					} else {
						CommonToast.showLongToast("正在录音，请停止后再添加设备");
					}
				});
			break;
		default:break;
		}
	}

	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onMusicDotEvent(EventMusicDot event) {
		renderMusicDotView();
	}

	/**
	 * 小于15天，且未申请过
	 * 每隔3天显示一次
	 * 最多显示3次
	 */
	private void renderMusicDotView() {
		boolean showDots = false;
		User user = BabyVoiceApp.mUserInfo;
		if (user != null && 0 != user.expected_date &&
				StringUtils.differentDays(System.currentTimeMillis(), user.expected_date * 1000) < 14 &&
				user.userExtension != null && user.userExtension.custCount <= 0) {
			time = SharedPreferencesUtil.getLastShowMusicDotTime(this);
			showCounts = SharedPreferencesUtil.getMusicDotShowCount(this);
			if (showCounts < 3) {
				if (System.currentTimeMillis() - time > CHECK_VERSION_DURATION_3_DAY) {
					showDots = true;
				}
			}
		}

		if (showDots) {
			showCounts++;
			SharedPreferencesUtil.setLastShowMusicDotTime(this, System.currentTimeMillis());
			SharedPreferencesUtil.setMusicDotShowCount(this, showCounts);
		}
		View v = mTabLayout.getTabAt(TOOLS_TAB).getCustomView();
		if (v instanceof MainTabCustomView) {
			((MainTabCustomView) v).setDotViewVisibility(showDots ? View.VISIBLE : View.GONE);
		}

	}

	/**
	 * 检测旧数据
	 */
	private void checkOldVoiceData() {
		if (!SharedPreferencesUtil.isProcessOldVoiceData(this)) {
			if (mOldVoicePresenter != null) {
				mOldVoicePresenter.getVoiceDataSize();
				SharedPreferencesUtil.setProcessOldVoiceData(this, true);
			}
		}

	}

	/**
	 * 显示隐私政策弹窗
	 */
	private void showPrivacyDialog() {
		CommonDialog.createDialog(this)
				.setTitleText("甜贝隐私政策概要")
				.setTextSize(16)
				.setTextGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL)
				.setTextMargin(8, 0, 8, 0)
				.setTextWithLinkUrl(getClickableSpan(getString(R.string.txt_privacy_tips), v -> {
					WebViewActivity.navigate(NewMainActivity.this, Constant.PRIVACY_WEB_SITE, getString(R.string.txt_app_privacy));
				}))
				.setIconVisible(CommonDialog.Visible.Gone)
				.setLeftButtonText("暂不使用")
				.setLeftButtonAction(v -> {
					ActivityTaskManager.getInstance().removeAllActivity();
				})
				.setRightButtonText("同意")
				.setRightButtonAction(v -> {
					SharedPreferencesUtil.setShowPrivacyDialog(NewMainActivity.this, false);
				})
				.setCloseOnTouchOutside(false)
				.setCancelable(false)
				.show();
	}


	private SpannableString getClickableSpan(String content, View.OnClickListener listener) {
		SpannableString spannableInfo = new SpannableString(content);
		spannableInfo.setSpan(new ItbClickSpannable(listener, getResources().getColor(R.color.color_00bed7)), 121, 136, Spanned.SPAN_MARK_MARK);
		return spannableInfo;
	}

	/**
	 * 显示隐私政策弹窗
	 *
	 * @param modelList
	 */
	private void showImportOldVoiceDialog(List<AudioRecordModel> modelList) {
		CommonDialog.createDialog(this)
				.setTitleText("旧数据导入提醒")
				.setText("确定要将旧数据导入 " + BabyVoiceApp.mUserInfo.mobile + " 账户吗？")
				.setIconVisible(CommonDialog.Visible.Gone)
				.setLeftButtonText("取消")
				.setLeftButtonAction(v -> {

				})
				.setRightButtonText("确认")
				.setRightButtonAction(v -> {
					if (mOldVoicePresenter != null) {
						List<AudioRecordModel> delDataList = new ArrayList<>();
						List<AudioRecordModel> updateDataList = new ArrayList<>();
						long newId = BabyVoiceApp.mUserInfo.id;
						for (AudioRecordModel model : modelList) {
							long timestamp = model.getTimestamp();
							AudioRecordModel newModel = new AudioRecordModel();
							if (String.valueOf(timestamp).length() == 13) {
								newModel.setTimestamp(timestamp / 1000);
								delDataList.add(model);
							} else {
								newModel.setTimestamp(timestamp);
							}
							newModel.setUid(newId);
							newModel.setName(model.getName());
							newModel.setType(model.getType());
							newModel.setDuration(model.getDuration());
							newModel.setUrl(model.getUrl());
							newModel.setIsUploaded(model.getIsUploaded());
							newModel.setServerFileId(model.getServerFileId());

							updateDataList.add(newModel);
						}
						mOldVoicePresenter.updateAllVoiceData(delDataList, updateDataList);
					}
				})
				.show();
	}

	// region presenter回调
	@Override
	public void handleFailed() {

	}

	@Override
	public void handleData(List<AudioRecordModel> modelList) {
		int size = modelList.size();
		Ln.d("old size =%d", size);
		if (size > 0) {
			// 弹窗显示导入提醒
			showImportOldVoiceDialog(modelList);
		}
	}


	@Override
	public void showToast(String msg) {
		CommonToast.showShortToast(msg);
	}

	@Override
	public void processResult(boolean flag) {
		if (flag) {
			CommonToast.showShortToast("导入成功");
			mHomeTbaiFragment.startRefresh();
		}
	}
	// endregion presenter回调
}
