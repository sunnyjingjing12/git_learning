package com.itingbaby.app.activity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.EditText;

import com.itingbaby.app.R;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.baselib.commonutils.PermissionCheckUtil;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.dev.events.EventBleDeviceConnectStatus;
import com.itingbaby.dev.events.EventFeasycomATCommand;
import com.itingbaby.dev.iTingBabyBleDevice;
import com.itingbaby.dev.iTingBabyBleDeviceManager;
import com.tbruyelle.rxpermissions2.RxPermissions;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.Calendar;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * 设备改名页面
 */

public class ParamsModifyInfoActivity extends BaseFragmentActivity {

	private static final String TAG = ParamsModifyInfoActivity.class.getSimpleName();

	private static final int MODIFY_SUCCESSFUL = 1;
	private static final int MODIFY_FAILED = 0;
	private static final long DELAY_FINISH = 3000;
	private static final String KEY_BLE_DEVICE = "key_ble_device";
	private static final String KEY_DEVICE_TYPE = "key_device_type";

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.modifyInformation)
	EditText modifyInformationEdit;

	private int modifyResult = MODIFY_FAILED;
	private iTingBabyBleDevice bleDevice;
	private int deviceType;
	//private Set<String> commandSet;
	private Handler handler = new Handler();
	private StringBuffer modifyInformation = new StringBuffer();


	public static void navigate(Context context, iTingBabyBleDevice device, int type) {
		Intent intent = new Intent();
		intent.putExtra(KEY_BLE_DEVICE, device);
		intent.putExtra(KEY_DEVICE_TYPE, type);
		intent.setClass(context, ParamsModifyInfoActivity.class);
		context.startActivity(intent);
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		EventBus.getDefault().register(this);

		super.onCreate(savedInstanceState);

		Intent intent = getIntent();
		bleDevice = intent.getParcelableExtra(KEY_BLE_DEVICE);
		deviceType = intent.getIntExtra(KEY_DEVICE_TYPE, 0);

		setContentView(R.layout.activity_params_modify_info);
		ButterKnife.bind(this);

		loadData();
		initViews();
		initListener();

		final RxPermissions rxPermissions = new RxPermissions(this);
		rxPermissions.request(Manifest.permission.ACCESS_FINE_LOCATION).subscribe(granted -> {
			if (granted) {
				iTingBabyBleDeviceManager.getInstance().connect(bleDevice);
			} else {
				PermissionCheckUtil.showGrantFailDialog(this, R.string.grant_location_permission);
			}
		});
	}

	@Override
	protected void onDestroy() {
		iTingBabyBleDeviceManager.getInstance().disconnect();
		EventBus.getDefault().unregister(this);
		super.onDestroy();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			setResult(modifyResult);
			finish();
		}
		return true;
	}

	private void loadData() {
		//bluetoothDeviceWrapper = (BluetoothDeviceWrapper) getIntent().getSerializableExtra("bluetoothDeviceWrapper");
		//modifyInformation.append(getResources().getString(R.string.name) + " " + bluetoothDeviceWrapper.getName() + "\r\n");
		//modifyInformation.append(getResources().getString(R.string.addr) + " " + bluetoothDeviceWrapper.getAddress() + "\r\n\r\n");
		//commandSet = (Set<String>) getIntent().getSerializableExtra("commandSet");
	}

	private void initViews() {
		modifyInformationEdit.setText(modifyInformation);
	}

	private void initListener() {
		titleBar.setLeftOnClickListener(v -> {
			setResult(modifyResult);
			finish();
		});

		titleBar.setRightOnClickListener(v -> {
			Log.i(TAG, "");
		});
	}

	private void addState(String string) {
		Calendar c = Calendar.getInstance();
		int hour = c.get(Calendar.HOUR_OF_DAY);
		int minute = c.get(Calendar.MINUTE);
		int second = c.get(Calendar.SECOND);
		int msecond = c.get(Calendar.MILLISECOND);
		String strTime = String.format(Locale.CHINA, "【%02d:%02d:%02d.%03d】", hour, minute, second, msecond);
		modifyInformation.append(strTime).append(string).append("\r\n");
		modifyInformationEdit.setText(modifyInformation);
	}

	private void setCallBacks() {
//		if (BLE_MODE) {
//			fscBleCentralApi.setCallbacks(new FscBleCentralCallbacksImpInformation(new WeakReference<ParameterModifyInformationActivity>((ParameterModifyInformationActivity) activity)));
//            fscBleCentralApi.setCallbacks(new FscBleCentralCallbacksImp() {
//
//                @Override
//                public void atCommandCallBack(String command, String param, String status) {
//                    if (CommandBean.COMMAND_BEGIN.equals(command)) {
//                        if (status == CommandBean.COMMAND_SUCCESSFUL) {
//                            addState(getResources().getString(R.string.openEngineSuccess) + "\r\n");
//                        } else if (status == CommandBean.COMMAND_FAILED) {
//                            addState(getResources().getString(R.string.openEngineFailed) + "\r\n");
//                            fscBleCentralApi.disconnect();
//                            runOnUiThread(new Runnable() {
//                                @Override
//                                public void run() {
//                                    modifyInformationEdit.setTextColor(getResources().getColor(R.color.red));
//                                }
//                            });
//                            handler.postDelayed(new Runnable() {
//                                @Override
//                                public void run() {
//                                    setResult(modifyResult);
//                                    activity.finish();
//                                }
//                            }, 2500);
//                        } else if (status == CommandBean.COMMAND_TIME_OUT) {
//                            addState(getResources().getString(R.string.openEngineTimeOut) + "\r\n");
//                            fscBleCentralApi.disconnect();
//                            runOnUiThread(new Runnable() {
//                                @Override
//                                public void run() {
//                                    modifyInformationEdit.setTextColor(getResources().getColor(R.color.red));
//                                }
//                            });
//                            handler.postDelayed(new Runnable() {
//                                @Override
//                                public void run() {
//                                    setResult(modifyResult);
//                                    activity.finish();
//                                }
//                            }, 2500);
//                        }
//                    } else if (commandSet.contains(command)) {
//                        if (status == CommandBean.COMMAND_SUCCESSFUL) {
//                            if (command.contains("=")) {
//                                /**
//                                 *  modify parameter
//                                 */
//                                addState(getResources().getString(R.string.modify) + " " + command.substring(command.indexOf("+") + 1, command.indexOf("=")) + " " + getResources().getString(R.string.success) + "\r\n");
//                            } else {
//                                /**
//                                 * inquery information
//                                 */
//                                addState(getResources().getString(R.string.read) + " " + command.substring(command.indexOf("+") + 1, command.length()) + " " + getResources().getString(R.string.success));
//                                addState(param + "\r\n");
//                            }
//                        } else if (status == CommandBean.COMMAND_NO_NEED) {
//                            addState(getResources().getString(R.string.same) + " " + command.substring(command.indexOf("+") + 1, command.indexOf("=")) + "\r\n");
//                        } else if (status == CommandBean.COMMAND_FAILED) {
//                            if (command.contains("=")) {
//                                /**
//                                 *  modify parameter
//                                 */
//                                addState(getResources().getString(R.string.modify) + " " + command.substring(command.indexOf("+") + 1, command.indexOf("=")) + " " + getResources().getString(R.string.failed) + "\r\n");
//                            } else {
//                                /**
//                                 * inquery information
//                                 */
//                                addState(getResources().getString(R.string.read) + " " + command.substring(command.indexOf("+") + 1, command.length()) + " " + getResources().getString(R.string.failed) + "\r\n");
//                            }
//                        } else if (status == CommandBean.COMMAND_TIME_OUT) {
//                            if (command.contains("=")) {
//                                /**
//                                 *  modify parameter
//                                 */
//                                addState(getResources().getString(R.string.modify) + " " + command.substring(command.indexOf("+") + 1, command.indexOf("=")) + " " + getResources().getString(R.string.timeout) + "\r\n");
//                            } else {
//                                /**
//                                 * inquery information
//                                 */
//                                addState(getResources().getString(R.string.read) + " " + command.substring(command.indexOf("+") + 1, command.length()) + " " + getResources().getString(R.string.timeout) + "\r\n");
//                            }
//                            fscBleCentralApi.disconnect();
//                            runOnUiThread(new Runnable() {
//                                @Override
//                                public void run() {
//                                    modifyInformationEdit.setTextColor(getResources().getColor(R.color.red));
//                                }
//                            });
//                            handler.postDelayed(new Runnable() {
//                                @Override
//                                public void run() {
//                                    setResult(modifyResult);
//                                    activity.finish();
//                                }
//                            }, 2500);
//                        }
//                    } else if (status == CommandBean.COMMAND_FINISH) {
//                        /**
//                         * remember to disconnect after the modification is complete
//                         */
//                        addState(getResources().getString(R.string.modifyComplete) + "\r\n");
//                        String temp = new String(modifyInformation);
//                        if (temp.contains(getResources().getString(R.string.failed))) {
//                            runOnUiThread(new Runnable() {
//                                @Override
//                                public void run() {
//                                    modifyInformationEdit.setTextColor(getResources().getColor(R.color.red));
//                                }
//                            });
//                        } else {
//                            modifyResult = MODIFY_SUCCESSFUL;
//                        }
//                        fscBleCentralApi.disconnect();
//                        handler.postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                                setResult(modifyResult);
//                                activity.finish();
//                            }
//                        }, 3000);
//                    }
//                }
//
//                @Override
//                public void blePeripheralConnected(BluetoothGatt gatt, BluetoothDevice device) {
//                    addState(getResources().getString(R.string.connected));
//                    /**
//                     * after the connection is successful, it is recommended to wait for a while before modifying
//                     */
//                    handler.postDelayed(new Runnable() {
//                        @Override
//                        public void run() {
//                            fscBleCentralApi.sendATCommand(commandSet);
//                        }
//                    }, 2500);
//                }
//
//                @Override
//                public void blePeripheralDisonnected(BluetoothGatt gatt, BluetoothDevice device) {
//                    addState(getResources().getString(R.string.disconnected));
//                }
//            });
//		} else {
//			fscSppApi.setCallbacks(new FscSppCallbacksImpInformation(new WeakReference<ParameterModifyInformationActivity>((ParameterModifyInformationActivity) activity)));
//            fscSppApi.setCallbacks(new FscSppCallbacksImp() {
//                @Override
//                public void sppConnected(BluetoothDevice device) {
//                    addState(getResources().getString(R.string.connected));
//                    /**
//                     * after the connection is successful, it is recommended to wait for a while before modifying
//                     */
//                    handler.postDelayed(new Runnable() {
//                        @Override
//                        public void run() {
//                            fscSppApi.sendATCommand(commandSet);
//                        }
//                    }, 2000);
//                }
//
//                @Override
//                public void sppDisconnected(BluetoothDevice device) {
//                    addState(getResources().getString(R.string.disconnected));
//                }
//
//                @Override
//                public void atCommandCallBack(String command, String param, String status) {
//                    if (CommandBean.COMMAND_BEGIN.equals(command)) {
//                        if (status == CommandBean.COMMAND_SUCCESSFUL) {
//                            addState(getResources().getString(R.string.openEngineSuccess) + "\r\n");
//                        } else if (status == CommandBean.COMMAND_FAILED) {
//                            addState(getResources().getString(R.string.openEngineFailed) + "\r\n");
//                            fscSppApi.disconnect();
//                            runOnUiThread(new Runnable() {
//                                @Override
//                                public void run() {
//                                    modifyInformationEdit.setTextColor(getResources().getColor(R.color.red));
//                                }
//                            });
//                            handler.postDelayed(new Runnable() {
//                                @Override
//                                public void run() {
//                                    setResult(modifyResult);
//                                    activity.finish();
//                                }
//                            }, 2500);
//                        } else if (status == CommandBean.COMMAND_TIME_OUT) {
//                            addState(getResources().getString(R.string.openEngineTimeOut) + "\r\n");
//                            fscSppApi.disconnect();
//                            runOnUiThread(new Runnable() {
//                                @Override
//                                public void run() {
//                                    modifyInformationEdit.setTextColor(getResources().getColor(R.color.red));
//                                }
//                            });
//                            handler.postDelayed(new Runnable() {
//                                @Override
//                                public void run() {
//                                    setResult(modifyResult);
//                                    activity.finish();
//                                }
//                            }, 2500);
//                        }
//                    } else if (commandSet.contains(command)) {
//                        if (status == CommandBean.COMMAND_SUCCESSFUL) {
//                            if (command.contains("=")) {
//                                /**
//                                 *  modify parameter
//                                 */
//                                addState(getResources().getString(R.string.modify) + " " + command.substring(command.indexOf("+") + 1, command.indexOf("=")) + " " + getResources().getString(R.string.success) + "\r\n");
//                            } else {
//                                /**
//                                 * inquery information
//                                 */
//                                addState(getResources().getString(R.string.read) + " " + command.substring(command.indexOf("+") + 1, command.length()) + " " + getResources().getString(R.string.success));
//                                addState(param + "\r\n");
//                            }
//                        } else if (status == CommandBean.COMMAND_NO_NEED) {
//                            addState(getResources().getString(R.string.same) + " " + command.substring(command.indexOf("+") + 1, command.indexOf("=")) + "\r\n");
//                        } else if (status == CommandBean.COMMAND_FAILED) {
//                            if (command.contains("=")) {
//                                /**
//                                 *  modify parameter
//                                 */
//                                addState(getResources().getString(R.string.modify) + " " + command.substring(command.indexOf("+") + 1, command.indexOf("=")) + " " + getResources().getString(R.string.failed) + "\r\n");
//                            } else {
//                                /**
//                                 * inquery information
//                                 */
//                                addState(getResources().getString(R.string.read) + " " + command.substring(command.indexOf("+") + 1, command.length()) + " " + getResources().getString(R.string.failed) + "\r\n");
//                            }
//                        } else if (status == CommandBean.COMMAND_TIME_OUT) {
//                            if (command.contains("=")) {
//                                /**
//                                 *  modify parameter
//                                 */
//                                addState(getResources().getString(R.string.modify) + " " + command.substring(command.indexOf("+") + 1, command.indexOf("=")) + " " + getResources().getString(R.string.timeout) + "\r\n");
//                            } else {
//                                /**
//                                 * inquery information
//                                 */
//                                addState(getResources().getString(R.string.read) + " " + command.substring(command.indexOf("+") + 1, command.length()) + " " + getResources().getString(R.string.timeout) + "\r\n");
//                            }
//                            fscSppApi.disconnect();
//                            runOnUiThread(new Runnable() {
//                                @Override
//                                public void run() {
//                                    modifyInformationEdit.setTextColor(getResources().getColor(R.color.red));
//                                }
//                            });
//                            handler.postDelayed(new Runnable() {
//                                @Override
//                                public void run() {
//                                    setResult(modifyResult);
//                                    activity.finish();
//                                }
//                            }, 2500);
//                        }
//                    } else if (status == CommandBean.COMMAND_FINISH) {
//                        /**
//                         * remember to disconnect after the modification is complete
//                         */
//                        addState(getResources().getString(R.string.modifyComplete) + "\r\n");
//                        String temp = new String(modifyInformation);
//                        if (temp.contains(getResources().getString(R.string.failed))) {
//                            runOnUiThread(new Runnable() {
//                                @Override
//                                public void run() {
//                                    modifyInformationEdit.setTextColor(getResources().getColor(R.color.red));
//                                }
//                            });
//                        } else {
//                            modifyResult = MODIFY_SUCCESSFUL;
//                        }
//                        fscSppApi.disconnect();
//                        handler.postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                                setResult(modifyResult);
//                                activity.finish();
//                            }
//                        }, 3000);
//                    }
//                }
//            });
//		}
	}

	// 根据MAC地址生成听贝贝设备名
	private String macToiTingBabyDeviceName(String mac) {
		String[] lines = mac.split(":");
		String ret = "";
		if (iTingBabyBleDeviceManager.DEVICE_TYPE_STETHOSCOPE == deviceType) {
			ret = "TBB_";
		} else if (iTingBabyBleDeviceManager.DEVICE_TYPE_EHG == deviceType) {
			ret = "EHG_";
		}
		for (String str : lines) {
			ret += str;
		}
		return ret;
	}

	// region EventBus事件
	// 设备连接状态事件回调
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onFeasycomConnectionStatus(EventBleDeviceConnectStatus event) {
		int status = event.getStatus();
		if (EventBleDeviceConnectStatus.CONNECTION_STATUS_CONNECTING == status) {
			addState("正在连接中");
		} else if (EventBleDeviceConnectStatus.CONNECTION_STATUS_CONNECTED == status) {
			addState("已连接，准备进入AT模式");
			iTingBabyBleDeviceManager.getInstance().atEnter();
		} else if (EventBleDeviceConnectStatus.CONNECTION_STATUS_DISCONNECTED == status) {
			modifyInformationEdit.setTextColor(getResources().getColor(R.color.colorAccent));
			addState("已断开，" + (DELAY_FINISH / 1000) + "秒后离开页面");
			handler.postDelayed(new Runnable() {
				@Override
				public void run() {
					//setResult(modifyResult);
					finish();
				}
			}, DELAY_FINISH);
//			CommonDialog.createDialog(this)
//				.setTitleText(getString(R.string.title_tips))
//				.setText(getResources().getString(R.string.txt_ble_disconnect))
//				.setIconVisible(CommonDialog.Visible.Gone)
//				.setLeftButtonText(getString(R.string.btn_txt_cancel))
//				.setLeftButtonAction(v->{
//				})
//				.setRightButtonText(getString(R.string.btn_txt_reconnect))
//				.setRightButtonAction(v->{
//					iTingBabyBleDeviceManager.getInstance().reconnect();
//				})
//				.setCloseOnTouchOutside(true)
//				.setCancelable(true)
//				.show();
			//CommonToast.showLongToast(getString(R.string.txt_ble_disconnect));
		}
	}

	// AT模式命令回调
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onFeasycomATCallback(EventFeasycomATCommand event) {
		boolean flag = event.isResult();
		if (!flag) {
			return;
		}
		int type = event.getType();
		if (EventFeasycomATCommand.AT_TYPE_ENTER == type) {
			iTingBabyBleDeviceManager.getInstance().atGetName();
		} else if (EventFeasycomATCommand.AT_TYPE_NAME_GET == type) {
			String name = event.getName();
			if (null != name) {
				addState("获得设备名：" + name);
			}
			String str = macToiTingBabyDeviceName(bleDevice.getAddress());
			addState("将要设置的设备名：" + str);
			iTingBabyBleDeviceManager.getInstance().atChangeName(str);
		} else if (EventFeasycomATCommand.AT_TYPE_NAME_SET == type) {
			addState("修改设备名成功，" + (DELAY_FINISH / 1000) + "秒后离开页面");
			handler.postDelayed(new Runnable() {
				@Override
				public void run() {
					//setResult(modifyResult);
					finish();
				}
			}, DELAY_FINISH);
		} else {
			addState("位置AT命令类型：" + type);
		}
	}
	// endregion
}
