package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.User;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.SharedPreferencesUtil;
import com.itingbaby.app.utils.SoftInputUtil;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.umeng.analytics.MobclickAgent;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.RequestBody;

/**
 * Created by lhb on 2017/4/1.
 */
public class PasswordChangeActivity extends BaseFragmentActivity {


	private static final String KEY_ACCOUNT = "key_account";
	private static final String KEY_TYPE = "key_type";


	public static final int TYPE_MODIFY_PWD = 0;    // 修改密码
	public static final int TYPE_SETTING_PWD = 1;   // 设置密码

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.txt_account)
	TextView txtAccount;
	@BindView(R.id.edit_new_password)
	EditText editNewPassword;
	@BindView(R.id.img_new_clear_password)
	ImageView imgNewClearPassword;
	@BindView(R.id.img_new_open_password)
	ImageView imgNewOpenPassword;
	@BindView(R.id.divider_line_new_password)
	View dividerLineNewPassword;
	@BindView(R.id.txt_change_pwd_btn)
	TextView txtChangePwdBtn;
	@BindView(R.id.txt_setting_pwd_title)
	TextView txtSettingPwdTitle;

	private boolean mIsNewPwdVisible = false;
	private String mAccountStr = "";
	private int mType;

	public static void navigate(Context context, String account, int type) {
		Intent intent = new Intent();
		intent.putExtra(KEY_ACCOUNT, account);
		intent.putExtra(KEY_TYPE, type);
		intent.setClass(context, PasswordChangeActivity.class);
		context.startActivity(intent);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_change_password);
		ButterKnife.bind(this);

		initData();

		initView();

		initListener();

	}

	private void initData() {
		Intent intent = getIntent();
		if (intent != null) {
			if (intent.hasExtra(KEY_ACCOUNT)) {
				mAccountStr = intent.getStringExtra(KEY_ACCOUNT);
			}
			if (intent.hasExtra(KEY_TYPE)) {
				mType = intent.getIntExtra(KEY_TYPE, 0);
			}
		}
	}

	private void initView() {
		txtChangePwdBtn.setEnabled(mAccountStr.length() > 0);
		txtAccount.setText(mAccountStr);
		if (mType == TYPE_MODIFY_PWD) {
			txtSettingPwdTitle.setText(getString(R.string.txt_change_pwd_title));
		} else if (mType == TYPE_SETTING_PWD) {
			txtSettingPwdTitle.setText(getString(R.string.txt_setting_pwd));
		}
	}


	private void initListener() {
		titleBar.setLeftOnClickListener(v -> {
			StartupActivity.navigate(this);
			finish();
		});


		txtChangePwdBtn.setOnClickListener(v -> {
			validateToChangePwd();
			SoftInputUtil.hideSoftInput(PasswordChangeActivity.this);
		});

		imgNewClearPassword.setOnClickListener(v -> {
			editNewPassword.setText("");
		});

		editNewPassword.setOnFocusChangeListener((v, hasFocus) ->
				dividerLineNewPassword.setBackgroundColor(hasFocus ? getResources().getColor(R.color.white) : getResources().getColor(R.color.color_ffffff_10)));

		imgNewOpenPassword.setOnClickListener(v -> {
			if (!mIsNewPwdVisible) {
				editNewPassword.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
				imgNewOpenPassword.setImageResource(R.drawable.ic_display);
				mIsNewPwdVisible = true;
			} else {
				editNewPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
				imgNewOpenPassword.setImageResource(R.drawable.ic_not_display);
				mIsNewPwdVisible = false;
			}
			// 光标移到最后
			editNewPassword.setSelection(editNewPassword.getText().length());
		});


		editNewPassword.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {

			}

			@Override
			public void afterTextChanged(Editable s) {
				if (s.length() > 0) {
					imgNewClearPassword.setVisibility(View.VISIBLE);
					imgNewOpenPassword.setVisibility(View.VISIBLE);
					txtChangePwdBtn.setEnabled(true);

				} else {
					imgNewClearPassword.setVisibility(View.GONE);
					imgNewOpenPassword.setVisibility(View.GONE);
					txtChangePwdBtn.setEnabled(false);
				}
				Ln.d("[lihb change password] 新密码文字改变, txtChangePwdBtn enable = %b", txtChangePwdBtn.isEnabled());

			}
		});


	}

	/**
	 * Called when the activity has detected the user's press of the back
	 * key.  The default implementation simply finishes the current activity,
	 * but you can override this to do whatever you want.
	 */
	@Override
	public void onBackPressed() {
		Intent intent = new Intent(PasswordChangeActivity.this, StartupActivity.class);
		startActivity(intent);
		finish();
	}


	/**
	 * 登录验证逻辑
	 * 2、账户是否合法
	 * 3、密码是否为空
	 */
	private void validateToChangePwd() {
		String newPassword = editNewPassword.getText().toString();

		if (StringUtils.isEmpty(newPassword)) {
			CommonToast.showShortToast("密码为空");
		} else if (newPassword.length() < 6 || newPassword.length() > 16) {
			CommonToast.showShortToast(getString(R.string.txt_input_new_code));
		} else {
			// 执行修改密码逻辑
			if (!StringUtils.isEmpty(mAccountStr)) {
				sendChangePwdRequest(mAccountStr, StringUtils.stringToMd5(newPassword));
			}

		}
	}


	@Override
	public void onResume() {
		super.onResume();
		MobclickAgent.onPageStart("PasswordChangeActivity");
		MobclickAgent.onResume(this);
	}

	@Override
	public void onPause() {
		super.onPause();
		MobclickAgent.onPageEnd("PasswordChangeActivity");
		MobclickAgent.onPause(this);
	}


	/**
	 * 发送修改密码协议
	 *
	 * @param loginAccount
	 * @param newPassword
	 */
	private void sendChangePwdRequest(final String loginAccount, final String newPassword) {
		showProgressDialog(getString(R.string.txt_login_now), false, null);
		ServiceGenerator.createService(ApiManager.class)
				.changePassword(RequestBody.create(MediaType.parse("multipart/form-data"), loginAccount), RequestBody.create(MediaType.parse("multipart/form-data"), newPassword))
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(httpResponse -> {
					Ln.i("lihb", httpResponse.toString());
					dismissProgressDialog();
					if (httpResponse.code == ResponseCode.RESPONSE_OK) {
						// 成功
						CommonToast.showShortToast("登录成功");

						User userInfo = httpResponse.data;

						SharedPreferencesUtil.saveToPreferences(PasswordChangeActivity.this, userInfo);
						//BabyVoiceApp.getInstance().setLogin(true);
						BabyVoiceApp.mUserInfo = userInfo;

						NewMainActivity.navigate(PasswordChangeActivity.this);
						finish();
					} else {
						CommonToast.showShortToast(httpResponse.msg);
					}
				}, throwable -> {
					dismissProgressDialog();
					CommonToast.showShortToast("登录失败，请重新登录!");
				});
	}
}
