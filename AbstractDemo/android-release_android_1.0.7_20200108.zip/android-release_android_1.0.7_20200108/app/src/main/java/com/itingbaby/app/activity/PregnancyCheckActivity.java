package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.itingbaby.app.R;
import com.itingbaby.app.components.IPregnancyCheckComponent;
import com.itingbaby.app.components.presenter.PregnancyCheckPresenter;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.pregnancycheck.PregnancyCheckModel;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.db.PregnancyExamineManager;
import com.itingbaby.app.viewbinder.PregnancyCheckModelViewBinder;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.ItbEmptyViewLayout;
import com.itingbaby.baselib.views.widget.swipeviews.RefreshLoadRecyclerLayout;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.drakeet.multitype.MultiTypeAdapter;

/**
 * 产检时间表activity
 */
public class PregnancyCheckActivity extends BaseFragmentActivity implements IPregnancyCheckComponent.IView {


	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.txt_interval_days)
	TextView txtIntervalDays;
	@BindView(R.id.swipe_refresh_layout)
	RefreshLoadRecyclerLayout swipeRefreshLayout;
	@BindView(R.id.view_empty_layout)
	ItbEmptyViewLayout viewEmptyLayout;


	private SwipeRecyclerView recyclerView;
	private MultiTypeAdapter mAdapter;

	private List mItems = new ArrayList<>();

	private PregnancyCheckPresenter mPresenter;
	private Calendar mCalendar;
	private PregnancyCheckModelViewBinder pregnancyCheckModelViewBinder;

	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日", Locale.getDefault());
	private List<PregnancyCheckModel> mDataList = new ArrayList<>();


	public static void navigate(Context context) {
		Intent intent = new Intent();
		intent.setClass(context, PregnancyCheckActivity.class);
		context.startActivity(intent);
	}

	@Override
	protected void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		setContentView(R.layout.activity_pregnancy_check);
		ButterKnife.bind(this);

		initView();

	}


	private void initView() {

		titleBar.setLeftOnClickListener(v -> {
			onBackPressed();
		});

		titleBar.setRightOnClickListener(v -> {
			RemindSettingActivity.navigate(this, RemindSettingActivity.FROM_PREGNANCY_CARE, mCalendar);
		});

		mPresenter = new PregnancyCheckPresenter(this);

		initRefreshLayout();

		// 设置无数据页面
		viewEmptyLayout.setEmptyViewMarginTopPercentHeight(0.3f);
		viewEmptyLayout.setEmptyMessage(getString(R.string.load_empty_msg));
		viewEmptyLayout.setEmptyImageRes(R.drawable.empty_data);

		StatusBarUtil.StatusBarLightMode(this);

		mPresenter.getAllPregnancyCheckData();
	}

	private void initRefreshLayout() {
		viewEmptyLayout.setOnErrorBtnClickListener(v -> {
			if (mPresenter != null) {
				mPresenter.getAllPregnancyCheckData();
			}
		});

		recyclerView = swipeRefreshLayout.getSwipeRecyclerView();
		mAdapter = new MultiTypeAdapter(mItems);


		swipeRefreshLayout.setAdapter(mAdapter);
		swipeRefreshLayout.setCanRefresh(false);
		swipeRefreshLayout.setCanLoadMore(false);
		recyclerView.setBackgroundResource(R.color.color_f5f5f5);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
		recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

		registerMultiType();
		initListener();

	}

	private void registerMultiType() {
		pregnancyCheckModelViewBinder = new PregnancyCheckModelViewBinder();
		mAdapter.register(PregnancyCheckModel.class, pregnancyCheckModelViewBinder);

	}

	private void initListener() {
		if (pregnancyCheckModelViewBinder != null) {
			pregnancyCheckModelViewBinder.setListener(new PregnancyCheckModelViewBinder.OnPregnancyCheckBinderListener() {
				@Override
				public void onUpdateStatus(int pos, PregnancyCheckModel model) {
					model.flag = (model.flag == 0) ? 1 : 0;
					if (model.flag == 1) {
						CommonToast.showShortToast("完成一次产检，棒棒哒！");
					}
					if (pos >= 0 && pos < mItems.size()) {
						mAdapter.notifyItemChanged(pos);
					}
					// 保存信息到数据库
					PregnancyExamineManager.getInstance().update(model);
				}

				@Override
				public void onUpdateDate(int pos, PregnancyCheckModel model) {
					if (pos >= 0 && pos < mDataList.size()) {
						mDataList.set(pos, model);
					}
					// 保存信息到数据库
					PregnancyExamineManager.getInstance().update(model);

					updateDataList(mDataList);
				}
			});
		}
	}

	@Override
	public void handleFailed() {
		Ln.d("lihb handleFailed");
		if (mAdapter.getItemCount() > 0) {
			CommonToast.showShortToast(getString(R.string.list_empty_net_error));
			return;
		}

		if (ListUtils.isEmpty(mItems) && viewEmptyLayout != null) {
			viewEmptyLayout.showError();
		}
	}

	@Override
	public void handleEmpty() {
		Ln.d("lihb handleEmpty");
		if (mAdapter.getItemCount() > 0) {
			return;
		}

		if (viewEmptyLayout != null) {
			viewEmptyLayout.showEmpty();
		}
	}

	@Override
	public void updateDataList(List<PregnancyCheckModel> dataList) {
		Ln.d("lihb updateDataList, list size =%d", dataList.size());
		if (ListUtils.isEmpty(dataList)) {
			viewEmptyLayout.showEmpty();
			return;
		}
		mDataList = dataList;
		int minDiff = Integer.MAX_VALUE;  // 最近一次产检项目天数
		int nextIndex = -1;                  // 最近一次产检项目的index
		for (int i = 0, size = dataList.size(); i < size; i++) {
			PregnancyCheckModel model = dataList.get(i);
			Calendar calendar = getExamineDate(model.date);
			if (calendar != null) {
				long timeInMillis = StringUtils.getYearMonthDay(calendar.getTimeInMillis());
				long currTimeMillis = StringUtils.getYearMonthDay(System.currentTimeMillis());
				int diffDay = StringUtils.differentDays(currTimeMillis, timeInMillis);
				if (diffDay >= 0) {
					if (diffDay < minDiff) {
						minDiff = diffDay;
						nextIndex = i;
					}
					model.showFlag = PregnancyCheckModel.SHOW_FLAG_NOT_EXPIRE;
				} else {
					model.showFlag = PregnancyCheckModel.SHOW_FLAG_EXPIRED;
				}
			}
		}
		txtIntervalDays.setVisibility(nextIndex >= 0 ? View.VISIBLE : View.GONE);

		if (nextIndex >= 0) {
			PregnancyCheckModel remindModel = dataList.get(nextIndex); // 最近一次需要提醒的产检项目
			remindModel.showFlag = PregnancyCheckModel.SHOW_FLAG_NEXT_REMIND;
			mCalendar = getExamineDate(remindModel.date);
			txtIntervalDays.setText(Html.fromHtml(String.format(getString(R.string.txt_event_next_day_tips), "产检", minDiff)));
		}


		viewEmptyLayout.hideAllView();
		mItems.clear();
		mItems.addAll(dataList);

		mAdapter.notifyDataSetChanged();
		recyclerView.scrollToPosition(nextIndex > 0 ? nextIndex : 0); // 跳转到最近的一次需产检项目
	}


	@Override
	public void showToast(String msg) {
		CommonToast.showShortToast(msg);
	}


	private Calendar getExamineDate(String nowTime) {
		try {
			Date date = sdf.parse(nowTime);
			Calendar calendar = Calendar.getInstance(Locale.getDefault());
			calendar.setTime(date);
			return calendar;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}
}
