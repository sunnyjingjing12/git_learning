package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.bumptech.glide.Glide;
import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.customview.PregnancyCheckSubItemView;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.pregnancycheck.PregnancyCheckItem;
import com.itingbaby.app.model.pregnancycheck.PregnancyCheckReportImg;
import com.itingbaby.app.model.pregnancycheck.PregnancyCheckSubItem;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.camera.PhotoHelper;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.ItbEmptyViewLayout;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class PregnancyCheckDetailActivity extends BaseFragmentActivity {

	public static final String KEY_EXAMINATION_ID = "key_examination_id";

	private static final String KEY_EXAMINATION_TITLE = "key_examination_title";
	public static final int REQUEST_IMAGE_BROWSER = 100;

	private static final int WIDTH_HEIGHT = 1024;
	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.tv_pcd_weeks)
	TextView tvPcdWeeks;
	@BindView(R.id.pcd_items_layout)
	LinearLayout pcdItemsLayout;
	@BindView(R.id.tv_pcd_tips)
	TextView tvPcdTips;

	@BindView(R.id.empty_view_layout)
	ItbEmptyViewLayout emptyViewLayout;

	@BindView(R.id.upload_img_container)
	LinearLayout uploadImgContainer;

	@BindView(R.id.report_img_layout)
	ConstraintLayout reportImgLayout;

	@BindView(R.id.upload_img_layout)
	LinearLayout uploadImgLayout;

	@BindView(R.id.report_img_1)
	ImageView reportImg1;
	@BindView(R.id.report_img_2)
	ImageView reportImg2;
	@BindView(R.id.report_img_3)
	ImageView reportImg3;

	private int mExaminationId;

	private boolean[] hasImgFlag;
	private ImageView[] imageViews;
	private ArrayList<String> picStrList = new ArrayList<>();
	private PregnancyCheckItem mPregnancyCheckItem;

	public static void navigate(Context context, int examinationId, String title) {
		Intent intent = new Intent();
		intent.putExtra(KEY_EXAMINATION_ID, examinationId);
		intent.putExtra(KEY_EXAMINATION_TITLE, title);
		intent.setClass(context, PregnancyCheckDetailActivity.class);
		context.startActivity(intent);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pregnancy_check_detail);
		ButterKnife.bind(this);

		StatusBarUtil.StatusBarLightMode(this);

		emptyViewLayout.setEmptyViewMarginTopPercentHeight(0.3f);
		emptyViewLayout.setOnErrorBtnClickListener(v -> {
			if (BabyVoiceApp.mUserInfo != null) {
				sendGetPregnancyCheckDetailRequest(BabyVoiceApp.mUserInfo.id, mExaminationId);
			} else {
				CommonToast.showShortToast("请先登录甜贝APP");
				LoginActivity.navigate(this);
			}
		});
		initData();
		initListener();

		if (BabyVoiceApp.mUserInfo != null) {
			sendGetPregnancyCheckDetailRequest(BabyVoiceApp.mUserInfo.id, mExaminationId);
		} else {
			CommonToast.showShortToast("请先登录甜贝APP");
			LoginActivity.navigate(this);
		}

	}

	private void initData() {
		Intent i = getIntent();
		if (i != null) {
			if (i.hasExtra(KEY_EXAMINATION_ID)) {
				mExaminationId = i.getIntExtra(KEY_EXAMINATION_ID, 1);
			}
			if (i.hasExtra(KEY_EXAMINATION_TITLE)) {
				String title = i.getStringExtra(KEY_EXAMINATION_TITLE);
				titleBar.setTitle(String.format("%s小贴士", title));
			}
		}
		hasImgFlag = new boolean[]{false, false, false};
		imageViews = new ImageView[]{reportImg1, reportImg2, reportImg3};
	}

	private void initListener() {

		titleBar.setLeftOnClickListener(v -> {
			finish();
		});
		uploadImgLayout.setOnClickListener(v -> {
			selectImageFromAlbum();
		});


		handleImageViewClickEvent();
	}

	private void handleImageViewClickEvent() {
		for (int i = 0; i < imageViews.length; i++) {
			int finalI = i;
			imageViews[i].setOnClickListener(v -> {
				if (hasImgFlag[finalI]) {
					//打开图片
					startActivityForResult(ImageBrowseActivity.intentFor(PregnancyCheckDetailActivity.this, picStrList, finalI), REQUEST_IMAGE_BROWSER);
				} else {
					// 选择图片
					selectImageFromAlbum();
				}
			});
		}
	}

	/**
	 * 渲染view
	 *
	 * @param item
	 */
	private void renderView(PregnancyCheckItem item) {
		mPregnancyCheckItem = item;
		if (item == null) {
			emptyViewLayout.showEmpty();
		} else {
			tvPcdWeeks.setText(item.time);
			tvPcdTips.setText(item.tips.isEmpty() ? "" : item.tips);
			for (PregnancyCheckSubItem subItem : item.subItemList) {
				PregnancyCheckSubItemView itemView = new PregnancyCheckSubItemView(this);
				itemView.rendView(subItem);
				pcdItemsLayout.addView(itemView);
			}
			List<PregnancyCheckReportImg> reportImgList = item.reportImgList;
			if (reportImgList == null || reportImgList.isEmpty()) {
				updateImgLayoutVisibility(false);
			} else {
				updateImgLayoutVisibility(true);
				picStrList.clear();
				for (int i = 0, size = reportImgList.size(); i < size; i++) {
					PregnancyCheckReportImg reportImg = reportImgList.get(i);
					picStrList.add(ServiceGenerator.URL_IMG_SERVER + reportImg.url);
				}
				renderImageViewList();
			}
		}
	}

	/**
	 * 渲染3个图片
	 */
	private void renderImageViewList() {
		hasImgFlag = new boolean[]{false, false, false};
		for (ImageView imageView : imageViews) {
			imageView.setVisibility(View.INVISIBLE);
			imageView.setImageResource(R.drawable.ic_pcd_add_pic);
		}
		if (picStrList.isEmpty()) {
			updateImgLayoutVisibility(false);
			return;
		}
		for (int i = 0, size = picStrList.size(); i < size; i++) {
			if (i + 1 < imageViews.length) {
				imageViews[i + 1].setVisibility(View.VISIBLE);
			}
			showImg(picStrList.get(i), imageViews[i]);
			hasImgFlag[i] = true;
		}
	}

	/**
	 * 两个图片组件的显示和隐藏
	 */
	private void updateImgLayoutVisibility(boolean showReportImg) {
		uploadImgContainer.setVisibility(showReportImg ? View.GONE : View.VISIBLE);
		reportImgLayout.setVisibility(showReportImg ? View.VISIBLE : View.GONE);
	}

	/**
	 * 选择图片
	 */
	private void selectImageFromAlbum() {
		PhotoHelper.create(this)
				.setPreferredSize(WIDTH_HEIGHT, WIDTH_HEIGHT)
				.start();
	}

	/**
	 * gilde显示图片
	 *
	 * @param url
	 * @param imageView
	 */
	private void showImg(String url, ImageView imageView) {
		imageView.setVisibility(View.VISIBLE);
		Glide.with(this)
				.load(url)
				.placeholder(R.drawable.ic_pcd_add_pic)
				.error(R.drawable.ic_pcd_add_pic)
				.dontAnimate()
				.into(imageView);
	}


	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == RESULT_OK) {
			switch (requestCode) {
				case PhotoHelper.REQUEST_TAKE_PICTURE:
					String picturePath = data.getStringExtra(PhotoHelper.OUTPUT_PATH);
					updateImgLayoutVisibility(true);
					for (int i = 0, size = imageViews.length; i < size; i++) {
						if (i + 1 < size) {
							imageViews[i + 1].setVisibility(View.VISIBLE);
						}
						if (!hasImgFlag[i]) {
							showImg(picturePath, imageViews[i]);
							hasImgFlag[i] = true;
							sendReportExaminationImgRequest(mExaminationId, picturePath);
							break;
						}
					}
					break;
				case REQUEST_IMAGE_BROWSER:
					ArrayList<String> leftImgs = data.getStringArrayListExtra("images");
					picStrList = leftImgs;
					renderImageViewList();

					ArrayList<Integer> delImgsId = new ArrayList<>();
					List<PregnancyCheckReportImg> reportImgList = mPregnancyCheckItem.reportImgList;
					for (PregnancyCheckReportImg reportImg : reportImgList) {
						boolean findFlag = false;
						for (String str2 : leftImgs) {
							if (str2.contains(reportImg.url)) {
								findFlag = true;
								break;
							}
						}
						if (!findFlag) {
							delImgsId.add(reportImg.id);
						}
					}

					sendDelReportExaminationImgRequest(BabyVoiceApp.mUserInfo.id, delImgsId);
					break;
			}
		}

	}


	/**
	 * 发送协议
	 */
	private void sendGetPregnancyCheckDetailRequest(long uid, int examinationId) {
		ServiceGenerator.createService(ApiManager.class)
				.getPregnancyCheckDetail(uid, examinationId)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.doOnTerminate(() -> Ln.d("lihb getPregnancyCheckDetail doOnTerminate"))
				.subscribe(httpResponse -> {
					if (ResponseCode.RESPONSE_OK == httpResponse.code) {
						PregnancyCheckItem item = httpResponse.data;
						renderView(item);
						emptyViewLayout.hideAllView();
					} else {
						CommonToast.showShortToast(httpResponse.msg);
					}
				}, throwable -> {
					Ln.e(throwable);
					emptyViewLayout.showError();
				});
	}

	private void sendDelReportExaminationImgRequest(long uid, List<Integer> picIds) {
		ServiceGenerator.createService(ApiManager.class)
				.delExaminationImg(uid, picIds)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.doOnTerminate(() -> Ln.d("lihb getPregnancyCheckDetail doOnTerminate"))
				.subscribe(httpResponse -> {
					if (ResponseCode.RESPONSE_OK == httpResponse.code) {
						Ln.d("删除成功");
					} else {
						CommonToast.showShortToast(httpResponse.msg);
					}
				}, throwable -> Ln.e(throwable));
	}

	private void sendReportExaminationImgRequest(int examinationId, String picturePath) {

		List<File> fileList = new ArrayList<>();
		File file = null;
		if (!StringUtils.isBlank(picturePath)) {
			file = new File(picturePath);
		}

		if (file == null || !file.exists()) {
			Ln.i("no pic to upload!!");
		} else {
			fileList.add(file);
		}
		MultipartBody body = filesToMultipartBody(examinationId, fileList);
		ServiceGenerator.createService(ApiManager.class)
				.reportExaminationImg(body)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.doOnTerminate( ()-> Ln.d("lihb sendReportExaminationImgRequest doOnTerminate"))
				.subscribe(httpResponse -> {
					if (ResponseCode.RESPONSE_OK == httpResponse.code) {
						Ln.d("lihb sendReportExaminationImgRequest success");
						List<PregnancyCheckReportImg> reportImgList = httpResponse.data;
						for (int i = 0, size = reportImgList.size(); i < size; i++) {
							PregnancyCheckReportImg reportImg = reportImgList.get(i);
							picStrList.add(ServiceGenerator.URL_IMG_SERVER + reportImg.url);
						}
					} else {
						CommonToast.showShortToast(httpResponse.msg);
					}
				}, throwable -> Ln.e(throwable));
	}

	private MultipartBody filesToMultipartBody(int eid, List<File> files) {
		MultipartBody.Builder builder = new MultipartBody.Builder();
		builder.addFormDataPart("uid", Long.toString(BabyVoiceApp.mUserInfo.id));
		builder.addFormDataPart("eid", Integer.toString(eid));
		if (files.size() > 0) {
			for (File file : files) {
				RequestBody requestBody = RequestBody.create(MediaType.parse(""), file);
				builder.addFormDataPart("files", file.getName(), requestBody);
			}
		} else {
			builder.addFormDataPart("", "");
		}
		builder.setType(MultipartBody.FORM);
		MultipartBody multipartBody = builder.build();
		return multipartBody;
	}



}
