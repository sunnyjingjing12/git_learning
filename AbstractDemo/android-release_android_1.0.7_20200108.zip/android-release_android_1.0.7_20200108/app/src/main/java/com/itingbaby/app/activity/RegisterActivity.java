package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.itingbaby.app.Constant;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.User;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.GenerateBitmapCodeUtil;
import com.itingbaby.app.utils.SoftInputUtil;
import com.itingbaby.baselib.commonutils.ApplicationUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.umeng.analytics.MobclickAgent;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.RequestBody;

/**
 * Created by lhb on 2017/4/1.
 */
public class RegisterActivity extends BaseFragmentActivity {

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.txt_register)
	TextView txtRegister;
	@BindView(R.id.edit_account)
	EditText editAccount;
	@BindView(R.id.img_clear_account)
	ImageView imgClearAccount;
	@BindView(R.id.account_layout)
	RelativeLayout accountLayout;
	@BindView(R.id.edit_password)
	EditText editPassword;
	@BindView(R.id.img_clear_password)
	ImageView imgClearPassword;
	@BindView(R.id.img_open_password)
	ImageView imgOpenPassword;
	@BindView(R.id.password_layout)
	RelativeLayout passwordLayout;
	@BindView(R.id.edit_verify)
	EditText editVerify;
	@BindView(R.id.img_code)
	ImageView imgCode;
	@BindView(R.id.txt_next_code)
	TextView txtNextCode;
	@BindView(R.id.verify_layout)
	RelativeLayout verifyLayout;
	@BindView(R.id.txt_register_btn)
	TextView txtRegisterBtn;
	@BindView(R.id.sms_check_box)
	CheckBox smsCheckBox;
	@BindView(R.id.txt_sms_protocol)
	TextView txtSmsProtocol;
	@BindView(R.id.divider_line_account)
	View dividerLineAccount;
	@BindView(R.id.divider_line_password)
	View dividerLinePassword;
	@BindView(R.id.divider_line_verify)
	View dividerLineVerify;

	private boolean mIsPwdVisible = false;
	private String mCurrCode = "";


	public static void navigate(Context context) {
		Intent intent = new Intent();
		intent.setClass(context, RegisterActivity.class);
		context.startActivity(intent);
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);
		ButterKnife.bind(this);
		initView();

		initListener();

	}

	@Override
	protected void onResume() {
		super.onResume();
		MobclickAgent.onPageStart("RegisterActivity");
		MobclickAgent.onResume(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		MobclickAgent.onPageEnd("RegisterActivity");
		MobclickAgent.onPause(this);
	}

	private void initView() {
		txtRegisterBtn.setEnabled(false);
		txtSmsProtocol.setText(Html.fromHtml(getString(R.string.txt_agree_protocol)));
		generateImgCode();
	}

	private void initListener() {
		titleBar.setLeftOnClickListener(v -> finish());

		txtNextCode.setOnClickListener(v -> generateImgCode());

		txtRegisterBtn.setOnClickListener(v -> {
			validateToRegister();
			SoftInputUtil.hideSoftInput(RegisterActivity.this);
		});

		imgClearAccount.setOnClickListener(v -> editAccount.setText(""));
		imgClearPassword.setOnClickListener(v -> editPassword.setText(""));

		editAccount.setOnFocusChangeListener((v, hasFocus) ->
				dividerLineAccount.setBackgroundColor(hasFocus ? getResources().getColor(R.color.white) : getResources().getColor(R.color.color_ffffff_10)));

		editPassword.setOnFocusChangeListener((v, hasFocus) ->
				dividerLinePassword.setBackgroundColor(hasFocus ? getResources().getColor(R.color.white) : getResources().getColor(R.color.color_ffffff_10)));

		editVerify.setOnFocusChangeListener((v, hasFocus) ->
				dividerLineVerify.setBackgroundColor(hasFocus ? getResources().getColor(R.color.white) : getResources().getColor(R.color.color_ffffff_10)));

		imgOpenPassword.setOnClickListener(v -> {
			if (!mIsPwdVisible) {
				editPassword.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
				imgOpenPassword.setImageResource(R.drawable.ic_display);
				mIsPwdVisible = true;
			} else {
				editPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
				imgOpenPassword.setImageResource(R.drawable.ic_not_display);
				mIsPwdVisible = false;
			}
			// 光标移到最后
			editPassword.setSelection(editPassword.getText().length());
		});

		editAccount.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {

			}

			@Override
			public void afterTextChanged(Editable s) {
				if (s.length() > 0) {
					imgClearAccount.setVisibility(View.VISIBLE);
					if (editPassword.getText().length() > 0 && editVerify.getText().length() > 0) {
						txtRegisterBtn.setEnabled(true);
					}
				} else {
					imgClearAccount.setVisibility(View.GONE);
					txtRegisterBtn.setEnabled(false);
				}
				Ln.d("[lihb register] 账户文字改变, txtRegisterBtn enable = %b", txtRegisterBtn.isEnabled());

			}
		});

		editPassword.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {

			}

			@Override
			public void afterTextChanged(Editable s) {
				if (s.length() > 0) {
					imgClearPassword.setVisibility(View.VISIBLE);
					imgOpenPassword.setVisibility(View.VISIBLE);
					if (editAccount.getText().length() > 0 && editVerify.getText().length() > 0) {
						txtRegisterBtn.setEnabled(true);
					}
				} else {
					imgClearPassword.setVisibility(View.GONE);
					imgOpenPassword.setVisibility(View.GONE);
					txtRegisterBtn.setEnabled(false);
				}

				Ln.d("[lihb register] 密码文字改变, txtRegisterBtn enable = %b", txtRegisterBtn.isEnabled());
			}
		});

		editVerify.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {

			}

			@Override
			public void afterTextChanged(Editable s) {
				if (s.length() > 0) {
					if (editAccount.getText().length() > 0 && editPassword.getText().length() > 0) {
						txtRegisterBtn.setEnabled(true);
					}
				} else {
					txtRegisterBtn.setEnabled(false);
				}

				Ln.d("[lihb register] 验证码文字改变, txtRegisterBtn enable = %b", txtRegisterBtn.isEnabled());
			}
		});
	}

	/**
	 * 生成图片验证码
	 */
	private void generateImgCode() {
		ApplicationUtils.mMainHandler.postDelayed(() -> {
			imgCode.setImageBitmap(GenerateBitmapCodeUtil.getInstance().setSize(imgCode.getWidth(), imgCode.getHeight()).createBitmap());
			mCurrCode = GenerateBitmapCodeUtil.getInstance().getCode();
			Ln.d("[lihb register] mCurrCode = %s", mCurrCode);
		}, 50);

	}


	/**
	 * 登录验证逻辑
	 * 1、先检查验证码
	 * 2、账户是否合法
	 * 3、密码是否为空
	 */
	private void validateToRegister() {
		String account = editAccount.getText().toString();
		String password = editPassword.getText().toString();
		String code = editVerify.getText().toString();

		if (!smsCheckBox.isChecked()) {
			CommonToast.showShortToast(getString(R.string.agree_protocol));
		} else if (!StringUtils.areEqual(code, mCurrCode, true)) {
			CommonToast.showShortToast("验证码不正确");
		} else if (!StringUtils.checkMail(account) && !StringUtils.checkPhoneNumber(account)) {
			CommonToast.showShortToast(getString(R.string.input_correct_phone_or_email_account));
		} else if (password.length() < 6 || password.length() > 16) {
			CommonToast.showShortToast("请输入6-16位的密码");
		} else {
			register(account, StringUtils.stringToMd5(password));
		}
	}

	private void register(String userAccount, String password) {

		showProgressDialog(getString(R.string.txt_registering), false, null);

		ServiceGenerator.createService(ApiManager.class)
				.register(RequestBody.create(MediaType.parse("multipart/form-data"), userAccount), RequestBody.create(MediaType.parse("multipart/form-data"), password))
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribe(httpResponse -> {
					dismissProgressDialog();
					if (httpResponse.code == ResponseCode.RESPONSE_OK) {
						CommonToast.showShortToast(getString(R.string.txt_register_success));

						final User userInfo = httpResponse.data;
						Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);

						if (null == userInfo) {
							// TODO 是否提示用户设置用户名
						}
						if (null != userInfo.mobile) {
							intent.putExtra("account", userInfo.mobile);
						}
						if (null != userInfo.email) {
							intent.putExtra("account", userInfo.email);
						}
						startActivity(intent);
						finish();
					} else if (httpResponse.code == 1102) { // 用户已经注册
						CommonToast.showShortToast(httpResponse.msg);
						Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
						startActivity(intent);
						finish();
					} else {
						CommonToast.showShortToast(httpResponse.msg);
					}
				}, throwable -> {
					dismissProgressDialog();
					CommonToast.showShortToast(getString(R.string.txt_register_fail));
					Ln.e("error:", throwable.toString());
				});

	}

	@OnClick({R.id.txt_protocol, R.id.txt_privacy})
	public void onViewClicked(View view) {
		switch (view.getId()) {
			case R.id.txt_protocol:
				WebViewActivity.navigate(this, Constant.USER_AGREEMENT, getString(R.string.txt_app_service_protocol));
				break;
			case R.id.txt_privacy:
				WebViewActivity.navigate(this, Constant.PRIVACY_WEB_SITE, getString(R.string.txt_app_privacy));
				break;
		}
	}
}
