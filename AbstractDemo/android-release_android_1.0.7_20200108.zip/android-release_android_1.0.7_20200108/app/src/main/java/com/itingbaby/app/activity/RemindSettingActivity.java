package com.itingbaby.app.activity;

import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;

import com.bigkoo.pickerview.builder.OptionsPickerBuilder;
import com.bigkoo.pickerview.view.OptionsPickerView;
import com.itingbaby.app.R;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.AlarmEntity;
import com.itingbaby.app.utils.AlarmTimerUtil;
import com.itingbaby.app.utils.CommonNotificationUtils;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.db.ExaminationAlarmManager;
import com.itingbaby.app.utils.db.VaccineAlarmManager;
import com.itingbaby.baselib.commonutils.ApplicationContext;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;

public class RemindSettingActivity extends BaseFragmentActivity {

	public static final String KEY_FROM_TYPE = "key_from_type";
	public static final String KEY_CALENDAR = "key_calendar";

	public static final int FROM_VACCINE = 0;
	public static final int FROM_PREGNANCY_CARE = 1;
	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.switch_remind)
	Switch switchRemind;
	@BindView(R.id.remind_switch_layout)
	RelativeLayout remindSwitchLayout;
	@BindView(R.id.tv_remind_tips)
	TextView tvRemindTips;
	@BindView(R.id.tv_remind_time)
	TextView tvRemindTime;
	@BindView(R.id.remind_time_layout)
	RelativeLayout remindTimeLayout;

	private int mCurrType = FROM_VACCINE;

	private ArrayList<String> options1Items = new ArrayList<>();
	private ArrayList<String> options2Items = new ArrayList<>();
	private ArrayList<String> options3Items = new ArrayList<>();
	private AlarmEntity mAlarm;
	private Calendar mCalendar;  //最近一次需要提醒的日期


	public static void navigate(Context context, int fromType, Calendar calendar) {
		Intent intent = new Intent();
		intent.setClass(context, RemindSettingActivity.class);
		intent.putExtra(KEY_FROM_TYPE, fromType);
		intent.putExtra(KEY_CALENDAR, calendar);
		context.startActivity(intent);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_remind_setting);
		ButterKnife.bind(this);
		initData();

		initView();

		initListener();

	}

	private void initView() {
		StatusBarUtil.StatusBarLightMode(this);

		mAlarm = (mCurrType == FROM_VACCINE) ? VaccineAlarmManager.getInstance().getAlarm()
				: ExaminationAlarmManager.getInstance().getAlarm();
		if (mAlarm != null) {
			tvRemindTime.setText(String.format("%s %s%s", options1Items.get(mAlarm.type), options2Items.get(mAlarm.hour), options3Items.get(mAlarm.minute)));
			switchRemind.setChecked(mAlarm.switchs == 1);
			tvRemindTips.setText(mAlarm.switchs == 1 ? "关闭提醒" : "开启提醒");
		} else {
			tvRemindTime.setText(String.format("%s %s%s", options1Items.get(0), options2Items.get(8), options3Items.get(30)));
			switchRemind.setChecked(true);
			tvRemindTips.setText("关闭提醒");
		}
		remindTimeLayout.setVisibility(switchRemind.isChecked() ? View.VISIBLE : View.GONE);

		titleBar.setTitle((mCurrType == FROM_VACCINE) ? "疫苗提醒设置" : "产检提醒设置");

	}


	private void initListener() {
		titleBar.setLeftOnClickListener(v -> {
			finish();
		});

		switchRemind.setOnCheckedChangeListener((buttonView, isChecked) -> {
			remindTimeLayout.setVisibility(isChecked ? View.VISIBLE : View.GONE);
			tvRemindTips.setText(isChecked ? "关闭提醒" : "开启提醒");
			// 保存信息到数据库
			if (mAlarm != null) {
				mAlarm.switchs = isChecked ? 1 : 0;
				saveDataToDB(mAlarm);
			}
		});

		remindTimeLayout.setOnClickListener(v -> {
			showPickerView();
		});

	}

	private void initData() {
		Intent i = getIntent();
		if (i != null) {
			if (i.hasExtra(KEY_FROM_TYPE)) {
				mCurrType = i.getIntExtra(KEY_FROM_TYPE, 0);
			}
			if (i.hasExtra(KEY_CALENDAR)) {
				mCalendar = (Calendar) i.getSerializableExtra(KEY_CALENDAR);
			}
		}

		setPickViewData();
	}

	private void showPickerView() {
		OptionsPickerView pvOptions = new OptionsPickerBuilder(this, (options1, options2, options3, v) -> {
			//返回的分别是三个级别的选中位置
			String opt1tx = options1Items.size() > 0 ?
					options1Items.get(options1) : "";

			String opt2tx = options2Items.size() > 0 ?
					options2Items.get(options2) : "";

			String opt3tx = options2Items.size() > 0 ?
					options3Items.get(options3) : "";

			String tx = opt1tx + " " + opt2tx + opt3tx;
			tvRemindTime.setText(tx);

			// 保存信息到数据库
			if (mAlarm != null) {
				mAlarm.type = options1;
				mAlarm.hour = options2;
				mAlarm.minute = options3;
				mAlarm.switchs = 1;
				saveDataToDB(mAlarm);
			}

		})
				.setTitleText("请设置时间")
				.setCancelColor(getResources().getColor(R.color.color_00bed7))
				.setSubmitColor(getResources().getColor(R.color.color_00bed7))
				.setDividerColor(Color.BLACK)
				.setTextColorCenter(Color.BLACK) //设置选中项文字颜色
				.setContentTextSize(18)
				.build();

		pvOptions.setNPicker(options1Items, options2Items, options3Items);//三级选择器
		if (mAlarm != null) {
			pvOptions.setSelectOptions(mAlarm.type, mAlarm.hour, mAlarm.minute);
		} else {
			pvOptions.setSelectOptions(0, 8, 30);
		}
		pvOptions.show();
	}

	private void setPickViewData() {

		String preTypeStr = mCurrType == FROM_VACCINE ? "每次疫苗" : "每次产检";
		options1Items.add(preTypeStr + "前三天");
		options1Items.add(preTypeStr + "前一天");
		options1Items.add(preTypeStr + "当天");

		for (int i = 0; i < 24; i++) {
			options2Items.add(String.format(Locale.getDefault(), "%02d时", i));
		}

		for (int i = 0; i < 60; i++) {
			options3Items.add(String.format(Locale.getDefault(), "%02d分", i));
		}

	}

	private void saveDataToDB(AlarmEntity entity) {
		boolean flag = false;
		if (mCurrType == FROM_VACCINE) {
			flag = VaccineAlarmManager.getInstance().update(entity);
		} else if (mCurrType == FROM_PREGNANCY_CARE) {
			flag = ExaminationAlarmManager.getInstance().update(entity);
		}
		// 设置提醒
		// 先取消之前设置的
		String action = (mCurrType == FROM_VACCINE) ? AlarmTimerUtil.TIMER_ACTION_VACCINE : AlarmTimerUtil.TIMER_ACTION_EXAMINATION;
		AlarmTimerUtil.cancelAlarmTimer(ApplicationContext.getContext(), action);
		if (flag && entity.switchs == 1) {
			Calendar calendar = getRemindCalendar(entity);
			if (calendar != null && calendar.getTimeInMillis() > System.currentTimeMillis()) {
				String extra = (calendar.get(Calendar.MONTH) + 1) + "月" + calendar.get(Calendar.DAY_OF_MONTH) + "日";
				if (!CommonNotificationUtils.isNotificationEnabled(this)) {
					CommonToast.showShortToast("请先开启通知栏权限");
					CommonNotificationUtils.requestPermission(this);
				} else {
					AlarmTimerUtil.setAlarmTimer(ApplicationContext.getContext(), calendar.getTimeInMillis(), action, extra, AlarmManager.RTC_WAKEUP);
				}
			}
		}

	}

	private Calendar getRemindCalendar(AlarmEntity entity) {
		if (mCalendar != null) {
			int day = 0;
			if (entity.type == 0) {
				day = -3;
			} else if (entity.type == 1) {
				day = -1;
			} else if (entity.type == 2) {
				day = 0;
			}
			Calendar calendar = Calendar.getInstance();
			calendar.setTimeInMillis(mCalendar.getTimeInMillis());
			calendar.add(Calendar.DAY_OF_MONTH, day);
			calendar.set(Calendar.HOUR, entity.hour);
			calendar.set(Calendar.MINUTE, entity.minute);
			return calendar;
		}
		return null;

	}
}
