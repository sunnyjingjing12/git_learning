package com.itingbaby.app.activity;

import android.os.Bundle;

import com.journeyapps.barcodescanner.CaptureActivity;

/**
 * Created by lihb on 2018/2/3.
 */

public class ScanActivity extends CaptureActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }
}
