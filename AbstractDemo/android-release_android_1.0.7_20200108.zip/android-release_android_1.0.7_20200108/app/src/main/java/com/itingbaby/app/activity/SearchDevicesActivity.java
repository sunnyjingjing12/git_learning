package com.itingbaby.app.activity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.SparseArray;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.components.ISearchDeviceComponent;
import com.itingbaby.app.components.presenter.SearchDevicePresenter;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.AudioType;
import com.itingbaby.app.model.BleDeviceWrapper;
import com.itingbaby.app.model.DaoSession;
import com.itingbaby.app.model.HistoryBleDeviceModel;
import com.itingbaby.app.model.HistoryBleDeviceModelDao;
import com.itingbaby.app.model.SimpleTextItem;
import com.itingbaby.app.utils.CobubConfigUtil;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.viewbinder.BluetoothDeviceViewBinder;
import com.itingbaby.app.viewbinder.SimpleTextItemViewBinder;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.PermissionCheckUtil;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.ItbEmptyViewLayout;
import com.itingbaby.baselib.views.widget.swipeviews.RefreshLoadRecyclerLayout;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;
import com.itingbaby.dev.DeviceType;
import com.itingbaby.dev.events.EventBleDeviceConnectStatus;
import com.itingbaby.dev.events.EventBleRuntimeDetectPowerStatus;
import com.itingbaby.dev.iTingBabyBleDevice;
import com.itingbaby.dev.iTingBabyBleDeviceManager;
import com.tbruyelle.rxpermissions2.RxPermissions;
import com.umeng.analytics.MobclickAgent;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.drakeet.multitype.MultiTypeAdapter;

/**
 * Created by lihb on 2018/6/29.
 */
public class SearchDevicesActivity extends BaseFragmentActivity implements ISearchDeviceComponent.IView {

	private static final String TAG = "SearchDevicesActivity";

	public static final String KEY_RECORD_TYPE = "record_type";
	private static final long SCAN_TIME_DURATION = 10000;

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.swipe_refresh_layout)
	RefreshLoadRecyclerLayout swipeRefreshLayout;
	@BindView(R.id.view_empty_layout)
	ItbEmptyViewLayout viewEmptyLayout;

	private int recordType;
	private boolean isScanning;
	private Animation operatingAnim;

	private SwipeRecyclerView recyclerView;
	private MultiTypeAdapter mAdapter;

	private List mItems = new ArrayList<>();

	private BluetoothDeviceViewBinder mBluetoothDeviceViewBinder;

	private SearchDevicePresenter mPresenter;

	private SparseArray<String> bleDeviceFilter = new SparseArray<>();

	private final RxPermissions rxPermissions = new RxPermissions(this);


	public static void navigate(Context context, int recordType) {
		Intent intent = new Intent();
		intent.putExtra(KEY_RECORD_TYPE, recordType);
		intent.setClass(context, SearchDevicesActivity.class);
		context.startActivity(intent);
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		iTingBabyBleDeviceManager.getInstance().setBleDeviceNameFilter(new String[]{ "TBB" });
		EventBus.getDefault().register(this);

		setContentView(R.layout.activity_search_device);
		ButterKnife.bind(this);

		initView();
		initData();
		initListener();

	}

	@Override
	protected void onDestroy() {
		EventBus.getDefault().unregister(this);
		super.onDestroy();
	}

	@Override
	protected void onPause() {
		super.onPause();
		iTingBabyBleDeviceManager.getInstance().stopScan();
		initLoadingView(false);
	}

	private void initView() {
		initRefreshLayout();

		// 设置无数据页面
		viewEmptyLayout.setEmptyViewMarginTopPercentHeight(0.3f);
		viewEmptyLayout.setEmptyMessage(getString(R.string.load_empty_msg));
		viewEmptyLayout.setEmptyImageRes(R.drawable.empty_data);

		operatingAnim = AnimationUtils.loadAnimation(this, R.anim.rotate);
		operatingAnim.setInterpolator(new LinearInterpolator());

		StatusBarUtil.StatusBarLightMode(this);
	}

	private void initData() {
		if (getIntent() != null && getIntent().hasExtra(KEY_RECORD_TYPE)) {
			recordType = getIntent().getIntExtra(KEY_RECORD_TYPE, AudioType.AUDIO_TYPE_BABY);
		}
		mPresenter = new SearchDevicePresenter(this);
		mPresenter.getBleDeviceData();
	}

	private void initListener() {
		titleBar.setLeftOnClickListener(v -> {
			Ln.i("click left button");
			finish();
		});

		titleBar.setRightOnClickListener(v -> {
			rxPermissions.request(Manifest.permission.ACCESS_FINE_LOCATION).subscribe(granted -> {
				if (granted) { // Always true pre-M
					if (isScanning) {
						iTingBabyBleDeviceManager.getInstance().stopScan();
						initLoadingView(false);
					} else {
						clearBleDeviceView();
						iTingBabyBleDeviceManager.getInstance().scan(SCAN_TIME_DURATION, scanCallback);
					}
				} else {
					PermissionCheckUtil.showGrantFailDialog(this, R.string.grant_location_permission);
				}
			});
		});

		mBluetoothDeviceViewBinder.setOnDeviceClickListener(new BluetoothDeviceViewBinder.OnDeviceClickListener() {
			@Override
			public void onConnect(iTingBabyBleDevice device) {
				rxPermissions.request(Manifest.permission.ACCESS_FINE_LOCATION).subscribe(granted -> {
					if (granted) { // Always true pre-M
						initLoadingView(false);
						iTingBabyBleDeviceManager.getInstance().connect(device);
					} else {
						PermissionCheckUtil.showGrantFailDialog(SearchDevicesActivity.this, R.string.grant_location_permission);
					}
				});
			}

			@Override
			public void onDisConnect(String mac) {

			}

			@Override
			public void onDetail(String mac) {

			}
		});
	}

	private void initRefreshLayout() {
		viewEmptyLayout.setOnErrorBtnClickListener(v -> {
			if (mPresenter != null) {
				mPresenter.getBleDeviceData();
			}
		});

		recyclerView = swipeRefreshLayout.getSwipeRecyclerView();
		mAdapter = new MultiTypeAdapter(mItems);

		swipeRefreshLayout.setAdapter(mAdapter);
		swipeRefreshLayout.setCanRefresh(false);
		swipeRefreshLayout.setCanLoadMore(false);
		swipeRefreshLayout.setToggleLoadCount(4);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
		recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

		mAdapter.register(SimpleTextItem.class, new SimpleTextItemViewBinder());
		mBluetoothDeviceViewBinder = new BluetoothDeviceViewBinder();
		mAdapter.register(BleDeviceWrapper.class, mBluetoothDeviceViewBinder);

	}

	private void clearBleDeviceView() {
		bleDeviceFilter.clear();
		if (mPresenter != null) {
			mPresenter.clearNearbyDeviceList();
			mPresenter.getBleDeviceData();
		}
	}


	private void initLoadingView(boolean flag) {
		isScanning = flag;
		TextView rightText = titleBar.getRightText();
		if (isScanning) {
			rightText.startAnimation(operatingAnim);
		} else {
			rightText.clearAnimation();
		}
	}


	@Override
	public void handleFailed() {
		if (mAdapter.getItemCount() > 0) {
			CommonToast.showShortToast(getString(R.string.list_empty_net_error));
			return;
		}

		if (ListUtils.isEmpty(mItems) && viewEmptyLayout != null) {
			viewEmptyLayout.showError();
		}
	}

	@Override
	public void handleEmpty() {
		Ln.d("lihb handleEmpty");
		if (mAdapter.getItemCount() > 0) {
			return;
		}

		if (viewEmptyLayout != null) {
			viewEmptyLayout.setEmptyImageRes(R.drawable.empty_data);
			viewEmptyLayout.showEmpty();
		}
	}

	@Override
	public void updateDataList(List<HistoryBleDeviceModel> dataList, List<iTingBabyBleDevice> bleDevices) {
		mItems.clear();

		if (!ListUtils.isEmpty(dataList)) {
			SimpleTextItem simpleTextItem = new SimpleTextItem.Builder()
					.title(getString(R.string.txt_history_device))
					.textColor(R.color.color_000000_30)
					.background(R.drawable.bg_bluetooth_text_shape)
					.build();

			mItems.add(simpleTextItem);
			for (HistoryBleDeviceModel model : dataList) {
				BleDeviceWrapper wrapper = new BleDeviceWrapper();
				wrapper.historyBleDeviceModel = model;
				wrapper.bleDevice = iTingBabyBleDeviceManager.getInstance().createBleDevice(model.getMac(), model.getBleType());
				mItems.add(wrapper);
			}
		}

		if (!ListUtils.isEmpty(bleDevices)) {
			SimpleTextItem simpleTextItem = new SimpleTextItem.Builder()
					.title(getString(R.string.nearby_device))
					.textColor(R.color.color_000000_30)
					.background(R.drawable.bg_bluetooth_text_shape)
					.build();

			mItems.add(simpleTextItem);
			for (iTingBabyBleDevice device : bleDevices) {
				BleDeviceWrapper wrapper = new BleDeviceWrapper();
				wrapper.bleDevice = device;
				mItems.add(wrapper);
			}
		}
		SimpleTextItem otherSimpleTextItem = new SimpleTextItem.Builder()
				.title(getString(R.string.other_device))
				.textColor(R.color.color_000000_30)
				.background(R.drawable.bg_bluetooth_text_shape)
				.build();

		mItems.add(otherSimpleTextItem);
		BleDeviceWrapper wrapper = new BleDeviceWrapper("凯格尔训练仪", DeviceType.DEVICE_TYPE_KEGEL);
		mItems.add(wrapper);

		viewEmptyLayout.hideAllView();
		mAdapter.notifyDataSetChanged();
	}

	@Override
	public void showToast(String msg) {
		CommonToast.showShortToast(msg);
	}

	// region EventBus事件

	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onBluetoothPowerStatus(EventBleRuntimeDetectPowerStatus event) {
		DaoSession daoSession = BabyVoiceApp.getInstance().getDaoSession();
		HistoryBleDeviceModelDao deviceModelDao = daoSession.getHistoryBleDeviceModelDao();
		deviceModelDao.deleteAll();// 因为蓝牙开关关闭后，所有之前临时保存的设备信息都清空了
		clearBleDeviceView();
	}

	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onBleDeviceConnectionStatus(EventBleDeviceConnectStatus event) {
		Ln.d("lihb " + event.toString());
		int status = event.getStatus();
		if (EventBleDeviceConnectStatus.CONNECTION_STATUS_CONNECTING == status) {
			showProgressDialog(getString(R.string.txt_ble_connecting), true, ()->{
				iTingBabyBleDeviceManager.getInstance().disconnect();
			});
		} else if (EventBleDeviceConnectStatus.CONNECTION_STATUS_CONNECTED == status) {
			dismissProgressDialog();
			if (DeviceType.DEVICE_TYPE_TBB == event.getDevType()) {
				BlueToothRecordActivity.navigate(SearchDevicesActivity.this, recordType);
				saveHistoryBleDevice(event);
				postConnectedEvent(event.getDevType(), event.getDevMac());// 打点
			} else if (DeviceType.DEVICE_TYPE_EHG == event.getDevType()) {
				CardiographActivity.navigate(SearchDevicesActivity.this);
			}
			// 上报连接设备
			if (mPresenter != null) {
				mPresenter.reportUserDevice(BabyVoiceApp.mUserInfo.id, DeviceType.DEVICE_TYPE_TBB, event.getDevMac());
			}
		} else if (EventBleDeviceConnectStatus.CONNECTION_STATUS_DISCONNECTED == status) {
			dismissProgressDialog();
			clearBleDeviceView();
			CommonToast.showLongToast(getString(R.string.txt_ble_disconnect));
		}
	}

	// endregion


	/**
	 * 插入数据库
	 */
	private void saveHistoryBleDevice(EventBleDeviceConnectStatus event) {
		if (event == null) {
			return;
		}

		DaoSession daoSession = BabyVoiceApp.getInstance().getDaoSession();
		HistoryBleDeviceModelDao deviceModelDao = daoSession.getHistoryBleDeviceModelDao();
		HistoryBleDeviceModel model = new HistoryBleDeviceModel(BabyVoiceApp.mUserInfo.id, event.getDevType(), event.getDevBleType(), event.getDevName(), event.getDevMac(), System.currentTimeMillis());
		deviceModelDao.insertOrReplaceInTx(model);

	}

	/**
	 * 设备连接成功上报打点
	 *
	 * @param devType 设备类型
	 * @param devMac  设备mac地址
	 */
	private void postConnectedEvent(int devType, String devMac) {
		HashMap<String, String> map = new HashMap<>();
		map.put("deviceType", String.valueOf(devType));
		map.put("mac", devMac);
		MobclickAgent.onEvent(this, CobubConfigUtil.EVENT_CONNECTED_DEVICE, map);
	}

	private iTingBabyBleDeviceManager.ScanCallback scanCallback = new iTingBabyBleDeviceManager.ScanCallback() {
		@Override
		public void scanStarted() {
			initLoadingView(true);
		}

		@Override
		public void scanTimeout() {
			initLoadingView(false);
		}

		@Override
		public void scanFound(iTingBabyBleDevice device) {
			Ln.d("lihb EventBleDeviceScanFound ,event=%s", device.toString());
			for (int i=0; i<bleDeviceFilter.size(); ++i) {
				String mac = bleDeviceFilter.valueAt(i);
				if (mac.equals(device.getAddress())) {
					return;
				}
			}
			// 拿数据
			if (mPresenter != null) {
				mPresenter.addNearbyDeviceList(device);
				mPresenter.getBleDeviceData();
			}
		}
	};
}
