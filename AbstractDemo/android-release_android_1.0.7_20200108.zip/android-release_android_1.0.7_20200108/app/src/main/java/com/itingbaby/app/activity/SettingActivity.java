package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;

import com.bigkoo.pickerview.builder.OptionsPickerBuilder;
import com.bigkoo.pickerview.listener.OnOptionsSelectListener;
import com.bigkoo.pickerview.view.OptionsPickerView;
import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.Constant;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.components.IProfileSettingComponent;
import com.itingbaby.app.components.presenter.ProfileSettingPresenter;
import com.itingbaby.app.customview.CommonItem;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.User;
import com.itingbaby.app.upgrade.UpgradeUtil;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.SharedPreferencesUtil;
import com.itingbaby.app.utils.SimpleDatePickerDialog;
import com.itingbaby.app.utils.camera.PhotoHelper;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.CommonDialog;

import java.util.ArrayList;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SettingActivity extends BaseFragmentActivity implements IProfileSettingComponent.IView {


	private static final int AVATAR_WIDTH_HEIGHT = 480;
	private static final String DIVIDER_CHARS = "##";

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.item_avatar)
	CommonItem itemAvatar;
	@BindView(R.id.item_nick_name)
	CommonItem itemNickName;
	@BindView(R.id.item_phone)
	CommonItem itemPhone;
	@BindView(R.id.item_email)
	CommonItem itemEmail;
	@BindView(R.id.item_qq)
	CommonItem itemQQ;
	@BindView(R.id.item_real_name)
	CommonItem itemRealName;
	@BindView(R.id.item_address)
	CommonItem itemAddress;
	@BindView(R.id.item_birthday)
	CommonItem itemBirthday;
	@BindView(R.id.item_due_date)
	CommonItem itemDueDate;
	@BindView(R.id.item_gender)
	CommonItem itemGender;
	@BindView(R.id.item_weight)
	CommonItem itemWeight;
	@BindView(R.id.item_check_version)
	CommonItem itemCheckVersion;
	@BindView(R.id.item_user_proto)
	CommonItem itemUserProto;
	@BindView(R.id.item_about_us)
	CommonItem itemAboutUs;
	@BindView(R.id.item_exit)
	CommonItem itemExit;
	@BindView(R.id.item_feedback)
	CommonItem itemFeedback;

	private SimpleDatePickerDialog datePickerDialog;

	private ProfileSettingPresenter mPresenter;

	private OptionsPickerView genderOptions;

	private ArrayList<String> genderItems = new ArrayList<>();

	public static void navigate(Context context) {
		Intent intent = new Intent();
		intent.setClass(context, SettingActivity.class);
		context.startActivity(intent);
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setting);
		ButterKnife.bind(this);

		initListener();
	}

	@Override
	protected void onResume() {
		super.onResume();
		initData();
	}

	private void initData() {
		final User userInfo = BabyVoiceApp.mUserInfo;
		if (userInfo != null) {
			itemAvatar.setImgItemValue(userInfo.avatar, false);
			renderItemName(itemNickName, userInfo.nickname);
			renderItemName(itemPhone, userInfo.getTelephoneNum());
			renderItemName(itemEmail, userInfo.email);
			renderItemName(itemQQ, userInfo.qq);
			renderItemName(itemRealName, userInfo.realname);
			renderItemName(itemAddress, userInfo.address);
			String strGender = "";
			if (1 == userInfo.gender) {
				strGender = getString(R.string.txt_gender_male);
			} else if (2 == userInfo.gender) {
				strGender = getString(R.string.txt_gender_female);
			}
			renderItemName(itemGender, strGender);
			renderWeightItem(itemWeight, userInfo.weight);

			if (null != userInfo.birthday) {
				renderDateItem(itemBirthday, userInfo.birthday, false);
			}
			if (0 != userInfo.expected_date) {
				renderDateItem(itemDueDate, userInfo.expected_date, false);
			}
		}

		StatusBarUtil.StatusBarLightMode(this);

		mPresenter = new ProfileSettingPresenter(this);

		genderItems.clear();
		genderItems.add("宝爸");
		genderItems.add("宝妈");
	}

	private void renderWeightItem(CommonItem item, Integer weight) {
		String desc;
		if (weight == null) {
			desc = "未设置";
		} else {
			desc = String.format(Locale.getDefault(), "%dkg", weight);
		}
		item.setItemValue(desc);
	}

	private void initListener() {
		titleBar.setLeftOnClickListener(v -> {
			finish();
		});

		// 修改个人信息
		itemAvatar.setOnClickListener(v -> {
			selectImageFromAlbum();
		});
		itemNickName.setOnClickListener(v -> {
			startActivity(EditProfileActivity.intentFor(this, itemNickName.getItemValue(), EditProfileActivity.KEY_NICKNAME));
		});
		itemPhone.setOnClickListener(v -> {
			startActivity(EditProfileActivity.intentFor(this, itemPhone.getItemValue(), EditProfileActivity.KEY_MOBILE_PHONE));
		});
		itemEmail.setOnClickListener(v -> {
			startActivity(EditProfileActivity.intentFor(this, itemEmail.getItemValue(), EditProfileActivity.KEY_EMAIL));
		});
		itemQQ.setOnClickListener(v -> {
			startActivity(EditProfileActivity.intentFor(this, itemQQ.getItemValue(), EditProfileActivity.KEY_QQ));
		});
		itemRealName.setOnClickListener(v -> {
			startActivity(EditProfileActivity.intentFor(this, itemRealName.getItemValue(), EditProfileActivity.KEY_REAL_NAME));
		});
		itemAddress.setOnClickListener(v -> {
			AddressActivity.navigate(this, AddressActivity.FROM_TYPE_SETTING);
		});
		itemGender.setOnClickListener(v -> {
			showGenderPicker();
		});
		itemWeight.setOnClickListener(v -> {
			startActivity(EditProfileActivity.intentFor(this, itemWeight.getItemValue(), EditProfileActivity.KEY_WEIGHT));
		});

		// 关于
		itemCheckVersion.setOnClickListener(v -> {
			UpgradeUtil.checkUpgrade(this, UpgradeUtil.FROM_ME_FRAGMENT);
		});


		itemAboutUs.setOnClickListener(v -> {
			AboutActivity.navigate(this);
		});

		itemExit.setOnClickListener(v -> {
			showLogoutDialog();
		});

		itemUserProto.setOnClickListener(v -> {
			WebViewActivity.navigate(this, Constant.USER_AGREEMENT, getString(R.string.profile_user_term));
		});

		// 预产期
		itemDueDate.setOnClickListener(v -> {
			showSelectDateDialog(itemDueDate);
		});

		// 生日
		itemBirthday.setOnClickListener(v -> {
			showSelectDateDialog(itemBirthday);
		});

		// 意见反馈
		itemFeedback.setOnClickListener(v -> {
			FeedbackActivity.navigate(this);
		});
	}

	private void renderItemName(CommonItem item, String desc) {
		if (null == desc || StringUtils.isEmpty(desc)) {
			desc = "未设置";
		}
		if (item == itemAddress) {
			if(!StringUtils.isEmpty(desc)){
				String[] addressArr = desc.split(DIVIDER_CHARS);
				if (addressArr.length > 1) {
					item.setItemValue(addressArr[0]+addressArr[1]);
				}else {
					item.setItemValue(addressArr[0]);
				}
			}
		}else {
			item.setItemValue(desc);
		}
	}

	private void renderDateItem(CommonItem item, Long date, boolean isUpdate) {
		if (null != date) {
			item.setItemValue(StringUtils.TimeStamp2Date(date, "yyyy-MM-dd"));
			if (isUpdate) {
				try {
					User userInfo = new User();
					userInfo.id = BabyVoiceApp.mUserInfo.id;
					if (item == itemBirthday) {
						userInfo.birthday = date;
					} else if (item == itemDueDate) {
						userInfo.expected_date = date;
						SharedPreferencesUtil.setExamineDate(this, true);
					}

					if (mPresenter != null) {
						showProgressDialog(null, true, null);
						mPresenter.updateProfile(userInfo);
					}
				} catch (Exception e) {
					Ln.e(e);
				}
			}
		} else {
			item.setItemValue("未设置");
		}
	}

	private void showGenderPicker() {
		if (genderOptions == null) {
			genderOptions = new OptionsPickerBuilder(this, new OnOptionsSelectListener() {
				@Override
				public void onOptionsSelect(int options1, int options2, int options3, View v) {
					//返回的分别是三个级别的选中位置
					String gender = genderItems.get(options1);
					renderItemName(itemGender, gender);
					if (mPresenter != null) {
						showProgressDialog(null, true, null);
						User userInfo = new User();
						userInfo.id = BabyVoiceApp.mUserInfo.id;
						if (StringUtils.areEqual(getString(R.string.txt_gender_male), gender)){
							userInfo.gender = 1;
						} else if (StringUtils.areEqual(getString(R.string.txt_gender_female), gender)) {
							userInfo.gender = 2;
						}
						mPresenter.updateProfile(userInfo);
					}
				}
			})
					.setTitleText("请选择性别")
					.setCancelColor(getResources().getColor(R.color.color_00bed7))
					.setSubmitColor(getResources().getColor(R.color.color_00bed7))
					.setDividerColor(Color.BLACK)
					.setTextColorCenter(Color.BLACK) //设置选中项文字颜色
					.setContentTextSize(18)
					.build();
		}
		genderOptions.setPicker(genderItems);//一级选择器
		genderOptions.show();

	}


	private void showSelectDateDialog(final CommonItem currItem) {
		String dateStr = "";

		long dateTimeStamp = System.currentTimeMillis();
		SimpleDatePickerDialog.Builder builder = new SimpleDatePickerDialog.Builder()
				.setContext(SettingActivity.this)
				.setTitleId(R.string.select_date)
				.setConfirmListener(which -> {
					String strDate = datePickerDialog.getYYYYMMDD("%04d-%02d-%02d");
					long timestamp = StringUtils.DateStringToTimestamp(strDate, "yyyy-MM-dd");
					renderDateItem(currItem, timestamp, true);
				});

		if (currItem == itemBirthday) {
			dateStr = itemBirthday.getItemValue();
			builder.setMaxDate(dateTimeStamp);
		} else if (currItem == itemDueDate) {
			dateStr = itemDueDate.getItemValue();
			builder.setMinDate(dateTimeStamp);
			builder.setMaxDate(dateTimeStamp + StringUtils.PREGNANT_DAYS_MILLIS);
		}
		builder.setYYYYMMDD(dateStr, "yyyy-MM-dd");

		datePickerDialog = builder.build();
		datePickerDialog.show();
	}

	private void showLogoutDialog() {
		CommonDialog.createDialog(this)
				.setTitleText(getString(R.string.title_tips))
				.setText(getString(R.string.txt_is_logout))
				.setIconVisible(CommonDialog.Visible.Gone)
				.setLeftButtonText(getString(R.string.btn_txt_cancel))
				.setRightButtonText(getString(R.string.btn_txt_confirm))
				.setRightButtonAction(new CommonDialog.OnActionListener() {
					@Override
					public void onAction(int which) {
						clearUserInfo();
						gotoStartUpActivity();
					}
				})
				.setCancelable(true)
				.show();
	}

	/**
	 * 选择图片
	 */
	private void selectImageFromAlbum() {
		PhotoHelper.create(this)
				.setPreferredSize(AVATAR_WIDTH_HEIGHT, AVATAR_WIDTH_HEIGHT)
				.start();
	}


	private void clearUserInfo() {
		BabyVoiceApp.mUserInfo = null;
		SharedPreferencesUtil.saveToPreferences(this, null);
		SharedPreferencesUtil.setFirstLaunch(this, true);
	}

	private void gotoStartUpActivity() {
		Intent intent = new Intent(this, StartupActivity.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivity(intent);
		finish();

	}


	// Get the results:
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == RESULT_OK) {
			String stringExtra = data.getStringExtra(EditProfileActivity.KEY_EDIT_CONTENT);
			switch (requestCode) {
				case PhotoHelper.REQUEST_TAKE_PICTURE:
					String picturePath = data.getStringExtra(PhotoHelper.OUTPUT_PATH);
					updateLocalAvatar(picturePath);
					break;
			}
		}

	}

	private void updateLocalAvatar(String picturePath) {
		if (TextUtils.isEmpty(picturePath)) {
			return;
		}
		itemAvatar.setImgItemValue(picturePath, true);

		// 更新头像到服务器
		if (mPresenter != null) {
			showProgressDialog(null, true, null);
			mPresenter.uploadAvatarToServer(picturePath);
		}
	}


	@Override
	public void updateAvatarSuccess(String avatarUrl) {
		BabyVoiceApp.mUserInfo.avatar = avatarUrl;
		SharedPreferencesUtil.saveToPreferences(this, BabyVoiceApp.mUserInfo);
		itemAvatar.setImgItemValue(ServiceGenerator.URL_IMG_SERVER + avatarUrl, false);
		dismissProgressDialog();
	}

	@Override
	public void updateProfileSuccess(User userInfo) {
		CommonToast.showShortToast("更新成功");
		BabyVoiceApp.mUserInfo = userInfo;
		SharedPreferencesUtil.saveToPreferences(SettingActivity.this, userInfo);
		dismissProgressDialog();

	}

	@Override
	public void handleFailed() {
		CommonToast.showShortToast("失败");
		dismissProgressDialog();
	}

	@Override
	public void showToast(String msg) {
		CommonToast.showShortToast(msg);
	}


}
