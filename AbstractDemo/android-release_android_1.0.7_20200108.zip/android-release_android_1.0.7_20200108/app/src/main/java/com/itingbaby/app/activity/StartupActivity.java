package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.ImageView;
import android.widget.TextView;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.model.User;
import com.itingbaby.app.utils.GsonHelper;
import com.itingbaby.app.utils.SharedPreferencesUtil;
import com.itingbaby.baselib.commonutils.ApplicationUtils;
import com.itingbaby.baselib.manager.ActivityTaskManager;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.jakewharton.rxbinding3.view.RxView;
import com.umeng.analytics.MobclickAgent;

import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by lhb on 2017/4/1.
 */

public class StartupActivity extends BaseFragmentActivity {

	private static final String TAG = "StartupActivity";
	@BindView(R.id.big_logo)
	ImageView bigLogo;
	@BindView(R.id.txt_login)
	TextView txtLogin;
	@BindView(R.id.txt_register)
	TextView txtRegister;
	@BindView(R.id.txt_forget_change_pwd)
	TextView txtForgetChangePwd;


	public static void navigate(Context context) {
		Intent intent = new Intent();
		intent.setClass(context, StartupActivity.class);
		context.startActivity(intent);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_startup);
		ButterKnife.bind(this);
		initView();

		// 加密上传到友盟的数据
		MobclickAgent.enableEncrypt(true);
		initListener();
	}

	private void initView() {

		if (!SharedPreferencesUtil.isFirstLaunch(StartupActivity.this)) {
			SharedPreferences sharedPreferences = getSharedPreferences(SharedPreferencesUtil.USER_INFO_SHARED_PREFERENCES_FILE, MODE_PRIVATE);

			BabyVoiceApp.mUserInfo = GsonHelper.jsonToObject(sharedPreferences.getString(SharedPreferencesUtil.USER_INFO_DATA, ""), User.class);

			NewMainActivity.navigate(this);
			finish();
		}
	}

	private void initListener() {
		RxView.clicks(txtRegister)
				.throttleFirst(1, TimeUnit.SECONDS)
				.subscribe(aVoid -> {
					RegisterActivity.navigate(this);
				});

		RxView.clicks(txtLogin)
				.throttleFirst(1, TimeUnit.SECONDS)
				.subscribe(aVoid -> {
					LoginActivity.navigate(this);
				});

		RxView.clicks(txtForgetChangePwd)
				.throttleFirst(1, TimeUnit.SECONDS)
				.subscribe(aVoid -> {
					ForgetPwdActivity.navigate(this,"");
				});


		bigLogo.setOnLongClickListener(v -> {
			if (ApplicationUtils.IS_DEBUG) {
				DebugSettingActivity.navigate(StartupActivity.this);
			}
			return false;
		});
	}


	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			ActivityTaskManager.getInstance().removeAllActivity();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public void onResume() {
		super.onResume();
		MobclickAgent.onPageStart(TAG);
		MobclickAgent.onResume(this);
	}

	@Override
	public void onPause() {
		super.onPause();
		MobclickAgent.onPageEnd(TAG);
		MobclickAgent.onPause(this);
	}


}
