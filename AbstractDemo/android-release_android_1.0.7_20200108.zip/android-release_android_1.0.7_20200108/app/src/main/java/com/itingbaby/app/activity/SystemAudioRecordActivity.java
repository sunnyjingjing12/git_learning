package com.itingbaby.app.activity;

public class SystemAudioRecordActivity/* extends BaseRecordActivity*/ {

//    private static final String TAG = SystemAudioRecordActivity.class.getSimpleName();
//
//    private static final int FREQUENCY = 16000;// 设置音频采样率，44100是目前的标准，但是某些设备仍然支持22050，16000，11025
//    private static final int CHANNELCONGIFIGURATION = AudioFormat.CHANNEL_IN_MONO;// 设置单声道声道
//    private static final int AUDIOENCODING = AudioFormat.ENCODING_PCM_16BIT;// 音频数据格式：每个样本16位
//    public final static int AUDIO_SOURCE = MediaRecorder.AudioSource.MIC;// 音频获取源
//
//    private ArrayList<Short> inBuf = new ArrayList<Short>();//缓冲区数据
//    private ArrayList<byte[]> write_data = new ArrayList<byte[]>();//写入文件数据
//    public boolean isRecording = false;// 录音线程控制标记
//    private boolean isWriting = false;// 录音线程控制标记
//
//
//    private int recBufSize;// 录音最小buffer大小
//    private AudioRecord audioRecord;
//    private AudioTrack audioTrack;
//    private boolean mIsBegin = false;
//    private boolean startWrite;
//
//    private WaveCanvasNew waveCanvas;
//    private int readsize;
//    private long c_time;
//
//    private String savePcmPath;//保存pcm文件路径
//    private String saveWavPath;//保存wav文件路径
//
//
//    public static void navigate(Context context, int recordType) {
//        Intent intent = new Intent();
//        intent.putExtra("recordType", recordType);
//        intent.setClass(context, SystemAudioRecordActivity.class);
//        context.startActivity(intent);
//    }
//
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        initHeadSetPluginChangeEvent();
//        record();
//    }
//
//
//    private void initHeadSetPluginChangeEvent() {
////        RxBus.getDefault().registerOnActivity(HeadSetPluginChangedCommand.class, this)
////                .observeOn(AndroidSchedulers.mainThread())
////                .subscribe(new Action1<HeadSetPluginChangedCommand>() {
////                    @Override
////                    public void call(HeadSetPluginChangedCommand headSetPluginChangedCommand) {
////                        if (headSetPluginChangedCommand.getState() == HeadSetPluginChangedCommand.HeadSetPluginState.HEAD_SET_OUT) {
////                            Ln.i(TAG, "headset is out!!");
////
////                            if ((mRecordType == PickedCategoryCommand.TYPE_HEART || mRecordType == PickedCategoryCommand.TYPE_LUNG) && mIsBegin) {
////                                CommonToast.showLongToast(R.string.plugin_headset_first);
////                                finish();
////                            }
////                        }
////                    }
////                }, new Action1<Throwable>() {
////                    @Override
////                    public void call(Throwable throwable) {
////                        Ln.e("headset out ,error: %s", throwable.getMessage());
////                    }
////                });
//    }
//
//
//    @Override
//    protected void audioRecordClickStarted() {
//        if (waveCanvas != null) {
//            if (!mIsBegin) {
//                record();
//            }
//            startWriteFile();
//        } else {
//            CommonToast.showShortToast("发生错误，请重新打开该页面");
//        }
//    }
//
//    @Override
//    protected void audioRecordClickEnded() {
//        if (waveCanvas != null) {
//            waveCanvas.stop();
//        }
//
//        stopRecord();
//
//        VoiceSaveActivity.navigate(SystemAudioRecordActivity.this, mRecordType, mFileName);
//    }
//
//
//    @Override
//    protected void audioRecordTimeOvered() {
//        if (waveCanvas != null) {
//            waveCanvas.stop();
//        }
//
//        stopRecord();
//    }
//
//    /**
//     * 开始录制
//     */
//    private void record() {
//        // 权限检测
//		String[] permissions = new String[]{Manifest.permission.RECORD_AUDIO,
//                Manifest.permission.READ_EXTERNAL_STORAGE,
//                Manifest.permission.WRITE_EXTERNAL_STORAGE};
//        if (PermissionCheckUtil.checkPermissionAllGranted(this, permissions)) {
//            initAudio();
//        } else {
////            requestPermissions(permissions, PermissionCheckUtil.REQUEST_PERMISSION);
//            PermissionCheckUtil.requestPermission(this, permissions);
//        }
//    }
//
//    public void initAudio() {
//        if (recBufSize == 0) {
//            recBufSize = AudioRecord.getMinBufferSize(FREQUENCY,
//                    CHANNELCONGIFIGURATION, AUDIOENCODING);// 录音组件
//        }
//        if (audioRecord == null) {
//            audioRecord = new AudioRecord(AUDIO_SOURCE,// 指定音频来源，这里为麦克风
//                    FREQUENCY, // 16000HZ采样频率
//                    CHANNELCONGIFIGURATION,// 录制通道
//                    AUDIO_SOURCE,// 录制编码格式
//                    recBufSize);// 录制缓冲区大小 //先修改
//        }
//
//        if (audioTrack == null) {
//            audioTrack = new AudioTrack(AudioManager.STREAM_MUSIC, FREQUENCY,
//                    AudioFormat.CHANNEL_OUT_MONO, AUDIOENCODING, recBufSize,
//                    AudioTrack.MODE_STREAM);
//        }
//
//        String[] items = getResources().getStringArray(R.array.voice_type);
//
//        if (waveCanvas == null) {
//            waveCanvas = new WaveCanvasNew();
//        }
////        waveCanvas.baseLine = mWaveSfv.getHeight() / 2;
//
//        mFileName = items[mRecordType] + System.currentTimeMillis();
//
//        startRecord(callback);
//    }
//
//    private void startRecord(Handler.Callback callback) {
//        isRecording = true;
//        isWriting = true;
//        savePcmPath = Constant.DATA_DIRECTORY + mFileName + ".pcm";
//        saveWavPath = Constant.DATA_DIRECTORY + mFileName;
////        waveCanvas.init(mWaveSfv);
//
//        new RecordTask(callback).execute();
//    }
//
//    @Override
//    public void onBackPressed() {
//        Ln.d(TAG, "onBackPressed, mIsBegin = " + mIsBegin);
//        if (mIsBegin) {
//            CommonDialog.createDialog(this)
//                    .setTitleText("退出")
//                    .setText("是否保存录音并退出")
//                    .setLeftButtonText("继续录制")
//                    .setRightButtonText("退出")
//                    .setRightButtonAction(new CommonDialog.OnActionListener() {
//                        @Override
//                        public void onAction(int which) {
//                            recordText.setText("录制");
//                            if (null != waveCanvas) {
//                                waveCanvas.stop();
//                            }
//                            stopRecord();
//                            VoiceSaveActivity.navigate(SystemAudioRecordActivity.this, mRecordType, mFileName);
//
//                            mTitleBar.setLeftText(getString(R.string.look_for_baby_heart_pos));
//                            voicePosImg.setVisibility(View.VISIBLE);
//                        }
//                    })
//                    .setCancelable(true)
//                    .show();
//
//        } else {
//            if (null != waveCanvas) {
//                waveCanvas.stop();
//            }
//            stopRecord();
//            finish();
//        }
//    }
//
//    /**
//     * 开始写音频文件数据
//     */
//    private void startWriteFile() {
//        new Thread(new WriteRunnable()).start();//开线程写文件
//
//        Message msg = Message.obtain();
//        msg.what = MSG_SINGAL_START;
//        callback.handleMessage(msg);
//    }
//
//    /**
//     * 释放资源
//     */
//    private void stopRecord() {
//        isRecording = false;
//
//        audioRecord.stop();
//        audioTrack.stop();
//        inBuf.clear();// 清除
//
//        Message msg = Message.obtain();
//        msg.what = MSG_SINGAL_STOP;
//        callback.handleMessage(msg);
//    }
//
//
//    /**
//     * 异步录音程序
//     *
//     * @author cokus
//     */
//    class RecordTask extends AsyncTask<Object, Object, Object> {
//        private Handler.Callback callback;
//
//        public RecordTask(Handler.Callback callback) {
//
//            this.callback = callback;
//            inBuf.clear();// 清除
//        }
//
//
//        @Override
//        protected Object doInBackground(Object... params) {
//            try {
//                short[] buffer = new short[recBufSize];
//                audioRecord.startRecording();// 开始录制
//                audioTrack.play();
//                while (isRecording) {
//                    // 从MIC保存数据到缓冲区
//                    readsize = audioRecord.read(buffer, 0, recBufSize);
//                    audioTrack.write(buffer, 0, readsize);
//                    synchronized (inBuf) {
//                        for (int i = 0; i < readsize; i += waveCanvas.getRateX()) {
//                            inBuf.add(buffer[i]);
//                        }
//                    }
//                    publishProgress();
//                    if (AudioRecord.ERROR_INVALID_OPERATION != readsize && startWrite) {
//                        synchronized (write_data) {
//							byte[] bys = new byte[readsize * 2];
//                            //因为arm字节序问题，所以需要高低位交换
//                            for (int i = 0; i < readsize; i++) {
//								byte[] ss = getBytes(buffer[i]);
//                                bys[i * 2] = ss[0];
//                                bys[i * 2 + 1] = ss[1];
//                            }
//                            write_data.add(bys);
//                        }
//                    }
//                }
//                isWriting = false;
//            } catch (Throwable t) {
//                Message msg = Message.obtain();
//                msg.what = MSG_SINGAL_ERROR;
//                msg.obj = t.getMessage();
//                callback.handleMessage(msg);
//            }
//            return null;
//        }
//
//
//        @Override
//        protected void onProgressUpdate(Object... values) {
//            long time = new Date().getTime();
//            if (time - c_time >= waveCanvas.getDraw_time()) {
//                ArrayList<Short> buf = new ArrayList<Short>();
//                synchronized (inBuf) {
//                    if (inBuf.size() == 0)
//                        return;
////                    while (inBuf.size() > (mWaveSfv.getWidth() - waveCanvas.getMarginRight()) / waveCanvas.getDivider()) {
////                        if (inBuf.size() > 0) {
////                            inBuf.remove(0);
////                        }
////                    }
//                    buf = (ArrayList<Short>) inBuf.clone();// 保存
//                }
//                if (isRecording) {
//                    waveCanvas.simpleDraw(buf);// 把缓冲区数据画出来
//                }
//                c_time = new Date().getTime();
//            }
//            super.onProgressUpdate(values);
//
//        }
//
//
//        public byte[] getBytes(short s) {
//            byte[] buf = new byte[2];
//            for (int i = 0; i < buf.length; i++) {
//                buf[i] = (byte) (s & 0x00ff);
//                s >>= 8;
//            }
//            return buf;
//        }
//
//    }
//
//
//    /**
//     * 异步写文件
//     *
//     * @author cokus
//     */
//    class WriteRunnable implements Runnable {
//        @Override
//        public void run() {
//            try {
//                startWrite = true;
//
//                FileOutputStream fos2wav = null;
//                File file2wav = null;
//                try {
//                    file2wav = new File(savePcmPath);
//                    if (file2wav.exists()) {
//                        file2wav.delete();
//                    }
//                    fos2wav = new FileOutputStream(file2wav);// 建立一个可存取字节的文件
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//                while (isWriting || write_data.size() > 0) {
//                    byte[] buffer = null;
//                    synchronized (write_data) {
//                        if (write_data.size() > 0) {
//                            buffer = write_data.get(0);
//                            write_data.remove(0);
//                        }
//                    }
//                    try {
//                        if (buffer != null) {
//                            fos2wav.write(buffer);
//                            fos2wav.flush();
//                        }
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                }
//
//                fos2wav.close();
//                Pcm2Wav p2w = new Pcm2Wav();//将pcm格式转换成wav 其实就尼玛加了一个44字节的头信息
//                p2w.convertAudioFiles(savePcmPath, saveWavPath, (short) 16, 16000);
//            } catch (Throwable t) {
//                Ln.e(TAG, "save file failed..");
//            } finally {
//                Ln.i(TAG, "finally, always delete pcm file..");
//                deleteFiles(savePcmPath);
//            }
//        }
//    }
//
//    /**
//     * 删除SD卡或者手机的缓存图片和目录
//     */
//    public void deleteFiles(String filePath) {
//        File dirFile = new File(filePath);
//        if (!dirFile.exists()) {
//            return;
//        }
//        if (dirFile.isDirectory()) {
//            String[] children = dirFile.list();
//            for (int i = 0; i < children.length; i++) {
//                File subFile = new File(dirFile.getAbsolutePath() + File.separator + children[i]);
//                if (subFile.isDirectory()) {
//                    deleteFile(subFile.getAbsolutePath());
//                } else {
//                    final File to = new File(subFile.getAbsolutePath() + System.currentTimeMillis());
//                    subFile.renameTo(to);
//                    to.delete();
////					new File(dirFile, children[i]).delete();
//                }
//            }
//        }
//
//        dirFile.delete();
//    }
//
//    /**
//     * 权限请求回调
//     *
//     * @param requestCode
//     * @param permissions
//     * @param grantResults
//     */
//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//
//        if (requestCode == PermissionCheckUtil.REQUEST_PERMISSION) {
//            boolean isAllGranted = true;
//
//            // 判断是否所有的权限都已经授予了
//            for (int grant : grantResults) {
//                if (grant != PackageManager.PERMISSION_GRANTED) {
//                    isAllGranted = false;
//                    break;
//                }
//            }
//
//            if (isAllGranted) {
//                initAudio();
//
//            } else {
//                // 弹出对话框告诉用户需要权限的原因, 并引导用户去应用权限管理中手动打开权限按钮
//                PermissionCheckUtil.showGrantFailDialog(this, R.string.grant_audio_record_permission);
//            }
//        }
//    }
}
