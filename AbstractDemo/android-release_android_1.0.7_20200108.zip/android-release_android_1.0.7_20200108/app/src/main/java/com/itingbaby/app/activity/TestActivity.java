package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.itingbaby.app.R;
import com.itingbaby.app.components.ISearchDeviceComponent;
import com.itingbaby.app.components.presenter.SearchDevicePresenter;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.BleDeviceWrapper;
import com.itingbaby.app.model.HistoryBleDeviceModel;
import com.itingbaby.app.model.SimpleTextItem;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.viewbinder.BluetoothDeviceViewBinder;
import com.itingbaby.app.viewbinder.SimpleTextItemViewBinder;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.ItbEmptyViewLayout;
import com.itingbaby.baselib.views.widget.swipeviews.RefreshLoadRecyclerLayout;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;
import com.itingbaby.dev.events.EventBleDeviceConnectStatus;
import com.itingbaby.dev.events.EventLSDeviceData;
import com.itingbaby.dev.iTingBabyBleDevice;
import com.itingbaby.dev.iTingBabyBleDeviceManager;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.drakeet.multitype.MultiTypeAdapter;

/**
 * 测试用Activity
 */
public class TestActivity extends BaseFragmentActivity implements ISearchDeviceComponent.IView {

	private static final String TAG = "LSDevLog";

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.swipe_refresh_layout)
	RefreshLoadRecyclerLayout swipeRefreshLayout;
	@BindView(R.id.view_empty_layout)
	ItbEmptyViewLayout viewEmptyLayout;

	private boolean isScanning;
	private Animation operatingAnim;
	private SwipeRecyclerView recyclerView;
	private MultiTypeAdapter mAdapter;
	private BluetoothDeviceViewBinder mBluetoothDeviceViewBinder;
	private List mItems = new ArrayList<>();
	private SearchDevicePresenter mPresenter;

	public static void navigate(Context context) {
		Intent intent = new Intent();
		intent.setClass(context, TestActivity.class);
		context.startActivity(intent);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_test);
		ButterKnife.bind(this);

		initView();
		initData();
		initListener();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		iTingBabyBleDeviceManager.getInstance().cancelLSDeviceConnect();
	}

	@Override
	protected void onResume() {
		super.onResume();
		EventBus.getDefault().register(this);
	}

	@Override
	protected void onPause() {
		super.onPause();
		EventBus.getDefault().unregister(this);
	}

	private void initView() {
		initRefreshLayout();
		// 设置无数据页面
		viewEmptyLayout.setEmptyViewMarginTopPercentHeight(0.3f);
		viewEmptyLayout.setEmptyMessage(getString(R.string.load_empty_msg));
		viewEmptyLayout.setEmptyImageRes(R.drawable.empty_data);

		operatingAnim = AnimationUtils.loadAnimation(this, R.anim.rotate);
		operatingAnim.setInterpolator(new LinearInterpolator());

		StatusBarUtil.StatusBarLightMode(this);
	}

	private void initRefreshLayout() {
		viewEmptyLayout.setOnErrorBtnClickListener(v -> {
			if (mPresenter != null) {
				mPresenter.getBleDeviceData();
			}
		});

		recyclerView = swipeRefreshLayout.getSwipeRecyclerView();
		mAdapter = new MultiTypeAdapter(mItems);

		swipeRefreshLayout.setAdapter(mAdapter);
		swipeRefreshLayout.setCanRefresh(false);
		swipeRefreshLayout.setCanLoadMore(false);
		swipeRefreshLayout.setToggleLoadCount(4);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
		recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));

		mAdapter.register(SimpleTextItem.class, new SimpleTextItemViewBinder());
		mBluetoothDeviceViewBinder = new BluetoothDeviceViewBinder();
		mAdapter.register(BleDeviceWrapper.class, mBluetoothDeviceViewBinder);
	}

	private void initData() {
		mPresenter = new SearchDevicePresenter(this);
		mPresenter.getBleDeviceData();
	}

	private void initListener() {
		titleBar.setLeftOnClickListener(v -> {
			finish();
		});

		titleBar.setRightOnClickListener(v -> {
			if (isScanning) {
				initLoadingView(false);
			}
		});

		mBluetoothDeviceViewBinder.setOnDeviceClickListener(new BluetoothDeviceViewBinder.OnDeviceClickListener() {
			@Override
			public void onConnect(iTingBabyBleDevice device) {
				initLoadingView(false);
			}

			@Override
			public void onDisConnect(String mac) {
			}

			@Override
			public void onDetail(String mac) {
			}
		});
	}

	private void initLoadingView(boolean flag) {
		isScanning = flag;
		TextView rightText = titleBar.getRightText();
		if (isScanning) {
			rightText.startAnimation(operatingAnim);
		} else {
			rightText.clearAnimation();
		}
	}

	private void clearBleDeviceView() {
		if (mPresenter != null) {
			mPresenter.clearNearbyDeviceList();
			mPresenter.getBleDeviceData();
		}
	}

	// region ISearchDeviceComponent事件

	@Override
	public void handleFailed() {
		if (mAdapter.getItemCount() > 0) {
			CommonToast.showShortToast(getString(R.string.list_empty_net_error));
			return;
		}

		if (ListUtils.isEmpty(mItems) && viewEmptyLayout != null) {
			viewEmptyLayout.showError();
		}
	}

	@Override
	public void handleEmpty() {
		Ln.d("lihb handleEmpty");
		if (mAdapter.getItemCount() > 0) {
			return;
		}

		if (viewEmptyLayout != null) {
			viewEmptyLayout.setEmptyImageRes(R.drawable.empty_data);
			viewEmptyLayout.showEmpty();
		}
	}

	@Override
	public void updateDataList(List<HistoryBleDeviceModel> dataList, List<iTingBabyBleDevice> bluetoothDevices) {
		mItems.clear();
		if (!ListUtils.isEmpty(bluetoothDevices)) {
			SimpleTextItem simpleTextItem = new SimpleTextItem.Builder()
					.title(getString(R.string.nearby_device))
					.textColor(R.color.color_000000_30)
					.background(R.drawable.bg_bluetooth_text_shape)
					.build();

			mItems.add(simpleTextItem);
			for (iTingBabyBleDevice device : bluetoothDevices) {
				BleDeviceWrapper wrapper = new BleDeviceWrapper();
				wrapper.bleDevice = device;
				mItems.add(wrapper);
			}
		}
		viewEmptyLayout.hideAllView();
		mAdapter.notifyDataSetChanged();
	}

	@Override
	public void showToast(String msg) {
		//CommonToast.showShortToast(msg);
	}

	// endregion

	// region EventBus事件

	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onBLEDeviceConnectionStatus(EventBleDeviceConnectStatus event) {
		Ln.i(event.toString());
	}

	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onBLEDeviceData(EventLSDeviceData event) {
		switch (event.type) {
		case EventLSDeviceData.LS_DEVICE_MAC:
			Log.i(TAG, "LS设备MAC " + event.devMac);
		break;
		case EventLSDeviceData.LS_DEVICE_BATTERY_PERCENTAGE:
			Log.i(TAG, "LS设备电池电量百分比 " + event.devBattery);
		break;
		case EventLSDeviceData.LS_DEVICE_RSSI:
			Log.i(TAG, "LS设备RSSI " + event.devRSSI);
		break;
		case EventLSDeviceData.LS_DEVICE_PRESSURE:
			Log.i(TAG, "LS设备压力值 " + event.devPressure);
		break;
		}
	}

	// endregion
}
