package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.util.SparseArray;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.components.IVaccineComponent;
import com.itingbaby.app.components.presenter.VaccinePresenter;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.Vaccine;
import com.itingbaby.app.model.VaccineGroupDataModel;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.viewbinder.VaccineGroupDataViewBinder;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.ItbEmptyViewLayout;
import com.itingbaby.baselib.views.widget.swipeviews.RefreshLoadRecyclerLayout;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.drakeet.multitype.MultiTypeAdapter;


/**
 * 疫苗记录activity
 */
public class VaccineActivity extends BaseFragmentActivity implements IVaccineComponent.IView {

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.txt_interval_days)
	TextView txtIntervalDays;
	@BindView(R.id.swipe_refresh_layout)
	RefreshLoadRecyclerLayout swipeRefreshLayout;
	@BindView(R.id.view_empty_layout)
	ItbEmptyViewLayout viewEmptyLayout;


	private SwipeRecyclerView recyclerView;
	private MultiTypeAdapter mAdapter;

	private List mItems = new ArrayList<>();

	private VaccinePresenter mVaccinePresenter;
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
	private Calendar mCalendar;

	public static void navigate(Context context) {
		Intent intent = new Intent();
		intent.setClass(context, VaccineActivity.class);
		context.startActivity(intent);
	}

	@Override
	protected void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		setContentView(R.layout.activity_vaccine);
		ButterKnife.bind(this);

		if (BabyVoiceApp.mUserInfo == null) {
			CommonToast.showShortToast("请先登录甜贝APP");
			LoginActivity.navigate(this);
		}

		initView();

	}


	private void initView() {

		titleBar.setLeftOnClickListener(v -> {
			onBackPressed();
		});
		titleBar.setRightOnClickListener(v -> {
			RemindSettingActivity.navigate(this, RemindSettingActivity.FROM_VACCINE, mCalendar);
		});

		mVaccinePresenter = new VaccinePresenter(this);

		initRefreshLayout();

		// 设置无数据页面
		viewEmptyLayout.setEmptyViewMarginTopPercentHeight(0.3f);
		viewEmptyLayout.setEmptyMessage(getString(R.string.load_empty_msg));
		viewEmptyLayout.setEmptyImageRes(R.drawable.empty_data);

		StatusBarUtil.StatusBarLightMode(this);

		mVaccinePresenter.getAllVaccineData();
	}

	private void initRefreshLayout() {
		viewEmptyLayout.setOnErrorBtnClickListener(v -> {
			if (mVaccinePresenter != null) {
				mVaccinePresenter.getAllVaccineData();
			}
		});

		recyclerView = swipeRefreshLayout.getSwipeRecyclerView();
		mAdapter = new MultiTypeAdapter(mItems);


		swipeRefreshLayout.setAdapter(mAdapter);
		swipeRefreshLayout.setCanRefresh(false);
		swipeRefreshLayout.setCanLoadMore(false);
		recyclerView.setBackgroundResource(R.color.color_f5f5f5);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
		recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

		registerMultiType();

	}

	private void registerMultiType() {
		mAdapter.register(VaccineGroupDataModel.class, new VaccineGroupDataViewBinder());
	}

	@Override
	public void handleFailed() {
		Ln.d("lihb handleFailed");
		if (mAdapter.getItemCount() > 0) {
			CommonToast.showShortToast(getString(R.string.list_empty_net_error));
			return;
		}

		if (ListUtils.isEmpty(mItems) && viewEmptyLayout != null) {
			viewEmptyLayout.showError();
		}
	}

	@Override
	public void handleEmpty() {
		Ln.d("lihb handleEmpty");
		if (mAdapter.getItemCount() > 0) {
			return;
		}

		if (viewEmptyLayout != null) {
			viewEmptyLayout.showEmpty();
		}
	}

	@Override
	public void updateDataList(List<Vaccine> dataList) {
		Ln.d("lihb updateDataList, list size =%d", dataList.size());
		if (ListUtils.isEmpty(dataList)) {
			viewEmptyLayout.showEmpty();
			return;
		}

		viewEmptyLayout.hideAllView();
		mItems.clear();
		SparseArray sparseArray = new SparseArray();
		boolean isFindNext = false;
		int nextIndex = -1;
		for (Vaccine vaccine : dataList) {
			int vcTime = vaccine.time;
			VaccineGroupDataModel model = (VaccineGroupDataModel) sparseArray.get(vcTime);
			if (model == null) {
				model = new VaccineGroupDataModel();
				model.injectAge = getInjectAge(vaccine.time);
				Calendar calendar = getInjectDate(vaccine.time);
				if (!isFindNext) {
					long timeInMillis = StringUtils.getYearMonthDay(calendar.getTimeInMillis());
					long currTimeMillis = StringUtils.getYearMonthDay(System.currentTimeMillis());
					int diffDay = StringUtils.differentDays(currTimeMillis, timeInMillis);
					if (diffDay >= 0) {
						isFindNext = true;
						model.isNextInject = true;
						mCalendar = calendar;
						txtIntervalDays.setText(Html.fromHtml(String.format(getString(R.string.txt_event_next_day_tips), "疫苗", diffDay)));
					}
				}
				model.compInjectDate = sdf.format(calendar.getTime());
				model.injectNurse = vaccine.nurse;
				model.realInjectDate = vaccine.realTime;

				mItems.add(model);
				sparseArray.put(vcTime, model);

			}
			model.vaccineList.add(vaccine);
			if (model.isNextInject) {
				nextIndex = mItems.indexOf(model);
			}
		}
		mAdapter.notifyDataSetChanged();
		txtIntervalDays.setVisibility(isFindNext ? View.VISIBLE : View.GONE);
		recyclerView.scrollToPosition(isFindNext ? nextIndex : 0); // 跳转到最近的一次需注射疫苗
	}


	@Override
	public void showToast(String msg) {
		CommonToast.showShortToast(msg);
	}

	/**
	 * 获得需要注射年纪
	 *
	 * @param time
	 * @return
	 */
	private String getInjectAge(int time) {
		if (time < 1) {
			return "出生当天";
		} else if (time < 12) {
			return time + "月龄";
		} else {
			return (time % 12 == 0) ? (time / 12) + "岁" : (time / 12.0) + "岁";
		}

	}

	/**
	 * 获得需要注射日期
	 *
	 * @param time
	 * @return
	 */
	private Calendar getInjectDate(int time) {
		// 预产期，也就是宝宝生日
		long dueDateMillis = BabyVoiceApp.mUserInfo.expected_date;
		Calendar calendar = Calendar.getInstance(Locale.getDefault());
		calendar.setTimeInMillis(dueDateMillis * 1000);
		if (time < 12) {
			calendar.add(Calendar.MONTH, time);
		} else {
			int year = time / 12;
			int month = time % 12;
			calendar.add(Calendar.YEAR, year);
			calendar.add(Calendar.MONTH, month);
		}
		return calendar;

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == RESULT_OK) {
			if (requestCode == EditVaccineInfoActivity.REQUEST_EDIT_VACCINE_INFO) {
				if (mVaccinePresenter != null) {
					mVaccinePresenter.getAllVaccineData();
				}
			}
		}
	}
}
