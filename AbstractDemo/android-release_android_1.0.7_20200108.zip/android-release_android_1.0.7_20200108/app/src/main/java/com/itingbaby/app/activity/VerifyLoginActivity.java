package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.Constant;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.User;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.SharedPreferencesUtil;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.RequestBody;


/**
 * 验证码登录，包括手机验证码和邮箱验证码
 */
public class VerifyLoginActivity extends BaseFragmentActivity {

	private static final String TAG = VerifyLoginActivity.class.getSimpleName();

	private static final int COUNT_DOWN_TIME = 60 * 1000; // 单位：毫秒

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.edit_account)
	EditText editAccount;
	@BindView(R.id.img_clear_account)
	ImageView imgClearAccount;
	@BindView(R.id.account_layout)
	RelativeLayout accountLayout;
	@BindView(R.id.edit_password)
	EditText editPassword;
	@BindView(R.id.txt_get_code)
	TextView txtGetCode;
	@BindView(R.id.password_layout)
	RelativeLayout passwordLayout;
	@BindView(R.id.txt_login_btn)
	TextView txtLoginBtn;
	@BindView(R.id.sms_check_box)
	CheckBox checkBoxSms;
	@BindView(R.id.txt_sms_protocol)
	TextView txtSmsProtocol;
	@BindView(R.id.divider_line_account)
	View dividerLineAccount;
	@BindView(R.id.divider_line_password)
	View dividerLinePassword;

	private CountDownTimer mCountDownTimer;


	public static void navigate(Context context) {
		Intent intent = new Intent();
		intent.setClass(context, VerifyLoginActivity.class);
		context.startActivity(intent);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_verify_login);
		ButterKnife.bind(this);
		initViews();
		initListener();

	}

	private void initViews() {

		txtGetCode.setEnabled(false);

		txtSmsProtocol.setText(Html.fromHtml(getString(R.string.txt_agree_protocol)));

	}

	private void initListener() {
		titleBar.setLeftOnClickListener(v -> {
			finish();
		});

		editAccount.setOnFocusChangeListener((v, hasFocus) ->
				dividerLineAccount.setBackgroundColor(hasFocus ? getResources().getColor(R.color.white) : getResources().getColor(R.color.color_ffffff_10)));

		editPassword.setOnFocusChangeListener((v, hasFocus) ->
				dividerLinePassword.setBackgroundColor(hasFocus ? getResources().getColor(R.color.white) : getResources().getColor(R.color.color_ffffff_10)));


		editAccount.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {


			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void afterTextChanged(Editable s) {
				if (mCountDownTimer == null) {
					txtGetCode.setEnabled(s.length() > 0);
				}

				if (s.length() > 0) {
					imgClearAccount.setVisibility(View.VISIBLE);
					if (editPassword.getText().length() > 0 && txtGetCode.getText().length() > 0) {
						txtLoginBtn.setEnabled(true);
					}
				} else {
					imgClearAccount.setVisibility(View.GONE);
					txtLoginBtn.setEnabled(false);
				}
				Ln.d("[lihb login] 账户文字改变, txtRegisterBtn enable = %b", txtLoginBtn.isEnabled());


			}
		});

		editPassword.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {

			}

			@Override
			public void afterTextChanged(Editable s) {
				if (s.length() > 0) {
					if (editAccount.getText().length() > 0) {
						txtLoginBtn.setEnabled(true);
					}
				} else {
					txtLoginBtn.setEnabled(false);
				}

				Ln.d("[lihb login] 密码文字改变, txtLoginBtn enable = %b", txtLoginBtn.isEnabled());
			}
		});
	}

	@OnClick({R.id.img_clear_account, R.id.txt_get_code, R.id.txt_login_btn, R.id.txt_protocol, R.id.txt_privacy})
	public void onViewClicked(View view) {
		String account = editAccount.getText().toString();
		switch (view.getId()) {
			case R.id.img_clear_account:
				editAccount.setText("");
				break;
			case R.id.txt_get_code:
				// 手机号或者邮箱号是否合法
				validateAccountToGetCode(account);
				break;
			case R.id.txt_login_btn:
				String code = editPassword.getText().toString();
				validateAccountToLogin(account, code);

				break;
			case R.id.txt_protocol:
				WebViewActivity.navigate(this, Constant.USER_AGREEMENT, getString(R.string.txt_app_service_protocol));
				break;
			case R.id.txt_privacy:
				WebViewActivity.navigate(this, Constant.PRIVACY_WEB_SITE, getString(R.string.txt_app_privacy));
				break;

		}
	}

	private void getCountDownTimer() {
		mCountDownTimer = new CountDownTimer(COUNT_DOWN_TIME, 1000) {
			@Override
			public void onTick(long millisUntilFinished) {
				txtGetCode.setEnabled(false);
				txtGetCode.setText(getString(R.string.resend_sms_code, millisUntilFinished / 1000));
			}

			@Override
			public void onFinish() {
				txtGetCode.setEnabled(true);
				txtGetCode.setText(getString(R.string.send_verify_code));
				mCountDownTimer.cancel();
				mCountDownTimer = null;
			}
		};
	}

	/**
	 * 获取验证码验证逻辑
	 *
	 * @param account
	 */
	private void validateAccountToGetCode(String account) {
		if (StringUtils.checkPhoneNumber(account) || StringUtils.checkMail(account)) {
			if (null == mCountDownTimer) {
				getCountDownTimer();
			}
			mCountDownTimer.start();

			sendGetSmsCodeRequest(account);
			// 光标移动到输入验证码view
			editPassword.requestFocus();
		} else {
			if (StringUtils.isEmpty(account)) {
				CommonToast.showShortToast(getString(R.string.the_phone_number_is_empty));
			}else {
				CommonToast.showShortToast(getString(R.string.input_correct_phone_or_email_account));
			}
		}
	}

	/**
	 * 登录验证逻辑
	 * 1、先验证勾选协议
	 * 2、账户是否合法
	 * 3、密码是否为空
	 *
	 * @param account
	 * @param code
	 */
	private void validateAccountToLogin(String account, String code) {
		if (!checkBoxSms.isChecked()) {
			CommonToast.showShortToast(getString(R.string.agree_protocol));
		} else if (!StringUtils.checkPhoneNumber(account) && !StringUtils.checkMail(account)) {
			CommonToast.showShortToast(getString(R.string.input_correct_phone_or_email_account));
		} else if (StringUtils.isEmpty(code)) {
			CommonToast.showShortToast(getString(R.string.password_is_empty));
		} else {
			sendLoginBySmsCodeRequest(account, code);
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (null != mCountDownTimer) {
			mCountDownTimer.cancel();
			mCountDownTimer = null;
		}
	}

	/**
	 * 发送登录协议
	 *
	 * @param loginAccount
	 * @param password
	 */
	private void sendLoginBySmsCodeRequest(final String loginAccount, final String password) {
		showProgressDialog(getString(R.string.txt_login_now), false, null);
		ServiceGenerator.createService(ApiManager.class)
				.loginBySmsCode(RequestBody.create(MediaType.parse("multipart/form-data"), loginAccount), RequestBody.create(MediaType.parse("multipart/form-data"), password))
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(httpResponse -> {
					Ln.i("lihb", httpResponse.toString());
					dismissProgressDialog();
					if (httpResponse.code == ResponseCode.RESPONSE_OK) {
						// 成功
						CommonToast.showShortToast("登录成功");

						User userInfo = httpResponse.data;

						SharedPreferencesUtil.saveToPreferences(VerifyLoginActivity.this, userInfo);
						//BabyVoiceApp.getInstance().setLogin(true);
						BabyVoiceApp.mUserInfo = userInfo;
						if (userInfo != null && userInfo.userExtension != null && userInfo.userExtension.hasPwd) {
							NewMainActivity.navigate(VerifyLoginActivity.this);
						}else {
							PasswordChangeActivity.navigate(VerifyLoginActivity.this, loginAccount, PasswordChangeActivity.TYPE_SETTING_PWD);
						}
						finish();
					} else {
						CommonToast.showShortToast(httpResponse.msg);
					}
				}, throwable -> {
					dismissProgressDialog();
					CommonToast.showShortToast("登录失败，请重新登录!");
				});
	}


	/**
	 * 获取验证码,登录
	 *
	 * @param account
	 */
	private void sendGetSmsCodeRequest(String account) {
		ServiceGenerator.createService(ApiManager.class)
				.getSmsCode(account)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe( httpResponse -> {
					Ln.i("lihb", httpResponse.toString());
					if (httpResponse.code == ResponseCode.RESPONSE_OK) {
						CommonToast.showShortToast(R.string.sms_to_your_phone);
					} else {
						CommonToast.showShortToast(httpResponse.msg);
					}
				}, throwable -> {
					Ln.e("error-->" + throwable.toString());
					CommonToast.showShortToast("发送失败。");
				});
	}
}
