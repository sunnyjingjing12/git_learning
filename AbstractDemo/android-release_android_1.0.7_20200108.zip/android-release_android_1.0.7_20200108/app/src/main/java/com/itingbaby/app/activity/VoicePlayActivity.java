package com.itingbaby.app.activity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.Constant;
import com.itingbaby.app.DataManager;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.customview.RecordingAndPlayVoiceView;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.customview.VoicePlayListView;
import com.itingbaby.app.customview.VoicePlayTimeStopView;
import com.itingbaby.app.event.EventAudioPlayerComplete;
import com.itingbaby.app.event.EventAudioPlayerData;
import com.itingbaby.app.event.EventAudioPlayerNetPreparation;
import com.itingbaby.app.event.EventAudioPlayerProgress;
import com.itingbaby.app.model.AudioPlayData;
import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.app.model.AudioRecordModelDao;
import com.itingbaby.app.model.AudioType;
import com.itingbaby.app.model.DaoSession;
import com.itingbaby.app.model.MusicCategory;
import com.itingbaby.app.model.MusicClause;
import com.itingbaby.app.model.PlayStatus;
import com.itingbaby.app.player.AudioPlayer;
import com.itingbaby.app.player.AudioPlayerFactory;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.DownloadUtil;
import com.itingbaby.app.utils.NetworkHelper;
import com.itingbaby.app.utils.SharedPreferencesUtil;
import com.itingbaby.app.utils.TimerUtil;
import com.itingbaby.app.utils.UploadSoundUtil;
import com.itingbaby.baselib.commonutils.DimensionUtil;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.PermissionCheckUtil;
import com.itingbaby.baselib.commonutils.PopWindowUtils;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.CommonDialog;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import cn.sharesdk.onekeyshare.OnekeyShare;
import io.reactivex.observers.DisposableObserver;

public class VoicePlayActivity extends BaseFragmentActivity {

	private static final String TAG = VoicePlayActivity.class.getSimpleName();

	private static final String KEY_VOICE_MODEL = "key_voice_model";
	private static final String KEY_MUSIC_MODEL = "key_music_model";
	private static final String KEY_MUSIC_CATEGORY = "key_music_category";


	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.recording_and_play_view)
	RecordingAndPlayVoiceView recordingAndPlayView;
	@BindView(R.id.img_play)
	ImageView imgPlay;
	@BindView(R.id.img_prev)
	ImageView imgPrev;
	@BindView(R.id.img_next)
	ImageView imgNext;
	@BindView(R.id.img_pause)
	ImageView imgPause;

	@BindView(R.id.img_play_mode)
	ImageView imgPlayMode;
	@BindView(R.id.txt_play_mode)
	TextView txtPlayMode;
	@BindView(R.id.img_time)
	ImageView imgTime;
	@BindView(R.id.txt_time)
	TextView txtTime;
	@BindView(R.id.img_upload)
	ImageView imgUpload;
	@BindView(R.id.txt_upload)
	TextView txtUpload;
	@BindView(R.id.upload_layout)
	LinearLayout uploadLayout;
	@BindView(R.id.pb_loading)
	ProgressBar pbLoading;


	private VoicePlayListView playlistLayout;  // 播放列表view
	private VoicePlayTimeStopView voicePlayTimeStopView;  // 定时停止播放列表view
	private PopupWindow mPlaylistPopWindow;
	private PopupWindow mVoicePlayTimeStopPopWindow;

	private MusicCategory category;
	private AudioPlayData audioPlayData;

	private int mCurPlayMode = VoicePlayListView.PLAY_MODE_SEQUENCE; // 当前播放模式

	private String[] playModeStringItems;  // 播放模式字符串数组
	private int[] playModeIconItems;       // 播放模式icon数组

	private DisposableObserver timerDisposableObserver; 	 	// 定时器observer

	private AudioPlayer mAudioPlayer;

	public static void navigate(Context context, AudioRecordModel recordModel, MusicCategory musicCategory) {
		Intent intent = new Intent();
		intent.putExtra(KEY_MUSIC_CATEGORY, musicCategory);
		intent.putExtra(KEY_VOICE_MODEL, recordModel);
		intent.setClass(context, VoicePlayActivity.class);
		context.startActivity(intent);
	}

	public static void navigate(Context context, MusicClause music, MusicCategory musicCategory) {
		Intent intent = new Intent();
		intent.putExtra(KEY_MUSIC_CATEGORY, musicCategory);
		intent.putExtra(KEY_MUSIC_MODEL, music);
		intent.setClass(context, VoicePlayActivity.class);
		context.startActivity(intent);
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_play);
		ButterKnife.bind(this);

		initData();
		initViews();
		initListener();

		checkSDCardPermission();

		EventBus.getDefault().register(this);
	}

	@Override
	protected void onDestroy() {
		EventBus.getDefault().unregister(this);

		stopPlayTimer();
		mAudioPlayer.release();
		DownloadUtil.getInstance().pauseAllDownload();
		super.onDestroy();
	}

	// 初始进入页面
	private void initData() {
		Intent intent = getIntent();
		if (intent.hasExtra(KEY_MUSIC_CATEGORY)) {
			category = (MusicCategory) intent.getSerializableExtra(KEY_MUSIC_CATEGORY);
		}
		if (intent.hasExtra(KEY_VOICE_MODEL)) {
			audioPlayData = (AudioPlayData) intent.getSerializableExtra(KEY_VOICE_MODEL);
		} else if (intent.hasExtra(KEY_MUSIC_MODEL)) {
			audioPlayData = (AudioPlayData) intent.getSerializableExtra(KEY_MUSIC_MODEL);
		}

		if (!audioPlayData.isRemote() && (audioPlayData.getType() == AudioType.AUDIO_TYPE_BABY
				|| audioPlayData.getType() == AudioType.AUDIO_TYPE_MOM
				|| audioPlayData.getType() == AudioType.AUDIO_TYPE_LUNG)) {
			mAudioPlayer = AudioPlayerFactory.getAudioPlayer(AudioPlayerFactory.PLAYER_AUDIO_TRACK, this);
		} else {
			mAudioPlayer = AudioPlayerFactory.getAudioPlayer(AudioPlayerFactory.PLAYER_MEDIA_PLAYER, this);
		}

		playModeStringItems = getResources().getStringArray(R.array.voice_play_mode);
		playModeIconItems = new int[]{R.drawable.ic_order, R.drawable.ic_single, R.drawable.ic_random};
	}

	private void initViews() {
		playlistLayout = new VoicePlayListView(this);
		playlistLayout.initData(category, audioPlayData);
		voicePlayTimeStopView = new VoicePlayTimeStopView(this);

		renderAudioRecordInfo();
		recordingAndPlayView.initSrcType(RecordingAndPlayVoiceView.TYPE_PLAYING_VOICE, audioPlayData.getDuration());

		renderUploadLayoutView();
		renderShareBtn();
	}

	private void initListener() {
		titleBar.setLeftOnClickListener(v -> finish());

		titleBar.setRightOnClickListener(v -> {
			// 分享
			if (audioPlayData instanceof MusicClause) {
				// 网络音乐
				MusicClause music = (MusicClause) audioPlayData;
				String shareUrl = getString(R.string.share_url, ServiceGenerator.URL_SHARE_SERVER, music.getId(), category != null ? category.id : 1, audioPlayData.getType(), BabyVoiceApp.mUserInfo.id);
				Ln.d("lihb shareUrl=%s", shareUrl);
				showShare(shareUrl, audioPlayData.getTitle());
			} else if (audioPlayData instanceof AudioRecordModel) {
				AudioRecordModel model = (AudioRecordModel) audioPlayData;
				if (model.getServerFileId() != null) {
					// 自己上传的音乐
					String shareUrl = getString(R.string.share_url, ServiceGenerator.URL_SHARE_SERVER, model.getServerFileId(), MusicCategory.MUSIC_CATEGORY_USER, audioPlayData.getType(), BabyVoiceApp.mUserInfo.id);
					Ln.d("lihb shareUrl=%s", shareUrl);
					showShare(shareUrl, audioPlayData.getTitle());
				} else {
					CommonToast.showShortToast(R.string.txt_need_upload_tips);
				}
			}
		});

		// 播放列表view回调函数
		playlistLayout.setOnVoicePlayListViewListener(new VoicePlayListView.OnVoicePlayListViewListener() {
			@Override
			public void onCollapseIconClick() {
				if (mPlaylistPopWindow != null && mPlaylistPopWindow.isShowing()) {
					mPlaylistPopWindow.dismiss();
				}
			}

			@Override
			public void onItemClick(AudioPlayData wrapper) {
				if (mPlaylistPopWindow != null && mPlaylistPopWindow.isShowing()) {
					mPlaylistPopWindow.dismiss();
				}
				checkNetworkToPlayVoice(wrapper);
			}
		});

		// 定时停止播放view回调函数
		voicePlayTimeStopView.setOnVoicePlayTimeStopViewListener(new VoicePlayTimeStopView.OnVoicePlayTimeStopViewListener() {
			@Override
			public void onItemClick(int time) {
				if (mVoicePlayTimeStopPopWindow != null && mVoicePlayTimeStopPopWindow.isShowing()) {
					mVoicePlayTimeStopPopWindow.dismiss();
				}
				handlePlayStopTime(time);
			}

			@Override
			public void onDismiss() {
				if (mVoicePlayTimeStopPopWindow != null && mVoicePlayTimeStopPopWindow.isShowing()) {
					mVoicePlayTimeStopPopWindow.dismiss();
				}
			}
		});
	}

	/**
	 * 更新分享按钮UI
	 * 播放本地歌曲时，不显示分享按钮
	 */
	private void renderShareBtn() {
		titleBar.setRightDrawable(category == null || category.sharable ? getResources().getDrawable(R.drawable.ic_share) : null);
	}


	@OnClick({R.id.img_play, R.id.img_pause, R.id.img_prev, R.id.img_next, R.id.play_mode_layout, R.id.time_layout, R.id.upload_layout, R.id.playlist_layout})
	public void onViewClicked(View view) {
		switch (view.getId()) {
			case R.id.img_play: // 点击播放按钮
				checkNetworkToPlayVoice(audioPlayData);
				break;
			case R.id.img_pause: // 点击暂停按钮
				pauseVoice();
				break;
			case R.id.img_prev: {// 播放上一首
				Ln.d("lihb 播放上一首");
				checkNetworkToPlayVoice(playlistLayout.getPreAudioRecord(audioPlayData, true));
			}
			break;
			case R.id.img_next: {// 播放下一首
				Ln.d("lihb 播放下一首");
				checkNetworkToPlayVoice(playlistLayout.getNextAudioRecord(audioPlayData, true));
			}
			break;
			case R.id.play_mode_layout:
				// 播放模式切换
				mCurPlayMode = (mCurPlayMode + 1) % 3;
				renderPlayModeView();
				playlistLayout.updatePlayMode(mCurPlayMode);
				break;
			case R.id.time_layout:
				// 定时停止播放
				showVoicePlayTimeStopView();
				break;
			case R.id.upload_layout:
				// 上传到云端
				if (audioPlayData != null && audioPlayData.getId() == null) {
					uploadAudioRecord((AudioRecordModel) audioPlayData);
				} else {
					CommonToast.showShortToast(getString(R.string.txt_uploaded));
				}
				break;
			case R.id.playlist_layout:
				// 显示播放列表
				showPlaylistLayoutView();
				break;

		}
	}

	/**
	 * 上传AudioRecord到服务端
	 */
	private void uploadAudioRecord(AudioRecordModel model) {
		showProgressDialog(getString(R.string.txt_uploading), true, null);

		UploadSoundUtil.uploadSound(model, new UploadSoundUtil.OnUploadListener() {
			@Override
			public void onSuccess(String msg, long serverFileId, String url) {
				dismissProgressDialog();

				CommonToast.showShortToast(msg);

				model.setServerFileId(serverFileId);

				DaoSession daoSession = BabyVoiceApp.getInstance().getDaoSession();
				AudioRecordModelDao audioRecordModelDao = daoSession.getAudioRecordModelDao();
				audioRecordModelDao.insertOrReplaceInTx(model);

				renderUploadLayoutView();
			}

			@Override
			public void onFailed(String msg) {
				dismissProgressDialog();
				CommonToast.showShortToast("上传失败，请稍后重试！");
			}
		});

	}

	/**
	 * 检查网络，是否播放
	 */
	private void checkNetworkToPlayVoice(AudioPlayData wrapper) {
		if (wrapper == null) {
			return;
		}
		if (wrapper.isRemote() && NetworkHelper.getNetType(VoicePlayActivity.this) == Constant.SYSNET_MOBILE
				&& SharedPreferencesUtil.isEnableShowNetwork(VoicePlayActivity.this)
				&& DataManager.getInstance().isEnableShowNetworkDialog()) {
			showNetWorkDialog(wrapper);
		} else {
			playVoice(wrapper);
		}
	}


	/**
	 * 开始播放
	 */
	private void playVoice(AudioPlayData wrapper) {
		if (!StringUtils.areEqual(audioPlayData.getUrl(), wrapper.getUrl())) {
			mAudioPlayer.stop();
			audioPlayData.setPlaying(false);
			audioPlayData = wrapper;
		}

		Ln.i("lihb okgo start play audioModelWrapper.url = %s", audioPlayData.getUrl());

		renderPlayPauseVisibility(PlayStatus.PLAY_STATUS_PLAYING);

		if (wrapper.isRemote()) {
			String filePath = BabyVoiceApp.getInstance().getCacheMusicPath() + StringUtils.stringToMd5(ServiceGenerator.URL_IMG_SERVER + audioPlayData.getUrl());
			if (DownloadUtil.getInstance().isDownloaded(ServiceGenerator.URL_IMG_SERVER + audioPlayData.getUrl())) {
				mAudioPlayer.play(filePath);
			} else {
				mAudioPlayer.play(ServiceGenerator.URL_IMG_SERVER + audioPlayData.getUrl());
			}
		} else {
			mAudioPlayer.play(audioPlayData.getUrl());
		}

		if (wrapper.isRemote()) {
			startDownloadFutureFile();
		}

		renderAudioRecordInfo();
		renderUploadLayoutView();
		recordingAndPlayView.startWaveLineAnim();

		audioPlayData.setPlaying(true);
	}

	/**
	 * 暂停播放
	 */
	private void pauseVoice() {
		renderPlayPauseVisibility(PlayStatus.PLAY_STATUS_INIT);
		mAudioPlayer.pause();
		recordingAndPlayView.stopWaveLineAnim();
	}

	/**
	 * 预先下载文件
	 */
	private void startDownloadFutureFile() {
		// 先暂停之前的全部下载
		DownloadUtil.getInstance().pauseAllDownload();

		// 从播放列表中拿歌曲来下载
		Set<AudioPlayData> set = playlistLayout.getFutureSong(audioPlayData);
		for (AudioPlayData model : set) {
			Ln.d("lihb download ,name=%s", model.getTitle());
			String tag = ServiceGenerator.URL_IMG_SERVER + model.getUrl();
			if (!DownloadUtil.getInstance().isDownloaded(tag)) {
				DownloadUtil.getInstance().downloadFile(tag);
			}
		}
	}

	/**
	 * 更新播放模式UI
	 */
	private void renderPlayModeView() {
		imgPlayMode.setImageResource(playModeIconItems[mCurPlayMode]);
		txtPlayMode.setText(playModeStringItems[mCurPlayMode]);
	}


	/**
	 * 更新上传按钮UI
	 */
	private void renderUploadLayoutView() {
		if (audioPlayData != null) {
			imgUpload.setImageResource(audioPlayData.getId() != null ? R.drawable.ic_uploaded : R.drawable.ic_uploadcloud);
			txtUpload.setText(audioPlayData.getId() != null ? getString(R.string.txt_uploaded) : getString(R.string.txt_upload_to_server));

		}
		uploadLayout.setVisibility(category != null ? View.GONE : View.VISIBLE);
	}


	/**
	 * 更新播放、暂停按钮的显示和隐藏
	 */
	private void renderPlayPauseVisibility(int playStatus) {
		switch (playStatus) {
			case PlayStatus.PLAY_STATUS_INIT:
				imgPause.setVisibility(View.GONE);
				imgPlay.setVisibility(View.VISIBLE);
				pbLoading.setVisibility(View.GONE);
				break;
			case PlayStatus.PLAY_STATUS_START_PLAY:
				imgPause.setVisibility(View.GONE);
				imgPlay.setVisibility(View.GONE);
				pbLoading.setVisibility(View.VISIBLE);
				break;
			case PlayStatus.PLAY_STATUS_PLAYING:
				imgPause.setVisibility(View.VISIBLE);
				imgPlay.setVisibility(View.GONE);
				pbLoading.setVisibility(View.GONE);
				break;
		}
	}

	/**
	 * 检查SD卡权限
	 */
	protected void checkSDCardPermission() {
		// 第 1 步: 检查是否有相应的权限

		boolean isAllGranted = PermissionCheckUtil.checkPermissionAllGranted(this,
				new String[]{
						Manifest.permission.READ_EXTERNAL_STORAGE,
						Manifest.permission.WRITE_EXTERNAL_STORAGE
				}
		);
		// 如果权限全都拥有, 则直接返回
		if (isAllGranted) {
			return;
		}


		// 第 2 步: 请求权限
		// 一次请求多个权限, 如果其他有权限是已经授予的将会自动忽略掉
		PermissionCheckUtil.requestPermission(this, new String[]{
				Manifest.permission.READ_EXTERNAL_STORAGE,
				Manifest.permission.WRITE_EXTERNAL_STORAGE
		});
	}

	// 第 3 步: 申请权限结果返回处理
	@Override
	public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == PermissionCheckUtil.REQUEST_PERMISSION) {
			boolean isAllGranted = true;

			// 判断是否所有的权限都已经授予了
			for (int grant : grantResults) {
				if (grant != PackageManager.PERMISSION_GRANTED) {
					isAllGranted = false;
					break;
				}
			}

			// 弹出对话框告诉用户需要权限的原因, 并引导用户去应用权限管理中手动打开权限按钮
			if (!isAllGranted) {
				PermissionCheckUtil.showGrantFailDialog(this);
			}
		}
	}


	/**
	 * 渲染用户录音文件的相关信息
	 */
	private void renderAudioRecordInfo() {
		recordingAndPlayView.setAudioRecordModel(audioPlayData, category);
		playlistLayout.setAudioRecordModel(audioPlayData);
		titleBar.setTitle(audioPlayData.getTitle());
	}

	/**
	 * 显示播放列表view
	 */
	private void showPlaylistLayoutView() {
		if (mPlaylistPopWindow == null) {
			mPlaylistPopWindow = PopWindowUtils.popView(this, playlistLayout, DimensionUtil.getScreenWidth(this), DimensionUtil.dipToPx(this, 440), Gravity.BOTTOM);
		}
		if (!mPlaylistPopWindow.isShowing()) {
			PopWindowUtils.popWindow(this, mPlaylistPopWindow, Gravity.BOTTOM);
		}

	}

	/**
	 * 显示定时处理view
	 */
	private void showVoicePlayTimeStopView() {
		if (mVoicePlayTimeStopPopWindow == null) {
			mVoicePlayTimeStopPopWindow = PopWindowUtils.popView(this, voicePlayTimeStopView, DimensionUtil.getScreenWidth(this), DimensionUtil.dipToPx(this, 440), Gravity.BOTTOM);
		}
		if (!mVoicePlayTimeStopPopWindow.isShowing()) {
			PopWindowUtils.popWindow(this, mVoicePlayTimeStopPopWindow, Gravity.BOTTOM);
		}

	}


	/**
	 * 处理定时停止播放功能
	 */
	private void handlePlayStopTime(int time) {
		// 定时停止播放
		if (time != 0) {
			// 先干掉之前可能存在的
			stopPlayTimer();
			// 重新开启一个

			timerDisposableObserver = TimerUtil.getInstance().startTimer(time, TimeUnit.MINUTES, new DisposableObserver() {
				public void onNext(Object o) {
					Ln.d("lihb onNext %s", o.toString());
				}

				@Override
				public void onComplete() {
					Ln.d("lihb onComplete");
					// 暂停当前播放
					pauseVoice();
					voicePlayTimeStopView.setSelectTime(0);
				}

				@Override
				public void onError(Throwable e) {

				}
			});
			CommonToast.showShortToast(getString(R.string.txt_setting_play_stop_time, time));
		} else {
			stopPlayTimer();
			CommonToast.showShortToast(R.string.txt_cancel_play_stop);
		}
	}

	/**
	 * 释放定时停止播放timer
	 */
	private void stopPlayTimer() {
		if (timerDisposableObserver != null) {
			TimerUtil.getInstance().stopTimer(timerDisposableObserver);
			timerDisposableObserver = null;
		}
	}

	/**
	 * 显示流量弹窗
	 */
	private void showNetWorkDialog(final AudioPlayData wrapper) {
		CommonDialog.createDialog(this)
				.setTitleText(getString(R.string.title_tips))
				.setText("你当前的网络为2/3/4G，在线播放将消耗你的网络流量")
				.setIconVisible(CommonDialog.Visible.Gone)
				.setLeftButtonText("知道了")
				.setLeftButtonAction(v -> {
					DataManager.getInstance().setEnableShowNetworkDialog(false);
					playVoice(wrapper);
				})
				.setRightButtonText("不再提醒")
				.setRightButtonAction(v -> {
					SharedPreferencesUtil.setEnableShowNetwork(VoicePlayActivity.this, false);
					playVoice(wrapper);

				})
				.setOnCancelListener(dialog -> playVoice(wrapper))
				.setCloseOnTouchOutside(true)
				.setCancelable(true)
				.show();
	}

	/**
	 * 分享功能
	 */
	private void showShare(String  url, String title) {
		OnekeyShare oks = new OnekeyShare();
		// 关闭sso授权
		//oks.disableSSOWhenAuthorize();

		// title标题，印象笔记、邮箱、信息、微信、人人网和QQ空间等使用
		oks.setTitle(title);
		// titleUrl是标题的网络链接，QQ和QQ空间等使用
		oks.setTitleUrl(url);
		// text是分享文本，所有平台都需要这个字段
		oks.setText(getString(R.string.txt_share_txt));
		// url仅在微信（包括好友和朋友圈）中使用
		oks.setUrl(url);

		// 音乐地址
		oks.setMusicUrl(url);

		oks.setImageUrl("https://www.itingbaby.com/image/appicon/logo.png");

//		oks.setSilent(true);
//		Bitmap enableLogo = BitmapFactory.decodeResource(getResources(), R.drawable.bg_update);
//		String label = "ShareSDK";
//		View.OnClickListener listener = new View.OnClickListener() {
//			public void onClick(View v) {
//				Ln.i("");
//			}
//		};
//		oks.setCustomerLogo(enableLogo, label, listener);
		// 启动分享GUI
		oks.show(this);
	}

	// region EventBus事件

	// 文件播放完毕后停止的事件
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onAudioPlayerComplete(EventAudioPlayerComplete event) {
		Ln.d("lihb 自动播放下一首");
		checkNetworkToPlayVoice(playlistLayout.getNextAudioRecord(audioPlayData, false));
	}

	// 播放音频文件时回调音频数据的事件
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onAudioPlayerData(EventAudioPlayerData event) {
		recordingAndPlayView.updateAudioData(event.getAudioData());
	}

	// 播放进度
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onAudioPlayerProgress(EventAudioPlayerProgress event) {
		int currPos = event.getPosition();
		recordingAndPlayView.renderPlayTimeCount(currPos, audioPlayData.getDuration());
//		if (mPlayStatus != PlayStatus.PLAY_STATUS_PLAYING && currPos >=1) {
//			renderPlayPauseVisibility(PlayStatus.PLAY_STATUS_PLAYING);
//		}
	}

	// 播放器网络文件准备
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onAudioPlayerNetPreparation(EventAudioPlayerNetPreparation event) {
		int status = event.getStatus();
		if (AudioPlayer.AUDIO_NET_STATUS_BEGIN == status) {
			renderPlayPauseVisibility(PlayStatus.PLAY_STATUS_START_PLAY);
		} else if (AudioPlayer.AUDIO_NET_STATUS_PLAYING == status) {
			renderPlayPauseVisibility(PlayStatus.PLAY_STATUS_PLAYING);
		} else {
			renderPlayPauseVisibility(PlayStatus.PLAY_STATUS_INIT);
			CommonToast.showLongToast("加载失败...");
		}
	}

	// endregion
}
