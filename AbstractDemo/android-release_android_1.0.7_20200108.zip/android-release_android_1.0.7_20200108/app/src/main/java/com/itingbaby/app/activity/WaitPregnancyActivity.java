package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.itingbaby.app.R;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.fragment.WaitPregnancyFragment;
import com.itingbaby.app.model.WaitTodoGoods;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.ScrollableViewPager;
import com.itingbaby.baselib.views.widget.tablayout.TabViewPagerAdapter;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * 待产包页面
 */
public class WaitPregnancyActivity extends BaseFragmentActivity {

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.main_view_pager)
	ScrollableViewPager mViewPager;

	private TabViewPagerAdapter pagerAdapter;
	private int mCurrTab = 0;
	private WaitPregnancyFragment momFragment;
	private WaitPregnancyFragment babyFragment;

	public static void navigate(Context context) {
		Intent intent = new Intent();
		intent.setClass(context, WaitPregnancyActivity.class);
		context.startActivity(intent);
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_wait_pregnancy);
		ButterKnife.bind(this);

		initViews();
		initListener();

	}

	private void initViews() {
		titleBar.setLeftOnClickListener(v -> finish());

		mViewPager.setCanScroll(false);

		pagerAdapter = new TabViewPagerAdapter(getSupportFragmentManager());

		momFragment = WaitPregnancyFragment.create(WaitTodoGoods.GOODS_TYPE_MOM);
		babyFragment = WaitPregnancyFragment.create(WaitTodoGoods.GOODS_TYPE_BABY);
		pagerAdapter.addFrag(momFragment, "");
		pagerAdapter.addFrag(babyFragment, "");

		mViewPager.setOffscreenPageLimit(2);
		mViewPager.setAdapter(pagerAdapter);

		mViewPager.setCurrentItem(mCurrTab, false);

	}

	private void initListener() {
		if (momFragment != null) {
			momFragment.setOnTabSelectListener(index -> {
				mViewPager.setCurrentItem(index, false);
			});
		}
		if (babyFragment != null) {
			babyFragment.setOnTabSelectListener(index -> {
				mViewPager.setCurrentItem(index, false);
			});
		}
	}
}
