package com.itingbaby.app.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.itingbaby.app.R;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.customview.X5WebView;
import com.itingbaby.baselib.commonutils.ApplicationUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.tencent.smtt.sdk.URLUtil;
import com.tencent.smtt.sdk.WebChromeClient;
import com.tencent.smtt.sdk.WebView;
import com.tencent.smtt.sdk.WebViewClient;
import com.umeng.analytics.MobclickAgent;


public class WebViewActivity extends BaseFragmentActivity {

    private static final String TAG = "WebViewActivity";
    public static final String KEY_URL = "key_url";
    public static final String KEY_TITLE = "key_title";

    private ProgressBar mProgressBar = null;
    private X5WebView mWebView = null;
    private String mUrl = "about:blank";
    private TitleBar titleBar;
    private String mTitleText;
	private RelativeLayout mShowAdvLayout;


    public static void navigate(Context context, String url, String title) {
        Intent intent = new Intent();
        intent.setClass(context, WebViewActivity.class);
        intent.putExtra(KEY_URL, url);
        intent.putExtra(KEY_TITLE, title);
        context.startActivity(intent);
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview);

        initViews();
        StatusBarUtil.StatusBarLightMode(this);

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mWebView != null) {
            mWebView.loadUrl(mUrl);
        }
        MobclickAgent.onPageStart(TAG);
        MobclickAgent.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mWebView != null) {
            mWebView.loadUrl("about:blank");
        }
        MobclickAgent.onPageEnd(TAG);
        MobclickAgent.onPause(this);
    }

    private void initViews() {

        Intent intent = getIntent();
        if (intent != null) {
            if (intent.hasExtra(KEY_URL)) {
                mUrl = intent.getStringExtra(KEY_URL);
            }
            if (intent.hasExtra(KEY_TITLE)) {
                mTitleText = intent.getStringExtra(KEY_TITLE);
            }
        }

        mProgressBar = findViewById(R.id.showAdvProgressBar);
        mProgressBar.setProgress(0);

        titleBar = findViewById(R.id.title_bar);

		mShowAdvLayout = findViewById(R.id.showAdvLayout);

        mWebView = findViewById(R.id.showAdvWebView);

        mWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                mProgressBar.setProgress(newProgress);
                if (newProgress == 100) {
                    mProgressBar.setVisibility(View.GONE);
                } else {
                    mProgressBar.setVisibility(View.VISIBLE);
                }
                super.onProgressChanged(view, newProgress);
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                super.onReceivedTitle(view, title);
                if (TextUtils.isEmpty(mTitleText)) { // 如果没给标题，就从网页中获取标题
                    titleBar.setTitle(title);
                }
            }
        });
        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                try {
                    if (URLUtil.isFileUrl(url)) {
                        Ln.i("WebViewActivity url isFileUrl -->  url=%s", url);
                        return false;
                    }

                    if (URLUtil.isValidUrl(url)) {
                        //此处需要post是因为X5在页面内跳转时出现空白页
                        ApplicationUtils.mMainHandler.post(() -> {
                            if (mWebView != null) {
                                mWebView.loadUrl(url);
                            }
                            Ln.i("WebViewActivity url isValidUrl -->  url=%s", url);
                        });
                        return true;
                    }
                } catch (Exception e) {
                    Ln.e("WebViewActivity occur exception --> %s", e);
                }
                return false;
            }
        });
        titleBar.setTitle(mTitleText);
        titleBar.setLeftOnClickListener(v -> {
            if (mWebView.canGoBack()) {
                mWebView.goBack();   // 后退
            } else {
                onBackPressed();
            }

        });
        // 点击后退按钮, 让WebView后退一页
        mWebView.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                if (keyCode == KeyEvent.KEYCODE_BACK && mWebView.canGoBack()) {  //表示按返回键时的操作
                    mWebView.goBack();   // 后退
                    return true;         // 已处理
                }
            }
            return false;
        });
    }


    @Override
    public void finish() {
		if (mShowAdvLayout != null) {
			mShowAdvLayout.removeAllViews();

        }
//        ViewGroup viewGroup = (ViewGroup) getWindow().getDecorView();
//        if (viewGroup != null) {
//            // Bug: Activity has leaked window android.widget.ZoomButtonsController that was originally added here android.view.WindowLeaked
//            // 移除所有控件，防止关闭该activity时，内存泄漏的问题
//            viewGroup.removeAllViews();
//        }
        super.finish();
    }
}
