package com.itingbaby.app.activity.mix_video;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.github.hiteshsondhi88.libffmpeg.ExecuteBinaryResponseHandler;
import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.MixVoiceDataManager;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.components.IVoiceMixComponent;
import com.itingbaby.app.components.presenter.VoiceMixPresenter;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.event.EventAudioPlayerComplete;
import com.itingbaby.app.model.AudioPlayData;
import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.app.model.EmptyDataModel;
import com.itingbaby.app.model.MixMusicSelectStatus;
import com.itingbaby.app.model.MusicClause;
import com.itingbaby.app.model.SimpleTextItem;
import com.itingbaby.app.player.AudioPlayer;
import com.itingbaby.app.player.AudioPlayerFactory;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.FileUtils;
import com.itingbaby.app.viewbinder.AudioRecordModelViewBinder;
import com.itingbaby.app.viewbinder.EmptyDataViewBinder;
import com.itingbaby.app.viewbinder.MusicViewBinder;
import com.itingbaby.app.viewbinder.SimpleTextItemViewBinder;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.PermissionCheckUtil;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.CommonDialog;
import com.itingbaby.baselib.views.widget.swipeviews.RefreshLoadRecyclerLayout;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import me.drakeet.multitype.MultiTypeAdapter;

public class VoiceMixActivity extends BaseFragmentActivity implements IVoiceMixComponent.IView {

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.txt_start_mix)
	TextView txtStartMix;
	@BindView(R.id.txt_re_mix)
	TextView txtReMix;
	@BindView(R.id.txt_save_mix)
	TextView txtSaveMix;
	@BindView(R.id.swipe_refresh_layout)
	RefreshLoadRecyclerLayout swipeRefreshLayout;
	@BindView(R.id.img_mix_play)
	ImageView imgMixPlay;
	@BindView(R.id.img_mix_pause)
	ImageView imgMixPause;
	@BindView(R.id.cons_layout_operation)
	ConstraintLayout consLayoutOperation;

	public static final String mixVoiceSuffix = ".wav";


	private SwipeRecyclerView recyclerView;
	private MultiTypeAdapter mAdapter;

	private List mItems = new ArrayList<>();

	HashSet<AudioPlayData> recordModelList = new HashSet<>();
	HashSet<AudioPlayData> musicList = new HashSet<>();

	private AudioRecordModel pickedRecordModel;
	private MusicClause pickedMusicClause;

	// 列表里当前播放歌曲
	private AudioPlayData auditionModel;

	private AudioRecordModelViewBinder mAudioRecordModelViewBinder;
	private MusicViewBinder musicViewBinder;

	private String outputFilePath;

	private VoiceMixPresenter mixPresenter;

	private AudioPlayer mAudioPlayer;
	private SimpleDateFormat mSimpleDateFormat;


	public static void navigate(Context context) {
		Intent intent = new Intent();
		intent.setClass(context, VoiceMixActivity.class);
		context.startActivity(intent);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_voice_mix);
		ButterKnife.bind(this);

		initView();
		initListener();

		recordModelList = MixVoiceDataManager.getInstance().getRecordModelSet();
		musicList = MixVoiceDataManager.getInstance().getMusicSet();


		mAudioPlayer = AudioPlayerFactory.getAudioPlayer(AudioPlayerFactory.PLAYER_MEDIA_PLAYER, this);
		mixPresenter.loadFFMpegBinary();
		mSimpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault());

		if (!EventBus.getDefault().isRegistered(this)) {
			EventBus.getDefault().register(this);
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		updateDataList();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		MixVoiceDataManager.getInstance().release();
		mAudioPlayer.release();

		if (EventBus.getDefault().isRegistered(this)) {
			EventBus.getDefault().unregister(this);
		}
	}

	private void initView() {
		StatusBarUtil.StatusBarLightMode(this);
		renderStartAndPlayUI(false);
		initRefreshLayout();
		mixPresenter = new VoiceMixPresenter(this);
		mixPresenter.init(this);
	}

	private void initListener() {
		titleBar.setLeftOnClickListener(v -> finish());

		titleBar.setRightOnClickListener(v -> {
			startActivity(VoiceSelectActivity.intentFor(this));
		});
		if (mAudioRecordModelViewBinder != null) {
			mAudioRecordModelViewBinder.setOnAudioRecordModelViewBinderListener(new AudioRecordModelViewBinder.OnAudioRecordModelViewBinderListener() {
				@Override
				public void onItemClick(int position) {
					Object o = mItems.get(position);
					if (o instanceof AudioRecordModel) {
						pickedRecordModel = null;
						AudioRecordModel model = (AudioRecordModel) o;
						for (AudioPlayData recordModel : recordModelList) {
							if (recordModel == model) {
								if (recordModel.mixMusicSelectStatus == MixMusicSelectStatus.MUSIC_MIX_SELECTED) {
									recordModel.mixMusicSelectStatus = MixMusicSelectStatus.MUSIC_MIX_UN_SELECTED;
								} else {
									recordModel.mixMusicSelectStatus = MixMusicSelectStatus.MUSIC_MIX_SELECTED;
									pickedRecordModel = (AudioRecordModel) recordModel;
								}
							} else {
								recordModel.mixMusicSelectStatus = MixMusicSelectStatus.MUSIC_MIX_UN_SELECTED;
							}
						}

						mAdapter.notifyDataSetChanged();
					}
				}

				@Override
				public void onItemMoreOperClick(int position) {

				}

				@Override
				public void onPlayImgClick(int position) {
					Object o = mItems.get(position);
					if (o instanceof AudioPlayData) {
						updateAllDataPlayingStatus((AudioPlayData) o);
					}
				}

				@Override
				public void onPlaySvgaClick(int position) {
					Object o = mItems.get(position);
					if (o instanceof AudioPlayData) {
						updateAllDataPlayingStatus((AudioPlayData) o);
					}
				}
			});
		}
		if (musicViewBinder != null) {
			musicViewBinder.setListener(new MusicViewBinder.OnMusicViewBinderListener() {
				@Override
				public void onItemClick(int position) {
					Object o = mItems.get(position);
					if (o instanceof MusicClause) {
						MusicClause music = (MusicClause) o;
						pickedMusicClause = null;
						for (AudioPlayData musicClause : musicList) {
							if (musicClause == music) {
								if (musicClause.mixMusicSelectStatus == MixMusicSelectStatus.MUSIC_MIX_SELECTED) {
									musicClause.mixMusicSelectStatus = MixMusicSelectStatus.MUSIC_MIX_UN_SELECTED;
								} else {
									musicClause.mixMusicSelectStatus = MixMusicSelectStatus.MUSIC_MIX_SELECTED;
									pickedMusicClause = (MusicClause) musicClause;
								}
							} else {
								musicClause.mixMusicSelectStatus = MixMusicSelectStatus.MUSIC_MIX_UN_SELECTED;
							}
						}

						mAdapter.notifyDataSetChanged();
					}
				}

				@Override
				public void onMusicPlayImgClick(int position) {
					Object o = mItems.get(position);
					if (o instanceof AudioPlayData) {
						updateAllDataPlayingStatus((AudioPlayData) o);
					}
				}

				@Override
				public void onMusicPlaySvgaClick(int position) {
					Object o = mItems.get(position);
					if (o instanceof AudioPlayData) {
						updateAllDataPlayingStatus((AudioPlayData) o);
					}
				}
			});
		}
	}

	private void initRefreshLayout() {

		recyclerView = swipeRefreshLayout.getSwipeRecyclerView();
		mAdapter = new MultiTypeAdapter(mItems);

		swipeRefreshLayout.setAdapter(mAdapter);
		swipeRefreshLayout.setCanRefresh(false);
		swipeRefreshLayout.setCanLoadMore(false);
		swipeRefreshLayout.setToggleLoadCount(4);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
		recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

		mAudioRecordModelViewBinder = new AudioRecordModelViewBinder(AudioRecordModelViewBinder.SRC_TYPE_MUSIC_MIX);
		mAdapter.register(AudioRecordModel.class, mAudioRecordModelViewBinder);

		mAdapter.register(SimpleTextItem.class, new SimpleTextItemViewBinder());
		musicViewBinder = new MusicViewBinder(MusicViewBinder.SRC_TYPE_MIX_MUSIC);
		mAdapter.register(MusicClause.class, musicViewBinder);

		mAdapter.register(EmptyDataModel.class, new EmptyDataViewBinder());


	}

	private void updateAllDataPlayingStatus(AudioPlayData audioPlayData) {
		mAudioPlayer.pause();
		auditionModel = null;
		updateDataPlayingStatus(audioPlayData, recordModelList);
		updateDataPlayingStatus(audioPlayData, musicList);
		updateDataList();
	}

	private void updateDataPlayingStatus(AudioPlayData audioPlayData, HashSet<AudioPlayData> dataSet) {
		for (AudioPlayData tmpData : dataSet) {
			if (tmpData.getUrl().equals(audioPlayData.getUrl())) {
				tmpData.isPlaying = !tmpData.isPlaying;
				if (tmpData.isPlaying) {
					auditionModel = tmpData;
					if (!TextUtils.isEmpty(outputFilePath)) {
						renderPlayPauseUI(false);
					}
					String filePath = BabyVoiceApp.getInstance().getCacheMusicPath() + StringUtils.stringToMd5(ServiceGenerator.URL_IMG_SERVER + audioPlayData.getUrl());
					mAudioPlayer.play(filePath);
				}
			} else {
				tmpData.isPlaying = false;
			}
		}
	}

	private void clearAllDataPlayingStatus() {
		for (AudioPlayData tmpData : recordModelList) {
			tmpData.isPlaying = false;
		}
		for (AudioPlayData tmpData : musicList) {
			tmpData.isPlaying = false;
		}
		updateDataList();
	}

	/**
	 * 更新数据
	 *
	 */
	private void updateDataList() {
		pickedRecordModel = (AudioRecordModel) MixVoiceDataManager.getInstance().getPickedData(recordModelList);
		pickedMusicClause = (MusicClause) MixVoiceDataManager.getInstance().getPickedData(musicList);

		mItems.clear();

		SimpleTextItem textItem = new SimpleTextItem.Builder().title("我的心音").build();
		mItems.add(textItem);

		if (recordModelList.isEmpty()) {
			EmptyDataModel emptyDataModel = new EmptyDataModel("请选择心音~", R.drawable.ic_no_data_small);
			mItems.add(emptyDataModel);

			if (!musicList.isEmpty()) {
				SimpleTextItem textItem2 = new SimpleTextItem.Builder().title("混入音乐").build();
				mItems.add(textItem2);
				mItems.addAll(musicList);
			}
		} else {
			mItems.addAll(recordModelList);
			SimpleTextItem textItem2 = new SimpleTextItem.Builder().title("混入音乐").build();
			mItems.add(textItem2);

			if (!musicList.isEmpty()) {
				mItems.addAll(musicList);
			} else {
				EmptyDataModel emptyDataModel = new EmptyDataModel("请选择混入音乐~", R.drawable.ic_no_data_small);
				mItems.add(emptyDataModel);
			}
		}

		mAdapter.notifyDataSetChanged();
	}

	@OnClick({R.id.txt_start_mix, R.id.img_mix_play, R.id.img_mix_pause, R.id.txt_re_mix, R.id.txt_save_mix})
	public void onViewClicked(View view) {
		switch (view.getId()) {
			case R.id.txt_start_mix:
				if (mixPresenter != null) {
					mixPresenter.checkPermission(this);
				}
				break;
			case R.id.img_mix_play:
				// 先把auditionModel置空
				if (auditionModel != null) {
					mAudioPlayer.stop();
					clearAllDataPlayingStatus();
					auditionModel = null;
				}
				if (!TextUtils.isEmpty(outputFilePath) && FileUtils.isFileExists(outputFilePath)) {
					mAudioPlayer.play(outputFilePath);
				}
				renderPlayPauseUI(true);
				break;
			case R.id.img_mix_pause:
				mAudioPlayer.pause();
				renderPlayPauseUI(false);
				break;
			case R.id.txt_re_mix:
				CommonToast.showShortToast("已重置");
				reset();
				break;
			case R.id.txt_save_mix:
				if (StringUtils.isEmpty(outputFilePath)) {
					CommonToast.showShortToast("暂无文件需保存");
				} else {
					showSaveFileDialog();
				}
				break;
		}
	}

	/**
	 * 开始混音
	 */
	private void startVoiceMix() {
		// 先把auditionModel置空
		if (auditionModel != null) {
			mAudioPlayer.stop();
			clearAllDataPlayingStatus();
			auditionModel = null;
		}
		if (pickedRecordModel == null) {
			CommonToast.showShortToast("请选择一首录制心音");
			return;
		}
		if (pickedMusicClause == null) {
			CommonToast.showShortToast("请再选择一首混入音乐");
			return;
		}
		String input1 = BabyVoiceApp.getInstance().getCacheMusicPath() + StringUtils.stringToMd5(ServiceGenerator.URL_IMG_SERVER + pickedRecordModel.getUrl());
		String input2 = BabyVoiceApp.getInstance().getCacheMusicPath() + StringUtils.stringToMd5(ServiceGenerator.URL_IMG_SERVER + pickedMusicClause.getUrl());
		outputFilePath = BabyVoiceApp.getInstance().getCacheMusicPath() + mSimpleDateFormat.format(new Date()) + mixVoiceSuffix;
		String mixAudioCmd = String.format("-i %s -i %s -filter_complex amix=inputs=2:duration=first -strict -2 %s", input1, input2, outputFilePath);
		String[] cmd = mixAudioCmd.split(" ");
		mixPresenter.execFFmpegMixVoice(cmd, mResponseHandler);
	}

	/**
	 * 重新录制操作
	 */
	private void reset() {
		renderStartAndPlayUI(false);
		clearPickedDataStatus();
		clearAllDataPlayingStatus();
		mAudioPlayer.stop();
		if (!StringUtils.isEmpty(outputFilePath)) {
			FileUtils.deleteFile(outputFilePath);
		}
		outputFilePath = null;
	}


	/**
	 * 保存文件弹窗
	 */
	private void showSaveFileDialog() {
		int start = outputFilePath.lastIndexOf("/") + 1;
		int end = outputFilePath.indexOf(".");
		String oldFileName = outputFilePath.substring(start, end);
		CommonDialog dialog = CommonDialog.createDialog(this)
				.setTitleText(getString(R.string.voice_save))
				.setEditText(oldFileName)
				.setEditHint(R.string.txt_input_file_name)
				.setLeftButtonText(getString(R.string.btn_txt_cancel))
				.setLeftButtonAction(v -> {
					mixPresenter.deleteRecordFile(outputFilePath);

				})
				.setRightButtonText(getString(R.string.btn_txt_confirm))
				.setCloseOnTouchOutside(false)
				.setCancelable(false);

		dialog.setRightButtonAction(v -> {
			String newFileName = dialog.getEditText().trim();
			if (StringUtils.isEmpty(newFileName)) {
				CommonToast.showShortToast("文件名称不能为空");
				return;
			}
			if (newFileName.contains(".")) {
				newFileName = newFileName.substring(0, newFileName.indexOf("."));
			}
			String newFilePath = FileUtils.getVoiceFilePath(newFileName + mixVoiceSuffix);
			FileUtils.renameFile(outputFilePath, newFilePath);
			CommonToast.showShortToast("保存成功");
			// 保存到本地数据库
			mixPresenter.saveDataToDB(newFileName);
			reset();
		});

		dialog.show();
	}


	/**
	 * 混音成功，清除当前选择的混音歌曲
	 */
	private void clearPickedDataStatus() {
		for (AudioPlayData audioPlayData : recordModelList) {
			audioPlayData.mixMusicSelectStatus = MixMusicSelectStatus.MUSIC_MIX_UN_SELECTED;
		}
		for (AudioPlayData audioPlayData : musicList) {
			audioPlayData.mixMusicSelectStatus = MixMusicSelectStatus.MUSIC_MIX_UN_SELECTED;
		}
		updateDataList();
	}

	/**
	 * 底部中间按钮状态UI
	 *
	 * @param flag
	 */
	private void renderStartAndPlayUI(boolean flag) {
		txtStartMix.setVisibility(flag ? View.GONE : View.VISIBLE);
		imgMixPlay.setVisibility(flag ? View.VISIBLE : View.GONE);
		imgMixPause.setVisibility(View.GONE);
	}

	/**
	 * 播放、暂停按钮状态UI
	 * @param flag
	 */
	private void renderPlayPauseUI(boolean flag) {
		imgMixPlay.setVisibility(flag ? View.GONE : View.VISIBLE);
		imgMixPause.setVisibility(flag ? View.VISIBLE : View.GONE);
	}


	private ExecuteBinaryResponseHandler mResponseHandler = new ExecuteBinaryResponseHandler() {
		@Override
		public void onFailure(String s) {
			Ln.d("[ffmepg] onFailure %s", s);
			CommonToast.showShortToast(s);
		}

		@Override
		public void onSuccess(String s) {
			Ln.d("[ffmepg] onSuccess %s", s);
			dismissProgressDialog();
			CommonToast.showShortToast("恭喜~ 制作完成啦");
			renderStartAndPlayUI(true);
		}

		@Override
		public void onProgress(String s) {
			Ln.d("[ffmepg] onProgress %s", s);

		}

		@Override
		public void onStart() {
			Ln.d("[ffmepg] onStart");
			showProgressDialog("制作中...", false, null);

		}

		@Override
		public void onFinish() {
			Ln.d("[ffmepg] Finished");

		}
	};


	@Override
	public void showToast(String msg) {
		CommonToast.showShortToast(msg);
	}

	@Override
	public void showErrorMsg(String msg) {
		Ln.e(msg);
	}

	@Override
	public void permissionGrantSuccess() {
		startVoiceMix();
	}

	// 文件播放完毕后停止的事件
	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onAudioPlayerComplete(EventAudioPlayerComplete event) {
		if (auditionModel != null) {
			clearAllDataPlayingStatus();
			auditionModel = null;
		} else {
			renderPlayPauseUI(false);
		}
	}


	// 第 3 步: 申请权限结果返回处理
	@Override
	public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == PermissionCheckUtil.REQUEST_PERMISSION) {
			boolean isAllGranted = true;

			// 判断是否所有的权限都已经授予了
			for (int grant : grantResults) {
				if (grant != PackageManager.PERMISSION_GRANTED) {
					isAllGranted = false;
					break;
				}
			}
			if (isAllGranted) {
				// 如果所有的权限都授予了, 则开始混音
				startVoiceMix();
			} else {
				// 弹出对话框告诉用户需要权限的原因, 并引导用户去应用权限管理中手动打开权限按钮
				PermissionCheckUtil.showGrantFailDialog(this);
			}

		}
	}


}
