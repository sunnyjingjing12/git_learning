package com.itingbaby.app.activity.mix_video;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.itingbaby.app.R;
import com.itingbaby.app.customview.CategoryVoiceView;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.customview.VoiceListSelectView;
import com.itingbaby.app.model.MusicCategory;
import com.itingbaby.baselib.commonutils.StatusBarUtil;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;

import butterknife.BindView;
import butterknife.ButterKnife;

public class VoiceSelectActivity extends BaseFragmentActivity {

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.category_voice_view)
	CategoryVoiceView categoryVoiceView;
	@BindView(R.id.voice_list_select_view)
	VoiceListSelectView voiceListSelectView;

	public static Intent intentFor(Context context) {
		Intent intent = new Intent();
		intent.setClass(context, VoiceSelectActivity.class);
		return intent;
	}


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_voice_select);
		ButterKnife.bind(this);

		initView();

		initListener();

		initData();
	}

	private void initView() {
		StatusBarUtil.StatusBarLightMode(this);
	}

	private void initListener() {
		titleBar.setLeftOnClickListener(v -> finish());
		categoryVoiceView.setOnCategoryVoiceViewListener((pos, category) -> {
			voiceListSelectView.updateCategoryId(category.id);
		});
	}

	private void initData() {
		categoryVoiceView.getMusicGroupData();
		voiceListSelectView.updateCategoryId(MusicCategory.MUSIC_CATEGORY_USER);
	}


	@Override
	public void finish() {
		super.finish();
	}

}
