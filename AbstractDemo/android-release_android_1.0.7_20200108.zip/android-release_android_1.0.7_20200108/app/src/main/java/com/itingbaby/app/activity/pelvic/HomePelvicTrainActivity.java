package com.itingbaby.app.activity.pelvic;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.FrameLayout;

import com.itingbaby.app.R;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.fragment.HomeTrainingFragment;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;

import butterknife.BindView;
import butterknife.ButterKnife;

public class HomePelvicTrainActivity extends BaseFragmentActivity {


	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.fragment_layout)
	FrameLayout fragmentLayout;

	private HomeTrainingFragment mHomeTrainingFragment;


	public static void navigate(Context context) {
		Intent intent = new Intent();
		intent.setClass(context, HomePelvicTrainActivity.class);
		context.startActivity(intent);
	}

	@Override
	protected void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		setContentView(R.layout.activity_home_pelvic_train);
		ButterKnife.bind(this);

		initView();

	}


	private void initView() {
		if (mHomeTrainingFragment == null) {
			mHomeTrainingFragment = HomeTrainingFragment.create();
		}
		getSupportFragmentManager().beginTransaction().add(fragmentLayout.getId(), mHomeTrainingFragment, "HomeTrainingFragment").commitAllowingStateLoss();

		titleBar.setLeftOnClickListener(v -> {
			onBackPressed();
		});

		titleBar.setRightOnClickListener(v -> {
			PelvicTrainAnalysisActivity.navigate(this);
		});
	}
}
