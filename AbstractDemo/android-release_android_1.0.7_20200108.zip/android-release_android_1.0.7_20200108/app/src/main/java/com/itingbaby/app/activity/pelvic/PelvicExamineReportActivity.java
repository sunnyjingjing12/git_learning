package com.itingbaby.app.activity.pelvic;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.mikephil.charting.charts.HorizontalBarChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ValueFormatter;
import com.itingbaby.app.R;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.pelvictrain.MuscleForceData;
import com.itingbaby.app.model.pelvictrain.PelvicTrainRecord;
import com.itingbaby.app.utils.GsonHelper;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.dev.iTingBabyBleDeviceManager;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PelvicExamineReportActivity extends BaseFragmentActivity implements OnChartValueSelectedListener {

	private static final String TAG = PelvicExamineReportActivity.class.getSimpleName();

	private static final String KEY_PELVIC_TRAIN_RECORD = "key_pelvic_train_record";

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.tv_analysis_title)
	TextView tvAnalysisTitle;
	@BindView(R.id.tv_analysis_Imuscle_1)
	TextView tvAnalysisImuscle1;
	@BindView(R.id.tv_analysis_Ilevel)
	TextView tvAnalysisIlevel;
	@BindView(R.id.iv_recover_analysis_Ilevel1)
	ImageView ivRecoverAnalysisIlevel1;
	@BindView(R.id.iv_recover_analysis_Ilevel2)
	ImageView ivRecoverAnalysisIlevel2;
	@BindView(R.id.iv_recover_analysis_Ilevel3)
	ImageView ivRecoverAnalysisIlevel3;
	@BindView(R.id.iv_recover_analysis_Ilevel4)
	ImageView ivRecoverAnalysisIlevel4;
	@BindView(R.id.iv_recover_analysis_Ilevel5)
	ImageView ivRecoverAnalysisIlevel5;
	@BindView(R.id.ll_analysis_levelI)
	LinearLayout llAnalysisLevelI;
	@BindView(R.id.tv_analysis_IImuscle_1)
	TextView tvAnalysisIImuscle1;
	@BindView(R.id.tv_analysis_IIlevel)
	TextView tvAnalysisIIlevel;
	@BindView(R.id.iv_recover_analysis_IIlevel1)
	ImageView ivRecoverAnalysisIIlevel1;
	@BindView(R.id.iv_recover_analysis_IIlevel2)
	ImageView ivRecoverAnalysisIIlevel2;
	@BindView(R.id.iv_recover_analysis_IIlevel3)
	ImageView ivRecoverAnalysisIIlevel3;
	@BindView(R.id.iv_recover_analysis_IIlevel4)
	ImageView ivRecoverAnalysisIIlevel4;
	@BindView(R.id.iv_recover_analysis_IIlevel5)
	ImageView ivRecoverAnalysisIIlevel5;
	@BindView(R.id.ll_analysis_levelII)
	LinearLayout llAnalysisLevelII;
	@BindView(R.id.chart_analysis_current)
	HorizontalBarChart mChart_current;

	@BindView(R.id.tv_analysis_muscle_suggestion)
	TextView tvAnalysisMuscleSuggestion;
	@BindView(R.id.tv_analysis_plan)
	TextView tvAnalysisPlan;
	@BindView(R.id.tv_analysis_plannum)
	TextView tvAnalysisPlannum;
	@BindView(R.id.tv_analysis_level)
	TextView tvAnalysisLevel;
	@BindView(R.id.tv_analysis_levelnum)
	TextView tvAnalysisLevelnum;
	@BindView(R.id.btn_analysis_starttrain)
	Button btnStartTrain;

	private PelvicTrainRecord mPelvicTrainRecord;
	private ImageView[] slowMuscleImageViews;
	private ImageView[] quickMuscleImageViews;

	private int[] slowMuscleBackGroundIds;
	private int[] quickMuscleBackGroundIds;


	public static void navigate(Context context, String pelvicTrainRecord) {
		Intent intent = new Intent();
		intent.putExtra(KEY_PELVIC_TRAIN_RECORD, pelvicTrainRecord);
		intent.setClass(context, PelvicExamineReportActivity.class);
		context.startActivity(intent);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pelvic_examine_report);
		ButterKnife.bind(this);
		initData();
		initView();
		initListener();

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}


	private void initData() {
		Intent intent = getIntent();

		if (intent.hasExtra(KEY_PELVIC_TRAIN_RECORD)) {
			mPelvicTrainRecord = GsonHelper.jsonToObject(intent.getStringExtra(KEY_PELVIC_TRAIN_RECORD), PelvicTrainRecord.class);
		}
		slowMuscleImageViews = new ImageView[]{ivRecoverAnalysisIlevel1, ivRecoverAnalysisIlevel2, ivRecoverAnalysisIlevel3, ivRecoverAnalysisIlevel4, ivRecoverAnalysisIlevel5};
		quickMuscleImageViews = new ImageView[]{ivRecoverAnalysisIIlevel1, ivRecoverAnalysisIIlevel2, ivRecoverAnalysisIIlevel3, ivRecoverAnalysisIIlevel4, ivRecoverAnalysisIIlevel5};

		slowMuscleBackGroundIds = new int[]{R.drawable.bg_rect_20_01d7d2_shape, R.drawable.bg_rect_40_01d7d2_shape,
				R.drawable.bg_rect_60_01d7d2_shape, R.drawable.bg_rect_80_01d7d2_shape, R.drawable.bg_rect_100_01d7d2_shape,};
		quickMuscleBackGroundIds = new int[]{R.drawable.bg_rect_20_ff87c8_shape, R.drawable.bg_rect_40_ff87c8_shape,
				R.drawable.bg_rect_60_ff87c8_shape, R.drawable.bg_rect_80_ff87c8_shape, R.drawable.bg_rect_100_ff87c8_shape,};
	}

	private void initView() {
		renderSlowMuscleView(mPelvicTrainRecord.oneMuscle);
		renderQuickMuscleView(mPelvicTrainRecord.twoMuscle);

		renderRecommendView(mPelvicTrainRecord.caseName, mPelvicTrainRecord.tester);

		initCurrChart();
	}

	private void initListener() {
		// 返回按钮点击事件
		titleBar.setLeftOnClickListener(v -> {
			finish();
			if (iTingBabyBleDeviceManager.getInstance().isLSDeviceConnected()) {
				iTingBabyBleDeviceManager.getInstance().cancelLSDeviceConnect();
			}
		});

		btnStartTrain.setOnClickListener(v -> {
			finish();
			PelvicTrainAdjustActivity.navigate(PelvicExamineReportActivity.this, 2, 60, GsonHelper.objectToJson(mPelvicTrainRecord));
		});
	}

	private void initCurrChart() {

		mChart_current.setOnChartValueSelectedListener(this);
		//无分割线
		mChart_current.setDrawGridBackground(false);
		mChart_current.setDescription("");

		// scaling can now only be done on x- and y-axis separately
		//设置不可以缩放
		mChart_current.setPinchZoom(false);
		//设置无阴影
		mChart_current.setDrawBarShadow(false);
		mChart_current.setDrawValueAboveBar(false);
		//设置左坐标轴
		mChart_current.getAxisLeft().setEnabled(false);
		mChart_current.getAxisLeft().setDrawAxisLine(false);
		mChart_current.getAxisLeft().setDrawLabels(false);
		mChart_current.getAxisLeft().setDrawGridLines(false);
		//设置右坐标轴
		mChart_current.getAxisRight().setDrawLabels(false);
		mChart_current.getAxisRight().setDrawGridLines(false);
		mChart_current.getAxisRight().setStartAtZero(false);
		mChart_current.getAxisRight().setAxisMaxValue(6f);
		mChart_current.getAxisRight().setAxisMinValue(-6f);
		mChart_current.getAxisRight().setLabelCount(7, false);
		mChart_current.getAxisRight().setValueFormatter(new CustomFormatter());
		mChart_current.getAxisRight().setTextSize(9f);

		//禁止图表缩放
		mChart_current.setScaleXEnabled(false);
		mChart_current.setScaleYEnabled(false);
		mChart_current.setFocusable(false);
		mChart_current.setFocusableInTouchMode(false);
		//设置图标不能识别触摸手势
		mChart_current.setTouchEnabled(false);

		//设置X轴有双侧(正负值)
		XAxis xAxis = mChart_current.getXAxis();
		xAxis.setPosition(XAxis.XAxisPosition.BOTH_SIDED);
		xAxis.setDrawGridLines(false);
		xAxis.setDrawAxisLine(true);
		xAxis.setTextSize(9f);

		Legend l = mChart_current.getLegend();
		l.setPosition(Legend.LegendPosition.BELOW_CHART_CENTER);
		l.setFormSize(16f);
		l.setFormToTextSpace(4f);
		l.setXEntrySpace(6f);

		// IMPORTANT: When using negative values in stacked bars, always make sure the negative values are in the array first
		//填入双侧数据
		ArrayList<BarEntry> yValues = new ArrayList<BarEntry>();
		List<MuscleForceData> childs = mPelvicTrainRecord.child;
		for (int i = 0, size = childs.size(); i < size; i++) {
			MuscleForceData data = childs.get(i);
			yValues.add(new BarEntry(new float[]{-data.cOneMuscle, data.cTwoMuscle}, i));
		}

		//设置图表属性
		BarDataSet set = new BarDataSet(yValues, "");
		set.setValueFormatter(new CustomFormatter());
		set.setValueTextSize(7f);
		set.setAxisDependency(YAxis.AxisDependency.RIGHT);
		set.setBarSpacePercent(40f);
		set.setColors(new int[]{0xFF01D7D2, 0xFFFF87C8});
		set.setStackLabels(new String[]{"I类肌", "II类肌"});

		String[] xVals = new String[]{"1", "2", "3", "4", "5"};

		BarData data = new BarData(xVals, set);
		mChart_current.setData(data);
		mChart_current.invalidate();

		mChart_current.animateY(1500);

	}

	private void renderSlowMuscleView(int oneMuscle) {
		tvAnalysisIlevel.setText(oneMuscle + "级");
		for (int i = 0, length = slowMuscleImageViews.length; i < length; i++) {
			if (i < oneMuscle) {
				slowMuscleImageViews[i].setImageResource(slowMuscleBackGroundIds[i]);
			} else {
				slowMuscleImageViews[i].setImageResource(R.drawable.bg_ffe5e5e5_shape);
			}
		}
	}

	private void renderQuickMuscleView(int twoMuscle) {
		tvAnalysisIIlevel.setText(twoMuscle + "级");
		for (int i = 0, length = quickMuscleImageViews.length; i < length; i++) {
			if (i < twoMuscle) {
				quickMuscleImageViews[i].setImageResource(quickMuscleBackGroundIds[i]);
			} else {
				quickMuscleImageViews[i].setImageResource(R.drawable.bg_ffe5e5e5_shape);
			}
		}
	}

	private void renderRecommendView(String caseName, String tester) {
		tvAnalysisPlannum.setText(caseName);
		tvAnalysisLevelnum.setText("5");
		tvAnalysisMuscleSuggestion.setText(tester);
	}

	@Override
	public void onValueSelected(Entry e, int dataSetIndex, Highlight h) {

	}

	@Override
	public void onNothingSelected() {

	}


	private class CustomFormatter implements ValueFormatter {

		private DecimalFormat mFormat;

		public CustomFormatter() {
			mFormat = new DecimalFormat("###");
		}

		@Override
		public String getFormattedValue(float value) {
			return mFormat.format(Math.abs(value)) + "级";
		}
	}


}
