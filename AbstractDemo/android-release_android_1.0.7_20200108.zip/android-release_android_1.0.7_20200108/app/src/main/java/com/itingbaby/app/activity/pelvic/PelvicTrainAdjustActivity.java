package com.itingbaby.app.activity.pelvic;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.RawRes;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.customview.ColorProgressBar;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.pelvictrain.PelvicTrainRecord;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.GsonHelper;
import com.itingbaby.app.utils.SelectTrainingPlanDialog;
import com.itingbaby.baselib.commonutils.ApplicationUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.PermissionCheckUtil;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.CommonDialog;
import com.itingbaby.baselib.views.widget.RadiusImageView;
import com.itingbaby.dev.DeviceType;
import com.itingbaby.dev.events.EventLSDeviceConnection;
import com.itingbaby.dev.events.EventLSDeviceData;
import com.itingbaby.dev.iTingBabyBleDeviceManager;
import com.tbruyelle.rxpermissions2.RxPermissions;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.RequestBody;

public class PelvicTrainAdjustActivity extends BaseFragmentActivity {

	private static final String TAG = PelvicTrainAdjustActivity.class.getSimpleName();
	private static final String DEV_TAG = "LSDevLog";

	private static final String KEY_TYPE = "key_type";
	private static final String KEY_PELVIC_TRAIN_RECORD = "key_pelvic_train_record";
	private static final String KEY_WEIGHT = "key_weight";

	@BindView(R.id.title_bar)
	TitleBar titleBar;

	@BindView(R.id.iv_recover_analysis_mashine)
	RadiusImageView ivRecoverAnalysisMashine;
	@BindView(R.id.tv_adjustment_powernum)
	TextView tvAdjustmentPowernum;
	@BindView(R.id.pb_recover_adjust_power)
	ColorProgressBar pbRecoverAdjustPower;
	@BindView(R.id.ll_pressure)
	LinearLayout llPressure;
	@BindView(R.id.txt_begin_action)
	TextView txtBeginAction;

	private int mSelectType;  // 评估还是训练
	private float mUserWeight = 60;          //用户体重

	private MediaPlayer mPlayer;  // 播放器

	private SelectTrainingPlanDialog mSelectTrainingPlanDialog;

	protected int[] batteryIcons;

	private PelvicTrainRecord mPelvicTrainRecord;

	private float proMax = 100;
	private int trainLevel;
	private int trainTime;
	private int trainType;
	private String level;
	private String type;
	private String time;
	private float adjustPower; // 标定值
	private CommonDialog disconnectDialog;

	private final RxPermissions rxPermissions = new RxPermissions(this);


	public static void navigate(Context context, int type, float userWeight, String pelvicTrainRecord) {
		Intent intent = new Intent();
		intent.putExtra(KEY_TYPE, type);
		intent.putExtra(KEY_PELVIC_TRAIN_RECORD, pelvicTrainRecord);
		intent.putExtra(KEY_WEIGHT, userWeight);
		intent.setClass(context, PelvicTrainAdjustActivity.class);
		context.startActivity(intent);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pelvic_train_adjust);
		ButterKnife.bind(this);
		initData(getIntent());
		initView();
		initListener();

	}

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		Ln.d("lihb onNewIntent");
		initData(intent);
		initView();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		releaseSound();
		if (EventBus.getDefault().isRegistered(this)) {
			EventBus.getDefault().unregister(this);
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		if (!EventBus.getDefault().isRegistered(this)) {
			EventBus.getDefault().register(this);
		}
		boolean connected = iTingBabyBleDeviceManager.getInstance().isLSDeviceConnected();
		Ln.d("lihb connected=%b", connected);
		if (!connected) {
			if (disconnectDialog == null || !disconnectDialog.isShowing()) {
				ApplicationUtils.mMainHandler.postDelayed(() -> {
					rxPermissions.request(Manifest.permission.ACCESS_FINE_LOCATION).subscribe(granted -> {
						if (granted) { // Always true pre-M
							iTingBabyBleDeviceManager.getInstance().searchLSDeviceForConnect();
						} else {
							finish();
						}
					});
				}, 20);
			}
		} else {
			dismissProgressDialog();
			playSound(R.raw.adjust1);
			renderBlueToothIconView(true);
		}

	}

	@Override
	protected void onPause() {
		super.onPause();

		releaseSound();
		if (EventBus.getDefault().isRegistered(this)) {
			EventBus.getDefault().unregister(this);
		}
	}

	private void initView() {

		//压力条
		pbRecoverAdjustPower.setCurrentCount(0);  //最小值0
		proMax = (float) (mUserWeight * 0.12 * 9.8);
		pbRecoverAdjustPower.setMaxCount(proMax);

		txtBeginAction.setEnabled(false);
		titleBar.setTitle(mSelectType == 1 ? "评估准备" : "训练准备");
		txtBeginAction.setText(mSelectType == 1 ? "开始评估" : "开始训练");
	}

	private void initData(Intent intent) {

		batteryIcons = new int[]{R.drawable.ic_lowpower, R.drawable.ic_mediumpower, R.drawable.ic_highpower};

		if (intent.hasExtra(KEY_TYPE)) {
			mSelectType = intent.getIntExtra(KEY_TYPE, 1);
		}
		if (intent.hasExtra(KEY_WEIGHT)) {
			mUserWeight = intent.getFloatExtra(KEY_WEIGHT, 50);
		}
		if (intent.hasExtra(KEY_PELVIC_TRAIN_RECORD)) {
			mPelvicTrainRecord = GsonHelper.jsonToObject(intent.getStringExtra(KEY_PELVIC_TRAIN_RECORD), PelvicTrainRecord.class);
		}

		if (mSelectType == 1) {
			trainLevel = 5;
			trainTime = 5;
			trainType = 1;
			level = "5";
			type = "1";
			time = "5";
			txtBeginAction.setText("开始评估");
		} else {
			trainLevel = 5;
			trainTime = 5;
			trainType = 2;
			level = "5";
			type = "1";
			time = "5";
			txtBeginAction.setText("开始训练");
		}
	}

	private void initListener() {

		// 返回按钮点击事件
		titleBar.setLeftOnClickListener(v -> {
			finish();
			iTingBabyBleDeviceManager.getInstance().cancelLSDeviceConnect();
		});

		// 蓝牙图标点击事件
		titleBar.setRightOnClickListener(v -> {
			rxPermissions.request(Manifest.permission.ACCESS_FINE_LOCATION).subscribe(granted -> {
				if (granted) { // Always true pre-M
					iTingBabyBleDeviceManager.getInstance().searchLSDeviceForConnect();
				} else {
					PermissionCheckUtil.showGrantFailDialog(this, R.string.grant_location_permission);
				}
			});
		});

		// 开始按钮点击事件
		txtBeginAction.setOnClickListener(v -> {
			// 跳转到评估、训练activity
			if (mSelectType == 1) {
				PelvicTrainingActivity.navigate(PelvicTrainAdjustActivity.this, mSelectType, adjustPower, GsonHelper.objectToJson(mPelvicTrainRecord));
			} else {
				// 弹出选择训练方式弹窗
				showSelectTrainingPlanDialog();
			}
		});
	}

	private void renderBlueToothIconView(boolean isConnected) {
		titleBar.setRightDrawable(isConnected ? getDrawable(R.drawable.ic_bluetooth_connect) : getDrawable(R.drawable.ic_bluetooth_disconnect));
	}

	private void showSelectTrainingPlanDialog() {

		SelectTrainingPlanDialog.Builder builder = new SelectTrainingPlanDialog.Builder()
				.setContext(PelvicTrainAdjustActivity.this)
				.setTitle("训练方案：" + mPelvicTrainRecord.caseName)
				.setTrainLevel(5)
				.setTrainTime(5)
				.setConfirmListener(which -> {
					PelvicTrainingActivity.navigate(PelvicTrainAdjustActivity.this, mSelectType, adjustPower,
							mSelectTrainingPlanDialog.getTrainLevel(), mSelectTrainingPlanDialog.getTrainTime(), GsonHelper.objectToJson(mPelvicTrainRecord));
				});

		mSelectTrainingPlanDialog = builder.build();
		mSelectTrainingPlanDialog.show();
	}

	/**
	 * 播放提示音效
	 *
	 * @param resId raw资源文件id ：R.drawable.adjust1
	 */
	private void playSound(@RawRes int resId) {
		try {
			mPlayer = MediaPlayer.create(this, resId);
			mPlayer.setOnCompletionListener(mp -> {
				if (mPlayer != null) {
					mPlayer.release();
					mPlayer = null;
				}
			});
			mPlayer.start();
		} catch (Exception e) {
			Ln.e(e);
		}

	}

	private void releaseSound() {
		Ln.d("lihb releaseSound");
		if (mPlayer != null) {
			mPlayer.stop();
			mPlayer.release();
			mPlayer = null;
		}
	}

	// 更新电量UI
	private void updateBatteryValue(int percent) {
		int index = Math.min(percent / 34, batteryIcons.length - 1);
		titleBar.setSecondRightDrawable(getResources().getDrawable(batteryIcons[index]));
	}

	/**
	 * 显示设备连接断开弹窗
	 */
	private void showDeviceDisconnectDialog() {
		if (disconnectDialog == null) {
			disconnectDialog = CommonDialog.createDialog(this)
					.setTitleText(getString(R.string.title_tips))
					.setText(getResources().getString(R.string.txt_ble_disconnect))
					.setIconVisible(CommonDialog.Visible.Gone)
					.setLeftButtonText(getString(R.string.btn_txt_cancel))
					.setLeftButtonAction(v -> {
						finish();
					})
					.setRightButtonText(getString(R.string.btn_txt_reconnect))
					.setRightButtonAction(v -> {
						rxPermissions.request(Manifest.permission.ACCESS_FINE_LOCATION).subscribe(granted -> {
							if (granted) { // Always true pre-M
								iTingBabyBleDeviceManager.getInstance().searchLSDeviceForConnect();
							} else {
								PermissionCheckUtil.showGrantFailDialog(this, R.string.grant_location_permission);
							}
						});
					})
					.setCloseOnTouchOutside(true)
					.setCancelable(true);
		}

		disconnectDialog.show();
	}


	// region EventBus事件

	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onLSDeviceComm(EventLSDeviceConnection event) {
		switch (event.type) {
		case EventLSDeviceConnection.LS_DEVICE_SCAN_TIMEOUT:
			Log.i(DEV_TAG, "请检查附近是否有训练仪");
		case EventLSDeviceConnection.LS_DEVICE_DISCONNECTED: {
			Log.i(DEV_TAG, "训练仪已断开");
			txtBeginAction.setEnabled(false);
			renderBlueToothIconView(false);
			dismissProgressDialog();
			showDeviceDisconnectDialog();
		}
		break;

		case EventLSDeviceConnection.LS_DEVICE_CONNECTED:
			Log.i(DEV_TAG, "训练仪连接成功");
			dismissProgressDialog();
			playSound(R.raw.adjust1);
			CommonToast.showShortToast("连接成功");
			renderBlueToothIconView(true);

			reportUserDevice(BabyVoiceApp.mUserInfo.id, DeviceType.DEVICE_TYPE_KEGEL, event.devMac);
		break;

		case EventLSDeviceConnection.LS_DEVICE_CONNECTING:
			Log.i(DEV_TAG, "正在搜索并连接训练仪");
			showProgressDialog(getString(R.string.txt_ble_connecting), true, () -> {
				iTingBabyBleDeviceManager.getInstance().cancelLSDeviceConnect();
			});
		break;
		}
	}

	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onLSDeviceData(EventLSDeviceData event) {
		switch (event.type) {
		case EventLSDeviceData.LS_DEVICE_MAC:
			Log.i(DEV_TAG, "训练仪MAC " + event.devMac);
		break;
		case EventLSDeviceData.LS_DEVICE_BATTERY_PERCENTAGE:
			Log.i(DEV_TAG, "训练仪电池电量百分比 " + event.devBattery);
			updateBatteryValue(event.devBattery);
		break;
		case EventLSDeviceData.LS_DEVICE_RSSI:
			Log.i(DEV_TAG, "训练仪RSSI " + event.devRSSI);
		break;
		case EventLSDeviceData.LS_DEVICE_PRESSURE:
			Log.i(DEV_TAG, "训练仪压力值 " + event.devPressure);
			pbRecoverAdjustPower.setCurrentCount(event.devPressure);
			adjustPower = event.devPressure;
			if (!txtBeginAction.isEnabled()) {
				ApplicationUtils.mMainHandler.postDelayed(new Runnable() {
					@Override
					public void run() {
						txtBeginAction.setEnabled(true);
					}
				}, 2000);
			}

		break;
		}
	}

	// endregion

	public void reportUserDevice(long uid, int deviceType, String deviceMac) {
		RequestBody reqUid = RequestBody.create(MediaType.parse("multipart/form-data"), Long.toString(uid));
		RequestBody reqDeviceType = RequestBody.create(MediaType.parse("multipart/form-data"), Integer.toString(deviceType));
		RequestBody reqDeviceMac = RequestBody.create(MediaType.parse("multipart/form-data"), deviceMac);

		ServiceGenerator.createService(ApiManager.class)
				.reportUserDevice(reqUid, reqDeviceType, reqDeviceMac)
				.observeOn(AndroidSchedulers.mainThread())
				.doOnTerminate(() -> {
				})
				.subscribeOn(Schedulers.io())
				.subscribe(httpResponse -> {
					Ln.i("lihb", httpResponse.toString());
					if (ResponseCode.RESPONSE_OK == httpResponse.code) {
						// 成功
						Ln.d("上报设备成功");
					} else {
						CommonToast.showShortToast(httpResponse.msg);
					}
				}, throwable -> Ln.e(throwable.toString()));
	}
}
