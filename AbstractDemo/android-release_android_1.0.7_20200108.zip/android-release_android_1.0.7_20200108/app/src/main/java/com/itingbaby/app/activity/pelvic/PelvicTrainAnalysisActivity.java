package com.itingbaby.app.activity.pelvic;

import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.mikephil.charting.charts.Chart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.Utils;
import com.itingbaby.app.R;
import com.itingbaby.app.components.IHomeTrainingComponent;
import com.itingbaby.app.components.presenter.HomeTrainingPresenter;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.User;
import com.itingbaby.app.model.pelvictrain.PelvicTrainRecord;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PelvicTrainAnalysisActivity extends BaseFragmentActivity implements OnChartValueSelectedListener, IHomeTrainingComponent.IView<PelvicTrainRecord> {

	private static final String TAG = PelvicTrainAnalysisActivity.class.getSimpleName();

	private static final int LIMIT = 5; // 默认获取数量

	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.tv_analysis_title)
	TextView tvAnalysisTitle;
	@BindView(R.id.tv_analysis_Imuscle_1)
	TextView tvAnalysisImuscle1;
	@BindView(R.id.tv_analysis_Ilevel)
	TextView tvAnalysisIlevel;
	@BindView(R.id.iv_recover_analysis_Ilevel1)
	ImageView ivRecoverAnalysisIlevel1;
	@BindView(R.id.iv_recover_analysis_Ilevel2)
	ImageView ivRecoverAnalysisIlevel2;
	@BindView(R.id.iv_recover_analysis_Ilevel3)
	ImageView ivRecoverAnalysisIlevel3;
	@BindView(R.id.iv_recover_analysis_Ilevel4)
	ImageView ivRecoverAnalysisIlevel4;
	@BindView(R.id.iv_recover_analysis_Ilevel5)
	ImageView ivRecoverAnalysisIlevel5;
	@BindView(R.id.ll_analysis_levelI)
	LinearLayout llAnalysisLevelI;
	@BindView(R.id.tv_analysis_IImuscle_1)
	TextView tvAnalysisIImuscle1;
	@BindView(R.id.tv_analysis_IIlevel)
	TextView tvAnalysisIIlevel;
	@BindView(R.id.iv_recover_analysis_IIlevel1)
	ImageView ivRecoverAnalysisIIlevel1;
	@BindView(R.id.iv_recover_analysis_IIlevel2)
	ImageView ivRecoverAnalysisIIlevel2;
	@BindView(R.id.iv_recover_analysis_IIlevel3)
	ImageView ivRecoverAnalysisIIlevel3;
	@BindView(R.id.iv_recover_analysis_IIlevel4)
	ImageView ivRecoverAnalysisIIlevel4;
	@BindView(R.id.iv_recover_analysis_IIlevel5)
	ImageView ivRecoverAnalysisIIlevel5;
	@BindView(R.id.ll_analysis_levelII)
	LinearLayout llAnalysisLevelII;
	@BindView(R.id.chart_analysis_histroy)
	LineChart chartAnalysisHistroy;
	@BindView(R.id.tv_analysis_muscle_suggestion)
	TextView tvAnalysisMuscleSuggestion;
//	@BindView(R.id.tv_analysis_plan)
//	TextView tvAnalysisPlan;
//	@BindView(R.id.tv_analysis_plannum)
//	TextView tvAnalysisPlannum;
//	@BindView(R.id.tv_analysis_level)
//	TextView tvAnalysisLevel;
//	@BindView(R.id.tv_analysis_levelnum)
//	TextView tvAnalysisLevelnum;
//	@BindView(R.id.btn_analysis_starttrain)
//	Button btnAnalysisStartTrain;

	private ImageView[] slowMuscleImageViews;
	private ImageView[] quickMuscleImageViews;

	private int[] slowMuscleBackGroundIds;
	private int[] quickMuscleBackGroundIds;

	// 坐标轴X值
	ArrayList<String> xVals1 = new ArrayList<String>();
	// 实际测量压力值数据
	ArrayList<Entry> yVals1 = new ArrayList<Entry>();
	// 实际测量压力值数据
	ArrayList<Entry> yVals2 = new ArrayList<Entry>();
	// 实际测量压力值数据
	ArrayList<Entry> yVals = new ArrayList<Entry>();
	private float maxPowerData = 0;        //最大肌力历史数据中的最大值
	private int maxPowerDivide = 1;        //最大肌力的除值

	private HomeTrainingPresenter mHomeTrainingPresenter;
	private List<PelvicTrainRecord> mPelvicTrainRecordList = new ArrayList<>();
	private PelvicTrainRecord mPelvicTrainRecord;


	public static void navigate(Context context) {
		Intent intent = new Intent();
		intent.setClass(context, PelvicTrainAnalysisActivity.class);
		context.startActivity(intent);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pelvic_analysis);
		ButterKnife.bind(this);
		initData();
		initListener();

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}


	private void initData() {
		mHomeTrainingPresenter = new HomeTrainingPresenter(this);

		slowMuscleImageViews = new ImageView[]{ivRecoverAnalysisIlevel1, ivRecoverAnalysisIlevel2, ivRecoverAnalysisIlevel3, ivRecoverAnalysisIlevel4, ivRecoverAnalysisIlevel5};
		quickMuscleImageViews = new ImageView[]{ivRecoverAnalysisIIlevel1, ivRecoverAnalysisIIlevel2, ivRecoverAnalysisIIlevel3, ivRecoverAnalysisIIlevel4, ivRecoverAnalysisIIlevel5};

		slowMuscleBackGroundIds = new int[]{R.drawable.bg_rect_20_01d7d2_shape, R.drawable.bg_rect_40_01d7d2_shape,
				R.drawable.bg_rect_60_01d7d2_shape, R.drawable.bg_rect_80_01d7d2_shape, R.drawable.bg_rect_100_01d7d2_shape,};
		quickMuscleBackGroundIds = new int[]{R.drawable.bg_rect_20_ff87c8_shape, R.drawable.bg_rect_40_ff87c8_shape,
				R.drawable.bg_rect_60_ff87c8_shape, R.drawable.bg_rect_80_ff87c8_shape, R.drawable.bg_rect_100_ff87c8_shape,};

		mHomeTrainingPresenter.getPelvicExamineData(1, LIMIT);

		initNoDataChart();

	}

	private void initNoDataChart() {
		Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
		p.setColor(0xFF01D7D2);
		p.setTextAlign(Paint.Align.CENTER);
		p.setTextSize(Utils.convertDpToPixel(12f));
		chartAnalysisHistroy.setPaint(p, Chart.PAINT_INFO);
		chartAnalysisHistroy.setPaint(p, Chart.PAINT_DESCRIPTION);
		chartAnalysisHistroy.setNoDataText("暂无数据");
		chartAnalysisHistroy.setNoDataTextDescription("请评估后在来");
	}


	private void renderAnalysisView() {
		renderSlowMuscleView(mPelvicTrainRecord.oneMuscle);
		renderQuickMuscleView(mPelvicTrainRecord.twoMuscle);

		renderRecommendView(mPelvicTrainRecord.caseName, mPelvicTrainRecord.tester);

		initHistoryChart();
	}

	private void initListener() {
		// 返回按钮点击事件
		titleBar.setLeftOnClickListener(v -> {
			finish();
		});

	}

	private void initHistoryChart() {
		chartAnalysisHistroy.setOnChartValueSelectedListener(this);
		chartAnalysisHistroy.setDescription("");
		chartAnalysisHistroy.setDrawGridBackground(false);

		XAxis xAxis = chartAnalysisHistroy.getXAxis();
		xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
		xAxis.setAvoidFirstLastClipping(true);
		// xAxis.setTypeface(mTf);
		xAxis.setDrawGridLines(false);
		xAxis.setDrawAxisLine(true);
		xAxis.setDrawLabels(true);
		YAxis leftAxis = chartAnalysisHistroy.getAxisLeft();
		// leftAxis.setTypeface(mTf);
		leftAxis.setLabelCount(5, false);

		leftAxis.setAxisMinValue(0);
		leftAxis.setAxisMaxValue(6);
		// 禁止右边Y坐标轴显示
		chartAnalysisHistroy.getAxisRight().setEnabled(false);
		// 禁止X坐标轴显示
		chartAnalysisHistroy.getXAxis().setEnabled(true);
		// 禁止图表缩放
		chartAnalysisHistroy.setScaleXEnabled(false);
		chartAnalysisHistroy.setScaleYEnabled(false);
		chartAnalysisHistroy.setDrawBorders(true);
		chartAnalysisHistroy.setFocusable(true);
		chartAnalysisHistroy.setFocusableInTouchMode(true);
		// recoverchart.setClickable(false);
		// 设置画图标轮廓线
		// 设置图标不能识别触摸手势
		chartAnalysisHistroy.setTouchEnabled(true);

		chartAnalysisHistroy.animateX(0);


	}

	private void renderSlowMuscleView(int oneMuscle) {
		tvAnalysisIlevel.setText(oneMuscle + "级");
		for (int i = 0, length = slowMuscleImageViews.length; i < length; i++) {
			if (i < oneMuscle) {
				slowMuscleImageViews[i].setImageResource(slowMuscleBackGroundIds[i]);
			} else {
				slowMuscleImageViews[i].setImageResource(R.drawable.bg_ffe5e5e5_shape);
			}
		}
	}

	private void renderQuickMuscleView(int twoMuscle) {
		tvAnalysisIIlevel.setText(twoMuscle + "级");
		for (int i = 0, length = quickMuscleImageViews.length; i < length; i++) {
			if (i < twoMuscle) {
				quickMuscleImageViews[i].setImageResource(quickMuscleBackGroundIds[i]);
			} else {
				quickMuscleImageViews[i].setImageResource(R.drawable.bg_ffe5e5e5_shape);
			}
		}
	}

	private void renderRecommendView(String caseName, String tester) {
//		tvAnalysisPlannum.setText(caseName);
//		tvAnalysisLevelnum.setText("5");
		tvAnalysisMuscleSuggestion.setText(tester);
	}

	@Override
	public void onValueSelected(Entry e, int dataSetIndex, Highlight h) {
		Ln.d("onValueSelected, val = %f, XIndex = %d, dataSetIndex = %d", e.getVal(), e.getXIndex(), dataSetIndex);
		int size = mPelvicTrainRecordList.size();
		int xIndex = e.getXIndex();
		if (xIndex < size) {
			mPelvicTrainRecord = mPelvicTrainRecordList.get((size - 1) - xIndex);
			renderAnalysisView();
		}
	}

	@Override
	public void onNothingSelected() {

	}

	/**
	 * 设置数据
	 */
	private void setHistoryData() {
		//清空坐标
		xVals1.clear();
		yVals.clear();
		yVals1.clear();
		yVals2.clear();


		int size = mPelvicTrainRecordList.size();
		int showCount = 5;

		for (int i = 0; i < size; i++) {
			float maxPower = mPelvicTrainRecordList.get(i).maxPower;
			if (maxPower > maxPowerData) {
				maxPowerData = maxPower;
			}
		}
		maxPowerDivide = (int) (maxPowerData / 5);
		maxPowerDivide++;
		for (int i = 0; i < showCount; i++) {
			if (i < size) {
				PelvicTrainRecord record = mPelvicTrainRecordList.get(size - i - 1);
				String dateStr = StringUtils.TimeStamp2Date(record.recordTimeStamp, "yyyy-MM-dd HH:mm:ss");
				int startIndex = dateStr.indexOf("-") + 1;
				int endIndex = dateStr.indexOf(" ");
				xVals1.add(dateStr.substring(startIndex, endIndex));
				yVals1.add(new Entry(record.oneMuscle, i));
				yVals.add(new Entry(record.twoMuscle, i));
				yVals2.add(new Entry(record.maxPower / maxPowerDivide, i));
			} else {
				xVals1.add("");
			}
		}
		LineDataSet set1 = new LineDataSet(yVals1, "I类肌");
		LineDataSet set2 = new LineDataSet(yVals, "II类肌");
		LineDataSet set3 = new LineDataSet(yVals2, "最大肌力");
		// I类肌曲线设置
		set1.enableDashedLine(10f, 0f, 0f);
		set1.setColor(0xFF01D7D2);
		set1.setLineWidth(2f);
		set1.setDrawCircles(true);
		set1.setDrawCircleHole(true);
		set1.setDrawValues(false);
//		set1.setLabel("aa");
		// II类肌曲线设置
		set2.enableDashedLine(10f, 0f, 0f);
		set2.setColor(0xFFFF87C8);
		set2.setLineWidth(2f);
		set2.setDrawCircles(true);
		set2.setDrawCircleHole(true);
		set2.setDrawValues(false);
		// 最大肌力曲线设置
		set3.enableDashedLine(10f, 0f, 0f);
		set3.setColor(0xFFB690FF);
		set3.setLineWidth(2f);
		set3.setDrawCircles(true);
		set3.setDrawCircleHole(true);
		set3.setDrawValues(false);


		//先放set2,再放set1,把set1(实际波形)显示在上层
		ArrayList<LineDataSet> dataSets = new ArrayList<LineDataSet>();
		dataSets.add(set2); // add the datasets
		dataSets.add(set1);
		dataSets.add(set3);
		LineData datachart = new LineData(xVals1, dataSets);
		// set data 如果y坐标大于x坐标则报错
		if ((yVals.size() <= xVals1.size()) || (yVals1.size() <= xVals1.size())) {
			chartAnalysisHistroy.setData(datachart);
		}

	}


	@Override
	public void stopRefresh() {

	}

	@Override
	public void stopLoadMore() {

	}

	@Override
	public void handleFailed() {

	}

	@Override
	public void handleEmpty() {

	}

	@Override
	public void setIsLastPage(boolean isLastPage) {

	}

	@Override
	public void updateProfileSuccess(User userInfo) {

	}

	@Override
	public void updateDataList(List<PelvicTrainRecord> dataList) {
		mPelvicTrainRecordList = dataList;
		int size = dataList.size();
		if (size > 0) {
			mPelvicTrainRecord = dataList.get(size - 1);
		}
		renderAnalysisView();
		setHistoryData();
	}

	@Override
	public void addMoreDataList(List<PelvicTrainRecord> dataList) {

	}

	@Override
	public void showToast(String msg) {
		CommonToast.showShortToast(msg);
	}

}
