package com.itingbaby.app.activity.pelvic;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RawRes;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.model.pelvictrain.MuscleForceData;
import com.itingbaby.app.model.pelvictrain.PelvicTrainRecord;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.GsonHelper;
import com.itingbaby.app.utils.SharedPreferencesUtil;
import com.itingbaby.baselib.commonutils.ApplicationUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.PermissionCheckUtil;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.CommonDialog;
import com.itingbaby.dev.DeviceType;
import com.itingbaby.dev.events.EventLSDeviceConnection;
import com.itingbaby.dev.events.EventLSDeviceData;
import com.itingbaby.dev.iTingBabyBleDeviceManager;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.RequestBody;


public class PelvicTrainingActivity extends BaseFragmentActivity {

	private static final String DEV_TAG = "LSDevLog";
	private static final String KEY_ACTION_TYPE = "key_action_type";
	private static final String KEY_PELVIC_TRAIN_RECORD = "key_pelvic_train_record";
	private static final String KEY_ADJUST_POWER = "key_adjust_power";
	private static final String KEY_TRAIN_LEVEL = "key_train_level";
	private static final String KEY_TRAIN_TIME = "key_train_time";

	private static final int DEFAULT_EXAMINE_TIME = 5;


	@BindView(R.id.title_bar)
	TitleBar titleBar;
	@BindView(R.id.img_speaker)
	ImageView imgSpeaker;
	@BindView(R.id.pb_recover_train_traintime)
	ProgressBar pbRecoverTrainTrainTime;
	@BindView(R.id.txt_remain_time)
	TextView txtRemainTime;
	@BindView(R.id.txt_remain_time_value)
	TextView txtRemainTimeValue;
	@BindView(R.id.line_recover_chart)
	LineChart lineRecoverChart;
	@BindView(R.id.layout_chart)
	ConstraintLayout layoutChart;
	@BindView(R.id.tv_recover_max)
	TextView tvRecoverMax;
	@BindView(R.id.tv_recover_maxpower)
	TextView tvRecoverMaxpower;
	@BindView(R.id.tv_recover_maxkgf)
	TextView tvRecoverMaxkgf;
	@BindView(R.id.tv_recover_now)
	TextView tvRecoverNow;
	@BindView(R.id.tv_recover_nowpower)
	TextView tvRecoverNowpower;
	@BindView(R.id.tv_recover_nowkgf)
	TextView tvRecoverNowkgf;
	@BindView(R.id.ll_recover_nowpower)
	LinearLayout llRecoverNowpower;
	@BindView(R.id.tv_recover_con)
	TextView tvRecoverCon;
	@BindView(R.id.tv_recover_duration)
	TextView tvRecoverDuration;
	@BindView(R.id.ll_recover_con)
	LinearLayout llRecoverCon;
	@BindView(R.id.tv_recover_num)
	TextView tvRecoverNum;
	@BindView(R.id.tv_recover_frequency)
	TextView tvRecoverFrequency;
	@BindView(R.id.tv_recover_second)
	TextView tvRecoverSecond;
	@BindView(R.id.ll_fast_tighten_relax_count)
	LinearLayout llFastTightenRelaxCount;
	@BindView(R.id.tv_recover_goal)
	TextView tvRecoverGoal;
	@BindView(R.id.tv_recover_goalITitle)
	TextView tvRecoverGoalITitle;
	@BindView(R.id.tv_recover_goalI)
	TextView tvRecoverGoalI;
	@BindView(R.id.tv_recover_goalIUnit)
	TextView tvRecoverGoalIUnit;
	@BindView(R.id.tv_recover_goalIITitle)
	TextView tvRecoverGoalIITitle;
	@BindView(R.id.tv_recover_goalII)
	TextView tvRecoverGoalII;
	@BindView(R.id.tv_recover_goalIIUnit)
	TextView tvRecoverGoalIIUnit;
	@BindView(R.id.ll_recover_goal_title)
	LinearLayout llRecoverGoalTitle;


	private int trainLevel;
	private int trainTime = DEFAULT_EXAMINE_TIME;
	private double adjustPower = 10.0f;

	private int trainType; // 训练模式，评估还是单纯训练

	private int maxPowerFlag = 1;   //采集最大肌力和测试波形切换标记
	private int maxPowerCount = 1;// 用于计算最大肌力，采集2次即进入测试
	private MediaPlayer mediaPlayer;
	private int PCBVersion = 1;
	private float maxPower;
	private float powerPara = (float) 0.4;// 训练力度系数
	private String[][] trainPlans;  // 训练方案映射表
	private String trainPlan; // 训练方案;

	private PelvicTrainRecord mPelvicTrainRecord;

	// 倒计时控件
	private CountDownTimer mCountDownTimer;


	// 定义Y坐标轴阈值,已弃用
	private static final Float levelYAxis_1 = (float) 0.6;
	private static final Float levelYAxis_2 = (float) 1.2;
	private static final Float levelYAxis_3 = (float) 2.5;
	private static final Float levelYAxis_4 = (float) 5.0;
	private static final Float levelYAxis_5 = (float) 6.0;
	private static final Float levelYAxis_6 = (float) 10.0;
	private static final Float levelYAxis_7 = (float) 12.0;
	private static final Float levelYAxis_8 = (float) 15.0;
	private static final Float levelYAxis_9 = (float) 20.0;
	private static final Float levelYAxis_10 = (float) 25.0;

	// 定义不同等级Y阈值,已弃用
	private static final Float levelY_1 = (float) 0.33;
	private static final Float levelY_2 = (float) 0.66;
	private static final Float levelY_3 = (float) 1.3;
	private static final Float levelY_4 = (float) 2.6;
	private static final Float levelY_5 = (float) 3.9;
	private static final Float levelY_6 = (float) 5.9;
	private static final Float levelY_7 = (float) 7.9;
	private static final Float levelY_8 = (float) 9.9;
	private static final Float levelY_9 = (float) 11.9;
	private static final Float levelY_10 = (float) 14.4;

	private float pressureValue = 0f;// 下位机上传的压力值
	private float[] pressureDataSet = new float[300];// 下位机上传的压力值

	// 波形种类
	private int waveType = 1;// 训练波形
	private int[] trainWaveTypeSet = new int[10];// 训练波形方案波形组
	private int trainWaveTypeCount = 0; //训练模式下第几个波形
	private float highTypeSet = 1;  //高波模式下的倍数

	private boolean timeADCflag = false;//是否计数持续时间标记，当模板波形要求有收缩时实际收缩才计入有效的持续

	private int durationCount = 0;// 持续时间计算
	private int durationCount_train = 0;// 持续时间计算,用于肌力训练
	private int num_train = 0;// 收放次数计算,用于肌力训练、

	private int slowCount = 0;        //I类肌计数
	private int quickCount = 0;       //II类肌计数
	private int quickLevel = 0; // 快肌等级
	private boolean quickLevelFirstTime = true; // 快肌等级
	private int slowLevel; // 慢肌等级
	private int trainScore; // 训练评分

	// 保存的测试记录
	private List<MuscleForceData> actionDataList = new ArrayList<>();


	//训练模式
	private int contractionTime;           //I类肌收缩时间目标值
	private int contractionNum;           //II类肌收缩次数目标值


	// X坐标
	private ArrayList<String> xVals1 = new ArrayList<String>();
	// 实际测量压力值数据
	private ArrayList<Entry> yVals1 = new ArrayList<Entry>();

	// 模板波形数据，需分不同等级
	ArrayList<Entry> yVals = new ArrayList<Entry>();
	private String mPlan;
	private boolean enablePlaySound = true;
	private int curXVals;
	private boolean typeChoose;
	private int timeCount;
	private boolean testMuscleFlag;
	private double time_MuscleI;
	private boolean isStartCountTimer = false;

	private boolean firstStartAction = false;
	private int remainTime; // 倒计时时长
	private PelvicTrainRecord saveTrainRecord; // 保存后，服务端返回的记录

	public static void navigate(Context context, int actionType, float adjustPower, String pelvicTrainRecord) {
		Intent intent = new Intent();
		intent.putExtra(KEY_ACTION_TYPE, actionType);
		intent.putExtra(KEY_PELVIC_TRAIN_RECORD, pelvicTrainRecord);
		intent.putExtra(KEY_ADJUST_POWER, adjustPower);
		intent.setClass(context, PelvicTrainingActivity.class);
		context.startActivity(intent);
	}

	public static void navigate(Context context, int actionType, float adjustPower, int trainLevel, int trainTime, String pelvicTrainRecord) {
		Intent intent = new Intent();
		intent.putExtra(KEY_ACTION_TYPE, actionType);
		intent.putExtra(KEY_PELVIC_TRAIN_RECORD, pelvicTrainRecord);
		intent.putExtra(KEY_ADJUST_POWER, adjustPower);
		intent.putExtra(KEY_TRAIN_LEVEL, trainLevel);
		intent.putExtra(KEY_TRAIN_TIME, trainTime);
		intent.setClass(context, PelvicTrainingActivity.class);
		context.startActivity(intent);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);  // 屏幕常亮
		setContentView(R.layout.activity_pelvic_training);
		ButterKnife.bind(this);
		initData();
		initView();
		initListener();


	}


	@Override
	protected void onResume() {
		super.onResume();
		boolean connected = iTingBabyBleDeviceManager.getInstance().isLSDeviceConnected();
		if (!EventBus.getDefault().isRegistered(this)) {
			EventBus.getDefault().register(this);
		}

		Ln.d("lihb connected=%b", connected);
		if (!connected) {
			if (!PermissionCheckUtil.checkHasPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
				PermissionCheckUtil.requestPermission(this, new String[]{
						Manifest.permission.ACCESS_FINE_LOCATION,
				});
				return;
			}
			iTingBabyBleDeviceManager.getInstance().searchLSDeviceForConnect();
		} else {
			if (SharedPreferencesUtil.isTrainTipsDialogShowed(PelvicTrainingActivity.this, BabyVoiceApp.mUserInfo.id)) {
				beginAction();
			} else {
				// 显示方法提示弹窗
				showTrainTipsDialog();
			}
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		releaseSound();
		if (EventBus.getDefault().isRegistered(this)) {
			EventBus.getDefault().unregister(this);
		}

		ApplicationUtils.mMainHandler.removeCallbacks(runnable);
		runnable = null;

	}

	@Override
	protected void onPause() {
		super.onPause();
		releaseSound();
		if (mCountDownTimer != null) {
			mCountDownTimer.cancel();
			mCountDownTimer = null;
		}
		if (EventBus.getDefault().isRegistered(this)) {
			EventBus.getDefault().unregister(this);
		}
		ApplicationUtils.mMainHandler.removeCallbacks(runnable);
//		runnable = null;
	}


	@Override
	public void onBackPressed() {
		super.onBackPressed();
		releaseSound();
		if (EventBus.getDefault().isRegistered(this)) {
			EventBus.getDefault().unregister(this);
		}
		ApplicationUtils.mMainHandler.removeCallbacks(runnable);
		runnable = null;
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == PermissionCheckUtil.REQUEST_PERMISSION) {
			boolean isAllGranted = true;

			// 判断是否所有的权限都已经授予了
			for (int grant : grantResults) {
				if (grant != PackageManager.PERMISSION_GRANTED) {
					isAllGranted = false;
					break;
				}
			}
			if (isAllGranted) {
				iTingBabyBleDeviceManager.getInstance().searchLSDeviceForConnect();
			} else {
				// 弹出对话框告诉用户需要权限的原因, 并引导用户去应用权限管理中手动打开权限按钮
				PermissionCheckUtil.showGrantFailDialog(this, R.string.grant_location_permission);
			}
		}
	}

	private void initData() {

		Intent intent = getIntent();
		if (intent.hasExtra(KEY_ACTION_TYPE)) {
			trainType = intent.getIntExtra(KEY_ACTION_TYPE, 1);
		}
		if (intent.hasExtra(KEY_ADJUST_POWER)) {
			adjustPower = intent.getFloatExtra(KEY_ADJUST_POWER, 16);
		}
		if (intent.hasExtra(KEY_PELVIC_TRAIN_RECORD)) {
			mPelvicTrainRecord = GsonHelper.jsonToObject(intent.getStringExtra(KEY_PELVIC_TRAIN_RECORD), PelvicTrainRecord.class);
		}

		if (intent.hasExtra(KEY_TRAIN_LEVEL)) {
			trainLevel = intent.getIntExtra(KEY_TRAIN_LEVEL, 5);
		}

		if (intent.hasExtra(KEY_TRAIN_TIME)) {
			trainTime = intent.getIntExtra(KEY_TRAIN_TIME, 5);
		}

		// 初始化训练方案
		trainPlans = new String[][]{
				{"A", "A", "B", "C", "D", "E"},
				{"A", "A", "B", "C", "D", "E"},
				{"A", "F", "G", "H", "I", "J"},
				{"A", "K", "L", "M", "N", "O"},
				{"A", "P", "Q", "R", "S", "T"},
				{"A", "U", "V", "W", "X", "Y"},
		};

		// 初始化actionDataList
		for (int i = 0; i < 5; i++) {
			MuscleForceData data = new MuscleForceData();
			actionDataList.add(data);
		}
	}

	private void initView() {
		if (trainType == 1) { // 评估
			trainTime = DEFAULT_EXAMINE_TIME;    //默认测试5分钟
			if (PCBVersion == 1) {
				trainLevel = 9;   //默认测试强度为9级,即最大肌力默认20kgf
			} else {
				trainLevel = 6;   //默认测试强度为6级,即最大肌力默认10kgf
			}
			maxPower = 0;
			tvRecoverMaxpower.setText(String.valueOf(maxPower));
			titleBar.setTitle("肌力评估");
			//初始化图表
			initChart(trainLevel);
			setData(0, 0, trainLevel);
			lineRecoverChart.animateX(0);
		} else {
			if (mPelvicTrainRecord != null) {
				maxPower = (float) mPelvicTrainRecord.maxPower;
				mPlan = mPelvicTrainRecord.caseName == null ? "A" : mPelvicTrainRecord.caseName;
			}
			//播放训练语音
			titleBar.setTitle("肌力训练");
			//根据训练等级不同,设置不同的训练难度,即占最大肌力的比例不同
			switch (trainLevel) {
				case 1:  //40%
					powerPara = (float) 0.4;
					break;
				case 2:  //50%
					powerPara = (float) 0.5;
					break;
				case 3:  //60%
					powerPara = (float) 0.6;
					break;
				case 4:  //70%
					powerPara = (float) 0.7;
					break;
				case 5:  //75%
					powerPara = (float) 0.75;
					break;
				case 6:  //80%
					powerPara = (float) 0.8;
					break;
				case 7:  //85%
					powerPara = (float) 0.85;
					break;
				case 8:  //90%
					powerPara = (float) 0.9;
					break;
				case 9:  //95%
					powerPara = (float) 0.95;
					break;
				case 10: //100%
					powerPara = (float) 1;
					break;
				default:
					break;
			}
			//2为训练标记,直接开始训练波形,不需要采集最大肌力
			maxPowerFlag = 2;
			//初始化图表
			initChart(trainLevel);
			//设置图表坐标轴,当最大肌力小于10时就设置为10,大于10时则设置为1.2倍
//			if(maxpower >= 10)
			lineRecoverChart.getAxisLeft().setAxisMaxValue((float) (maxPower * 1.2));
//			else
//				recoverchart.getAxisLeft().setAxisMaxValue((float) (10*1.2));
			//清理模板数组
			yVals.clear();
			//训练初始化波形为2
			setParameter();
			waveType = trainWaveTypeSet[0];
			//设置模板波形
//			if(maxpower >= 10)
			setModelyValsType(waveType, levelYAxis_1, (float) (maxPower * powerPara));
//			else
//				setModelyValsType(type, levelYAxis_1, (float) (10*powerpara));
			//设置数据到图表中
			setData(0, 0, trainLevel);
			//显示
			lineRecoverChart.animateX(0);
			//当前肌力显示隐藏
			llRecoverNowpower.setVisibility(View.GONE);
			llRecoverCon.setVisibility(View.GONE);
			llRecoverGoalTitle.setVisibility(View.VISIBLE);
//			show_goal_ll.setVisibility(View.VISIBLE);
			//当为波形测试时，标题显示切换
			tvRecoverMax.setText("I类肌收缩持续时间：");
//			show_nowPower_title.setText("目标：");
//			show_nowPower.setText(String.valueOf(contractionTime));
//			llRecoverNowpower.set
//			show_duration_title.setText("II类肌有效收缩次数：");
			tvRecoverNum.setText("II类肌有效收缩次数：");
			tvRecoverMaxkgf.setText("秒");
			//设计目标值
			contractionTime *= trainTime / 5;
			contractionNum *= trainTime / 5;
			tvRecoverGoalI.setText(String.valueOf(contractionTime));
			tvRecoverGoalII.setText(String.valueOf(contractionNum));
		}

		remainTime = trainTime * 60;
		pbRecoverTrainTrainTime.setMax(remainTime);
		pbRecoverTrainTrainTime.setProgress(0);

	}

	private void initListener() {

		// 返回按钮点击事件
		titleBar.setLeftOnClickListener(v -> {
			finish();
		});

		imgSpeaker.setOnClickListener(v -> {
			enablePlaySound = !enablePlaySound;
			imgSpeaker.setImageResource(enablePlaySound ? R.drawable.ic_speaker_open : R.drawable.ic_speaker_close);
		});

	}

	private void showTrainTipsDialog() {
		CommonDialog.createDialog(this)
				.setTitleText(getString(R.string.title_tips))
				.setText("曲线上升时收缩肌肉\n曲线下降时放松肌肉")
				.setIconVisible(CommonDialog.Visible.Gone)
				.setLeftButtonText("知道了")
				.setLeftButtonAction(v -> {
					if (iTingBabyBleDeviceManager.getInstance().isLSDeviceConnected()) {
						beginAction();
					} else {
						if (!PermissionCheckUtil.checkHasPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
							PermissionCheckUtil.requestPermission(this, new String[]{
									Manifest.permission.ACCESS_FINE_LOCATION,
							});
							return;
						}
						iTingBabyBleDeviceManager.getInstance().searchLSDeviceForConnect();
					}
				})
				.setRightButtonText("不再提醒")
				.setRightButtonAction(v -> {
					SharedPreferencesUtil.setTrainTipsDialogShowed(PelvicTrainingActivity.this, BabyVoiceApp.mUserInfo.id, true);
					if (iTingBabyBleDeviceManager.getInstance().isLSDeviceConnected()) {
						beginAction();
					} else {
						if (!PermissionCheckUtil.checkHasPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
							PermissionCheckUtil.requestPermission(this, new String[]{
									Manifest.permission.ACCESS_FINE_LOCATION,
							});
							return;
						}
						iTingBabyBleDeviceManager.getInstance().searchLSDeviceForConnect();
					}

				})
				.setCloseOnTouchOutside(false)
				.setCancelable(false)
				.show();
	}


	// 开始评估、训练操作
	private void beginAction() {
		if (!firstStartAction) {
			prepareAction();
			firstStartAction = true;
		} else {
			ApplicationUtils.mMainHandler.postDelayed(runnable, 100);
			isStartCountTimer = false;
		}
	}


	/**
	 * 初始化曲线图
	 */
	private void initChart(int level) {
		lineRecoverChart.setDescription("");
		lineRecoverChart.setDrawGridBackground(false);

		XAxis xAxis = lineRecoverChart.getXAxis();
		xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
		// xAxis.setTypeface(mTf);
		xAxis.setDrawGridLines(false);
		xAxis.setDrawAxisLine(true);

		YAxis leftAxis = lineRecoverChart.getAxisLeft();
		// leftAxis.setTypeface(mTf);
		leftAxis.setLabelCount(5, false);
		// 根据不同训练等级设置Y坐标轴
		switch (level) {
			case 1:
				leftAxis.setAxisMaxValue(levelYAxis_1);
				break;
			case 2:
				leftAxis.setAxisMaxValue(levelYAxis_2);
				break;
			case 3:
				leftAxis.setAxisMaxValue(levelYAxis_3);
				break;
			case 4:
				leftAxis.setAxisMaxValue(levelYAxis_4);
				break;
			case 5:
				leftAxis.setAxisMaxValue(levelYAxis_5);
				break;
			case 6:
				leftAxis.setAxisMaxValue(levelYAxis_6);
				break;
			case 7:
				leftAxis.setAxisMaxValue(levelYAxis_7);
				break;
			case 8:
				leftAxis.setAxisMaxValue(levelYAxis_8);
				break;
			case 9:
				leftAxis.setAxisMaxValue(levelYAxis_9);
				break;
			case 10:
				leftAxis.setAxisMaxValue(levelYAxis_10);
				break;
			default:
				leftAxis.setAxisMaxValue(30);
				break;
		}

		leftAxis.setAxisMinValue(0);

		// 禁止右边Y坐标轴显示
		lineRecoverChart.getAxisRight().setEnabled(false);
		// 禁止X坐标轴显示
		lineRecoverChart.getXAxis().setEnabled(false);
		// 禁止图表缩放
		lineRecoverChart.setScaleXEnabled(false);
		lineRecoverChart.setScaleYEnabled(false);
		lineRecoverChart.setFocusable(false);
		lineRecoverChart.setFocusableInTouchMode(false);
		// lineRecoverChart.setClickable(false);
		// 设置画图标轮廓线
		lineRecoverChart.setDrawBorders(true);
		// 设置图标不能识别触摸手势
		lineRecoverChart.setTouchEnabled(false);
		if (trainType == 1) {
			waveType = 7;
		} else if (trainType == 2) {
			waveType = 1;
		} else {
			Random a = new Random();
			waveType = a.nextInt(6);
			Ln.d("value=%d", waveType);
			waveType += 1;
		}
		setModelyVals(level, waveType);
		// setData(100, 10);
		lineRecoverChart.animateX(0);
	}


	/**
	 * 画图函数
	 *
	 * @param xVals
	 * @param data
	 * @param trainlevel
	 */
	private void setData(int xVals, float data, int trainlevel) {
		xVals1.clear();
		//先填入300个X坐标
		for (int i = 0; i < 300; i++) {
			xVals1.add("");
		}
		DecimalFormat decimalFormat = new DecimalFormat("0.0");
		//如果data大于坐标轴最大值则显示为最大值
		if (data <= 0)
			yVals1.add(new Entry(0, xVals));
		else if (data <= lineRecoverChart.getAxisLeft().getAxisMaxValue())
			yVals1.add(new Entry(data, xVals));
		else
			yVals1.add(new Entry(lineRecoverChart.getAxisLeft().getAxisMaxValue(), xVals));

		//如果是肌力测试,则当data大于maxpower的60%则属于有效数值，增加持续时间
		if (trainType == 1) {
			if ((data >= maxPower * 0.6) && (maxPowerFlag == 2) && (timeADCflag)) {
				durationCount += 1;
				if (waveType == 1)
					tvRecoverDuration.setText(decimalFormat.format(durationCount * 0.1));
			}
		} else  //如果是盆底训练则需要根据等级判断data是否大于maxpower*powerpara的值
			if ((data >= maxPower * powerPara) && (maxPowerFlag == 2) && (timeADCflag)) {
				//总持续时间
				durationCount_train += 1;
				//单次波形的持续时间,用于判断有效收放次数
				durationCount += 1;
				tvRecoverMaxpower.setText(decimalFormat.format(durationCount_train * 0.1));
			}

		//根据不同波形进行有效收放次数的显示
		switch (waveType) {
			case 2:
				if ((xVals == 80) || (xVals == 180) || (xVals == 280)) {
					if (durationCount * 0.1 >= 4) {
						num_train++;
						tvRecoverFrequency.setText(String.valueOf(num_train));
					}
					durationCount = 0;
				}
				break;
			case 3:
				if ((xVals == 120) || (xVals == 280)) {
					if (durationCount * 0.1 >= 6) {
						num_train++;
						tvRecoverFrequency.setText(String.valueOf(num_train));
					}
					durationCount = 0;
				}
				break;
			case 4:
				if ((xVals == 120) || (xVals == 260)) {
					if (durationCount * 0.1 >= 8) {
						num_train++;
						tvRecoverFrequency.setText(String.valueOf(num_train));
					}
					durationCount = 0;
				}
				break;
			case 5:
				if ((xVals == 50) || (xVals == 100) || (xVals == 150) || (xVals == 200) || (xVals == 250)) {
					if (durationCount * 0.1 >= 1) {
						num_train++;
						tvRecoverFrequency.setText(String.valueOf(num_train));
					}
					durationCount = 0;
				}
				break;
			case 6:
				if ((xVals == 40) || (xVals == 100) || (xVals == 160) || (xVals == 220) || (xVals == 280)) {
					if (trainType == 1) {
						if (durationCount >= 1) {
							quickLevel++;
							tvRecoverFrequency.setText(String.valueOf(quickLevel));
						}
					} else if (durationCount * 0.1 >= 1) {
						num_train++;
						tvRecoverFrequency.setText(String.valueOf(num_train));
					}
					durationCount = 0;
				}
				break;
			case 7:
				if ((xVals == 50) || (xVals == 150) || (xVals == 250)) {
					if (trainType == 2) {
						if (durationCount * 0.1 >= 1) {
							num_train++;
							tvRecoverFrequency.setText(String.valueOf(num_train));
						}
					}
					durationCount = 0;
				}
				break;
			default:
				break;
		}

		LineDataSet set1 = new LineDataSet(yVals1, "实际曲线");
		LineDataSet set2 = new LineDataSet(yVals, trainType == 1 ? "评估曲线" : "训练曲线");
		// 实际压力值曲线设置
		set1.enableDashedLine(10f, 0f, 0f);
		set1.setColor(0xFFF186FD);
		set1.setLineWidth(3f);
		set1.setDrawCircles(false);
		set1.setDrawCircleHole(false);
		set1.setDrawValues(false);
		// 模板训练曲线设置
		set2.enableDashedLine(10f, 0f, 0f);
		set2.setColor(0xFF00BED7);
		set2.setLineWidth(3f);
		set2.setDrawCircles(false);
		set2.setDrawCircleHole(false);
		set2.setDrawValues(false);

		//先放set2,再放set1,把set1(实际波形)显示在上层
		ArrayList<LineDataSet> dataSets = new ArrayList<LineDataSet>();
		dataSets.add(set2); // add the datasets
		dataSets.add(set1);
		LineData dataChart = new LineData(xVals1, dataSets);
		// set data 如果y坐标大于x坐标则报错
		if ((yVals.size() <= xVals1.size()) || (yVals1.size() <= xVals1.size())) {
			lineRecoverChart.setData(dataChart);
		}

	}

	/**
	 * 设置波形模板
	 *
	 * @param level
	 * @param type
	 */
	private void setModelyVals(int level, int type) {
		switch (level) {
			case 1:
				setModelyValsType(type, levelYAxis_1, levelY_1);
				break;
			case 2:
				setModelyValsType(type, levelYAxis_2, levelY_2);
				break;
			case 3:
				setModelyValsType(type, levelYAxis_3, levelY_3);
				break;
			case 4:
				setModelyValsType(type, levelYAxis_4, levelY_4);
				break;
			case 5:
				setModelyValsType(type, levelYAxis_5, levelY_5);
				break;
			case 6:
				setModelyValsType(type, levelYAxis_6, levelY_6);
				break;
			case 7:
				setModelyValsType(type, levelYAxis_7, levelY_7);
				break;
			case 8:
				setModelyValsType(type, levelYAxis_8, levelY_8);
				break;
			case 9:
				setModelyValsType(type, levelYAxis_9, levelY_9);
				break;
			case 10:
				setModelyValsType(type, levelYAxis_10, levelY_10);
				break;
			default:
				break;
		}
	}

	/**
	 * 模板波形数据，需分不同等级
	 *
	 * @param type
	 * @param levelYAxis
	 * @param levelY
	 */
	private void setModelyValsType(int type, float levelYAxis, float levelY) {
		switch (type) {
			// 波形1  I类肌测试波形  持续5秒
			case 1:
				for (int i = 0; i < 300; i++) {
					float val = 0;
					if (i <= 110 && i >= 100) {
						val = levelY / 10 * i - 10 * levelY;
					} else if (i < 160 && i > 110) {
						val = levelY;
					} else if (i <= 170 && i >= 160) {
						val = (-levelY) / 10 * i + 17 * levelY;
					} else {
						val = 0;
					}
					yVals.add(new Entry(val, i));
				}
				break;
			// 波形2 I类肌测试波形  持续4秒
			case 2:
				for (int i = 0; i < 300; i++) {
					float val = 0;
					if (i <= 30 && i >= 20) {
						val = levelY / 10 * i - 2 * levelY;
					} else if (i <= 130 && i >= 120) {
						val = levelY / 10 * i - 12 * levelY;
					} else if (i <= 230 && i >= 220) {
						val = levelY / 10 * i - 22 * levelY;
					} else if ((i <= 70 && i >= 30) || (i <= 170 && i >= 130) || (i <= 270 && i >= 230)) {
						val = levelY;
					} else if (i < 80 && i > 70) {
						val = (-levelY) / 10 * i + 8 * levelY;
					} else if (i <= 180 && i >= 170) {
						val = (-levelY) / 10 * i + 18 * levelY;
					} else if (i <= 280 && i >= 270) {
						val = (-levelY) / 10 * i + 28 * levelY;
					} else {
						val = 0;
					}
					yVals.add(new Entry(val, i));
				}
				break;

			// 波形3 I类肌测试波形  持续6秒
			case 3:
				for (int i = 0; i < 300; i++) {
					float val = 0;
					if (i <= 50 && i >= 40) {
						val = levelY / 10 * i - 4 * levelY;
					} else if (i <= 210 && i >= 200) {
						val = levelY / 10 * i - 20 * levelY;
					} else if ((i < 110 && i > 50) || (i < 270 && i > 210)) {
						val = levelY;
					} else if (i <= 120 && i >= 110) {
						val = (-levelY) / 10 * i + 12 * levelY;
					} else if (i <= 280 && i >= 270) {
						val = (-levelY) / 10 * i + 28 * levelY;
					} else {
						val = 0;
					}
					yVals.add(new Entry(val, i));
				}
				break;
			// 波形3 I类肌测试波形  持续8秒
			case 4:
				for (int i = 0; i < 300; i++) {
					float val = 0;
					if (i <= 30 && i >= 20) {
						val = levelY / 10 * i - 2 * levelY;
					} else if (i <= 170 && i >= 160) {
						val = levelY / 10 * i - 16 * levelY;
					} else if ((i < 110 && i > 30) || (i < 250 && i > 170)) {
						val = levelY;
					} else if (i <= 120 && i >= 110) {
						val = (-levelY) / 10 * i + 12 * levelY;
					} else if (i <= 260 && i >= 250) {
						val = (-levelY) / 10 * i + 26 * levelY;
					} else {
						val = 0;
					}
					yVals.add(new Entry(val, i));
				}
				break;
			case 5:
				for (int i = 0; i < 300; i++) {
					float val = 0;
					if (i <= 60 && i >= 50) {
						val = levelY / 10 * i - 5 * levelY;
					} else if ((i < 100 && i > 60) || (i < 240 && i > 200)) {
						val = levelY;
					} else if (i <= 110 && i >= 100) {
						val = (-levelY) / 10 * i + 11 * levelY;
					} else if (i <= 200 && i >= 190) {
						val = levelY / 10 * i - 19 * levelY;
					} else if (i <= 250 && i >= 240) {
						val = (-levelY) / 10 * i + 25 * levelY;
					} else {
						val = 0;
					}
					yVals.add(new Entry(val, i));
				}
				break;
			case 6:   //II类肌训练波形,5次快速收放
				for (int i = 0; i < 300; i++) {
					float val = 0;
					if (i <= 30 && i >= 20) {
						val = levelY / 10 * i - 2 * levelY;
					} else if (i < 90 && i >= 80) {
						val = levelY / 10 * i - 8 * levelY;
					} else if (i < 150 && i >= 140) {
						val = levelY / 10 * i - 14 * levelY;
					} else if (i < 210 && i >= 200) {
						val = levelY / 10 * i - 20 * levelY;
					} else if (i < 270 && i >= 260) {
						val = levelY / 10 * i - 26 * levelY;
					}
//				else if ((i <= 40 && i >= 30) || (i <= 90 && i >= 80)
//						|| (i <= 140 && i >= 130) || (i <= 190 && i >= 180)
//						|| (i <= 240 && i >= 230)) {
//					val = levelY;
//				} 
//				else if (i <= 50 && i > 40) {
//					val = (-levelY) / 10 * i + 5 * levelY;
//				} else if (i <= 100 && i > 90) {
//					val = (-levelY) / 10 * i + 10 * levelY;
//				} else if (i <= 150 && i > 140) {
//					val = (-levelY) / 10 * i + 15 * levelY;
//				} else if (i <= 200 && i > 190) {
//					val = (-levelY) / 10 * i + 20 * levelY;
//				} else if (i <= 250 && i > 240) {
//					val = (-levelY) / 10 * i + 25 * levelY;
//				}				
					else if (i <= 40 && i >= 30) {
						val = (-levelY) / 10 * i + 4 * levelY;
					} else if (i <= 100 && i >= 90) {
						val = (-levelY) / 10 * i + 10 * levelY;
					} else if (i <= 160 && i >= 150) {
						val = (-levelY) / 10 * i + 16 * levelY;
					} else if (i <= 220 && i >= 210) {
						val = (-levelY) / 10 * i + 22 * levelY;
					} else if (i <= 280 && i >= 270) {
						val = (-levelY) / 10 * i + 28 * levelY;
//					if(i == 250)
//						timeADCflag = false;
					} else {
						val = 0;
					}
					yVals.add(new Entry(val, i));
				}
				break;
			case 7:            // 波形7 II类肌训练波形,3次快速收放
				for (int i = 0; i < 300; i++) {
					float val = 0;
					if (i <= 30 && i >= 20) {
						val = levelY / 10 * i - 2 * levelY;
					} else if (i < 130 && i >= 120) {
						val = levelY / 10 * i - 12 * levelY;
					} else if (i < 230 && i >= 220) {
						val = levelY / 10 * i - 22 * levelY;
					} else if ((i <= 40 && i >= 30)
							|| (i <= 140 && i >= 130)
							|| (i <= 240 && i >= 230)) {
						val = levelY;
					} else if (i <= 50 && i > 40) {
						val = (-levelY) / 10 * i + 5 * levelY;
					} else if (i <= 150 && i > 140) {
						val = (-levelY) / 10 * i + 15 * levelY;
					} else if (i <= 250 && i > 240) {
						val = (-levelY) / 10 * i + 25 * levelY;
					} else {
						val = 0;
					}
					yVals.add(new Entry(val, i));
				}
				break;


			case 8://训练波形：基波
				for (int i = 0; i < 300; i++) {
					float val = 0;
					if (i <= 30 && i >= 20) {
						val = levelY / 10 * i - 2 * levelY;
					} else if (i < 130 && i >= 120) {
						val = levelY / 10 * i - 12 * levelY;
					} else if (i < 230 && i >= 220) {
						val = levelY / 10 * i - 22 * levelY;
					} else if ((i <= 70 && i >= 30)
							|| (i <= 170 && i >= 130)
							|| (i <= 270 && i >= 230)) {
						val = levelY;
					} else if (i <= 80 && i > 70) {
						val = (-levelY) / 10 * i + 8 * levelY;
					} else if (i <= 180 && i > 170) {
						val = (-levelY) / 10 * i + 18 * levelY;
					} else if (i <= 280 && i > 240) {
						val = (-levelY) / 10 * i + 28 * levelY;
					} else {
						val = 0;
					}
					yVals.add(new Entry(val, i));
				}
				break;
			case 9://训练波形：长波1
				for (int i = 0; i < 300; i++) {
					float val = 0;
					if (i <= 50 && i >= 40) {
						val = levelY / 10 * i - 4 * levelY;
					} else if (i < 190 && i >= 180) {
						val = levelY / 10 * i - 18 * levelY;
					} else if ((i <= 110 && i >= 50)
							|| (i <= 250 && i >= 190)) {
						val = levelY;
					} else if (i <= 120 && i > 110) {
						val = (-levelY) / 10 * i + 12 * levelY;
					} else if (i <= 260 && i > 250) {
						val = (-levelY) / 10 * i + 26 * levelY;
					} else {
						val = 0;
					}
					yVals.add(new Entry(val, i));
				}
				break;
			case 10://训练波形：长波2
				for (int i = 0; i < 300; i++) {
					float val = 0;
					if (i <= 50 && i >= 40) {
						val = levelY / 10 * i - 4 * levelY;
					} else if (i < 180 && i >= 170) {
						val = levelY / 10 * i - 17 * levelY;
					} else if ((i <= 120 && i >= 50)
							|| (i <= 250 && i >= 180)) {
						val = levelY;
					} else if (i <= 130 && i > 120) {
						val = (-levelY) / 10 * i + 13 * levelY;
					} else if (i <= 260 && i > 250) {
						val = (-levelY) / 10 * i + 26 * levelY;
					} else {
						val = 0;
					}
					yVals.add(new Entry(val, i));
				}
				break;
			case 11://训练波形：长波3
				for (int i = 0; i < 300; i++) {
					float val = 0;
					if (i <= 40 && i >= 30) {
						val = levelY / 10 * i - 3 * levelY;
					} else if (i < 180 && i >= 170) {
						val = levelY / 10 * i - 17 * levelY;
					} else if ((i <= 120 && i >= 40)
							|| (i <= 260 && i >= 180)) {
						val = levelY;
					} else if (i <= 130 && i > 120) {
						val = (-levelY) / 10 * i + 13 * levelY;
					} else if (i <= 270 && i > 260) {
						val = (-levelY) / 10 * i + 27 * levelY;
					} else {
						val = 0;
					}
					yVals.add(new Entry(val, i));
				}
				break;
			case 12://训练波形：长波4
				for (int i = 0; i < 300; i++) {
					float val = 0;
					if (i <= 40 && i >= 30) {
						val = levelY / 10 * i - 3 * levelY;
					} else if (i < 170 && i >= 160) {
						val = levelY / 10 * i - 16 * levelY;
					} else if ((i <= 130 && i >= 40)
							|| (i <= 260 && i >= 170)) {
						val = levelY;
					} else if (i <= 140 && i > 130) {
						val = (-levelY) / 10 * i + 14 * levelY;
					} else if (i <= 270 && i > 260) {
						val = (-levelY) / 10 * i + 27 * levelY;
					} else {
						val = 0;
					}
					yVals.add(new Entry(val, i));
				}
				break;
			case 13://训练波形：长波5
				for (int i = 0; i < 300; i++) {
					float val = 0;
					if (i <= 30 && i >= 20) {
						val = levelY / 10 * i - 2 * levelY;
					} else if (i < 170 && i >= 160) {
						val = levelY / 10 * i - 16 * levelY;
					} else if ((i <= 130 && i >= 30)
							|| (i <= 270 && i >= 170)) {
						val = levelY;
					} else if (i <= 140 && i > 130) {
						val = (-levelY) / 10 * i + 14 * levelY;
					} else if (i <= 280 && i > 270) {
						val = (-levelY) / 10 * i + 28 * levelY;
					} else {
						val = 0;
					}
					yVals.add(new Entry(val, i));
				}
				break;
			default:
				break;
		}

	}


	/**
	 * 设置训练参数
	 */
	private void setParameter() {
		if (mPlan.equals("A")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 9;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 9;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.1;
			contractionTime = 96;
			contractionNum = 10;
		} else if (mPlan.equals("B")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 10;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 10;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.1;
			contractionTime = 100;
			contractionNum = 10;
		} else if (mPlan.equals("C")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 11;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 11;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.1;
			contractionTime = 104;
			contractionNum = 10;
		} else if (mPlan.equals("D")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 12;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 12;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.1;
			contractionTime = 108;
			contractionNum = 10;
		} else if (mPlan.equals("E")) {

			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 13;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 13;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.1;
			contractionTime = 112;
			contractionNum = 10;
		} else if (mPlan.equals("F")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 9;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 9;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.15;
			contractionTime = 96;
			contractionNum = 10;
		} else if (mPlan.equals("G")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 10;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 10;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.15;
			contractionTime = 100;
			contractionNum = 10;
		} else if (mPlan.equals("H")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 11;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 11;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.15;
			contractionTime = 104;
			contractionNum = 10;
		} else if (mPlan.equals("I")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 12;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 12;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.15;
			contractionTime = 108;
			contractionNum = 10;
		} else if (mPlan.equals("J")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 13;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 13;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.15;
			contractionTime = 112;
			contractionNum = 10;
		} else if (mPlan.equals("K")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 9;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 9;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.2;
			contractionTime = 96;
			contractionNum = 10;
		} else if (mPlan.equals("L")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 10;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 10;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.2;
			contractionTime = 100;
			contractionNum = 10;
		} else if (mPlan.equals("M")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 11;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 11;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.2;
			contractionTime = 104;
			contractionNum = 10;
		} else if (mPlan.equals("N")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 12;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 12;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.2;
			contractionTime = 108;
			contractionNum = 10;
		} else if (mPlan.equals("O")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 13;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 13;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.2;
			contractionTime = 112;
			contractionNum = 10;
		} else if (mPlan.equals("P")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 9;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 9;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.25;
			contractionTime = 96;
			contractionNum = 10;
		} else if (mPlan.equals("Q")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 10;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 10;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.25;
			contractionTime = 100;
			contractionNum = 10;
		} else if (mPlan.equals("R")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 11;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 11;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.25;
			contractionTime = 104;
			contractionNum = 10;
		} else if (mPlan.equals("S")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 12;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 12;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.25;
			contractionTime = 108;
			contractionNum = 10;
		} else if (mPlan.equals("T")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 13;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 13;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.25;
			contractionTime = 112;
			contractionNum = 10;
		} else if (mPlan.equals("U")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 9;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 9;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.3;
			contractionTime = 96;
			contractionNum = 10;
		} else if (mPlan.equals("V")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 10;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 10;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.3;
			contractionTime = 100;
			contractionNum = 10;
		} else if (mPlan.equals("W")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 11;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 11;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.3;
			contractionTime = 104;
			contractionNum = 10;
		} else if (mPlan.equals("X")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 12;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 12;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.3;
			contractionTime = 108;
			contractionNum = 10;
		} else if (mPlan.equals("Y")) {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 13;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 13;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.3;
			contractionTime = 112;
			contractionNum = 10;
		} else {
			trainWaveTypeSet[0] = 8;
			trainWaveTypeSet[1] = 9;
			trainWaveTypeSet[2] = 8;
			trainWaveTypeSet[3] = 8;
			trainWaveTypeSet[4] = 6;
			trainWaveTypeSet[5] = 8;
			trainWaveTypeSet[6] = 8;
			trainWaveTypeSet[7] = 9;
			trainWaveTypeSet[8] = 6;
			trainWaveTypeSet[9] = 8;
			highTypeSet = (float) 1.1;
			contractionTime = 96;
			contractionNum = 10;
		}
//			System.out.println("mplan"+mplan);
//			System.out.println("Pipelength:"+Pipelength);
//			System.out.println("Pipenum:"+Pipenum);
	}


	/**
	 * 开启持续时间标记
	 *
	 * @param xVals
	 */
	private void openTimeCount(int xVals) {
		//timeADCflag为true时开启采集，为false关闭采集，即在休息期即使当前肌力达到要求也不会计算持续时间
		switch (waveType) {
			case 1:
				if (xVals == 110)
					timeADCflag = true;
				else if (xVals == 160)
					timeADCflag = false;
				break;
			case 2:
				if ((xVals == 20) || (xVals == 120) || (xVals == 220))
					timeADCflag = true;
				else if ((xVals == 80) || (xVals == 180) || (xVals == 280))
					timeADCflag = false;
				break;
			case 3:
				if ((xVals == 40) || (xVals == 200))
					timeADCflag = true;
				else if ((xVals == 120) || (xVals == 280))
					timeADCflag = false;
				break;
			case 4:
				if ((xVals == 20) || (xVals == 160))
					timeADCflag = true;
				else if ((xVals == 120) || (xVals == 260))
					timeADCflag = false;
				break;
			case 5:
				break;
			case 6:
				if ((xVals == 20) || (xVals == 80) || (xVals == 140) || (xVals == 200) || (xVals == 260))
					timeADCflag = true;
				else if ((xVals == 40) || (xVals == 100) || (xVals == 160) || (xVals == 220) || (xVals == 280))
					timeADCflag = false;
				break;
			case 7:
				if ((xVals == 20) || (xVals == 120) || (xVals == 220))
					timeADCflag = true;
				else if ((xVals == 50) || (xVals == 150) || (xVals == 250))
					timeADCflag = false;
				break;
			case 8:
				if ((xVals == 20) || (xVals == 120) || (xVals == 220))
					timeADCflag = true;
				else if ((xVals == 80) || (xVals == 180) || (xVals == 280))
					timeADCflag = false;
				break;
			case 9:
				if ((xVals == 40) || (xVals == 180))
					timeADCflag = true;
				else if ((xVals == 120) || (xVals == 260))
					timeADCflag = false;
				break;
			case 10:
				if ((xVals == 40) || (xVals == 170))
					timeADCflag = true;
				else if ((xVals == 130) || (xVals == 260))
					timeADCflag = false;
				break;
			case 11:
				if ((xVals == 30) || (xVals == 170))
					timeADCflag = true;
				else if ((xVals == 130) || (xVals == 270))
					timeADCflag = false;
				break;
			case 12:
				if ((xVals == 30) || (xVals == 160))
					timeADCflag = true;
				else if ((xVals == 140) || (xVals == 270))
					timeADCflag = false;
				break;
			case 13:
				if ((xVals == 20) || (xVals == 160))
					timeADCflag = true;
				else if ((xVals == 140) || (xVals == 280))
					timeADCflag = false;
				break;
			default:
				timeADCflag = false;
				break;
		}
	}


	/**
	 * 播放收缩、放松语音函数,在波形到来前1秒提示收缩,波形结束前一秒提示放松
	 *
	 * @param xvals
	 */
	private void playTrainSound(int xvals) {
		if (!enablePlaySound) { // 标记为false，直接退出
			return;
		}
		switch (waveType) {
			case 1:
				if (xvals == 90) {
					playSound(R.raw.shousuo);
				}
				if (xvals == 150) {
					playSound(R.raw.fangsong);
				}
				break;
			case 2:
				if ((xvals == 10) || (xvals == 110) || (xvals == 210)) {
					playSound(R.raw.shousuo);
				}
				if ((xvals == 60) || (xvals == 160) || (xvals == 260)) {
					playSound(R.raw.fangsong);
				}
				break;
			case 3:
				if ((xvals == 30) || (xvals == 190)) {
					playSound(R.raw.shousuo);
				}
				if ((xvals == 100) || (xvals == 260)) {
					playSound(R.raw.fangsong);
				}
				break;
			case 4:
				if ((xvals == 10) || (xvals == 150)) {
					playSound(R.raw.shousuo);
				}
				if ((xvals == 100) || (xvals == 240)) {
					playSound(R.raw.fangsong);
				}
				break;
			case 5:
				if ((xvals == 40) || (xvals == 180)) {
					playSound(R.raw.shousuo);
				}
				if ((xvals == 90) || (xvals == 230)) {
					playSound(R.raw.fangsong);
				}
				break;
			case 6:
				if ((xvals == 10) || (xvals == 70) || (xvals == 130) || (xvals == 190) || (xvals == 250)) {
					playSound(R.raw.shousuo);
				}
				if ((xvals == 30) || (xvals == 90) || (xvals == 150) || (xvals == 210) || (xvals == 270)) {
					playSound(R.raw.fangsong);
				}
				break;
			case 7:
				if ((xvals == 10) || (xvals == 110) || (xvals == 210)) {
					playSound(R.raw.shousuo);
				}
				if ((xvals == 40) || (xvals == 140) || (xvals == 240)) {
					playSound(R.raw.fangsong);
				}
				break;
			case 8:
				if ((xvals == 10) || (xvals == 110) || (xvals == 210)) {
					playSound(R.raw.shousuo);
				}
				if ((xvals == 60) || (xvals == 160) || (xvals == 260)) {
					playSound(R.raw.fangsong);
				}
				break;
			case 9:
				if ((xvals == 30) || (xvals == 170)) {
					playSound(R.raw.shousuo);
				}
				if ((xvals == 100) || (xvals == 240)) {
					playSound(R.raw.fangsong);
				}
				break;
			case 10:
				if ((xvals == 30) || (xvals == 160)) {
					playSound(R.raw.shousuo);
				}
				if ((xvals == 110) || (xvals == 240)) {
					playSound(R.raw.fangsong);
				}
				break;
			case 11:
				if ((xvals == 20) || (xvals == 160)) {
					playSound(R.raw.shousuo);
				}
				if ((xvals == 110) || (xvals == 250)) {
					playSound(R.raw.fangsong);
				}
				break;
			case 12:
				if ((xvals == 20) || (xvals == 150)) {
					playSound(R.raw.shousuo);
				}
				if ((xvals == 120) || (xvals == 250)) {
					playSound(R.raw.fangsong);
				}
				break;
			case 13:
				if ((xvals == 10) || (xvals == 150)) {
					playSound(R.raw.shousuo);
				}
				if ((xvals == 120) || (xvals == 260)) {
					playSound(R.raw.fangsong);
				}
				break;
			case 14:
				if ((xvals == 10) || (xvals == 110) || (xvals == 210)) {
					playSound(R.raw.shousuo);
				}
				if ((xvals == 60) || (xvals == 160) || (xvals == 260)) {
					playSound(R.raw.fangsong);
				}
				break;
			default:
				break;
		}
	}


	/**
	 * 肌力数值统计及调整肌力,对于每一帧波形最后1秒即10个压力值进行冒泡排序,然后取中值作为调整值
	 */
	private void updateAdjustPower() {

		float[] lastTenValues = new float[10];
		System.arraycopy(pressureDataSet, 290, lastTenValues, 0, 10);
		Arrays.sort(lastTenValues);
		adjustPower += lastTenValues[5];
	}


	/**
	 * 准备训练和测试
	 */
	private void prepareAction() {
		if (trainType == 1) {
			CommonToast.showShortToast("准备测试，倒数3秒钟");
			playSoundWithCompletionListener(R.raw.daoshu, mp -> {
				showStartToast(3000);
			});
		} else {
			CommonToast.showShortToast("训练开始，请按照训练波形进行训练，倒数3秒钟");
			playSoundWithCompletionListener(R.raw.begintrain, mp -> {
				showStartToast(3000);
			});
		}
	}

	private void showStartToast(int count) {
		new CountDownTimer(count, 1000) {

			public void onTick(long millisUntilFinished) {
				if (trainType == 1) {
					CommonToast.showShortToast(((millisUntilFinished + 1000) / 1000) + "秒后开始测试");
				} else {
					CommonToast.showShortToast(((millisUntilFinished + 1000) / 1000) + "秒后开始训练");
				}

			}

			public void onFinish() {
				xVals1.clear();
				yVals1.clear();
				isStartCountTimer = false;
				ApplicationUtils.mMainHandler.postDelayed(runnable, 100);
			}
		}.start();
	}

	// 开启定时器
	private void startCounterTimer() {
		mCountDownTimer = new CountDownTimer(remainTime * 1000, 1000) {
			public void onTick(long millisUntilFinished) {
				remainTime = (int) millisUntilFinished / 1000;
				txtRemainTimeValue.setText(StringUtils.formatTime2((int) (millisUntilFinished / 1000)));
				pbRecoverTrainTrainTime.setProgress((int) (trainTime * 60 - (millisUntilFinished / 1000)));

			}

			public void onFinish() {
				Ln.d("lihb pelvic 倒计时完成done");
			}
		};
		mCountDownTimer.start();
	}

	private Runnable runnable = new Runnable() {

		//波形显示线程
		@Override
		public void run() {
			ApplicationUtils.mMainHandler.postDelayed(this, 100);

			//存储压力值
			pressureDataSet[curXVals] = pressureValue;
			//如果压力值异常则处理
			if (pressureValue > 100)
				pressureValue = 0;
			//设置数据显示格式为0.0
			DecimalFormat decimalFormat = new DecimalFormat("0.0");
			//如果本次数据大于记录的最大肌力则更新最大肌力数值
			if ((pressureValue > maxPower) && (pressureValue > 0) && (pressureValue < 100)) {
				maxPower = pressureValue;
				if (trainType == 1)
					tvRecoverMaxpower.setText(decimalFormat.format(maxPower));
			}
			//播放收缩、放松语音
			playTrainSound(curXVals);
			//显示当前肌力
			if (trainType == 1) {
				if ((pressureValue <= 0) || (pressureValue > 500)) {
					tvRecoverNowpower.setText(decimalFormat.format(0.0));
				} else {
					tvRecoverNowpower.setText(decimalFormat.format(pressureValue));
				}
			}
//					allpowerdata[curXVals] = powerdata;
			//当模板波形输出为高是开放数据采集,即此时压力值高于模板波形幅度才算有效持续时间
			openTimeCount(curXVals);
			//设置数据并显示图表
			setData(curXVals, pressureValue, trainLevel);
			lineRecoverChart.animateX(0);
			//倒计时
			if (maxPowerFlag != 1 && !isStartCountTimer) {
				startCounterTimer();
				isStartCountTimer = true;
			}
			curXVals++;
			//当一个波形完成(30秒),即a计数到300
			if (curXVals >= 300) {
				curXVals = 0;
				//肌力基准值自适应算法
				updateAdjustPower();
				//若为肌力测试
				if (trainType == 1) {
					//如果为2时表示正在测试波形,倒计时才开始倒数
					if (maxPowerFlag == 2)
						timeCount++;
					//测试波形切换标记
					typeChoose = !typeChoose;
					//倒计时结束
					if (timeCount >= (trainTime * 2)) {
						timeCount = 0;
						//停止线程
						Ln.d("lihb pelvic 弄完了");
						ApplicationUtils.mMainHandler.removeCallbacks(runnable);
						playSound(R.raw.succee);
						// 保存报告
						muscleEstimate();

					} else {   //未计时结束,进行下一段波形
						xVals1.clear();
						yVals1.clear();
						yVals.clear();

						/**当本次最大肌力大于上一次的最大肌力,则要继续测试用户的最
						 * 大肌力,如果相同则表示用户已经达到最大肌力,其最大肌力无
						 * 法再提升
						 */
//							if(maxPower!=lastMaxPower)
						if (maxPowerCount != 0)
							maxPowerCount--;
						else {
							//成功采集最大肌力,设置标记,开始进入测试波形
							maxPowerFlag = 2;
							if (waveType == 7)
								CommonToast.showShortToast("成功采集最大肌力");
						}
						if (maxPowerFlag == 1) {
							waveType = 7;  //7为采集最大肌力波形
							//设置坐标轴最大值为最大肌力的1.2倍
							if (maxPower <= 10) {
								if (PCBVersion == 0)
									lineRecoverChart.getAxisLeft().setAxisMaxValue((float) 10.0);
								else
									lineRecoverChart.getAxisLeft().setAxisMaxValue((float) 20.0);
								setModelyVals(trainLevel, waveType);
							} else {
								lineRecoverChart.getAxisLeft().setAxisMaxValue((float) (maxPower * 1.2));
								setModelyValsType(waveType, levelYAxis_1, maxPower);
							}
						} else if (maxPowerFlag == 2) {
							if (testMuscleFlag == false) {
								waveType = 1;  //I类肌测试波形,5秒的持续时间
								testMuscleFlag = true;
								if (quickLevelFirstTime)
									quickLevelFirstTime = false;
								else {
									//存储每次的I类肌测试结果
//									quickData[quickCount] = quickLevel;
									MuscleForceData muscleForceData = actionDataList.get(quickCount);
									if (muscleForceData != null) {
										muscleForceData.cTwoMuscle = quickLevel;
									}
									Ln.d("lihb value:quickCount=%d, muscleForceData=%s", quickCount, muscleForceData);

									quickCount++;
									quickLevel = 0;
									tvRecoverFrequency.setText(String.valueOf(quickLevel));
								}
							} else {
								waveType = 6;  //II类肌测试波形,5次快速收放
								testMuscleFlag = false;
								//累计I累计的持续时间,然后取5次的平均值来评估肌力等级
								if (durationCount * 0.1 >= 5.0) {
									//若大于5秒则判断此次为5秒
									time_MuscleI += 5.0;
								} else {
									time_MuscleI += (float) Math.round(durationCount * 0.1);
								}
								MuscleForceData muscleForceData = actionDataList.get(slowCount);
								if (muscleForceData != null) {
									muscleForceData.cOneMuscle = (int) Math.round(durationCount * 0.1);
								}
								Ln.d("lihb value:slowCount=%d, durationCount=%d, muscleForceData=%s", slowCount, durationCount, muscleForceData);

								slowCount++;
							}
							//如果maxpower = 0则重新测试最大肌力，如果不等于0则把测试波形幅度设为60%，Y轴幅度设为120%
							if (maxPower != 0) {
								lineRecoverChart.getAxisLeft().setAxisMaxValue((float) (maxPower * 1.2));
								setModelyValsType(waveType, levelYAxis_1, (float) (maxPower * 0.6));
							} else {
								waveType = 7;    //重新采集最大肌力
								lineRecoverChart.getAxisLeft().setAxisMaxValue((float) 10.0);
								setModelyVals(trainLevel, waveType);
								maxPowerFlag = 1;
							}
						} else {
						}
						//复位持续时间
						durationCount = 0;
						tvRecoverDuration.setText(decimalFormat.format(durationCount * 0.1));
						System.out.println("value:" + waveType);
					}

				} else    //训练
				{
					timeCount++;
					if (timeCount >= (trainTime * 2)) {
						timeCount = 0;
						//停止线程
						ApplicationUtils.mMainHandler.removeCallbacks(runnable);
						//显示训练结束消息框
						CommonToast.showShortToast("训练结束");
						playSound(R.raw.succee);
						saveTrainData();
					} else {
						xVals1.clear();
						yVals1.clear();
						yVals.clear();
						trainWaveTypeCount++;
						if (trainWaveTypeCount > 9) {
							trainWaveTypeCount = 0;
						}
						waveType = trainWaveTypeSet[trainWaveTypeCount];
						if ((trainWaveTypeCount == 2) || (trainWaveTypeCount == 5)) {
							lineRecoverChart.getAxisLeft().setAxisMaxValue((float) (maxPower * 1.2 * highTypeSet));
							setModelyValsType(waveType, levelYAxis_1, (float) (maxPower * powerPara * highTypeSet));
						} else {
							lineRecoverChart.getAxisLeft().setAxisMaxValue((float) (maxPower * 1.2));
							setModelyValsType(waveType, levelYAxis_1, (float) (maxPower * powerPara));
						}
						//复位持续时间
					}
				}
			}
		}

	};

	/**
	 * 显示查看报告弹窗
	 */
	private void showReportDialog() {
		CommonDialog.createDialog(this)
				.setTitleText(getString(R.string.title_tips))
				.setText("评估完成啦！！")
				.setIconVisible(CommonDialog.Visible.Gone)
				.setLeftButtonText("重新测试")
				.setLeftButtonAction(v -> {
					reTest();
				})
				.setRightButtonText("查看报告")
				.setRightButtonAction(v -> {
					if (saveTrainRecord != null) {
						PelvicExamineReportActivity.navigate(PelvicTrainingActivity.this, GsonHelper.objectToJson(saveTrainRecord));
					} else {
						CommonToast.showShortToast("上传数据失败，请稍后重试");
					}

				})
				.setCloseOnTouchOutside(true)
				.setCancelable(true)
				.show();
	}

	/**
	 * 重新测试
	 */
	private void reTest() {
		quickLevel = 0;
		quickLevelFirstTime = true;
		slowCount = 0;
		quickCount = 0;
		slowLevel = 0;
		trainScore = 0;
		testMuscleFlag = false;

		waveType = 1;
		typeChoose = false;
		maxPower = 0;
		time_MuscleI = 0;

		maxPowerFlag = 1;
		timeADCflag = false;
		pressureValue = 0f;
		trainTime = DEFAULT_EXAMINE_TIME;    //默认测试5分钟
		trainLevel = 6;   //默认测试强度为6级,即最大肌力默认10kgf

		curXVals = 0;
		xVals1.clear();
		yVals1.clear();
		yVals.clear();
		DecimalFormat decimalFormat = new DecimalFormat("0.0");
		tvRecoverDuration.setText(decimalFormat.format(durationCount * 0.1));
		initChart(trainLevel);
		Ln.d("lihb pelvic, reTest setData");
		setData(0, 0, trainLevel);
		lineRecoverChart.animateX(0);

		// 倒计时控件
		isStartCountTimer = false;
		remainTime = trainTime * 60;
		txtRemainTimeValue.setText(StringUtils.formatTime2(remainTime));
		pbRecoverTrainTrainTime.setProgress(0);

		ApplicationUtils.mMainHandler.removeCallbacks(runnable);


		CommonToast.showShortToast("准备测试，倒数5秒钟");
		if (enablePlaySound) {
			playSoundWithCompletionListener(R.raw.starttest, mp -> {
				showStartToast(5000);
			});
		}
	}

	// region 音频播放暂停

	// 播放音频
	private void playSound(@RawRes int resId) {
		try {
			releaseSound(); // 先停止播放
			mediaPlayer = MediaPlayer.create(this, resId);
			mediaPlayer.start();
		} catch (Exception e) {
			Ln.e(e);
		}
	}

	private void playSoundWithCompletionListener(@RawRes int resId, MediaPlayer.OnCompletionListener completionListener) {
		try {
			releaseSound(); // 先停止播放
			mediaPlayer = MediaPlayer.create(this, resId);
			mediaPlayer.setOnCompletionListener(completionListener);
			mediaPlayer.start();
		} catch (Exception e) {
			Ln.e(e);
		}
	}

	// 停止播放
	private void releaseSound() {
		if (mediaPlayer != null) {
			mediaPlayer.stop();
			mediaPlayer.release();
			mediaPlayer = null;
		}
	}
	// endregion 音频播放暂停


	// 肌肉等级评估
	private void muscleEstimate() {
		if (maxPowerFlag == 2) {
			//把第五次的测量值存入数组
//			quickData[4] = quickLevel;
			MuscleForceData data = actionDataList.get(4);
			if (data != null) {
				data.cTwoMuscle = quickLevel;
			}

			for (int i = 0; i < 4; i++) {
				quickLevel += actionDataList.get(i).cTwoMuscle;
			}

			quickLevel /= 5;   //总次数除以5之后获得平均等级


			/**  I类肌等级判断：
			 持续时间小于2秒为1级
			 持续时间小于3秒为2级
			 持续时间小于4秒为3级
			 持续时间小于5秒为4级
			 持续时间大于等于5秒为5级
			 */
			time_MuscleI /= 5;

			if (time_MuscleI >= 0 && time_MuscleI < 1) {
				slowLevel = 0;
			} else if (time_MuscleI < 2) {
				slowLevel = 1;
			} else if (time_MuscleI < 3) {
				slowLevel = 3;
			} else if (time_MuscleI < 4) {
				slowLevel = 4;
			} else if (time_MuscleI < 5) {
				slowLevel = 5;
			} else {
				slowLevel = 1;
			}

			//根据I类肌和II类肌的等级判断训练方案
			trainPlan = trainPlans[quickLevel][slowLevel];
			//存储数据
			saveExamineData();

		} else {
			trainScore = trainScore / (trainTime * 2);
		}
	}

	/**
	 * 发送协议保存评估数据
	 */
	private void saveExamineData() {
		long uid = BabyVoiceApp.mUserInfo.id;
		showProgressDialog("保存数据中...", false, null);
		ServiceGenerator.createService(ApiManager.class)
				.savePelvicExamineData(uid, slowLevel, quickLevel, maxPower, GsonHelper.objectToJson(actionDataList))
				.doOnTerminate(() -> dismissProgressDialog())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(httpResponseData -> {
					if (ResponseCode.RESPONSE_OK == httpResponseData.code) {
						saveTrainRecord = httpResponseData.data;
						Ln.d("lihb savePelvicExamineData, data = %s", saveTrainRecord.toString());
						showReportDialog();
					} else {
						CommonToast.showShortToast(httpResponseData.msg);
					}
				}, throwable -> Ln.d("lihb throwable = %s", throwable.toString()));
	}

	/**
	 * 发送协议保存测试数据
	 */
	private void saveTrainData() {
		long uid = BabyVoiceApp.mUserInfo.id;
		ServiceGenerator.createService(ApiManager.class)
				.savePelvicTrainData(uid, trainTime, trainLevel, trainScore, trainTime, 2)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(httpResponse -> {
					if (httpResponse.code == ResponseCode.RESPONSE_OK) {
						Ln.d("lihb saveTrainData success.");
					} else {
						CommonToast.showShortToast(httpResponse.msg);
					}
				}, throwable -> Ln.d("lihb throwable = %s", throwable.toString()));

	}


	// region EventBus事件

	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onLSDeviceComm(EventLSDeviceConnection event) {
		switch (event.type) {
			case EventLSDeviceConnection.LS_DEVICE_SCAN_TIMEOUT:
				Log.i(DEV_TAG, "请检查附近是否有训练仪");
			case EventLSDeviceConnection.LS_DEVICE_DISCONNECTED: {
				Log.i(DEV_TAG, "训练仪已断开");

				ApplicationUtils.mMainHandler.removeCallbacks(runnable);

				if (mCountDownTimer != null) {
					mCountDownTimer.cancel();
					mCountDownTimer = null;
				}
				dismissProgressDialog();
				CommonDialog.createDialog(this)
						.setTitleText(getString(R.string.title_tips))
						.setText(getResources().getString(R.string.txt_ble_disconnect))
						.setIconVisible(CommonDialog.Visible.Gone)
						.setLeftButtonText(getString(R.string.btn_txt_cancel))
						.setLeftButtonAction(v -> {
							finish();
						})
						.setRightButtonText(getString(R.string.btn_txt_reconnect))
						.setRightButtonAction(v -> {
							if (!PermissionCheckUtil.checkHasPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
								PermissionCheckUtil.requestPermission(this, new String[]{
										Manifest.permission.ACCESS_FINE_LOCATION,
								});
								return;
							}
							iTingBabyBleDeviceManager.getInstance().searchLSDeviceForConnect();
						})
						.setCloseOnTouchOutside(true)
						.setCancelable(true)
						.show();
			}
			break;

			case EventLSDeviceConnection.LS_DEVICE_CONNECTED:
				Log.i(DEV_TAG, "训练仪连接成功");
				dismissProgressDialog();
				CommonToast.showShortToast("连接成功");
				beginAction();

				// 上报设备
				reportUserDevice(BabyVoiceApp.mUserInfo.id, DeviceType.DEVICE_TYPE_KEGEL, event.devMac);
				break;

			case EventLSDeviceConnection.LS_DEVICE_CONNECTING:
				Log.i(DEV_TAG, "正在搜索并连接训练仪");
				showProgressDialog(getString(R.string.txt_ble_connecting), true, () -> {
					iTingBabyBleDeviceManager.getInstance().cancelLSDeviceConnect();
				});
				break;
		}
	}

	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onLSDeviceData(EventLSDeviceData event) {
		switch (event.type) {
			case EventLSDeviceData.LS_DEVICE_MAC:
				Log.i(DEV_TAG, "训练仪MAC " + event.devMac);
				break;
			case EventLSDeviceData.LS_DEVICE_BATTERY_PERCENTAGE:
				Log.i(DEV_TAG, "训练仪电池电量百分比 " + event.devBattery);
				break;
			case EventLSDeviceData.LS_DEVICE_RSSI:
				Log.i(DEV_TAG, "训练仪RSSI " + event.devRSSI);
				break;
			case EventLSDeviceData.LS_DEVICE_PRESSURE:
				Log.i(DEV_TAG, "训练仪压力值 " + event.devPressure);
				pressureValue = (float) (event.devPressure - adjustPower);
				break;
		}
	}

	// endregion

	public void reportUserDevice(long uid, int deviceType, String deviceMac) {
		RequestBody reqUid = RequestBody.create(MediaType.parse("multipart/form-data"), Long.toString(uid));
		RequestBody reqDeviceType = RequestBody.create(MediaType.parse("multipart/form-data"), Integer.toString(deviceType));
		RequestBody reqDeviceMac = RequestBody.create(MediaType.parse("multipart/form-data"), deviceMac);

		ServiceGenerator.createService(ApiManager.class)
				.reportUserDevice(reqUid, reqDeviceType, reqDeviceMac)
				.observeOn(AndroidSchedulers.mainThread())
				.doOnTerminate(() -> {
				})
				.subscribeOn(Schedulers.io())
				.subscribe(httpResponse -> {
					Ln.i("lihb", httpResponse.toString());
					if (httpResponse.code == ResponseCode.RESPONSE_OK) {
						// 成功
						Ln.d("上报设备成功");
					} else {
						CommonToast.showShortToast(httpResponse.msg);
					}
				}, throwable -> Ln.e(throwable.toString()));
	}

}
