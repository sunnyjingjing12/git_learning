package com.itingbaby.app.command;

/**
 * Android系统事件基类
 * <p>
 * Created by caijw on 2015/9/21.
 */
public abstract class BaseAndroidCommand {
}
