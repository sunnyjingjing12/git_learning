package com.itingbaby.app.command;

/**
 * Created by huqiuyun on 16/3/9.
 */
public class DismissCommand extends BaseAndroidCommand {
    public DismissCommand() {
    }
}
