package com.itingbaby.app.command;

/**
 * Home按下事件
 * <p>
 * Created by caijw on 2015/9/21.
 */
public class HomeKeyPressedCommand extends BaseAndroidCommand {
    public HomeKeyPressedCommand() {
    }
}
