package com.itingbaby.app.components;

import com.itingbaby.app.model.MusicGroup;
import com.itingbaby.baselib.commonutils.lifecycle.ILifecycleListener;
import com.trello.rxlifecycle2.android.FragmentEvent;

import java.util.List;

/**
 * Created by lihb on 2019/6/10.
 */

public interface IHomeMusicComponent {

	interface IView extends ILifecycleListener<FragmentEvent> {

		void handleFailed();

		void handleEmpty();

		void updateMusicGroupList(List<MusicGroup> list);

		void showToast(String msg);

		void handleMusicSize(int size);

	}

	interface IPresenter {

		/**
		 * 获取音乐组列表数据
		 */
		void getMusicGroupData();

		/**
		 * 获取音乐条目数据
		 */
		void getMusicClauseData(int cid, int page, int rows);


		void getUserAudioRecordData(long recordType, int page, int rows);

	}
}
