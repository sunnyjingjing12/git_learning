package com.itingbaby.app.components;

import com.itingbaby.app.model.HomeDataListCard;
import com.itingbaby.baselib.commonutils.lifecycle.ILifecycleListener;
import com.trello.rxlifecycle2.android.FragmentEvent;

import java.util.List;

public interface IHomeTbaiComponent {

	interface IView extends ILifecycleListener<FragmentEvent> {

		void stopRefresh();

		void handleFailed();

		void handleEmpty();

		void updateDataList(List<HomeDataListCard> dataList);

		void showToast(String msg);

	}

	interface IPresenter {

		/**
		 * 获取首页卡片数据
		 *
		 * @return
		 */
		void getHomeDataListCard(long uid);

	}
}
