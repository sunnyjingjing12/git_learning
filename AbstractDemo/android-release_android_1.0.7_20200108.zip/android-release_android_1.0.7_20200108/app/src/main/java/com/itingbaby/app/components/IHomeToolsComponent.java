package com.itingbaby.app.components;


import com.itingbaby.app.model.ToolInfo;
import com.itingbaby.baselib.commonutils.lifecycle.ILifecycleListener;
import com.trello.rxlifecycle2.android.FragmentEvent;

import java.util.List;


/**
 * Created by lihb on 2019/10/17.
 */

public interface IHomeToolsComponent {

	interface IView extends ILifecycleListener<FragmentEvent> {

		void handleFailed();

		void handleEmpty();

		void updateDataList(List<ToolInfo> dataList);

		void showToast(String msg);

	}

	interface IPresenter {

		/**
		 * 获取工具集合数据
		 *
		 * @return
		 */
		void getToolListData(long uid);

	}
}
