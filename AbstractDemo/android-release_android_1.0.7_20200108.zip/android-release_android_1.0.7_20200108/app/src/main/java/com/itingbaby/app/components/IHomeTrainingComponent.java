package com.itingbaby.app.components;


import com.itingbaby.app.model.User;

import java.util.List;


/**
 * Created by lihb on 2019/6/7.
 */

public interface IHomeTrainingComponent {

	interface IView<T> {

		void stopRefresh();

		void stopLoadMore();

		void handleFailed();

		void handleEmpty();

		void setIsLastPage(boolean isLastPage);

		void updateDataList(List<T> dataList);

		void addMoreDataList(List<T> dataList);

		void showToast(String msg);

		void updateProfileSuccess(User userInfo);

	}

	interface IPresenter {

		/**
		 * 获取盆底评估数据
		 *
		 * @return
		 */
		void getPelvicExamineData(int page, int pageSize);

		/**
		 * 更新個人資料信息
		 */
		void updateProfile(User userInfo);

	}
}
