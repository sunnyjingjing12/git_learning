package com.itingbaby.app.components;


import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.baselib.commonutils.lifecycle.ILifecycleListener;
import com.trello.rxlifecycle2.android.FragmentEvent;

import java.util.List;


/**
 * Created by lihb on 2019/6/7.
 */

public interface IHomeVoiceComponent {

    interface IView extends ILifecycleListener<FragmentEvent> {

        void stopRefresh();

        void stopLoadMore();

        void handleFailed();

        void handleEmpty();

        void setIsLastPage(boolean isLastPage);

		void updateDataList(List list);

		void addMoreDataList(List list);

        void showToast(String msg);

    }

    interface IPresenter {

        /**
         * 从数据库中获取音频数据
         *
         * @return
         */
		void getVoiceData(int voiceType, int refreshType, int offset, int limit);


        /**
         * 从数据库中删除音频数据
         * @param audioRecordModel
         */
        void delVoiceData(AudioRecordModel audioRecordModel);

    }
}
