package com.itingbaby.app.components;

import java.util.List;

public interface IMusicListComponent {

	interface IView {

		void stopRefresh();

		void stopLoadMore();

		void handleFailed();

		void handleEmpty();

		void setIsLastPage(boolean isLastPage);

		void updateDataList(List dataList);

		void addMoreDataList(List dataList);

		void showToast(String msg);

	}

	interface IPresenter {

		/**
		 * 从数据库中获取音频数据
		 *
		 * @return
		 */
		void getVoiceData(int voiceType, int refreshType, int offset, int limit);

		/**
		 * 根据用户ID获取用户上传录音文件数据
		 */
		void getUserAudioRecordData(long recordType, int page, int rows);

		/**
		 * 根据音乐类别ID获取音频文件数据
		 */
		void getMusicClauseListData(int cid, int page, int rows);

	}
}
