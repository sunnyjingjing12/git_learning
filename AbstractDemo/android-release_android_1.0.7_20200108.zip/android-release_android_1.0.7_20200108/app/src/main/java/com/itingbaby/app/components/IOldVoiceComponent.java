package com.itingbaby.app.components;


import com.itingbaby.app.model.AudioRecordModel;

import java.util.List;

/**
 * Created by lihb on 2019/10/17.
 */

public interface IOldVoiceComponent {

	interface IView {

		void handleFailed();

		void handleData(List<AudioRecordModel> modelList);

		void showToast(String msg);

		void processResult(boolean flag);

	}

	interface IPresenter {
		/**
		 * 从数据库中获取音频数据数量
		 *
		 * @return
		 */
		void getVoiceDataSize();

		/**
		 * 批量更新所以音频文件的uid为新的uid
		 *
		 * @return
		 */
		void updateAllVoiceData(List<AudioRecordModel> delDataList, List<AudioRecordModel> updateList);

	}
}
