package com.itingbaby.app.components;

import com.itingbaby.app.model.pregnancycheck.PregnancyCheckModel;

import java.util.List;

public interface IPregnancyCheckComponent {

	interface IView {

		void handleFailed();

		void handleEmpty();

		void updateDataList(List<PregnancyCheckModel> dataList);

		void showToast(String msg);

	}

	interface IPresenter {

		/**
		 * 从数据库中获取产检数据
		 *
		 * @return
		 */
		void getAllPregnancyCheckData();


		/**
		 * 更新产检数据
		 *
		 * @param model
		 */
		void updatePregnancyCheck(PregnancyCheckModel model);

	}
}
