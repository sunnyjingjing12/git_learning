package com.itingbaby.app.components;

import com.itingbaby.app.model.User;

public interface IProfileSettingComponent {

	interface IView {
		void updateAvatarSuccess(String substring);

		void updateProfileSuccess(User userInfo);

		void handleFailed();

		void showToast(String msg);

	}

	interface IPresenter {

		/**
		 * 更新头像
		 *
		 * @return
		 */
		void uploadAvatarToServer(String filePath);

		/**
		 * 更新個人資料信息
		 */
		void updateProfile(User userInfo);

	}
}
