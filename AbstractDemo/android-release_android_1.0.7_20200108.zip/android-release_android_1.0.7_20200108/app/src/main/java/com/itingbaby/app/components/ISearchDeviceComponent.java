package com.itingbaby.app.components;

import com.itingbaby.app.model.HistoryBleDeviceModel;
import com.itingbaby.dev.iTingBabyBleDevice;

import java.util.List;

public interface ISearchDeviceComponent {

	interface IView {

		void handleFailed();

		void handleEmpty();

		void updateDataList(List<HistoryBleDeviceModel> dataList, List<iTingBabyBleDevice> bleDevices);

		void showToast(String msg);

	}

	interface IPresenter {

		/**
		 * 获取蓝牙设备
		 *
		 * @return
		 */
		void getBleDeviceData();

	}
}
