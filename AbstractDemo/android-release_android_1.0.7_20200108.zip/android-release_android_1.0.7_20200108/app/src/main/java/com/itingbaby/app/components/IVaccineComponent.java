package com.itingbaby.app.components;

import com.itingbaby.app.model.Vaccine;

import java.util.List;

public interface IVaccineComponent {

	interface IView {

		void handleFailed();

		void handleEmpty();

		void updateDataList(List<Vaccine> dataList);

		void showToast(String msg);

	}

	interface IPresenter {

		/**
		 * 从数据库中获取疫苗数据
		 *
		 * @return
		 */
		void getAllVaccineData();


		/**
		 * 更新疫苗数据
		 *
		 * @param vaccine
		 */
		void updateVaccine(Vaccine vaccine);

	}
}
