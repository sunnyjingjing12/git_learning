package com.itingbaby.app.components;

import android.content.Context;

import com.github.hiteshsondhi88.libffmpeg.ExecuteBinaryResponseHandler;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;

public interface IVoiceMixComponent {

	interface IView {

		void showToast(String msg);

		void showErrorMsg(String msg);

		void permissionGrantSuccess();

	}

	interface IPresenter {

		void init(Context context);

		void loadFFMpegBinary();

		void execFFmpegMixVoice(final String[] command, ExecuteBinaryResponseHandler handler);

		void saveDataToDB(String newFileName);

		void deleteRecordFile(String filePath);

		void checkPermission(BaseFragmentActivity activity);
	}
}
