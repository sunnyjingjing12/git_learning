package com.itingbaby.app.components;

import com.itingbaby.app.model.MusicCategory;

import java.util.List;

public interface IVoicePlayListComponent {

	interface IView {

		void handleFailed();

		void handleEmpty();

		void updateDataList(List dataList);

		void showToast(String msg);

	}

	interface IPresenter {

		/**
		 * 获取音频数据
		 *
		 * @return
		 * @param category
		 */
		void getVoiceData(MusicCategory category, int voiceType);

	}
}
