package com.itingbaby.app.components;


import com.itingbaby.app.model.WaitTodoGoods;
import com.itingbaby.baselib.commonutils.lifecycle.ILifecycleListener;
import com.trello.rxlifecycle2.android.FragmentEvent;

import java.util.List;


/**
 * Created by lihb on 2019/10/17.
 */

public interface IWaitPregnancyComponent {

	interface IView extends ILifecycleListener<FragmentEvent> {

		void handleFailed();

		void handleEmpty();

		void updateDataList(List<WaitTodoGoods> dataList);

		void showToast(String msg);

	}

	interface IPresenter {

		/**
		 * 获取所有待产物品
		 *
		 * @return
		 */
		void getAllTodoGoods(long uid, int goodsType);

		void updateTodoGoods(long uid, WaitTodoGoods goods);

	}
}
