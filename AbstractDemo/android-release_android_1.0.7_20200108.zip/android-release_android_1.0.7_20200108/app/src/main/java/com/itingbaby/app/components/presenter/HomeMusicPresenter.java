package com.itingbaby.app.components.presenter;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.components.IHomeMusicComponent;
import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.app.model.MusicClause;
import com.itingbaby.app.model.MusicGroup;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;

import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;


public class HomeMusicPresenter implements IHomeMusicComponent.IPresenter {

	private IHomeMusicComponent.IView mView;

	public HomeMusicPresenter(IHomeMusicComponent.IView view) {
		this.mView = view;
	}


	@Override
	public void getMusicGroupData() {
		ServiceGenerator.createService(ApiManager.class)
				.getMusicGroup()
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(httpResponse -> {
					if (ResponseCode.RESPONSE_OK == httpResponse.code) {
						List<MusicGroup> list = httpResponse.data;
						if (ListUtils.isEmpty(list)) {
							mView.handleEmpty();
							return;
						}
						mView.updateMusicGroupList(list);
					} else {
						mView.showToast(httpResponse.msg);
					}
				}, throwable -> {
					Ln.e(throwable.getMessage());
					mView.handleFailed();
				});
	}


	@Override
	public void getMusicClauseData(int cid, int page, int rows) {
		ServiceGenerator.createService(ApiManager.class)
				.getMusicClause(cid, page, rows)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(httpPageResponse -> {
					if (ResponseCode.RESPONSE_OK == httpPageResponse.code) {
						List<MusicClause> dataList = httpPageResponse.data;
						Ln.d("lihb getMusicClauseData page = %d, size = %d", page, dataList.size());
						mView.handleMusicSize(dataList.size());
					} else {
						mView.showToast(httpPageResponse.msg);
					}
				}, throwable -> {
					Ln.d("lihb throwable = %s", throwable.toString());
					mView.handleFailed();
				});

	}

	/**
	 * 根据用户ID获取用户上传录音文件数据
	 */
	public void getUserAudioRecordData(long recordType, int page, int rows) {
		long uid = BabyVoiceApp.mUserInfo.id;
		ServiceGenerator.createService(ApiManager.class)
				.getUserRecords(uid, recordType, page, rows)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(httpPageResponse -> {
					Ln.d("lihb getUserAudioRecordListData subscribe");
					if (ResponseCode.RESPONSE_OK == httpPageResponse.code) {
						List<AudioRecordModel> dataList = httpPageResponse.data;
						Ln.d("lihb getMusicClauseListData page = %d, size = %d", page, dataList.size());
						mView.handleMusicSize(dataList.size());
					} else {
						Ln.e(httpPageResponse.msg);
					}
				}, throwable -> {
					Ln.d("lihb throwable = %s", throwable.toString());
					mView.handleFailed();
				});
	}
}
