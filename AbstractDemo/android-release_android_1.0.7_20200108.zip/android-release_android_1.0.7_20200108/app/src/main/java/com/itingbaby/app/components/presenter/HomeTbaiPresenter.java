package com.itingbaby.app.components.presenter;

import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.components.IHomeTbaiComponent;
import com.itingbaby.app.model.HomeDataListCard;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;

import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class HomeTbaiPresenter implements IHomeTbaiComponent.IPresenter {

	private IHomeTbaiComponent.IView mView;

	public HomeTbaiPresenter(IHomeTbaiComponent.IView view) {
		mView = view;
	}

	private boolean isPreRequestFinish = true;

	@Override
	public void getHomeDataListCard(long uid) {
		if (isPreRequestFinish) {
			isPreRequestFinish = false;
			ServiceGenerator.createService(ApiManager.class)
					.getHomeDataListCards(uid)
					.observeOn(AndroidSchedulers.mainThread())
					.subscribeOn(Schedulers.io())
					.doOnTerminate(() -> {
						Ln.d("lihb getHomeDataListCard doOnTerminate");
						mView.stopRefresh();
						isPreRequestFinish = true;
					})
					.subscribe(httpResponse -> {
						if (ResponseCode.RESPONSE_OK == httpResponse.code) {
							List<HomeDataListCard> list = httpResponse.data;
							if (ListUtils.isEmpty(list)) {
								mView.handleEmpty();
								return;
							}
							mView.updateDataList(list);
						} else {
							mView.showToast(httpResponse.msg);
						}
					}, throwable -> mView.handleFailed());
		}
	}
}
