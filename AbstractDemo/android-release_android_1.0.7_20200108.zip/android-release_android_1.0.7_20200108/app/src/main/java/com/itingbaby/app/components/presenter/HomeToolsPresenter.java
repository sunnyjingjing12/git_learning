package com.itingbaby.app.components.presenter;

import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.components.IHomeToolsComponent;
import com.itingbaby.app.model.ToolInfo;
import com.itingbaby.baselib.commonutils.ListUtils;

import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class HomeToolsPresenter implements IHomeToolsComponent.IPresenter {

	private IHomeToolsComponent.IView mView;

	public HomeToolsPresenter(IHomeToolsComponent.IView view) {
		mView = view;
	}

	@Override
	public void getToolListData(long uid) {
		ServiceGenerator.createService(ApiManager.class)
				.getToolList(uid)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(httpResponse -> {
					if (httpResponse.code == ResponseCode.RESPONSE_OK) {
						List<ToolInfo> dataList = httpResponse.data;
						if (ListUtils.isEmpty(dataList)) {
							mView.handleEmpty();
							return;
						}
						mView.updateDataList(dataList);
					} else {
						mView.showToast(httpResponse.msg);
					}
				}, throwable -> mView.handleFailed());
	}
}
