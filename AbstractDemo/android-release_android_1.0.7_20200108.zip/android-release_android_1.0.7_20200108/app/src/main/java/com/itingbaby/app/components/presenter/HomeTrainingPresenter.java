package com.itingbaby.app.components.presenter;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.components.IHomeTrainingComponent;
import com.itingbaby.app.model.User;
import com.itingbaby.app.model.httpmodel.HttpPageResponse;
import com.itingbaby.app.model.pelvictrain.PelvicTrainRecord;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;

import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;


public class HomeTrainingPresenter implements IHomeTrainingComponent.IPresenter {

	private IHomeTrainingComponent.IView mView;

	public HomeTrainingPresenter(IHomeTrainingComponent.IView view) {
		this.mView = view;
	}

	@Override
	public void getPelvicExamineData(int requestPage, int pageSize) {
		long uid = BabyVoiceApp.mUserInfo.id;
		ServiceGenerator.createService(ApiManager.class)
				.getPelvicExamineData(uid, requestPage, pageSize)
				.observeOn(AndroidSchedulers.mainThread())
				.doOnTerminate(new Action() {
					@Override
					public void run() {
						Ln.d("lihb getPelvicExamineData doOnTerminate");
						if (requestPage == 1) {
							mView.stopRefresh();
						} else {
							mView.stopLoadMore();
						}
					}
				})
				.subscribeOn(Schedulers.io())
				.subscribe(new Consumer<HttpPageResponse>() {
					@Override
					public void accept(HttpPageResponse httpPageResponse) {
						if (ResponseCode.RESPONSE_OK == httpPageResponse.code) {
							List<PelvicTrainRecord> recordList = (List<PelvicTrainRecord>) httpPageResponse.data;
							mView.setIsLastPage(httpPageResponse.returnpage == httpPageResponse.pages);

							if (ListUtils.isEmpty(recordList) && requestPage == 1) {
								mView.handleEmpty();
								return;
							}
							if (requestPage == 1) {
								mView.updateDataList(recordList);
							} else {
								mView.addMoreDataList(recordList);
							}
						} else {
							mView.showToast(httpPageResponse.msg);
						}
					}
				}, new Consumer<Throwable>() {
					@Override
					public void accept(Throwable throwable) {
						Ln.d("lihb throwable = %s", throwable.toString());
						mView.handleFailed();
					}
				});

	}

	@Override
	public void updateProfile(User user) {
		ServiceGenerator.createService(ApiManager.class)
				.updateUserInfo(user)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(httpResponse -> {
					Ln.i("lihb", httpResponse.toString());
					if (httpResponse.code == ResponseCode.RESPONSE_OK) {
						// 成功
						mView.updateProfileSuccess(httpResponse.data);
					} else {
						mView.showToast(httpResponse.msg);
					}
				}, throwable -> {
					Ln.i(throwable.getMessage());
					CommonToast.showShortToast("修改失败");
				});
	}
}
