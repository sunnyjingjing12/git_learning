package com.itingbaby.app.components.presenter;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.components.IHomeVoiceComponent;
import com.itingbaby.app.fragment.HomeVoiceFragment;
import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.app.model.AudioRecordModelDao;
import com.itingbaby.app.model.AudioType;
import com.itingbaby.app.model.DaoSession;
import com.itingbaby.baselib.commonutils.ApplicationContext;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;

import org.greenrobot.greendao.query.Query;
import org.greenrobot.greendao.query.QueryBuilder;

import java.util.List;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class HomeVoicePresenter implements IHomeVoiceComponent.IPresenter {

	private IHomeVoiceComponent.IView mView;

	public HomeVoicePresenter(IHomeVoiceComponent.IView view) {
		mView = view;
	}

	@Override
	public void getVoiceData(int voiceType, int refreshType, int offset, final int limit) {
		Observable observable = Observable.create((emitter) -> {
			Long uid = BabyVoiceApp.mUserInfo.id;
			DaoSession daoSession = BabyVoiceApp.getInstance().getDaoSession();
			AudioRecordModelDao audioRecordModelDao = daoSession.getAudioRecordModelDao();

			QueryBuilder qb = audioRecordModelDao.queryBuilder();
			if (voiceType == HomeVoiceFragment.VOICE_TYPE_MIXED) {
				qb.where(AudioRecordModelDao.Properties.Uid.eq(uid),
						AudioRecordModelDao.Properties.Type.eq(AudioType.AUDIO_TYPE_MIXED));
			} else {
				qb.where(AudioRecordModelDao.Properties.Uid.eq(uid),
						qb.or(AudioRecordModelDao.Properties.Type.eq(AudioType.AUDIO_TYPE_BABY),
								AudioRecordModelDao.Properties.Type.eq(AudioType.AUDIO_TYPE_MOM),
								AudioRecordModelDao.Properties.Type.eq(AudioType.AUDIO_TYPE_LUNG)));

			}
			qb.orderDesc(AudioRecordModelDao.Properties.Timestamp)
					.limit(limit)
					.offset(offset);
			Query<AudioRecordModel> dataSet = qb.build();
			emitter.onNext(dataSet.list());
			emitter.onComplete();
		});
		observable.observeOn(AndroidSchedulers.mainThread())
				.doOnTerminate(() -> {
					Ln.d("lihb getVoiceData doOnTerminate");
					if (refreshType == ServiceGenerator.TYPE_FRESH) {
						mView.stopRefresh();
					} else {
						mView.stopLoadMore();
					}
				})
				.subscribeOn(Schedulers.io())
				.subscribe((o) -> {
					List<AudioRecordModel> dataList = (List<AudioRecordModel>) o;
					mView.setIsLastPage(dataList.size() < limit);

					if (ListUtils.isEmpty(dataList) && refreshType == ServiceGenerator.TYPE_FRESH) {
						mView.handleEmpty();
						return;
					}
					if (refreshType == ServiceGenerator.TYPE_FRESH) {
						mView.updateDataList(dataList);
					} else {
						mView.addMoreDataList(dataList);
					}
				}, throwable -> mView.handleFailed());

	}


	@Override
	public void delVoiceData(AudioRecordModel audioRecordModel) {
		if (audioRecordModel == null) {
			return;
		}
		Observable observable = Observable.create((emitter) -> {
			DaoSession daoSession = BabyVoiceApp.getInstance().getDaoSession();
			AudioRecordModelDao audioRecordModelDao = daoSession.getAudioRecordModelDao();
			audioRecordModelDao.delete(audioRecordModel);
			emitter.onNext(true);
			emitter.onComplete();
		});
		observable.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe((o) -> {
					boolean isSucceed = (Boolean) o;
					if (isSucceed) {
						mView.showToast(ApplicationContext.getContext().getString(R.string.del_succeed_tips));
					} else {
						mView.showToast(ApplicationContext.getContext().getString(R.string.del_failed_tips));
					}
				}, throwable -> mView.handleFailed());
	}
}
