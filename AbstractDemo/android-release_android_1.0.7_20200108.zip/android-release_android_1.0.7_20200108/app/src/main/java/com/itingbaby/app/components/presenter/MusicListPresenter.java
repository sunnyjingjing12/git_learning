package com.itingbaby.app.components.presenter;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.components.IMusicListComponent;
import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.app.model.AudioRecordModelDao;
import com.itingbaby.app.model.AudioType;
import com.itingbaby.app.model.DaoSession;
import com.itingbaby.app.model.MusicClause;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;

import org.greenrobot.greendao.query.Query;

import java.util.List;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * 音乐列表界面presenter
 */
public class MusicListPresenter implements IMusicListComponent.IPresenter {

	private IMusicListComponent.IView mView;

	public MusicListPresenter(IMusicListComponent.IView view) {
		mView = view;
	}

	@Override
	public void getVoiceData(int voiceType, int refreshType, int offset, final int limit) {
		Observable observable = Observable.create((emitter) -> {
			Long uid = BabyVoiceApp.mUserInfo.id;
			DaoSession daoSession = BabyVoiceApp.getInstance().getDaoSession();
			AudioRecordModelDao audioRecordModelDao = daoSession.getAudioRecordModelDao();
			Query<AudioRecordModel> dataset = audioRecordModelDao.queryBuilder()
					.where(AudioRecordModelDao.Properties.Uid.eq(uid),
							AudioRecordModelDao.Properties.Type.lt(AudioType.AUDIO_TYPE_MIXED))
					.orderDesc(AudioRecordModelDao.Properties.Timestamp)
					.limit(limit)
					.offset(offset).build();
			emitter.onNext(dataset.list());
			emitter.onComplete();
		});
		observable.observeOn(AndroidSchedulers.mainThread())
				.doOnTerminate(() -> {
					Ln.d("lihb getVoiceData doOnTerminate");
					if (refreshType == ServiceGenerator.TYPE_FRESH) {
						mView.stopRefresh();
					} else {
						mView.stopLoadMore();
					}
				})
				.subscribeOn(Schedulers.io())
				.subscribe((o) -> {
					List<AudioRecordModel> dataList = (List<AudioRecordModel>) o;
					mView.setIsLastPage(dataList.size() < limit);

					if (ListUtils.isEmpty(dataList) && refreshType == ServiceGenerator.TYPE_FRESH) {
						mView.handleEmpty();
						return;
					}
					if (refreshType == ServiceGenerator.TYPE_FRESH) {
						mView.updateDataList(dataList);
					} else {
						mView.addMoreDataList(dataList);
					}
				}, throwable -> mView.handleFailed());

	}


	@Override
	public void getUserAudioRecordData(long recordType, int page, int rows) {
		long uid = BabyVoiceApp.mUserInfo.id;
		ServiceGenerator.createService(ApiManager.class)
				.getUserRecords(uid, recordType, page, rows)
				.observeOn(AndroidSchedulers.mainThread())
				.doOnTerminate(() -> {
					Ln.d("lihb getUserAudioRecordListData doOnTerminate");
					if (page == 1) {
						mView.stopRefresh();
					} else {
						mView.stopLoadMore();
					}
				})
				.subscribeOn(Schedulers.io())
				.subscribe(httpPageResponse -> {
					Ln.d("lihb getUserAudioRecordListData subscribe");
					if (ResponseCode.RESPONSE_OK == httpPageResponse.code) {
						List<AudioRecordModel> dataList = httpPageResponse.data;
						Ln.d("lihb getMusicClauseListData page = %d, size = %d", page, dataList.size());
						mView.setIsLastPage(httpPageResponse.returnpage == httpPageResponse.pages);
						if (ListUtils.isEmpty(dataList) ) {
							mView.handleEmpty();
							return;
						}

						for (int i=0; i<dataList.size(); ++i) {
							AudioRecordModel model = dataList.get(i);
							model.setRemote(true);
						}
						if (page == 1) {
							mView.updateDataList(dataList);
						} else {
							mView.addMoreDataList(dataList);
						}
					} else {
						mView.showToast(httpPageResponse.msg);
					}
				}, throwable -> {
					Ln.d("lihb throwable = %s", throwable.toString());
					mView.handleFailed();
				});
	}

	@Override
	public void getMusicClauseListData(int cid, int page, int rows) {
		ServiceGenerator.createService(ApiManager.class)
				.getMusicClause(cid, page, rows)
				.observeOn(AndroidSchedulers.mainThread())
				.doOnTerminate(() -> {
					Ln.d("lihb getMusicClauseListData doOnTerminate");
					if (page == 1) {
						mView.stopRefresh();
					} else {
						mView.stopLoadMore();
					}
				})
				.subscribeOn(Schedulers.io())
				.subscribe(httpPageResponse -> {
					Ln.d("lihb getMusicClauseListData subscribe");
					if (ResponseCode.RESPONSE_OK == httpPageResponse.code) {
						List<MusicClause> dataList = httpPageResponse.data;
						Ln.d("lihb getMusicClauseListData page = %d, size = %d", page, dataList.size());
						mView.setIsLastPage(httpPageResponse.returnpage == httpPageResponse.pages);
						if (ListUtils.isEmpty(dataList) ) {
							mView.handleEmpty();
							return;
						}
						if (page == 1) {
							mView.updateDataList(dataList);
						} else {
							mView.addMoreDataList(dataList);
						}
					} else {
						mView.showToast(httpPageResponse.msg);
					}
				}, throwable -> {
					Ln.d("lihb throwable = %s", throwable.toString());
					mView.handleFailed();
				});
	}
}
