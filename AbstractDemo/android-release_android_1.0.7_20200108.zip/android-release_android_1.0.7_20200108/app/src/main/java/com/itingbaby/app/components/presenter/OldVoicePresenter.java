package com.itingbaby.app.components.presenter;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.components.IOldVoiceComponent;
import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.app.model.AudioRecordModelDao;
import com.itingbaby.app.model.DaoSession;
import com.itingbaby.baselib.commonutils.Ln;

import java.util.List;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class OldVoicePresenter implements IOldVoiceComponent.IPresenter {

	private IOldVoiceComponent.IView mView;

	public OldVoicePresenter(IOldVoiceComponent.IView view) {
		mView = view;
	}

	@Override
	public void getVoiceDataSize() {
		Observable observable = Observable.create((emitter) -> {
			DaoSession daoSession = BabyVoiceApp.getInstance().getDaoSession();
			AudioRecordModelDao audioRecordModelDao = daoSession.getAudioRecordModelDao();
			List<AudioRecordModel> modelList = audioRecordModelDao.loadAll();
			emitter.onNext(modelList);
			emitter.onComplete();
		});

		observable.observeOn(AndroidSchedulers.mainThread())
				.doOnTerminate(() -> {
					Ln.d("lihb getVoiceDataSize doOnTerminate");
				})
				.subscribeOn(Schedulers.io())
				.subscribe(o -> {
					mView.handleData((List<AudioRecordModel>) o);
				}, throwable -> mView.handleFailed());
	}

	@Override
	public void updateAllVoiceData(List<AudioRecordModel> delDataList, List<AudioRecordModel> updateList) {
		Observable observable = Observable.create((emitter) -> {
			DaoSession daoSession = BabyVoiceApp.getInstance().getDaoSession();
			AudioRecordModelDao audioRecordModelDao = daoSession.getAudioRecordModelDao();
			audioRecordModelDao.deleteInTx(delDataList);
			audioRecordModelDao.insertOrReplaceInTx(updateList);
			emitter.onNext(1);
			emitter.onComplete();
		});

		observable.observeOn(AndroidSchedulers.mainThread())
				.doOnTerminate(() -> {
					Ln.d("lihb updateAllVoiceDataId doOnTerminate");
				})
				.subscribeOn(Schedulers.io())
				.subscribe(o -> {
					mView.processResult(true);
				}, throwable -> mView.handleFailed());

	}
}
