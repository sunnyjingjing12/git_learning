package com.itingbaby.app.components.presenter;

import com.itingbaby.app.components.IPregnancyCheckComponent;
import com.itingbaby.app.model.pregnancycheck.PregnancyCheckModel;
import com.itingbaby.app.utils.db.PregnancyExamineManager;
import com.itingbaby.baselib.commonutils.ListUtils;

import java.util.List;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class PregnancyCheckPresenter implements IPregnancyCheckComponent.IPresenter {

	private IPregnancyCheckComponent.IView mView;

	public PregnancyCheckPresenter(IPregnancyCheckComponent.IView view) {
		this.mView = view;
	}


	@Override
	public void getAllPregnancyCheckData() {
		Observable observable = Observable.create(new ObservableOnSubscribe<List<PregnancyCheckModel>>() {
			@Override
			public void subscribe(ObservableEmitter<List<PregnancyCheckModel>> emitter) throws Exception {
				List<PregnancyCheckModel> pregnancyCheckModelList = PregnancyExamineManager.getInstance().getAllPregnancyCheckData();
				emitter.onNext(pregnancyCheckModelList);
				emitter.onComplete();
			}
		});
		observable.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(new Consumer() {
					@Override
					public void accept(Object o) throws Exception {
						List<PregnancyCheckModel> pregnancyCheckModelList = (List<PregnancyCheckModel>) o;
						if (ListUtils.isEmpty(pregnancyCheckModelList)) {
							mView.handleEmpty();
							return;
						}
						mView.updateDataList(pregnancyCheckModelList);

					}
				}, new Consumer<Throwable>() {
					@Override
					public void accept(Throwable throwable) throws Exception {
						mView.handleFailed();
					}
				});
	}

	@Override
	public void updatePregnancyCheck(PregnancyCheckModel model) {

	}
}
