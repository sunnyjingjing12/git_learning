package com.itingbaby.app.components.presenter;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.components.IProfileSettingComponent;
import com.itingbaby.app.model.User;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StringUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;


public class ProfileSettingPresenter implements IProfileSettingComponent.IPresenter {

	private IProfileSettingComponent.IView mView;

	public ProfileSettingPresenter(IProfileSettingComponent.IView view) {
		this.mView = view;
	}


	@Override
	public void uploadAvatarToServer(String filePath) {
		List<File> fileList = new ArrayList<>();
		File file = null;
		if (!StringUtils.isBlank(filePath)) {
			file = new File(filePath);
		}

		if (file == null || !file.exists()) {
			Ln.i("no pic to upload!!");
			return;
		}
		fileList.add(file);
		MultipartBody body = filesToMultipartBody(fileList);
		ServiceGenerator.createService(ApiManager.class)
				.uploadAvatar(body)
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribe(httpResponse ->  {
					if (ResponseCode.RESPONSE_OK == httpResponse.code) {
						Ln.i("upload avatar success.");
						CommonToast.showShortToast("更新成功");

						String avatarUrl = httpResponse.data;
						mView.updateAvatarSuccess(avatarUrl);
					} else {
						mView.showToast(httpResponse.msg);
					}
				}, throwable -> {
					Ln.e(throwable.getMessage());
					mView.handleFailed();
				});
	}

	@Override
	public void updateProfile(User user) {
		// 登录时，需要先设置预产期
		ServiceGenerator.createService(ApiManager.class)
				.updateUserInfo(user)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(httpResponse -> {
					Ln.i("lihb", httpResponse.toString());
					if (ResponseCode.RESPONSE_OK == httpResponse.code) {
						// 成功
						mView.updateProfileSuccess(httpResponse.data);
					} else {
						mView.showToast(httpResponse.msg);
					}
				}, throwable -> {
					Ln.i(throwable.getMessage());
					CommonToast.showShortToast("修改失败");
				});
	}

	private MultipartBody filesToMultipartBody(List<File> files) {
		MultipartBody.Builder builder = new MultipartBody.Builder();
		for (File file : files) {
			RequestBody requestBody = RequestBody.create(MediaType.parse(""), file);
			builder.addFormDataPart("uid", Long.toString(BabyVoiceApp.mUserInfo.id));
			builder.addFormDataPart("avatar", file.getName(), requestBody);
			//builder.addFormDataPart("fileName", file.getName());
		}
		builder.setType(MultipartBody.FORM);
		return builder.build();
	}
}
