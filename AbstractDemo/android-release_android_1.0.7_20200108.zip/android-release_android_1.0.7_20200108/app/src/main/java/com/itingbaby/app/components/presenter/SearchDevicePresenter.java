package com.itingbaby.app.components.presenter;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.components.ISearchDeviceComponent;
import com.itingbaby.app.model.DaoSession;
import com.itingbaby.app.model.HistoryBleDeviceModel;
import com.itingbaby.app.model.HistoryBleDeviceModelDao;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.dev.iTingBabyBleDevice;

import org.greenrobot.greendao.query.Query;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.RequestBody;

public class SearchDevicePresenter implements ISearchDeviceComponent.IPresenter {

	private ISearchDeviceComponent.IView mView;

	private List<iTingBabyBleDevice> scanDevices = new ArrayList<>();// 搜索出的BLE设备列表

	public SearchDevicePresenter(ISearchDeviceComponent.IView view) {
		mView = view;
	}

	@Override
	public void getBleDeviceData() {

		Observable observable = Observable.create((ObservableOnSubscribe<List<HistoryBleDeviceModel>>) emitter -> {
			Long uid = BabyVoiceApp.mUserInfo.id;
			DaoSession daoSession = BabyVoiceApp.getInstance().getDaoSession();
			HistoryBleDeviceModelDao deviceModelDao = daoSession.getHistoryBleDeviceModelDao();
			Query<HistoryBleDeviceModel> dataset = deviceModelDao.queryBuilder()
					.where(HistoryBleDeviceModelDao.Properties.Uid.eq(uid))
					.orderDesc(HistoryBleDeviceModelDao.Properties.Timestamp)
					.build();

			List<HistoryBleDeviceModel> list = dataset.list();
			emitter.onNext(list);
			emitter.onComplete();
		});

		observable.observeOn(AndroidSchedulers.mainThread())
				.doOnTerminate(() -> Ln.d("lihb getBleDeviceData doOnTerminate"))
				.subscribeOn(Schedulers.io())
				.subscribe(o -> {
					List<HistoryBleDeviceModel> modelList = (List<HistoryBleDeviceModel>) o; // 历史设备
					mView.updateDataList(modelList, scanDevices);
					if (ListUtils.isEmpty(modelList) && ListUtils.isEmpty(scanDevices)) {
						mView.handleEmpty();
						return;
					}
				}, throwable -> {
					mView.handleFailed();
				});

	}

	public void reportUserDevice(long uid, int deviceType, String deviceMac) {
		RequestBody reqUid = RequestBody.create(MediaType.parse("multipart/form-data"), Long.toString(uid));
		RequestBody reqDeviceType = RequestBody.create(MediaType.parse("multipart/form-data"), Integer.toString(deviceType));
		RequestBody reqDeviceMac = RequestBody.create(MediaType.parse("multipart/form-data"), deviceMac);

		ServiceGenerator.createService(ApiManager.class)
				.reportUserDevice(reqUid, reqDeviceType, reqDeviceMac)
				.observeOn(AndroidSchedulers.mainThread())
				.doOnTerminate(() -> {
				})
				.subscribeOn(Schedulers.io())
				.subscribe(httpResponse -> {
					Ln.i("lihb", httpResponse.toString());
					if (ResponseCode.RESPONSE_OK == httpResponse.code) {
						// 成功
						Ln.d("上报设备成功");
					} else {
						CommonToast.showShortToast(httpResponse.msg);
					}
				}, throwable -> Ln.e(throwable.toString()));
	}

	// 添加搜索到的附近设备进列表
	public void addNearbyDeviceList(iTingBabyBleDevice device) {
		if (null == device) {
			return;
		}
		// 这里放在UI做会一直占用导致阻塞
//		for (BluetoothDevice dev : scanDevices) {// 去重
//			if (dev.getAddress().equals(device.getAddress())) {
//				return;
//			}
//		}
		scanDevices.add(device);
	}

	// 清空搜索到的附近设备列表
	public void clearNearbyDeviceList() {
		if (null == scanDevices) {
			return;
		}
		scanDevices.clear();
	}
}
