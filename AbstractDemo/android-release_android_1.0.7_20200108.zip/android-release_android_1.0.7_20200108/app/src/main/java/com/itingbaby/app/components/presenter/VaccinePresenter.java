package com.itingbaby.app.components.presenter;

import com.itingbaby.app.components.IVaccineComponent;
import com.itingbaby.app.model.Vaccine;
import com.itingbaby.app.utils.db.VaccineManager;
import com.itingbaby.baselib.commonutils.ListUtils;

import java.util.List;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class VaccinePresenter implements IVaccineComponent.IPresenter {

	private IVaccineComponent.IView mView;

	public VaccinePresenter(IVaccineComponent.IView view) {
		this.mView = view;
	}


	@Override
	public void getAllVaccineData() {
		Observable observable = Observable.create(new ObservableOnSubscribe<List<Vaccine>>() {
			@Override
			public void subscribe(ObservableEmitter<List<Vaccine>> emitter) throws Exception {
				List<Vaccine> vaccineList = VaccineManager.getInstance().getAllVaccine();
				emitter.onNext(vaccineList);
				emitter.onComplete();
			}
		});
		observable.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(new Consumer() {
					@Override
					public void accept(Object o) throws Exception {
						List<Vaccine> vaccineList = (List<Vaccine>) o;
						if (ListUtils.isEmpty(vaccineList)) {
							mView.handleEmpty();
							return;
						}
						mView.updateDataList(vaccineList);

					}
				}, new Consumer<Throwable>() {
					@Override
					public void accept(Throwable throwable) throws Exception {
						mView.handleFailed();
					}
				});
	}

	@Override
	public void updateVaccine(Vaccine vaccine) {

	}
}
