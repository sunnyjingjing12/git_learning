package com.itingbaby.app.components.presenter;

import android.Manifest;
import android.content.Context;
import android.media.MediaMetadataRetriever;
import android.text.TextUtils;

import com.github.hiteshsondhi88.libffmpeg.ExecuteBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.FFmpeg;
import com.github.hiteshsondhi88.libffmpeg.LoadBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegCommandAlreadyRunningException;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegNotSupportedException;
import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.components.IVoiceMixComponent;
import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.app.model.AudioRecordModelDao;
import com.itingbaby.app.model.AudioType;
import com.itingbaby.app.model.DaoSession;
import com.itingbaby.app.utils.FileUtils;
import com.itingbaby.baselib.commonutils.ApplicationContext;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.PermissionCheckUtil;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;

import java.io.File;

public class VoiceMixPresenter implements IVoiceMixComponent.IPresenter {

	private IVoiceMixComponent.IView mView;

	private AudioRecordModelDao audioRecordModelDao;
	private FFmpeg ffmpeg;
	private Context context;

	public VoiceMixPresenter(IVoiceMixComponent.IView view) {
		this.mView = view;
	}

	@Override
	public void init(Context context) {
		this.context = context;
		DaoSession daoSession = ((BabyVoiceApp) (ApplicationContext.getApplication())).getDaoSession();
		audioRecordModelDao = daoSession.getAudioRecordModelDao();

		ffmpeg = FFmpeg.getInstance(context);

	}

	@Override
	public void loadFFMpegBinary() {

		try {
			ffmpeg.loadBinary(new LoadBinaryResponseHandler() {
				@Override
				public void onFailure() {
					Ln.e("load ffmpeg failed");
				}

				@Override
				public void onSuccess() {
					super.onSuccess();
					Ln.d("load ffmpeg success");
				}
			});
		} catch (FFmpegNotSupportedException e) {
			Ln.e(e);
		}
	}

	@Override
	public void execFFmpegMixVoice(String[] command, ExecuteBinaryResponseHandler handler) {
		try {
			ffmpeg.execute(command, handler);
		} catch (FFmpegCommandAlreadyRunningException e) {
			// do nothing for now
			mView.showErrorMsg(e.getMessage());
		}
	}

	@Override
	public void saveDataToDB(String newFileName) {
		AudioRecordModel audioRecordModel = new AudioRecordModel();
		audioRecordModel.setUid(BabyVoiceApp.mUserInfo.id);
		audioRecordModel.setName(newFileName);
		audioRecordModel.setType(AudioType.AUDIO_TYPE_MIXED);

		String newFilePath = FileUtils.getRecordDir() + newFileName + ".wav";
		audioRecordModel.setUrl(newFilePath);
		try {
			MediaMetadataRetriever retriever = new MediaMetadataRetriever();
			retriever.setDataSource(newFilePath);
			String durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION); // 播放时长单位为毫秒
			int duration = TextUtils.isEmpty(durationStr) ? 0 : Integer.valueOf(durationStr) / 1000;
			audioRecordModel.setDuration(duration);

		} catch (Exception e) {
			Ln.e(e);
		}

		audioRecordModel.setTimestamp(System.currentTimeMillis() / 1000);
		audioRecordModelDao.insertOrReplaceInTx(audioRecordModel);
	}

	@Override
	public void deleteRecordFile(String filePath) {
		File file = new File(filePath);
		if (file.exists()) {
			file.delete();
		}
	}

	@Override
	public void checkPermission(BaseFragmentActivity activity) {
		// 第 1 步: 检查是否有相应的权限

		boolean isAllGranted = PermissionCheckUtil.checkPermissionAllGranted(activity,
				new String[]{
						Manifest.permission.READ_EXTERNAL_STORAGE,
						Manifest.permission.WRITE_EXTERNAL_STORAGE
				}
		);
		// 如果权限全都拥有, 则直接返回
		if (isAllGranted) {
			mView.permissionGrantSuccess();
			return;
		}


		// 第 2 步: 请求权限
		// 一次请求多个权限, 如果其他有权限是已经授予的将会自动忽略掉
		PermissionCheckUtil.requestPermission(activity, new String[]{
				Manifest.permission.READ_EXTERNAL_STORAGE,
				Manifest.permission.WRITE_EXTERNAL_STORAGE
		});
	}
}
