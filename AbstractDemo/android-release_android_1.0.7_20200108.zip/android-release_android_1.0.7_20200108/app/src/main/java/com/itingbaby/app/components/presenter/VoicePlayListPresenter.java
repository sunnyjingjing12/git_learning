package com.itingbaby.app.components.presenter;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.components.IVoicePlayListComponent;
import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.app.model.AudioRecordModelDao;
import com.itingbaby.app.model.AudioType;
import com.itingbaby.app.model.DaoSession;
import com.itingbaby.app.model.MusicCategory;
import com.itingbaby.app.model.MusicClause;
import com.itingbaby.app.model.MusicGroup;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;

import org.greenrobot.greendao.query.Query;
import org.greenrobot.greendao.query.QueryBuilder;

import java.util.List;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;


public class VoicePlayListPresenter implements IVoicePlayListComponent.IPresenter {

	private IVoicePlayListComponent.IView mView;

	public VoicePlayListPresenter(IVoicePlayListComponent.IView view) {
		this.mView = view;
	}

	@Override
	public void getVoiceData(MusicCategory category, int voiceType) {
		if (category == null) {
			getVoiceDataFromLocal(voiceType);
		} else {
			if (MusicGroup.MUSIC_GROUP_ID_MY_VOICE == category.gid) {
				getVoiceDataFromServer();
			} else {
				getMusicDataFromServer(category.id);
			}
		}
	}

	private void getVoiceDataFromServer() {
		long uid = BabyVoiceApp.mUserInfo.id;
		long recordType = AudioType.AUDIO_TYPE_BABY | AudioType.AUDIO_TYPE_MOM | AudioType.AUDIO_TYPE_LUNG | AudioType.AUDIO_TYPE_MIXED;
		ServiceGenerator.createService(ApiManager.class)
				.getUserRecords(uid, recordType, 1, 200)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(httpPageResponse -> {
					Ln.d("lihb getMusicClauseData subscribe");
					if (httpPageResponse.code == ResponseCode.RESPONSE_OK) {
						List<AudioRecordModel> dataList = httpPageResponse.data;
						if (ListUtils.isEmpty(dataList)) {
							mView.handleEmpty();
							return;
						}
						for (AudioRecordModel model : dataList) {
							model.setRemote(true);
						}
						mView.updateDataList(dataList);
					} else {
						mView.showToast(httpPageResponse.msg);
					}
				},throwable -> {
					Ln.d("lihb throwable = %s", throwable.toString());
					mView.handleFailed();
				});
	}

	private void getMusicDataFromServer(int cid) {
		ServiceGenerator.createService(ApiManager.class)
				.getMusicClause(cid, 1, 200)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(httpPageResponse -> {
					if (httpPageResponse.code == ResponseCode.RESPONSE_OK) {
						Ln.d("lihb getMusicClauseData subscribe");
						List<MusicClause> dataList = httpPageResponse.data;
						if (ListUtils.isEmpty(dataList)) {
							mView.handleEmpty();
							return;
						}
						mView.updateDataList(dataList);
					} else {
						mView.showToast(httpPageResponse.msg);
					}
				},throwable -> {
					Ln.d("lihb throwable = %s", throwable.toString());
					mView.handleFailed();
				});
	}

	private void getVoiceDataFromLocal(int voiceType) {
		Observable observable = Observable.create((emitter) -> {
			long uid = BabyVoiceApp.mUserInfo.id;
			DaoSession daoSession = BabyVoiceApp.getInstance().getDaoSession();
			AudioRecordModelDao audioRecordModelDao = daoSession.getAudioRecordModelDao();
			QueryBuilder qb = audioRecordModelDao.queryBuilder();
			if (voiceType == 1) {
				qb.where(AudioRecordModelDao.Properties.Uid.eq(uid),
						AudioRecordModelDao.Properties.Type.eq(AudioType.AUDIO_TYPE_MIXED));
			} else {
				qb.where(AudioRecordModelDao.Properties.Uid.eq(uid),
						qb.or(AudioRecordModelDao.Properties.Type.eq(AudioType.AUDIO_TYPE_BABY),
								AudioRecordModelDao.Properties.Type.eq(AudioType.AUDIO_TYPE_MOM),
								AudioRecordModelDao.Properties.Type.eq(AudioType.AUDIO_TYPE_LUNG)));

			}
			qb.orderDesc(AudioRecordModelDao.Properties.Timestamp);
			Query<AudioRecordModel> dataSet = qb.build();
			emitter.onNext(dataSet.list());
			emitter.onComplete();
		});
		observable.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe((o) -> {
					List<AudioRecordModel> dataList = (List<AudioRecordModel>) o;
					if (ListUtils.isEmpty(dataList)) {
						mView.handleEmpty();
						return;
					}

					mView.updateDataList(dataList);
				}, throwable -> mView.handleFailed());
	}
}
