package com.itingbaby.app.components.presenter;

import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.components.IWaitPregnancyComponent;
import com.itingbaby.app.model.WaitTodoGoods;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;

import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.RequestBody;

public class WaitPregnancyPresenter implements IWaitPregnancyComponent.IPresenter {
	private IWaitPregnancyComponent.IView mView;

	public WaitPregnancyPresenter(IWaitPregnancyComponent.IView view) {
		this.mView = view;
	}

	private boolean isPreRequestFinish = true;

	@Override
	public void getAllTodoGoods(long uid, int goodsType) {
		if (isPreRequestFinish) {
			isPreRequestFinish = false;
			Ln.d("lihb getAllTodoGoods start, goodsType = %d", goodsType);
			ServiceGenerator.createService(ApiManager.class)
					.getTodoGoodsList(uid, goodsType)
					.observeOn(AndroidSchedulers.mainThread())
					.subscribeOn(Schedulers.io())
					.doOnTerminate(() -> {
						Ln.d("lihb getAllTodoGoods doOnTerminate");
						isPreRequestFinish = true;
					})
					.subscribe(httpResponse -> {
						if (ResponseCode.RESPONSE_OK == httpResponse.code) {
							List<WaitTodoGoods> dataList = httpResponse.data;
							if (ListUtils.isEmpty(dataList)) {
								mView.handleEmpty();
								return;
							}
							mView.updateDataList(dataList);
						} else {
							mView.showToast(httpResponse.msg);
						}
					}, throwable -> {
						Ln.d(throwable.toString());
						mView.handleFailed();
					});
		}
	}

	@Override
	public void updateTodoGoods(long uid, WaitTodoGoods goods) {
		RequestBody reqUid = RequestBody.create(MediaType.parse("multipart/form-data"), Long.toString(uid));
		RequestBody reqGid = RequestBody.create(MediaType.parse("multipart/form-data"), Integer.toString(goods.id));
		RequestBody reqFlag = RequestBody.create(MediaType.parse("multipart/form-data"), Integer.toString(goods.flag));
		ServiceGenerator.createService(ApiManager.class)
				.updateTodoGoods(reqUid, reqGid, reqFlag)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(httpResponse -> {
					if (httpResponse.code == ResponseCode.RESPONSE_OK) {
						Ln.d("更新成功");
					} else {
						CommonToast.showShortToast(httpResponse.msg);
					}
				}, throwable -> mView.handleFailed());
	}
}
