package com.itingbaby.app.customview;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.itingbaby.achartengine.ChartFactory;
import com.itingbaby.achartengine.GraphicalView;
import com.itingbaby.achartengine.chart.PointStyle;
import com.itingbaby.achartengine.model.XYMultipleSeriesDataset;
import com.itingbaby.achartengine.model.XYSeries;
import com.itingbaby.achartengine.renderer.XYMultipleSeriesRenderer;
import com.itingbaby.achartengine.renderer.XYSeriesRenderer;

/**
 * EHG单通道数据视图
 */
public class CardiographView extends RelativeLayout {

	private static final int COLOR_COORDINATE = Color.WHITE;

	// 采样率范围
	private static final int SAMPLE_RATE_MIN = 20;
	private static final int SAMPLE_RATE_MAX = 500;

	private static final float SIZE_POINT = 3.0f;
	private static final float SIZE_TEXT = 18f;

	private String title = "";

	private XYMultipleSeriesDataset dataset;
	private XYMultipleSeriesRenderer renderer;
	private GraphicalView chart;
	private XYSeries series;


	private int X_AXIS_AVERAGE = 1;// X轴等分(单位:秒)
	private int Y_AXIS_RANGE = 5;
	private int sampleRate;// 测试的采样率值
	private int pointScreen;// 满屏时最大点数量
	private double pointInterval;// 点之间的间隔
	private double[] xv;
	private double[] yv;
	private boolean updateFlag;


	public CardiographView(Context context) {
		this(context, null);
	}

	public CardiographView(Context context, @Nullable AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public CardiographView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);

//		TypedArray a = getContext().obtainStyledAttributes(attrs,
//				R.styleable.PelvicSubView, defStyleAttr, 0);
//
//		iconResId = a.getResourceId(R.styleable.PelvicSubView_sub_view_icon, 0);
//		nameResId = a.getResourceId(R.styleable.PelvicSubView_sub_view_name, 0);
//		a.recycle();

		initView();
		initCalc();
		initCardiograph();
	}

	// region 私有函数

	private void initView() {
	}

	private boolean initCalc() {
		sampleRate = 480;
		if (SAMPLE_RATE_MIN < sampleRate && sampleRate < SAMPLE_RATE_MAX) {
			pointScreen = sampleRate * X_AXIS_AVERAGE;
			pointInterval = (double)1 / sampleRate;
			xv = new double[pointScreen];
			yv = new double[pointScreen];
			return true;
		}
		return false;
	}

	private void initCardiograph() {
		series = new XYSeries(title);
		dataset = new XYMultipleSeriesDataset();
		renderer = new XYMultipleSeriesRenderer();
		XYSeriesRenderer r = new XYSeriesRenderer();
		r.setColor(Color.GREEN);
		r.setPointStyle(PointStyle.POINT);

		dataset.addSeries(series);

		setChartSettings();
		renderer.addSeriesRenderer(r);

		chart = ChartFactory.getLineChartView(getContext(), dataset, renderer);
		chart.setBackgroundColor(Color.BLACK);
		addView(chart);
	}

	private void setChartSettings() {
		// DefaultRenderer legend(最下面的文字说明)
		renderer.setAntialiasing(true);// 消除锯齿
		renderer.setAxesColor(COLOR_COORDINATE);// 设置X轴颜色
		renderer.setAxisTitleTextSize(SIZE_TEXT);// 设置坐标轴标题字体的大小
		renderer.setBackgroundColor(Color.BLACK);// 背景色
		//renderer.setChartTitle("标题");// 标题
		//renderer.setChartTitleTextSize(20);// 标题字号
		renderer.setClickEnabled(false);// 是否可点击
		renderer.setExternalZoomEnabled(false);
		renderer.setFitLegend(true);// 设置图例字号自适应
		renderer.setGridLineWidth(2.0f);
		renderer.setLabelsColor(COLOR_COORDINATE);// 设置标签颜色
		renderer.setLabelsTextSize(SIZE_TEXT);// 设置坐标轴标签文字的大小
		renderer.setLegendTextSize(SIZE_TEXT);
		//renderer.setMargins(new int[] { 0, 0, 0, 0 });// 设置图表的外边框(上/左/下/右)
		renderer.setPanEnabled(false);// 图表是否可以移动
		renderer.setShowAxes(true);// 是否显示坐标轴的轴线
		renderer.setShowGrid(true);// 是否显示网格
		renderer.setShowLabels(true);// 是否显示坐标轴区域，包括轴线和坐标值
		renderer.setShowLegend(false);// 是否显示图例
		renderer.setXLabelsColor(COLOR_COORDINATE);// 设置X轴标签颜色
		renderer.setYLabelsColor(0, COLOR_COORDINATE);// 设置Y轴标签颜色
		renderer.setZoomButtonsVisible(true);// 滑动和放大缩小
		renderer.setZoomEnabled(true);// 图表是否可以缩放设置

		// XYMultipleSeriesRenderer
		renderer.setAxisTitleTextSize(SIZE_TEXT);
		renderer.setGridColor(Color.GRAY);
		//renderer.setMarginsColor(Color.RED);
		renderer.setPointSize(SIZE_POINT);
		//renderer.setXTitle("X");// X轴标题
		//renderer.setYTitle("Y");// Y轴标题
		renderer.setXAxisMin(0);// 设置X轴最小值
		renderer.setXAxisMax(X_AXIS_AVERAGE);// 设置X轴最大值
		renderer.setYAxisMin(-Y_AXIS_RANGE);// 设置Y轴最小值
		renderer.setYAxisMax(Y_AXIS_RANGE);// 设置Y轴最大值
		//renderer.setYAxisAlign(Align.RIGHT, 0);//用来调整Y轴放置的位置，表示将第一条Y轴放在右侧
		renderer.setXLabels(0/*X_AXIS_AVERAGE*/);// 设置x轴显示刻度标签的个数。若不想显示X标签刻度，设置为0即可
		renderer.setYLabels(Y_AXIS_RANGE * 2);// 设置y轴显示刻度，以中点为零点
		renderer.setXLabelsAlign(Paint.Align.CENTER);// 刻度线与刻度标注之间的相对位置关系
		renderer.setYLabelsAlign(Paint.Align.RIGHT);
	}

	// endregion 私有函数

	// region 公有函数

	public void setTitle(String title) {
		this.title = title;
	}

	public void startRefresh() {
		updateFlag = true;
	}

	public void stopRefresh() {
		updateFlag = false;
		series.clear();
		chart.repaint();
	}

	public void clear() {
		if (updateFlag) {
			Toast.makeText(getContext(), "请先停止刷新", Toast.LENGTH_SHORT).show();
			return;
		}
		series.clear();
		chart.repaint();
	}

	public void updateData(float[] data) {
		if (!updateFlag) {
			return;
		}

		int n = series.getItemCount() + data.length;
		if (n > pointScreen) {
			int delCount = n - pointScreen;// 删除的旧点数量
			int bufSize = 0;
			double totalInterval = delCount * pointInterval;// 剩余需要刷新的点需要向左位移的距离
			for (int i=delCount; i<series.getItemCount(); ++i,++bufSize) {
				xv[bufSize] = series.getX(i) - totalInterval;
				yv[bufSize] = series.getY(i);
			}
			series.clear();
			for (int i=0; i<bufSize; ++i) {
				series.add(xv[i], yv[i]);
			}
		}

		for (int i=0; i<data.length; ++i) {
			int pos = series.getItemCount();
			if (0 == pos) {
				series.add(0, data[i]);
				continue;
			}
			double tmpX = series.getX(pos - 1);
			series.add(tmpX + pointInterval, data[i]);
		}

		chart.postInvalidate();
	}

	// endregion 公有函数
}
