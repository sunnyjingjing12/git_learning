package com.itingbaby.app.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.itingbaby.app.R;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.model.MusicCategory;
import com.itingbaby.app.model.MusicGroup;
import com.itingbaby.app.model.SimpleTextItem;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.viewbinder.SimpleTextItemViewBinder;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import me.drakeet.multitype.MultiTypeAdapter;

public class CategoryVoiceView extends LinearLayout {


	@BindView(R.id.category_recycler_view)
	SwipeRecyclerView recyclerView;

	private MultiTypeAdapter mAdapter;

	private List mItems = new ArrayList<>();
	private List<MusicCategory> categoriesList = new ArrayList<>();
	private SimpleTextItemViewBinder mSimpleTextItemViewBinder;

	private OnCategoryVoiceViewListener mOnCategoryVoiceViewListener;

	public void setOnCategoryVoiceViewListener(OnCategoryVoiceViewListener l) {
		this.mOnCategoryVoiceViewListener = l;
	}

	public CategoryVoiceView(Context context) {
		this(context, null);
	}

	public CategoryVoiceView(Context context, @Nullable AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public CategoryVoiceView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initView();

	}

	private void initView() {
		inflate(getContext(), R.layout.view_category_voice, this);
		ButterKnife.bind(this);
		setOrientation(VERTICAL);

		initRecyclerView();

	}

	private void initRecyclerView() {
		mAdapter = new MultiTypeAdapter(mItems);

		recyclerView.setAdapter(mAdapter);
		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

		mSimpleTextItemViewBinder = new SimpleTextItemViewBinder();
		mAdapter.register(SimpleTextItem.class, mSimpleTextItemViewBinder);

		mSimpleTextItemViewBinder.setOnItemClickListener(new SimpleTextItemViewBinder.OnItemClickListener() {
			@Override
			public void onItemClick(int position) {
				for (int i = 0; i < mItems.size(); i++) {
					SimpleTextItem item = (SimpleTextItem) mItems.get(i);
					int backgroundDrawable = 0;
					if (position == i) {
						backgroundDrawable = (i == 0) ? R.drawable.bg_fcffffff_20dp_shape : R.drawable.bg_fcffffff_shape;
					}
					item.background = backgroundDrawable;
				}
				mAdapter.notifyDataSetChanged();

				if (mOnCategoryVoiceViewListener != null) {
					mOnCategoryVoiceViewListener.onItemClick(position, categoriesList.get(position));
				}
			}

			@Override
			public void onRightTextClick() {

			}
		});
	}

	private void updateMusicGroupList(List<MusicGroup> list) {
		mItems.clear();
		categoriesList.clear();
		for (MusicGroup group : list) {
			List<MusicCategory> categoryList = group.categoryList;
			for (MusicCategory category : categoryList) {
				categoriesList.add(category);
				SimpleTextItem item = new SimpleTextItem.Builder()
						.title(category.title)
						.height(52)
						.textSize(19)
						.textColor(R.color.white)
						.isHorizontalCenter(true)
						.build();
				item.background = category.id == MusicCategory.MUSIC_CATEGORY_USER ? R.drawable.bg_fcffffff_20dp_shape : 0; // 默认选择第一个
				mItems.add(item);
			}
		}
		mAdapter.notifyDataSetChanged();
	}


	public void getMusicGroupData() {
		ServiceGenerator.createService(ApiManager.class)
				.getMusicGroup()
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(httpResponse -> {
					if (ResponseCode.RESPONSE_OK == httpResponse.code) {
						List<MusicGroup> list = httpResponse.data;

						updateMusicGroupList(list);
					} else {
						CommonToast.showShortToast(httpResponse.msg);
					}
				}, throwable -> {
					Ln.e(throwable.getMessage());
				});
	}

	public interface OnCategoryVoiceViewListener {
		void onItemClick(int pos, MusicCategory category);
	}

}
