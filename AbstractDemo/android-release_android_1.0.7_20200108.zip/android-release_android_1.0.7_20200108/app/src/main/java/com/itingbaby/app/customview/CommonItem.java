package com.itingbaby.app.customview;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.bumptech.glide.Glide;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.baselib.commonutils.DimensionUtil;

/**
 * 用法：
 * <CommonItem
 * android:id="@+id/item_lesson_detail"
 * android:layout_width="wrap_content"
 * android:layout_height="wrap_content"
 * android:visibility="gone"
 * app:studentItemSelector="@drawable/item_selector"
 * app:studentLeftIcon="@drawable/ic_lesson_detail"
 * app:studentRightIcon="@drawable/icon_my_next"
 * app:studentItemName="@string/student_setting_item_lesson_detail"
 * app:studentDividerVisible="true"
 * />
 */

public class CommonItem extends RelativeLayout {

	//属性
	private int mItemNameColor;  // 文字颜色
	private int mItemNameSize;   // 文字大小
	private int mCommonLeftIconLeftMargin; // 左侧图标距左侧距离
	private int mSelectorRes = 0;

	private int mLeftImgIconRes = 0;

	private int mRightIconRes = 0;

	private int mItemValueVisibility;

	private int mRightImgVisibility;

	private int mLeftImgIconVisibility;

	private String mNameString;

	private boolean mDividerVisible = true;

	private int mImgItemValueVisibility;
	private int mItemValueColor;
	private int mItemValueSize;

	// 控件
	private ConstraintLayout mContainer;


	private ImageView mRightImg;

	private ImageView mLeftImg;


	private TextView mNameTv;

	private TextView mItemValueTv;

	private DividerLine mDividerLine;

	private CircularImageView mImgItemValue;


	public CommonItem(Context context) {
		this(context, null);
	}

	public CommonItem(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public CommonItem(Context context, AttributeSet attrs, int defStyleAttr) {
		this(context, attrs, defStyleAttr, 0);
	}

	public CommonItem(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
		super(context, attrs, defStyleAttr);
		TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.CommonItem);
		if (typedArray != null) {
			// 选中背景色
			mSelectorRes = typedArray.getResourceId(R.styleable.CommonItem_commonItemSelector, 0);

			// 下划线
			mDividerVisible = typedArray.getBoolean(R.styleable.CommonItem_commonDividerVisible, true);

			// 左侧图片
			mLeftImgIconRes = typedArray.getResourceId(R.styleable.CommonItem_commonLeftIcon, 0);
			mLeftImgIconVisibility = typedArray.getInt(R.styleable.CommonItem_leftImgIconVisible, View.VISIBLE);
			mCommonLeftIconLeftMargin = typedArray.getDimensionPixelSize(R.styleable.CommonItem_commonLeftIconLeftMargin, DimensionUtil.dipToPx(context, 16));

			// 左侧文字
			mNameString = typedArray.getText(R.styleable.CommonItem_commonItemName).toString();
			mItemNameColor = typedArray.getColor(R.styleable.CommonItem_itemNameColor, 0xb3000000);
			mItemNameSize = typedArray.getDimensionPixelSize(R.styleable.CommonItem_itemNameSize, DimensionUtil.spToPx(context, 16));

			// 右侧文字
			mItemValueVisibility = typedArray.getInt(R.styleable.CommonItem_itemValueVisible, View.GONE);
			mItemValueColor = typedArray.getColor(R.styleable.CommonItem_itemValueColor, 0xb3000000);
			mItemValueSize = typedArray.getDimensionPixelSize(R.styleable.CommonItem_itemValueSize, DimensionUtil.spToPx(context, 14));

			// 右侧图片，一般是个人头像
			mImgItemValueVisibility = typedArray.getInt(R.styleable.CommonItem_imgItemValueVisible, View.GONE);

			// 最右侧图片，一般是箭头
			mRightIconRes = typedArray.getResourceId(R.styleable.CommonItem_commonRightIcon, R.drawable.ic_next);
			mRightImgVisibility = typedArray.getInt(R.styleable.CommonItem_rightImgVisible, View.VISIBLE);

			typedArray.recycle();
		}

		inflate(context, R.layout.common_item, this);

		mContainer = findViewById(R.id.common_item_group);
		mLeftImg = findViewById(R.id.item_img_left);
		mRightImg = findViewById(R.id.item_icon_right);
		mNameTv = findViewById(R.id.item_name);
		mItemValueTv = findViewById(R.id.item_value);
		mDividerLine = findViewById(R.id.item_divider);
		mImgItemValue = findViewById(R.id.img_item_value);


		if (mSelectorRes != 0) {
			mContainer.setBackgroundResource(mSelectorRes);
		} else {
			mContainer.setBackground(null);
		}

		mLeftImg.setImageResource(mLeftImgIconRes);


		ConstraintLayout.LayoutParams params = (ConstraintLayout.LayoutParams) mLeftImg.getLayoutParams();
		params.setMargins(mCommonLeftIconLeftMargin, 0, 0, 0);
		mLeftImg.setLayoutParams(params);

		mLeftImg.setVisibility(mLeftImgIconVisibility);

		if (mRightIconRes != 0) {
			mRightImg.setImageResource(mRightIconRes);
		} else {
			mRightImg.setImageDrawable(null);
		}
		mRightImg.setVisibility(mRightImgVisibility);

		mNameTv.setText(mNameString);
		mNameTv.setTextSize(TypedValue.COMPLEX_UNIT_PX, mItemNameSize);
		mNameTv.setTextColor(mItemNameColor);

		mItemValueTv.setVisibility(mItemValueVisibility);
		mItemValueTv.setTextSize(TypedValue.COMPLEX_UNIT_PX, mItemValueSize);
		mItemValueTv.setTextColor(mItemValueColor);

		if (mDividerVisible) {
			mDividerLine.setVisibility(View.VISIBLE);
		} else {
			mDividerLine.setVisibility(View.GONE);
		}


		mImgItemValue.setVisibility(mImgItemValueVisibility);

	}

	public void setLeftImgIconRes(@DrawableRes int res){
		mLeftImg.setImageResource(res);
	}

	public void setItemName(String value) {
		mNameTv.setText(value);
	}

	public void setItemValue(String value) {
		mItemValueTv.setText(value);
	}

	public void setItemValueColor(int color) {
		mItemValueTv.setTextColor(getResources().getColor(color));
	}

	public void setItemValueSize(int size) {
		mItemValueTv.setTextSize(size);
	}

	public String getItemValue() {
		return mItemValueTv.getText().toString().trim();
	}

	public void setOnClickListener(OnClickListener listener) {
		if (mContainer != null) {
			mContainer.setOnClickListener(listener);
		}
	}

	public void setImgItemValue(String avatarUrl, boolean isLocal) {
		if (!isLocal && !avatarUrl.contains("http")) {
			avatarUrl = ServiceGenerator.URL_IMG_SERVER + avatarUrl;
		}
		Glide.with(getContext())
				.load(avatarUrl)
				.placeholder(R.drawable.ic_default_avatar)
				.error(R.drawable.ic_default_avatar)
				.dontAnimate()
				.into(mImgItemValue);
	}


}
