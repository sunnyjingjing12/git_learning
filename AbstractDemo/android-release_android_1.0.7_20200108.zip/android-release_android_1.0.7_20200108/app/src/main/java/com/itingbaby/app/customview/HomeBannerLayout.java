package com.itingbaby.app.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.itingbaby.app.R;
import com.itingbaby.app.utils.GlideImageLoader;
import com.itingbaby.baselib.commonutils.DimensionUtil;
import com.youth.banner.Banner;
import com.youth.banner.BannerConfig;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class HomeBannerLayout extends FrameLayout {

	@BindView(R.id.banner_home)
	Banner mBanner;


	private Context mContext;
	private List<String> mImgUrls = new ArrayList<>();

	private OnBannerClickListener mOnBannerClickListener;

	public HomeBannerLayout(Context context) {
		this(context, null);
	}

	public HomeBannerLayout(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public HomeBannerLayout(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initView(context);
	}

	public void setOnBannerClickListener(OnBannerClickListener l) {
		this.mOnBannerClickListener = l;
	}

	private void initView(Context context) {
		mContext = context;
		inflate(context, R.layout.item_home_banner_group, this);
		ButterKnife.bind(this);
		LayoutParams params = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		params.setMargins(DimensionUtil.dipToPx(context, 16), DimensionUtil.dipToPx(context, 12), DimensionUtil.dipToPx(context, 16), DimensionUtil.dipToPx(context, 16));
		setLayoutParams(params);
//		setBackgroundResource(R.drawable.bg_solid_ffffff_corner_10dp);

		mBanner.setImageLoader(new GlideImageLoader());
		mBanner.setBannerStyle(BannerConfig.CIRCLE_INDICATOR);
		mBanner.setOnBannerListener(position -> {
			if (mOnBannerClickListener != null) {
				mOnBannerClickListener.onBannerClick(position);
			}

		});

	}

	public void updateImgs(List<String> imgUrls) {
		mImgUrls.clear();
		mImgUrls.addAll(imgUrls);

		mBanner.update(imgUrls);
	}

	public interface OnBannerClickListener {
		void onBannerClick(int position);
	}
}
