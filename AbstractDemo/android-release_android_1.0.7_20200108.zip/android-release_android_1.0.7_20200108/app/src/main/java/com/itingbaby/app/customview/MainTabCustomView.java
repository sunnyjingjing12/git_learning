package com.itingbaby.app.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;

import com.itingbaby.app.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainTabCustomView extends RelativeLayout {

	@BindView(R.id.txt_tab_title)
	TextView txtTabTitle;
	@BindView(R.id.dot_view)
	View dotView;

	public MainTabCustomView(@NonNull Context context) {
		this(context, null);

	}

	public MainTabCustomView(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public MainTabCustomView(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initView(context);
	}

	private void initView(Context context) {
		inflate(context, R.layout.main_custom_tab, this);
		ButterKnife.bind(this);
	}

	public void initData(String title, @DrawableRes int drawableId) {
		txtTabTitle.setText(title);
		txtTabTitle.setCompoundDrawablesWithIntrinsicBounds(null, getResources().getDrawable(drawableId), null, null);
	}

	public void setDotViewVisibility(int visibility) {
		dotView.setVisibility(visibility);
	}

}
