package com.itingbaby.app.customview;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.itingbaby.app.R;

import butterknife.BindView;
import butterknife.ButterKnife;


/**
 * 盆底肌力训练，测试记录子view
 */
public class PelvicSubView extends FrameLayout {

	@BindView(R.id.img_icon)
	ImageView imgIcon;
	@BindView(R.id.txt_name)
	TextView txtName;
	@BindView(R.id.txt_desc)
	TextView txtDesc;
	@BindView(R.id.txt_desc_unit)
	TextView txtDescUnit;

	private int iconResId;
	private int nameResId;

	public PelvicSubView(Context context) {
		this(context, null);
	}

	public PelvicSubView(Context context, @Nullable AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public PelvicSubView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);

		TypedArray a = getContext().obtainStyledAttributes(attrs,
				R.styleable.PelvicSubView, defStyleAttr, 0);

		iconResId = a.getResourceId(R.styleable.PelvicSubView_sub_view_icon, 0);
		nameResId = a.getResourceId(R.styleable.PelvicSubView_sub_view_name, 0);
		a.recycle();

		initView();
	}

	private void initView() {
		inflate(getContext(), R.layout.item_pelvic_sub_view, this);
		ButterKnife.bind(this);

		imgIcon.setImageResource(iconResId);
		txtName.setText(nameResId);
	}

	/**
	 * 初始化数据
	 * x	 * @param name
	 *
	 * @param desc
	 * @param unit
	 */
	public void initData(String desc, String unit) {
		txtDesc.setText(desc);
		txtDescUnit.setText(unit);
	}
}
