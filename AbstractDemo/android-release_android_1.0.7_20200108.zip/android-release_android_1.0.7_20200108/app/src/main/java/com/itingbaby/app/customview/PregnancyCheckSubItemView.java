package com.itingbaby.app.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.itingbaby.app.R;
import com.itingbaby.app.model.pregnancycheck.PregnancyCheckSubItem;
import com.itingbaby.baselib.commonutils.DimensionUtil;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PregnancyCheckSubItemView extends LinearLayout {

	@BindView(R.id.tv_item_title)
	TextView tvItemTitle;
	@BindView(R.id.tv_item_content)
	TextView tvItemContent;

	public PregnancyCheckSubItemView(Context context) {
		this(context, null);
	}

	public PregnancyCheckSubItemView(Context context, @Nullable AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public PregnancyCheckSubItemView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initView(context);
	}

	private void initView(Context context) {
		inflate(getContext(), R.layout.pregnacy_check_sub_item_view, this);
		ButterKnife.bind(this);

		setOrientation(VERTICAL);
		LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
		params.setMargins(DimensionUtil.dipToPx(context, 16), DimensionUtil.dipToPx(context, 10), DimensionUtil.dipToPx(context, 16), DimensionUtil.dipToPx(context, 0));
		setLayoutParams(params);

	}


	public void rendView(PregnancyCheckSubItem subItem) {
		tvItemTitle.setText(subItem.title);
		tvItemContent.setText(subItem.content);

	}
}
