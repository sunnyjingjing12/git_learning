package com.itingbaby.app.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.itingbaby.app.R;
import com.itingbaby.app.fragment.HomeVoiceFragment;
import com.itingbaby.baselib.commonutils.SVGAUtil;
import com.itingbaby.dev.iTingBabyBleDeviceManager;
import com.opensource.svgaplayer.SVGAImageView;

import butterknife.BindView;
import butterknife.ButterKnife;


public class RecordOperationView extends FrameLayout {

	@BindView(R.id.txt_record)
	TextView txtRecord;
	@BindView(R.id.svga_recording)
	SVGAImageView svgaRecording;
	@BindView(R.id.record_layout)
	RelativeLayout recordLayout;
	@BindView(R.id.save_layout)
	LinearLayout saveLayout;

	public RecordOperationView(@NonNull Context context) {
		this(context, null);
	}

	public RecordOperationView(@NonNull Context context, @Nullable AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public RecordOperationView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initView();
	}

	private void initView() {
		inflate(getContext(), R.layout.view_record_operation_layout, this);
		ButterKnife.bind(this);
	}


	public void renderRecordStatus(int fragmentType, OnClickListener listener1, OnClickListener listener2) {
		if (fragmentType == HomeVoiceFragment.VOICE_TYPE_RECORD) {
			if (iTingBabyBleDeviceManager.getInstance().isRecording()) {
				txtRecord.setText(getContext().getString(R.string.txt_recording));
				svgaRecording.setImageResource(0);
				playRecordingAnimation(true);
				saveLayout.setVisibility(GONE);
				setOnClickListener(listener2);
			} else {
				if (!iTingBabyBleDeviceManager.getInstance().isComplete()) {
					txtRecord.setText(getContext().getString(R.string.record_baby_voice));
					playRecordingAnimation(false);
					svgaRecording.setImageResource(R.drawable.record);
					saveLayout.setVisibility(GONE);
					setOnClickListener(listener1);
				} else {
					txtRecord.setText(getContext().getString(R.string.save));
					playRecordingAnimation(false);
					svgaRecording.setImageResource(R.drawable.ic_record_finshed);
					saveLayout.setVisibility(VISIBLE);
					setOnClickListener(listener2);
				}
			}
		} else {
			txtRecord.setText(getContext().getString(R.string.txt_mixed_voice));
			playRecordingAnimation(false);
			svgaRecording.setImageResource(R.drawable.ic_goto_mixed);
			saveLayout.setVisibility(GONE);
			setOnClickListener(listener2);
		}
	}

	/**
	 * 是否需要播放动画
	 *
	 * @param play
	 */
	private void playRecordingAnimation(boolean play) {
		if (play) {
			svgaRecording.setLoops(0);
			SVGAUtil.loadSvgaAnimation(svgaRecording, "svga/recording.svga", true);
		} else {
			svgaRecording.stopAnimation();
		}
	}


}
