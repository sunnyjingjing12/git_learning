package com.itingbaby.app.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.model.AudioPlayData;
import com.itingbaby.app.model.AudioType;
import com.itingbaby.app.model.MusicCategory;
import com.itingbaby.app.model.MusicGroup;
import com.itingbaby.baselib.commonutils.ApplicationUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.widget.WaveLineView;
import com.itingbaby.dev.events.EventAudioRecordComplete;
import com.itingbaby.dev.events.EventAudioRecordDuration;
import com.itingbaby.dev.iTingBabyBleDeviceManager;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * 录音和播放音频view
 * 包含两个动画view
 * 录制时：
 * 时长，胎心率view
 * 播放时：
 * 音频名称view，列表icon
 */
public class RecordingAndPlayVoiceView extends LinearLayout {

	public static final int TYPE_RECORDING_VOICE = 0;  // 录制
	public static final int TYPE_PLAYING_VOICE = 1;   // 播放

	@BindView(R.id.wave_line_view)
	WaveLineView waveLineView;
	@BindView(R.id.txt_count_time)
	TextView txtCountTime;
	@BindView(R.id.txt_heart_ratio)
	TextView txtHeartRatio;
	@BindView(R.id.txt_heart_ratio_tips)
	TextView txtHeartRatioTips;
	@BindView(R.id.recording_voice_layout)
	LinearLayout recordingVoiceLayout;
	@BindView(R.id.txt_playing_voice_name)
	TextView txtPlayingVoiceName;

	@BindView(R.id.txt_voice_duration)
	TextView txtVoiceDuration;
	@BindView(R.id.txt_voice_gestational_weeks)
	TextView txtVoiceGestationalWeeks;
	@BindView(R.id.playing_voice_layout)
	ConstraintLayout playingVoiceLayout;
	@BindView(R.id.wave_view)
	WaveView waveView;
	@BindView(R.id.txt_time_and_length)
	TextView txtTimeAndLength;
	@BindView(R.id.time_show_layout)
	LinearLayout timeShowLayout;
	@BindView(R.id.heart_layout)
	LinearLayout heartLayout;


	private int mRecordType; // 录制音频类型,胎心音，妈妈心音，肺音

	private int mSrcType = TYPE_RECORDING_VOICE; // 是录制还是播放

	public RecordingAndPlayVoiceView(Context context) {
		this(context, null);
	}

	public RecordingAndPlayVoiceView(Context context, @Nullable AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public RecordingAndPlayVoiceView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initView();
	}

	private void initView() {
		inflate(getContext(), R.layout.view_recording_voice, this);
		ButterKnife.bind(this);
		setOrientation(VERTICAL);

		waveLineView.setSensibility(10);
	}

	/**
	 * 在哪里使用，录音页面 和 播放页面
	 *
	 * @param srcType
	 */
	public void initSrcType(int srcType, int duration) {
		mSrcType = srcType;
		recordingVoiceLayout.setVisibility(srcType == TYPE_RECORDING_VOICE ? VISIBLE : GONE);
		playingVoiceLayout.setVisibility(srcType == TYPE_RECORDING_VOICE ? GONE : VISIBLE);

		if (srcType == TYPE_RECORDING_VOICE) {
			renderRecordTimeCount(duration);
		} else {
			renderPlayTimeCount(0, duration);
		}
	}


	//region 录音操作
	/* -----------------------------------------------  录音操作  --------------------------------*/

	/**
	 * 更新心率函数
	 *
	 * @param heartRatio
	 */
	public void updateHeartRatio(int heartRatio) {
		txtHeartRatio.setText(heartRatio == 0 ? "- -" : String.valueOf(heartRatio));
	}

	/**
	 * 刷新波形控件和冲击波控件的数据
	 *
	 * @param data
	 */
	public void updateAudioData(short[] data) {
		updateWaveViewData(data);
		updateWaveLineViewData(data);
	}


	/**
	 * 更新上面动画WaveLineView的数值
	 *
	 * @param data
	 */
	private void updateWaveLineViewData(short[] data) {
		for (int i = 0; i < data.length; i += 100) {
			int volume = data[i] * 100 / 1000;
			//Ln.d("volume = %d", volume);
			waveLineView.setVolume(volume);
		}
	}

	/**
	 * 更新下面动画WaveView的数值
	 *
	 * @param data
	 */
	private void updateWaveViewData(short[] data) {
		for (int i = 0; i < data.length; i += 60) {
			waveView.addData(data[i]);
		}
	}

	/**
	 * 更新录制音频类型
	 */
	public void updateRecordType(int recordType) {
		mRecordType = recordType;

		heartLayout.setVisibility(mRecordType == AudioType.AUDIO_TYPE_MOM ? VISIBLE : GONE);
	}


	/**
	 * 更新录制时长
	 */
	private void renderRecordTimeCount(int duration) {
		int maxDuration = iTingBabyBleDeviceManager.getInstance().getRecordTimeout();

		txtCountTime.setText(StringUtils.formatTime2(duration));

		txtTimeAndLength.setText(getContext().getString(R.string.recording_duration,
				StringUtils.formatTime2(duration), StringUtils.formatTime2(maxDuration)));
	}

	/* -------------------------------------------------  录音操作  --------------------------------*/
	//endregion

	//region 播放操作
	/* -------------------------------------------------  播放操作开始  --------------------------------*/


	/**
	 * 设置数据源
	 * @param model
	 * @param category
	 */
	public void setAudioRecordModel(AudioPlayData model, MusicCategory category) {
		renderVoiceInfoView(model, category);
	}


	/**
	 * 更新播放时长
	 */
	public void renderPlayTimeCount(int position, int duration) {
		txtTimeAndLength.setText(getContext().getString(R.string.recording_duration, StringUtils.formatTime2(position), StringUtils.formatTime2(duration)));
	}

	/**
	 * 更新音频文件信息
	 */
	private void renderVoiceInfoView(AudioPlayData model, MusicCategory category) {
		if (null != model) {
			txtPlayingVoiceName.setText(model.getTitle());
			txtVoiceDuration.setText(String.format("%ds", model.getDuration()));

			txtVoiceGestationalWeeks.setVisibility(((category == null || category.gid == MusicGroup.MUSIC_GROUP_ID_MY_VOICE)
					&& (model.getType() == AudioType.AUDIO_TYPE_MOM || model.getType() == AudioType.AUDIO_TYPE_BABY)) ? VISIBLE : GONE);

			txtVoiceGestationalWeeks.setText(StringUtils.gestationalWeeks(model.getTimestamp(), BabyVoiceApp.mUserInfo.expected_date));

			renderPlayTimeCount(0, model.getDuration());
		}
	}




	/* -------------------------------------------------  播放操作  --------------------------------*/
	//endregion


	// region EventBus事件

	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onRecordDurationEvent(EventAudioRecordDuration event) {
		if (event == null) {
			event = new EventAudioRecordDuration(0);
		}
		Ln.d("event is %s", event);
		renderRecordTimeCount(event.currDuration);
	}

	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onRecordCompleteEvent(EventAudioRecordComplete event) {
		renderRecordTimeCount(0);
	}

	// endregion EventBus事件


	@Override
	protected void onAttachedToWindow() {
		super.onAttachedToWindow();

		if (!EventBus.getDefault().isRegistered(this)) {
			EventBus.getDefault().register(this);
		}
	}

	@Override
	public void setVisibility(int visibility) {
		super.setVisibility(visibility);
		ApplicationUtils.mMainHandler.postDelayed(() -> {
			if (visibility == VISIBLE) {
				startWaveLineAnim();
			} else {
				stopWaveLineAnim();
			}
		}, 200);

	}


	/**
	 * 停止上面的音波动画
	 */
	public void stopWaveLineAnim() {
		waveLineView.stopAnim();
	}

	/**
	 * 初始化上面音波动画
	 */
	public void startWaveLineAnim() {
		waveLineView.stopAnim();
		waveLineView.startAnim();
	}

	@Override
	protected void onDetachedFromWindow() {
		super.onDetachedFromWindow();
		waveLineView.release(); // 释放资源

		if (EventBus.getDefault().isRegistered(this)) {
			EventBus.getDefault().unregister(this);
		}
	}

}
