package com.itingbaby.app.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.widget.RelativeLayout;

import androidx.annotation.Nullable;

import com.itingbaby.app.R;
import com.itingbaby.app.model.AudioType;
import com.itingbaby.baselib.views.widget.RadiusImageView;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SearchingAudioView extends RelativeLayout {

	@BindView(R.id.view_searching_img)
	RadiusImageView viewSearchingImg;


	private int audioType;

	private boolean showBackground = true;

	public boolean isShowBackground() {
		return showBackground;
	}

	public SearchingAudioView(Context context) {
		this(context, null);
	}

	public SearchingAudioView(Context context, @Nullable AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public SearchingAudioView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initView();
	}

	private void initView() {
		inflate(getContext(), R.layout.layout_search_audio, this);
		ButterKnife.bind(this);

		setOnClickListener(mOnClickListener);
		viewSearchingImg.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				// do nothing, just not close the view
			}
		});

	}


	private OnClickListener mOnClickListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			hide();
		}
	};

	public void setAudioType(int audioType) {
		this.audioType = audioType;
		if (this.audioType == AudioType.AUDIO_TYPE_MOM) {
			viewSearchingImg.setBackground(getResources().getDrawable(R.drawable.bg_searching_audio_mom));
		}else {
			viewSearchingImg.setBackground(getResources().getDrawable(R.drawable.bg_searching_audio_baby));
		}
	}

	public void hide() {
		setBackgroundResource(0);
//        hideLocation = ((FollowUserDoingActivity) mContext).getHideLocation();
		AnimationSet animationSet = new AnimationSet(true);
//        ScaleAnimation scaleAnimation = new ScaleAnimation(0.5f, 0.0f, 0.5f, 0.0f);
		AlphaAnimation alphaAnimation = new AlphaAnimation(1.0f, 0.0f);
//        TranslateAnimation translateAnimation = new TranslateAnimation(TranslateAnimation.RELATIVE_TO_SELF, 0.25f, TranslateAnimation.ABSOLUTE, hideLocation[0],
//                TranslateAnimation.RELATIVE_TO_SELF, 0.25f, TranslateAnimation.ABSOLUTE, hideLocation[1]);
		animationSet.setDuration(300);
		animationSet.addAnimation(alphaAnimation);
//        animationSet.addAnimation(scaleAnimation);
//        animationSet.addAnimation(translateAnimation);
		animationSet.setAnimationListener(new Animation.AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {
				setOnClickListener(null);
				setEnabled(false);
				setClickable(false);
				showBackground = false;
			}

			@Override
			public void onAnimationEnd(Animation animation) {
				setOnClickListener(mOnClickListener);
				setEnabled(true);
				setClickable(true);
				setVisibility(GONE);
				showBackground = true;
			}

			@Override
			public void onAnimationRepeat(Animation animation) {

			}
		});
		startAnimation(animationSet);
	}


	public void show() {
		if (showBackground) {
			setBackgroundResource(R.color.color_80_000000);
		}
		setVisibility(VISIBLE);
	}
}
