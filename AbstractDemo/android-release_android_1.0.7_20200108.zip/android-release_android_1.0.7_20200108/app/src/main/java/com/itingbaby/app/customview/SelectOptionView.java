package com.itingbaby.app.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.DrawableRes;
import androidx.annotation.Nullable;

import com.itingbaby.app.R;
import com.itingbaby.baselib.commonutils.DimensionUtil;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SelectOptionView extends LinearLayout implements View.OnClickListener {

	@BindView(R.id.txt_option_first)
	TextView txtOptionFirst;
	@BindView(R.id.txt_option_second)
	TextView txtOptionSecond;
	@BindView(R.id.txt_option_third)
	TextView txtOptionThird;

	private int mSelectType = 0;
	private Animation exitAnimation;  // 退出动画
	private boolean exitAnimationStarted = false;

	private SelectTypeViewListener mListener;

	public SelectOptionView(Context context) {
		this(context, null);
	}

	public SelectOptionView(Context context, @Nullable AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public SelectOptionView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initView();
	}

	private void initView() {
		inflate(getContext(), R.layout.view_home_select_record_type, this);
		ButterKnife.bind(this);
		setOrientation(VERTICAL);
		setBackgroundResource(R.drawable.select_record_type_shape);
		setMinimumWidth(DimensionUtil.dipToPx(72));
		setPadding(0, DimensionUtil.dipToPx(20), 0, DimensionUtil.dipToPx(24));

		txtOptionFirst.setOnClickListener(this);
		txtOptionSecond.setOnClickListener(this);
		txtOptionThird.setOnClickListener(this);

	}

	public void initData(String[] lables, @DrawableRes int[] drawableIds) {
		txtOptionFirst.setVisibility(GONE);
		txtOptionSecond.setVisibility(GONE);
		txtOptionThird.setVisibility(GONE);
		if (lables.length > 0) {
			txtOptionFirst.setVisibility(VISIBLE);
			txtOptionFirst.setText(lables[0]);
			txtOptionFirst.setCompoundDrawablesWithIntrinsicBounds(null, getResources().getDrawable(drawableIds[0]), null, null);
		}
		if (lables.length > 1) {
			txtOptionSecond.setVisibility(VISIBLE);
			txtOptionSecond.setText(lables[1]);
			txtOptionSecond.setCompoundDrawablesWithIntrinsicBounds(null, getResources().getDrawable(drawableIds[1]), null, null);
		}
		if (lables.length > 2) {
			txtOptionThird.setVisibility(VISIBLE);
			txtOptionThird.setText(lables[2]);
			txtOptionThird.setCompoundDrawablesWithIntrinsicBounds(null, getResources().getDrawable(drawableIds[2]), null, null);
		}
	}

	public void setListener(SelectTypeViewListener listener) {
		this.mListener = listener;
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
			case R.id.txt_option_second:
				mSelectType = 1;
				break;
			case R.id.txt_option_third:
				mSelectType = 2;
				break;
			default:
				mSelectType = 0;
				break;
		}
		if (mListener != null) {
			mListener.onOptionClicked(mSelectType);
		}
		exitWithAnim();

	}

	public void enterWithAnim() {
		Animation animation = AnimationUtils.loadAnimation(getContext(), R.anim.record_view_left_in);
		startAnimation(animation);
	}

	public void exitWithAnim() {
		if (exitAnimationStarted) {
			return;
		}
		if (exitAnimation == null) {
			exitAnimation = AnimationUtils.loadAnimation(getContext(), R.anim.push_left_out);
			exitAnimation.setAnimationListener(new Animation.AnimationListener() {
				@Override
				public void onAnimationStart(Animation animation) {
					exitAnimationStarted = true;
				}

				@Override
				public void onAnimationEnd(Animation animation) {
					exitAnimationStarted = false;
					setVisibility(GONE);
				}

				@Override
				public void onAnimationRepeat(Animation animation) {

				}
			});
		}
		startAnimation(exitAnimation);
	}

	public interface SelectTypeViewListener {
		void onOptionClicked(int pos);
	}
}
