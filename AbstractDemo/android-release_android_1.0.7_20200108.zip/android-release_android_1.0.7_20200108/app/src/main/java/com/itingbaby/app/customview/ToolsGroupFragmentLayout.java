package com.itingbaby.app.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.itingbaby.app.R;
import com.itingbaby.app.model.ToolInfo;
import com.itingbaby.app.model.ToolsGroupData;
import com.itingbaby.app.viewbinder.ToolsInfoViewBinder;
import com.itingbaby.baselib.commonutils.DimensionUtil;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.drakeet.multitype.MultiTypeAdapter;

/**
 * HomeToolsFragment 的recyclerView的item view
 */
public class ToolsGroupFragmentLayout extends RelativeLayout {


	private static final int SPAN_COUNT = 4;
	@BindView(R.id.swipe_recycler_view)
	SwipeRecyclerView recyclerView;
	@BindView(R.id.txt_group_title)
	TextView txtGroupTitle;

	private Context mContext;

	private MultiTypeAdapter mAdapter;

	private List mItems = new ArrayList<>();

	public ToolsGroupFragmentLayout(Context context) {
		this(context, null);
	}

	public ToolsGroupFragmentLayout(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public ToolsGroupFragmentLayout(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initView(context);
	}

	private void initView(Context context) {
		mContext = context;
		inflate(context, R.layout.item_tools_group_fragment, this);
		ButterKnife.bind(this);
		LayoutParams params = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		params.setMargins(DimensionUtil.dipToPx(context, 18), DimensionUtil.dipToPx(context, 40), DimensionUtil.dipToPx(context, 18), 0);
		setLayoutParams(params);
		setBackgroundResource(R.drawable.bg_tool_group_shape);

		mAdapter = new MultiTypeAdapter(mItems);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
		final GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), SPAN_COUNT);

		recyclerView.setLayoutManager(gridLayoutManager);
		mAdapter.register(ToolInfo.class, new ToolsInfoViewBinder());

		recyclerView.setAdapter(mAdapter);

	}

	public void renderData(ToolsGroupData toolsGroupData) {
		txtGroupTitle.setText(toolsGroupData.name);
		mItems.clear();
		mItems.addAll(toolsGroupData.toolsInfoList);
		mAdapter.notifyDataSetChanged();
	}
}
