package com.itingbaby.app.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.itingbaby.app.R;
import com.itingbaby.app.model.ToolInfo;
import com.itingbaby.app.model.ToolsGroupData;
import com.itingbaby.app.viewbinder.ToolsInfoViewBinder;
import com.itingbaby.baselib.commonutils.DimensionUtil;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.drakeet.multitype.MultiTypeAdapter;

public class ToolsGroupLayout extends RelativeLayout {


	private static final int SPAN_COUNT = 4;
	@BindView(R.id.swipe_recycler_view)
	SwipeRecyclerView recyclerView;

	private Context mContext;

	private MultiTypeAdapter mAdapter;

	private List mItems = new ArrayList<>();

	public ToolsGroupLayout(Context context) {
		this(context, null);
	}

	public ToolsGroupLayout(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public ToolsGroupLayout(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initView(context);
	}

	private void initView(Context context) {
		mContext = context;
		inflate(context, R.layout.item_home_tools_group, this);
		ButterKnife.bind(this);
		RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		params.setMargins(DimensionUtil.dipToPx(context, 18), DimensionUtil.dipToPx(context, 10), DimensionUtil.dipToPx(context, 18), 0);
		setLayoutParams(params);
		setBackgroundResource(R.drawable.bg_solid_ffffff_corner_10dp);
		setPadding(0, DimensionUtil.dipToPx(context, 18), 0, DimensionUtil.dipToPx(context, 12));

		mAdapter = new MultiTypeAdapter(mItems);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
		final GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), SPAN_COUNT);

		recyclerView.setLayoutManager(gridLayoutManager);
		mAdapter.register(ToolInfo.class, new ToolsInfoViewBinder());

		recyclerView.setAdapter(mAdapter);

	}

	public void renderData(ToolsGroupData toolsGroupData) {
		mItems.clear();
		mItems.addAll(toolsGroupData.toolsInfoList);
		mAdapter.notifyDataSetChanged();
	}
}
