package com.itingbaby.app.customview;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.itingbaby.app.R;
import com.itingbaby.baselib.commonutils.ApplicationUtils;
import com.itingbaby.baselib.commonutils.Ln;

import butterknife.BindView;
import butterknife.ButterKnife;


public class TrainingOperationView extends FrameLayout {


	@BindView(R.id.txt_training)
	TextView txtTraining;
	@BindView(R.id.img_training)
	ImageView imgTraining;
	@BindView(R.id.training_layout)
	RelativeLayout trainingLayout;

	private Runnable enterAnimRunnable;

	private ObjectAnimator exitAnim;
	private ObjectAnimator enterAnim;
	private boolean enterAnimStarted = true;

	public TrainingOperationView(@NonNull Context context) {
		this(context, null);
	}

	public TrainingOperationView(@NonNull Context context, @Nullable AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public TrainingOperationView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initView();
	}

	private void initView() {
		inflate(getContext(), R.layout.view_training_operation_layout, this);
		ButterKnife.bind(this);

		enterAnimRunnable = this::startEnterAnimation;
	}

	/**
	 * 当RecyclerView滑动时，调用
	 *
	 * @param newState
	 */
	public void onRecyclerViewScrolled(int newState) {
		ApplicationUtils.mMainHandler.removeCallbacks(enterAnimRunnable);

		if (newState == RecyclerView.SCROLL_STATE_IDLE) {
			ApplicationUtils.mMainHandler.postDelayed(enterAnimRunnable, 600);
		} else {
			startExitAnimation();
		}
	}

	/**
	 * 进入动画
	 */
	private void startEnterAnimation() {
		Ln.d("lihb  start enterAnim");
		if (enterAnim == null) {
			enterAnim = ObjectAnimator.ofFloat(this, "x", -this.getWidth(), 0);
			enterAnim.setDuration(400);
		}
		enterAnim.start();
		enterAnimStarted = true;
	}


	/**
	 * 退出动画
	 */
	private void startExitAnimation() {
		if (enterAnimStarted == true) {
			Ln.d("lihb start exitAnim");
			if (exitAnim == null) {
				exitAnim = ObjectAnimator.ofFloat(this, "x", 0, -this.getWidth());
				exitAnim.setDuration(400);
			}
			exitAnim.start();
			enterAnimStarted = false;
		}
	}

}
