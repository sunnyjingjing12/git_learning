package com.itingbaby.app.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.app.model.AudioRecordModelDao;
import com.itingbaby.app.model.DaoSession;
import com.itingbaby.app.model.DeviceInfo;
import com.itingbaby.app.model.HomeCardDevice;
import com.itingbaby.app.model.pelvictrain.PelvicTrainRecord;
import com.itingbaby.app.viewbinder.AudioRecordModelViewBinder;
import com.itingbaby.app.viewbinder.PelvicModelViewBinder;
import com.itingbaby.baselib.commonutils.DimensionUtil;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.views.widget.ItbEmptyViewLayout;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;
import com.itingbaby.dev.DeviceType;

import org.greenrobot.greendao.query.Query;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import me.drakeet.multitype.MultiTypeAdapter;

public class UserDeviceCardLayout extends RelativeLayout {

	@BindView(R.id.swipe_recycler_view)
	SwipeRecyclerView recyclerView;

	@BindView(R.id.txt_device_title)
	TextView txtDeviceTitle;
	@BindView(R.id.view_empty_layout)
	ItbEmptyViewLayout viewEmptyLayout;

	private Context mContext;

	private MultiTypeAdapter mAdapter;

	private List mItems = new ArrayList<>();

	public UserDeviceCardLayout(Context context) {
		this(context, null);
	}

	public UserDeviceCardLayout(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public UserDeviceCardLayout(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initView(context);
	}

	private void initView(Context context) {
		mContext = context;
		inflate(context, R.layout.item_home_user_device, this);
		ButterKnife.bind(this);
		LayoutParams params = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		params.setMargins(DimensionUtil.dipToPx(context, 18), DimensionUtil.dipToPx(context, 10), DimensionUtil.dipToPx(context, 18), 0);
		setLayoutParams(params);
		setBackgroundResource(R.drawable.bg_solid_ffffff_corner_10dp);

		// 设置无数据页面
		viewEmptyLayout.setEmptyViewMarginTopPercentHeight(0.3f);
		viewEmptyLayout.setEmptyMessage(context.getString(R.string.load_empty_msg));
		viewEmptyLayout.setEmptyImageRes(R.drawable.ic_no_data_small);

		mAdapter = new MultiTypeAdapter(mItems);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);

		recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
		mAdapter.register(AudioRecordModel.class, new AudioRecordModelViewBinder(AudioRecordModelViewBinder.SRC_TYPE_HOME_TBAI));
		mAdapter.register(PelvicTrainRecord.class, new PelvicModelViewBinder());

		recyclerView.setAdapter(mAdapter);

	}

	public void renderData(HomeCardDevice homeCardDevice) {
		if (homeCardDevice == null) {
			return;
		}

		DeviceInfo deviceInfo = homeCardDevice.deviceInfo;
		txtDeviceTitle.setText(deviceInfo.name);
		mItems.clear();
		if (deviceInfo.deviceType == DeviceType.DEVICE_TYPE_TBB) {  // 听贝贝心音仪
			getVoiceData(0, 3);
		} else if (deviceInfo.deviceType == DeviceType.DEVICE_TYPE_KEGEL) { // 凯格尔训练仪
			List<PelvicTrainRecord> pelvicTrainRecordList = homeCardDevice.recordsList;
			if (pelvicTrainRecordList == null || pelvicTrainRecordList.isEmpty()) {
				viewEmptyLayout.showEmpty();
				recyclerView.setVisibility(GONE);
			} else {
				recyclerView.setVisibility(VISIBLE);
				viewEmptyLayout.hideAllView();
				mItems.clear();
				mItems.addAll(pelvicTrainRecordList);
				mAdapter.notifyDataSetChanged();
			}
		} else {
			viewEmptyLayout.showEmpty();
			recyclerView.setVisibility(GONE);
		}

	}

	/**
	 * 拦截事件，所有事件到这里就不再往下传递了
	 *
	 * @param ev
	 * @return
	 */
	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev) {
		return true;
	}

	/**
	 * 获取录制数据
	 *
	 * @param offset
	 * @param limit
	 */
	public void getVoiceData(int offset, final int limit) {

		Observable observable = Observable.create((emitter) -> {
			Long uid = BabyVoiceApp.mUserInfo.id;
			DaoSession daoSession = BabyVoiceApp.getInstance().getDaoSession();
			AudioRecordModelDao audioRecordModelDao = daoSession.getAudioRecordModelDao();
			Query<AudioRecordModel> dataset = audioRecordModelDao.queryBuilder()
					.where(AudioRecordModelDao.Properties.Uid.eq(uid))
					.orderDesc(AudioRecordModelDao.Properties.Timestamp)
					.limit(limit)
					.offset(offset).build();
			emitter.onNext(dataset.list());
			emitter.onComplete();
		});

		observable.observeOn(AndroidSchedulers.mainThread())
				.doOnTerminate(() -> Ln.d("lihb getVoiceData doOnTerminate"))
				.subscribeOn(Schedulers.io())
				.subscribe((o) -> {
					List<AudioRecordModel> dataList = (List<AudioRecordModel>) o;
					if (dataList.isEmpty()) {
						viewEmptyLayout.showEmpty();
						recyclerView.setVisibility(GONE);
					} else {
						recyclerView.setVisibility(VISIBLE);
						viewEmptyLayout.hideAllView();
						mItems.clear();
						mItems.addAll(dataList);
						mAdapter.notifyDataSetChanged();
					}
				}, throwable -> Ln.e(throwable.toString()));
	}
}
