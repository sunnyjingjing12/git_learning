package com.itingbaby.app.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.itingbaby.app.R;
import com.itingbaby.app.activity.EditVaccineInfoActivity;
import com.itingbaby.app.model.Vaccine;
import com.itingbaby.app.model.VaccineGroupDataModel;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.GsonHelper;
import com.itingbaby.app.utils.db.VaccineManager;
import com.itingbaby.app.viewbinder.VaccineItemViewBinder;
import com.itingbaby.baselib.commonutils.DimensionUtil;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.drakeet.multitype.MultiTypeAdapter;

/**
 * HomeToolsFragment 的recyclerView的item view
 */
public class VaccineGroupDataLayout extends RelativeLayout {

	@BindView(R.id.txt_time)
	TextView txtTime;
	@BindView(R.id.txt_age)
	TextView txtAge;
	@BindView(R.id.swipe_recycler_view)
	SwipeRecyclerView recyclerView;
	@BindView(R.id.txt_vc_nurse)
	TextView txtVcNurse;

	@BindView(R.id.img_vc_inspect_nurse)
	ImageView imgVcInspectNurse;

	@BindView(R.id.img_vc_inspect_time)
	ImageView imgVcInspectTime;

	@BindView(R.id.txt_vc_inspect_time)
	TextView txtVcInspectTime;

	@BindView(R.id.inspect_time_and_nurse_layout)
	LinearLayout inspectTimeAndNurseLayout;


	private Context mContext;

	private MultiTypeAdapter mAdapter;

	private List mItems = new ArrayList<>();

	private VaccineGroupDataModel mVaccineGroupDataModel;
	private VaccineItemViewBinder vaccineItemViewBinder;

	public VaccineGroupDataLayout(Context context) {
		this(context, null);
	}

	public VaccineGroupDataLayout(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public VaccineGroupDataLayout(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initView(context);
	}

	private void initView(Context context) {
		mContext = context;
		inflate(context, R.layout.item_vaccine_layout, this);
		ButterKnife.bind(this);
		LayoutParams params = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		params.setMargins(DimensionUtil.dipToPx(context, 16), DimensionUtil.dipToPx(context, 2), DimensionUtil.dipToPx(context, 16), DimensionUtil.dipToPx(context, 8));
		setLayoutParams(params);
		setBackgroundResource(R.drawable.bg_solid_ffffff_corner_12dp);

		mAdapter = new MultiTypeAdapter(mItems);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);

		recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
		vaccineItemViewBinder = new VaccineItemViewBinder();
		mAdapter.register(Vaccine.class, vaccineItemViewBinder);

		recyclerView.setAdapter(mAdapter);

		inspectTimeAndNurseLayout.setOnClickListener(v -> {
			((BaseFragmentActivity) mContext).startActivityForResult(EditVaccineInfoActivity.intentFor(getContext(), GsonHelper.objectToJson(mVaccineGroupDataModel)), EditVaccineInfoActivity.REQUEST_EDIT_VACCINE_INFO);
		});

		vaccineItemViewBinder.setListener((pos, vaccine) -> {
			mAdapter.notifyItemChanged(pos);
			vaccine.status = (vaccine.status == 1) ? 2 : 1;
			if (vaccine.status == 2) {
				CommonToast.showShortToast("完成一个疫苗，棒棒哒！");
			}
			VaccineManager.getInstance().update(vaccine);
		});

	}

	public void renderData(VaccineGroupDataModel model) {
		mVaccineGroupDataModel = model;
		txtTime.setText(model.compInjectDate);
		txtAge.setText(model.injectAge);

		txtTime.setTextColor(model.isNextInject ? getResources().getColor(R.color.color_00bed7) : getResources().getColor(R.color.color_b3b3b3));
		txtAge.setTextColor(model.isNextInject ? getResources().getColor(R.color.color_00bed7) : getResources().getColor(R.color.color_b3b3b3));

		txtVcNurse.setText(model.injectNurse);
		txtVcInspectTime.setText(model.realInjectDate);
		imgVcInspectNurse.setVisibility(StringUtils.isEmpty(model.injectNurse) ? VISIBLE : GONE);
		imgVcInspectTime.setVisibility(StringUtils.isEmpty(model.realInjectDate) ? VISIBLE : GONE);

		mItems.clear();
		mItems.addAll(model.vaccineList);
		mAdapter.notifyDataSetChanged();
	}
}
