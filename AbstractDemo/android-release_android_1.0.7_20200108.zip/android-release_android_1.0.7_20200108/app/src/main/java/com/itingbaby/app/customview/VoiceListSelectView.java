package com.itingbaby.app.customview;

import android.Manifest;
import android.content.Context;
import android.util.ArrayMap;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.SparseBooleanArray;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.itingbaby.app.MixVoiceDataManager;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.components.IMusicListComponent;
import com.itingbaby.app.components.presenter.MusicListPresenter;
import com.itingbaby.app.model.AudioPlayData;
import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.app.model.AudioType;
import com.itingbaby.app.model.MusicCategory;
import com.itingbaby.app.model.MusicClause;
import com.itingbaby.app.model.MusicSelectStatus;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.DownloadUtil;
import com.itingbaby.app.viewbinder.AudioRecordModelViewBinder;
import com.itingbaby.app.viewbinder.MusicViewBinder;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.PermissionCheckUtil;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.widget.ItbEmptyViewLayout;
import com.itingbaby.baselib.views.widget.swipeviews.RefreshLoadRecyclerLayout;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;
import com.lzy.okgo.model.Progress;
import com.lzy.okserver.download.DownloadListener;
import com.tbruyelle.rxpermissions2.RxPermissions;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.drakeet.multitype.MultiTypeAdapter;

public class VoiceListSelectView extends LinearLayout implements IMusicListComponent.IView {


	private static final int COUNT = 10;
	@BindView(R.id.swipe_refresh_layout)
	RefreshLoadRecyclerLayout swipeRefreshLayout;
	@BindView(R.id.view_empty_layout)
	ItbEmptyViewLayout viewEmptyLayout;
	private MultiTypeAdapter mAdapter;

	private SwipeRecyclerView recyclerView;

	private List mItems = new ArrayList<>();

	private boolean mIsLastPage;
	private boolean mIsLoadingMore = false;
	private boolean mIsRefreshing = false;

	private MusicListPresenter musicListPresenter;

	private OnVoiceListSelectViewListener mListener;
	private AudioRecordModelViewBinder audioRecordModelViewBinder;
	private MusicViewBinder musicViewBinder;

	// 缓存数据
	private SparseArray<List> mItemsCacheArray = new SparseArray<List>();

	// 缓存能否下拉刷新标记
	private SparseBooleanArray mCanLoadMoreCacheArray = new SparseBooleanArray();

	// 缓存下载的listener
	private ArrayMap<String, MusicDownloadListener> downloadListenerArrayMap = new ArrayMap<>();

	// 当前类别id
	private int mCategoryId;

	private RxPermissions rxPermissions;
	private Context mContext;

	public void setVoiceListSelectViewListener(OnVoiceListSelectViewListener l) {
		this.mListener = l;
	}

	public VoiceListSelectView(Context context) {
		this(context, null);
	}

	public VoiceListSelectView(Context context, @Nullable AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public VoiceListSelectView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initView(context);

	}

	private void initView(Context context) {
		mContext = context;
		inflate(getContext(), R.layout.view_voice_list_select, this);
		ButterKnife.bind(this);
		setOrientation(VERTICAL);

		initRecyclerView();

		initListener();
		musicListPresenter = new MusicListPresenter(this);
		if (context instanceof BaseFragmentActivity) {
			rxPermissions = new RxPermissions((BaseFragmentActivity) context);
		}
	}

	private void initRecyclerView() {
		mAdapter = new MultiTypeAdapter(mItems);

		swipeRefreshLayout.setCanRefresh(false);
		swipeRefreshLayout.setCanLoadMore(true);
		swipeRefreshLayout.setToggleLoadCount(4);
		swipeRefreshLayout.setAdapter(mAdapter);

		recyclerView = swipeRefreshLayout.getSwipeRecyclerView();
		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
		recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

		audioRecordModelViewBinder = new AudioRecordModelViewBinder(AudioRecordModelViewBinder.SRC_TYPE_MUSIC_SELECT);
		mAdapter.register(AudioRecordModel.class, audioRecordModelViewBinder);
		musicViewBinder = new MusicViewBinder(MusicViewBinder.SRC_TYPE_SELECT_MUSIC);
		mAdapter.register(MusicClause.class, musicViewBinder);

	}

	private void initListener() {
		if (musicViewBinder != null) {
			musicViewBinder.setListener(new MusicViewBinder.OnMusicViewBinderListener() {
				@Override
				public void onItemClick(int position) {
					AudioPlayData audioPlayData = (AudioPlayData) mItems.get(position);
					handleItemClickEvent(audioPlayData);
					mAdapter.notifyItemChanged(position);
				}

				@Override
				public void onMusicPlayImgClick(int position) {

				}

				@Override
				public void onMusicPlaySvgaClick(int position) {

				}
			});
		}
		if (audioRecordModelViewBinder != null) {
			audioRecordModelViewBinder.setOnAudioRecordModelViewBinderListener(new AudioRecordModelViewBinder.OnAudioRecordModelViewBinderListener() {
				@Override
				public void onItemClick(int position) {
					AudioPlayData audioPlayData = (AudioPlayData) mItems.get(position);
					handleItemClickEvent(audioPlayData);
					mAdapter.notifyItemChanged(position);
				}

				@Override
				public void onItemMoreOperClick(int position) {

				}

				@Override
				public void onPlayImgClick(int position) {

				}

				@Override
				public void onPlaySvgaClick(int position) {

				}
			});
		}
		swipeRefreshLayout.setOnRefreshLoadListener(new RefreshLoadRecyclerLayout.OnRefreshLoadListener() {
			@Override
			public boolean isLoading() {
				return mIsLoadingMore | mIsRefreshing;
			}

			@Override
			public boolean isLastPage() {
				return mIsLastPage;
			}

			@Override
			public void onLoadMore() {
				if (mIsLoadingMore || mIsRefreshing) {
					return;
				}
				viewEmptyLayout.hideAllView();

				mIsLoadingMore = true;

				List dataList = mItemsCacheArray.get(mCategoryId);
				int page = 1;
				if (!ListUtils.isEmpty(dataList)) {
					int currSize = dataList.size();
					page = currSize / COUNT + 1;
				}
				if (MusicCategory.MUSIC_CATEGORY_USER == mCategoryId) {
					long recordType = AudioType.AUDIO_TYPE_BABY | AudioType.AUDIO_TYPE_MOM | AudioType.AUDIO_TYPE_LUNG;
					musicListPresenter.getUserAudioRecordData(recordType, page, COUNT);
				} else {
					musicListPresenter.getMusicClauseListData(mCategoryId, page, COUNT);
				}
			}

			@Override
			public void onRefresh(boolean auto) {

			}

			@Override
			public void showResult() {
			}
		});
	}

	/**
	 * 处理点击事件
	 *
	 * @param playData
	 */
	private void handleItemClickEvent(AudioPlayData playData) {
		String tag = ServiceGenerator.URL_IMG_SERVER + playData.getUrl();
		HashSet<AudioPlayData> pickedRecordSet = MixVoiceDataManager.getInstance().getRecordModelSet();
		HashSet<AudioPlayData> pickedMusicSet = MixVoiceDataManager.getInstance().getMusicSet();
		switch (playData.musicSelectStatus) {
			case MusicSelectStatus.MUSIC_STATUS_NOT_DOWNLOAD:
			case MusicSelectStatus.MUSIC_STATUS_DOWNLOAD_PAUSE:
			case MusicSelectStatus.MUSIC_STATUS_DOWNLOAD_FAILED:
				// 检查获取权限
				rxPermissions.request(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE).subscribe(granted -> {
					if (granted) {
						MusicDownloadListener listener = downloadListenerArrayMap.get(tag);
						if (listener == null) {
							listener = new MusicDownloadListener(tag, playData);
							downloadListenerArrayMap.put(tag, listener);
						}
						DownloadUtil.getInstance().downloadFile(tag, listener);
					} else {
						if (mContext instanceof BaseFragmentActivity) {
							PermissionCheckUtil.showGrantFailDialog((BaseFragmentActivity) mContext);
						}
					}
				});

				break;
			case MusicSelectStatus.MUSIC_STATUS_DOWNLOADING:
				DownloadUtil.getInstance().pauseDownload(tag);
				playData.musicSelectStatus = MusicSelectStatus.MUSIC_STATUS_DOWNLOAD_PAUSE;
				break;
			case MusicSelectStatus.MUSIC_STATUS_UN_SELECTED:
				playData.musicSelectStatus = MusicSelectStatus.MUSIC_STATUS_SELECTED;
				if (mCategoryId == MusicCategory.MUSIC_CATEGORY_USER) {
					MixVoiceDataManager.getInstance().addData(playData, pickedRecordSet);
				} else {
					MixVoiceDataManager.getInstance().addData(playData, pickedMusicSet);
				}
				break;
			case MusicSelectStatus.MUSIC_STATUS_SELECTED:
				playData.musicSelectStatus = MusicSelectStatus.MUSIC_STATUS_UN_SELECTED;
				if (mCategoryId == MusicCategory.MUSIC_CATEGORY_USER) {
					MixVoiceDataManager.getInstance().removeData(playData, pickedRecordSet);
				} else {
					MixVoiceDataManager.getInstance().removeData(playData, pickedMusicSet);
				}
				break;

		}
	}

	/**
	 * 切换类别
	 *
	 * @param cid
	 */
	public void updateCategoryId(int cid) {
		mCategoryId = cid;
		// 切换了类别，需设置是否还能加载更多， 默认为true
		boolean canLoadMore = mCanLoadMoreCacheArray.get(mCategoryId, true);
		swipeRefreshLayout.setCanLoadMore(canLoadMore);

		List dataList = mItemsCacheArray.get(mCategoryId);
		if (!ListUtils.isEmpty(dataList)) {
			refreshDataList(dataList, true);
		} else {
			if (musicListPresenter != null) {
				int page = 1;
				if (cid == MusicCategory.MUSIC_CATEGORY_USER) {
					long recordType = AudioType.AUDIO_TYPE_BABY | AudioType.AUDIO_TYPE_MOM | AudioType.AUDIO_TYPE_LUNG;
					musicListPresenter.getUserAudioRecordData(recordType, page, COUNT);
				} else {
					musicListPresenter.getMusicClauseListData(cid, page, COUNT);
				}
			}
		}
	}


	// region mvp view 方法
	@Override
	public void stopRefresh() {
		Ln.d("lihb stopRefresh");
		mIsRefreshing = false;
		swipeRefreshLayout.stopRefresh();
	}

	@Override
	public void stopLoadMore() {
		Ln.d("lihb stopLoadMore");
		mIsLoadingMore = false;
		swipeRefreshLayout.stopLoadMore();
	}

	@Override
	public void handleFailed() {
		Ln.d("lihb handleFailed");
		if (mAdapter.getItemCount() > 0) {
			CommonToast.showShortToast(getContext().getString(R.string.list_empty_net_error));
			return;
		}

		if (ListUtils.isEmpty(mItems) && viewEmptyLayout != null) {
			viewEmptyLayout.showError();
		}
	}

	@Override
	public void handleEmpty() {
		Ln.d("lihb handleEmpty");
		if (mAdapter.getItemCount() > 0) {
			return;
		}

		if (viewEmptyLayout != null) {
			viewEmptyLayout.showEmpty();
		}
	}

	@Override
	public void setIsLastPage(boolean isLastPage) {
		Ln.d("lihb setIsLastPage %b", isLastPage);
		mIsLastPage = isLastPage;
		swipeRefreshLayout.setCanLoadMore(!isLastPage);
		swipeRefreshLayout.setIsLastPage(isLastPage);
		mCanLoadMoreCacheArray.put(mCategoryId, !isLastPage);
	}

	@Override
	public void updateDataList(List list) {
		Ln.d("lihb updateDataList, list size =%d, mIsLastPage=%b", list.size(), mIsLastPage);
		if (ListUtils.isEmpty(list)) {
			viewEmptyLayout.showEmpty();
			return;
		}
		viewEmptyLayout.hideAllView();
		refreshDataList(list, true);

		// 添加到缓存
		mItemsCacheArray.put(mCategoryId, list);
	}

	@Override
	public void addMoreDataList(List list) {
		Ln.d("lihb addMoreDataList, list size =%d, mIsLastPage=%b", list.size(), mIsLastPage);
		viewEmptyLayout.hideAllView();
		if (!ListUtils.isEmpty(list)) {
			refreshDataList(list, false);

			// 添加到缓存
			List dataList = mItemsCacheArray.get(mCategoryId);
			dataList.addAll(list);
			mItemsCacheArray.put(mCategoryId, dataList);
		}


		mAdapter.notifyDataSetChanged();
	}

	@Override
	public void showToast(String msg) {
		CommonToast.showShortToast(msg);
	}

	// endregion

	/**
	 * 更新数据，刷新列表
	 *
	 * @param list
	 */
	private void refreshDataList(List list, boolean isRefresh) {
		if (isRefresh) {
			mItems.clear();
		}
		setSelectStatus(list);
		mItems.addAll(list);
		mAdapter.notifyDataSetChanged();
	}

	/**
	 * 设置初始选择状态
	 *
	 * @param list
	 */
	private void setSelectStatus(List list) {
		for (int i = 0, size = list.size(); i < size; i++) {
			Object o = list.get(i);
			if (o instanceof AudioPlayData) {
				AudioPlayData audioPlayData = (AudioPlayData) o;

				HashSet<AudioPlayData> pickedRecordSet = MixVoiceDataManager.getInstance().getRecordModelSet();
				HashSet<AudioPlayData> pickedMusicSet = MixVoiceDataManager.getInstance().getMusicSet();

				if (mCategoryId == MusicCategory.MUSIC_CATEGORY_USER) {
					setFromDataSelectStatus(audioPlayData, pickedRecordSet);
				}else {
					setFromDataSelectStatus(audioPlayData, pickedMusicSet);
				}
				if (audioPlayData.musicSelectStatus == MusicSelectStatus.MUSIC_STATUS_UN_KNOWN) {
					boolean downloaded = DownloadUtil.getInstance().isDownloaded(ServiceGenerator.URL_IMG_SERVER + audioPlayData.getUrl());
					audioPlayData.musicSelectStatus = downloaded ? MusicSelectStatus.MUSIC_STATUS_UN_SELECTED : MusicSelectStatus.MUSIC_STATUS_NOT_DOWNLOAD;
				}
			}
		}

	}

	private void setFromDataSelectStatus(AudioPlayData audioPlayData, HashSet<AudioPlayData> dataSet) {
		for (AudioPlayData model : dataSet) {
			if (model.getId().equals(audioPlayData.getId())) {
				audioPlayData.musicSelectStatus = MusicSelectStatus.MUSIC_STATUS_SELECTED;
				break;
			}
		}
	}

	public interface OnVoiceListSelectViewListener {
		void onItemClick(int pos, MusicClause musicClause);
	}

	/**
	 * 下载回调listener
	 */
	private class MusicDownloadListener extends DownloadListener {

		private AudioPlayData audioPlayData;

		public MusicDownloadListener(Object tag, AudioPlayData playData) {
			super(tag);
			this.audioPlayData = playData;
		}

		@Override
		public void onStart(Progress progress) {
			Ln.d("[aaaaa music download] onStart, hashCode = %d, progress = %s ", hashCode(), progress);
			audioPlayData.musicSelectStatus = MusicSelectStatus.MUSIC_STATUS_DOWNLOADING;
			audioPlayData.downloadProgress = progress.fraction;
			notifyItemChanged();
		}

		@Override
		public void onProgress(Progress progress) {
			Ln.d("[music download] onProgress, progress = %s", progress);
			audioPlayData.downloadProgress = progress.fraction;
			notifyItemChanged();
		}

		@Override
		public void onError(Progress progress) {
			Ln.d("[music download] onError, progress = %s", progress);
			audioPlayData.musicSelectStatus = MusicSelectStatus.MUSIC_STATUS_DOWNLOAD_FAILED;
			notifyItemChanged();
		}

		@Override
		public void onFinish(File file, Progress progress) {
			Ln.d("[music download] onFinish, progress = %s", progress);
			audioPlayData.musicSelectStatus = MusicSelectStatus.MUSIC_STATUS_UN_SELECTED;
			notifyItemChanged();
			downloadListenerArrayMap.remove(tag);
		}

		@Override
		public void onRemove(Progress progress) {
			Ln.d("[music download] onRemove, progress = %s", progress);
			downloadListenerArrayMap.remove(tag);
		}

		/**
		 * 更新UI
		 */
		private void notifyItemChanged() {
			int index = mItems.indexOf(audioPlayData);
			mAdapter.notifyItemChanged(index);
		}
	}

}
