package com.itingbaby.app.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.itingbaby.app.R;
import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.app.utils.FlagUtil;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class VoiceOperationView extends ConstraintLayout {

	@BindView(R.id.txt_voice_name)
	TextView txtVoiceName;

	@BindView(R.id.txt_voice_desc)
	TextView txtVoiceDesc;

	@BindView(R.id.item_upload_to_server)
	CommonItem itemUploadToServer;

	@BindView(R.id.item_rename)
	CommonItem itemRename;

	@BindView(R.id.item_delete)
	CommonItem itemDelete;

	private String[] recordTypeItems;

	private OnVoiceOperationViewListener mOnVoiceOperationViewListener;

	private AudioRecordModel mAudioRecordModel; // 当前播放的音频结构体

	public void setOnVoiceOperationViewListener(OnVoiceOperationViewListener listener) {
		mOnVoiceOperationViewListener = listener;
	}

	public VoiceOperationView(Context context) {
		this(context, null);
	}

	public VoiceOperationView(Context context, @Nullable AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public VoiceOperationView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initView();
		initData();
	}

	private void initView() {
		inflate(getContext(), R.layout.view_voice_more_operation, this);
		ButterKnife.bind(this);
		setBackgroundResource(R.drawable.shape_home_content_bg);

		initListener();
	}

	private void initData() {
		recordTypeItems = getContext().getResources().getStringArray(R.array.voice_type);
	}

	private void initListener() {
		itemDelete.setOnClickListener(v -> {
			if (mOnVoiceOperationViewListener != null) {
				mOnVoiceOperationViewListener.onDeleteVoice(mAudioRecordModel);
			}
		});

		itemRename.setOnClickListener(v -> {
			if (null != mOnVoiceOperationViewListener) {
				mOnVoiceOperationViewListener.onRenameVoice(mAudioRecordModel);
			}
		});

		itemUploadToServer.setOnClickListener(v -> {
			if (mOnVoiceOperationViewListener != null) {
				mOnVoiceOperationViewListener.onUploadVoice(mAudioRecordModel);
			}
		});
	}

	public void renderView(AudioRecordModel recordModel) {
		if (recordModel == null) {
			return;
		}
		mAudioRecordModel = recordModel;
		txtVoiceName.setText(recordModel.getName());
		int index = FlagUtil.getFirstOneIndexFromBits(recordModel.getType());
		if (index >= 0) {
			txtVoiceDesc.setText(recordTypeItems[index]);
		}
		itemUploadToServer.setItemName(recordModel.getServerFileId() != null ? getContext().getString(R.string.txt_uploaded) : getContext().getString(R.string.txt_upload_to_server));
		itemUploadToServer.setLeftImgIconRes(recordModel.getServerFileId() != null ? R.drawable.icon_uploaded : R.drawable.ic_upload);
	}

	@OnClick(R.id.txt_cancel)
	public void onViewClicked() {
		if (mOnVoiceOperationViewListener != null) {
			mOnVoiceOperationViewListener.onCollapseIconClick();
		}
	}


	public interface OnVoiceOperationViewListener {

		void onCollapseIconClick();

		void onUploadVoice(AudioRecordModel model);

		void onRenameVoice(AudioRecordModel model);

		void onDeleteVoice(AudioRecordModel model);
	}
}
