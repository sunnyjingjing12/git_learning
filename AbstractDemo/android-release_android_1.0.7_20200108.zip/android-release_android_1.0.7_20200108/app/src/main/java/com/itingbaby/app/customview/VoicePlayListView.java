package com.itingbaby.app.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.itingbaby.app.R;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.components.IVoicePlayListComponent;
import com.itingbaby.app.components.presenter.VoicePlayListPresenter;
import com.itingbaby.app.model.AudioPlayData;
import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.app.model.AudioType;
import com.itingbaby.app.model.MusicCategory;
import com.itingbaby.app.model.MusicClause;
import com.itingbaby.app.model.MusicGroup;
import com.itingbaby.app.model.SimpleTextItem;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.DownloadUtil;
import com.itingbaby.app.viewbinder.AudioRecordModelViewBinder;
import com.itingbaby.app.viewbinder.MusicViewBinder;
import com.itingbaby.app.viewbinder.SimpleTextItemViewBinder;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.widget.ItbEmptyViewLayout;
import com.itingbaby.baselib.views.widget.swipeviews.RefreshLoadRecyclerLayout;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import me.drakeet.multitype.MultiTypeAdapter;

/**
 * 播放列表数据view
 */
public class VoicePlayListView extends LinearLayout implements IVoicePlayListComponent.IView {

	private static final int LIMIT = 20; // 默认获取数量

	public static final int PLAY_MODE_SEQUENCE = 0; 	// 列表循环播放
	public static final int PLAY_MODE_SINGLE_CYCLE = 1; // 单曲循环播放
	public static final int PLAY_MODE_RANDOM = 2;       // 随机播放

	@BindView(R.id.img_collapse)
	ImageView imgCollapse;
	@BindView(R.id.swipe_refresh_layout)
	RefreshLoadRecyclerLayout swipeRefreshLayout;
	@BindView(R.id.view_empty_layout)
	ItbEmptyViewLayout viewEmptyLayout;

	private VoicePlayListPresenter mPresenter;
	private SwipeRecyclerView recyclerView;

	private MultiTypeAdapter mAdapter;

	private List mItems = new ArrayList<>();

	private SimpleTextItem simpleTextItem;
	private AudioRecordModelViewBinder mAudioRecordModelViewBinder;

	private OnVoicePlayListViewListener mOnVoicePlayListViewListener;

	private int mCurPlayMode = PLAY_MODE_SEQUENCE;
	private Random mRandom;
	private MusicCategory category;
	private AudioPlayData audioModelWrapper; // 当前播放的音频结构体

	private MusicViewBinder musicViewBinder;

	public void setOnVoicePlayListViewListener(OnVoicePlayListViewListener listener) {
		mOnVoicePlayListViewListener = listener;
	}

	public VoicePlayListView(Context context) {
		this(context, null);
	}

	public VoicePlayListView(Context context, @Nullable AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public VoicePlayListView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initView();

	}

	private void initView() {
		inflate(getContext(), R.layout.view_voice_playlist, this);
		ButterKnife.bind(this);
		setOrientation(VERTICAL);
		setBackgroundResource(R.drawable.shape_home_content_bg);

		mPresenter = new VoicePlayListPresenter(this);
		mRandom = new Random();

		initRefreshLayout();

	}

	private void initRefreshLayout() {

		viewEmptyLayout.setEmptyViewMarginTopPercentHeight(0.16f);

		viewEmptyLayout.setOnErrorBtnClickListener(v -> {
			if (mPresenter != null) {
				int voiceType = 0;
				if (audioModelWrapper != null && audioModelWrapper.getType() == AudioType.AUDIO_TYPE_MIXED) {
					voiceType = 1;
				}
				mPresenter.getVoiceData(category, voiceType);
			}
		});

		recyclerView = swipeRefreshLayout.getSwipeRecyclerView();
		mAdapter = new MultiTypeAdapter(mItems);

		swipeRefreshLayout.setAdapter(mAdapter);
		swipeRefreshLayout.setCanRefresh(false);
		swipeRefreshLayout.setCanLoadMore(false);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
		recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));

		simpleTextItem = new SimpleTextItem.Builder().build();

		mAdapter.register(SimpleTextItem.class, new SimpleTextItemViewBinder());

	}

	private void initListener() {
		if (mAudioRecordModelViewBinder != null) {
			mAudioRecordModelViewBinder.setOnAudioRecordModelViewBinderListener(new AudioRecordModelViewBinder.OnAudioRecordModelViewBinderListener() {
				@Override
				public void onItemClick(int position) { // 播放这个文件
					if (position < 0 || position >= mItems.size()) {
						return;
					}

					AudioPlayData item = (AudioPlayData) mItems.get(position);

					if (mOnVoicePlayListViewListener != null) {
						mOnVoicePlayListViewListener.onItemClick(item);
					}

					updatePlayingStatus();
					mAdapter.notifyDataSetChanged();

				}

				@Override
				public void onItemMoreOperClick(int position) { // do nothing

				}

				@Override
				public void onPlayImgClick(int position) {

				}

				@Override
				public void onPlaySvgaClick(int position) {

				}
			});
		}

		if (musicViewBinder != null) {
			musicViewBinder.setListener(new MusicViewBinder.OnMusicViewBinderListener() {
				@Override
				public void onItemClick(int pos) {
					if (pos < 0 || pos >= mItems.size()) {
						return;
					}
					AudioPlayData item = (AudioPlayData) mItems.get(pos);

					if (mOnVoicePlayListViewListener != null) {
						mOnVoicePlayListViewListener.onItemClick(item);
					}

					updatePlayingStatus();
					mAdapter.notifyDataSetChanged();
				}

				@Override
				public void onMusicPlayImgClick(int position) {

				}

				@Override
				public void onMusicPlaySvgaClick(int position) {

				}
			});
		}

	}


	public void initData(MusicCategory category, AudioPlayData audioPlayData) {
		this.category = category;
		registerMultiType();
		audioModelWrapper = audioPlayData;
		int voiceType = 0;
		if (audioModelWrapper != null && audioModelWrapper.getType() == AudioType.AUDIO_TYPE_MIXED) {
			voiceType = 1;
		}
		mPresenter.getVoiceData(category, voiceType);
	}


	@OnClick(R.id.img_collapse)
	public void onViewClicked() {
		if (mOnVoicePlayListViewListener != null) {
			mOnVoicePlayListViewListener.onCollapseIconClick();
		}
	}

	private void registerMultiType() {
		if (category == null || MusicGroup.MUSIC_GROUP_ID_MY_VOICE == category.gid) {
			mAudioRecordModelViewBinder = new AudioRecordModelViewBinder(AudioRecordModelViewBinder.SRC_TYPE_PLAY);
			mAdapter.register(AudioRecordModel.class, mAudioRecordModelViewBinder);
		} else {
			musicViewBinder = new MusicViewBinder(MusicViewBinder.SRC_TYPE_DEFAULT);
			mAdapter.register(MusicClause.class, musicViewBinder);
		}
		initListener();
	}

	/**
	 * 设置当前播放的音频结构体
	 *
	 */
	public void setAudioRecordModel(AudioPlayData model) {
		this.audioModelWrapper = model;

		updatePlayingStatus();
		mAdapter.notifyDataSetChanged();
	}


	/**
	 * 获取下一个播放的结构体
	 */
	public AudioPlayData getNextAudioRecord(AudioPlayData wrapper, boolean fromUser) {
		int index = getRecordIndexOfData(wrapper);

		int nextIndex = getNextIndex(index, fromUser);
		nextIndex = (nextIndex == mItems.size()) ? 1 : nextIndex;
		Ln.d("lihb getNextMusicClause, currIndex = %d, nextIndex = %d",index, nextIndex );

		Object item = mItems.get(nextIndex);
		if (item instanceof AudioPlayData) {
			return (AudioPlayData) item;
		}
		return null;
	}

	/**
	 * 获取上一个播放的结构体
	 */
	public AudioPlayData getPreAudioRecord(AudioPlayData wrapper, boolean fromUser) {
		int index = getRecordIndexOfData(wrapper);
		int preIndex = getPreIndex(index, fromUser);
		preIndex = (preIndex < 1) ? (mItems.size() - 1) : preIndex;

		Ln.d("lihb getPreMusicClause, currIndex = %d, preIndex = %d",index, preIndex );

		Object item = mItems.get(preIndex);
		if (item instanceof AudioPlayData) {
			return (AudioPlayData) item;
		}
		return null;
	}



	/**
	 * 更新播放模式
	 * @param playMode
	 */
	public void updatePlayMode(int playMode) {
		mCurPlayMode = playMode;
	}


	/**
	 * 获取上一首的索引值
	 * @param currIndex 当前索引
	 * @return
	 */
	private int getPreIndex(int currIndex, boolean fromUser) {
		int preIndex = currIndex;
		if (mCurPlayMode == PLAY_MODE_SEQUENCE || (mCurPlayMode == PLAY_MODE_SINGLE_CYCLE && fromUser)) {
			// 顺序循环播放；或者是单曲模式下，用户手动点击了上一首
			preIndex = currIndex - 1;
		} else if (mCurPlayMode == PLAY_MODE_RANDOM) {
			preIndex = mRandom.nextInt(mItems.size());
		}
		Ln.d("lihb getPreIndex, currIndex = %d, preIndex = %d, mCurPlayMode =%d",currIndex, preIndex, mCurPlayMode );

		return preIndex;
	}


	/**
	 * 获取下一首的索引值
	 * @param currIndex 当前索引
	 * @return
	 */
	private int getNextIndex(int currIndex, boolean fromUser) {
		int nextIndex = currIndex;
		if (mCurPlayMode == PLAY_MODE_SEQUENCE || (mCurPlayMode == PLAY_MODE_SINGLE_CYCLE && fromUser)) {
			// 顺序循环播放；或者是单曲模式下，用户手动点击了下一首
			nextIndex = currIndex + 1;
		} else if (mCurPlayMode == PLAY_MODE_RANDOM) {
			nextIndex = mRandom.nextInt(mItems.size());
			nextIndex = nextIndex == 0 ? 1 : nextIndex;

		}
		Ln.d("lihb getNextIndex, currIndex = %d, nextIndex = %d, mCurPlayMode =%d",currIndex, nextIndex, mCurPlayMode );
		return nextIndex;
	}


	// region mvp view 方法
	@Override
	public void handleFailed() {
		Ln.d("lihb handleFailed");
		if (mAdapter.getItemCount() > 0) {
			CommonToast.showShortToast(getContext().getString(R.string.list_empty_net_error));
			return;
		}

		if (ListUtils.isEmpty(mItems) && viewEmptyLayout != null) {
			viewEmptyLayout.showError();
		}
	}

	@Override
	public void handleEmpty() {
		Ln.d("lihb handleEmpty");
		if (mAdapter.getItemCount() > 0) {
			return;
		}

		if (viewEmptyLayout != null) {
			viewEmptyLayout.setEmptyImageRes(R.drawable.empty_data);
			viewEmptyLayout.showEmpty();
		}
	}

	@Override
	public void updateDataList(List dataList) {
		Ln.d("lihb updateDataList, list size =%d", dataList.size());
		if (ListUtils.isEmpty(dataList)) {
			viewEmptyLayout.showEmpty();
			return;
		}

		viewEmptyLayout.hideAllView();
		mItems.clear();

		simpleTextItem.title = (category == null ? getContext().getResources().getString(R.string.txt_my_voices) : category.title);
		mItems.add(simpleTextItem);
		mItems.addAll(dataList);

		updatePlayingStatus();
		mAdapter.notifyDataSetChanged();
	}

	@Override
	public void showToast(String msg) {
		CommonToast.showShortToast(msg);
	}
	// endregion


	/**
	 * 更新列表播放中的状态
	 */
	private void updatePlayingStatus() {
		if (audioModelWrapper == null) {
			return;
		}
		for (int i = 0, size = mItems.size(); i < size; i++) {
			Object o = mItems.get(i);
			if (o instanceof AudioPlayData) {
				AudioPlayData item = (AudioPlayData) o;
				if (StringUtils.areEqual(item.getUrl(), audioModelWrapper.getUrl())) {
					item.setPlaying(true);
				} else {
					item.setPlaying(false);
				}
			}
		}
	}


	private int getRecordIndexOfData(AudioPlayData wrapper) {
		int index = -1;
		if (wrapper == null) {
			return index;
		}
		for (int i = 0, size = mItems.size(); i < size; i++) {
			Object item = mItems.get(i);
			if (item instanceof AudioPlayData) {
				AudioPlayData playData = (AudioPlayData) mItems.get(i);
				if (StringUtils.areEqual(playData.getUrl(), wrapper.getUrl())) {
					index = i;
					break;
				}
			}

		}
		return index;
	}

	public Set<AudioPlayData> getFutureSong(AudioPlayData audioRecord) {
		Set<AudioPlayData> set = new HashSet<>();
		int index = getRecordIndexOfData(audioRecord);
		String tag = ServiceGenerator.URL_IMG_SERVER + audioRecord.getUrl();
		if (!DownloadUtil.getInstance().isDownloaded(tag)) {
			set.add(audioRecord);
		}
		if (mItems != null) {
			// 先从index位置往后找2个
			for (int i = index + 1; i < mItems.size(); i++) {
				Object item = mItems.get(i);
				if (item instanceof AudioPlayData) {
					AudioPlayData audioPlayData = (AudioPlayData) mItems.get(i);
					if (!addRecordModel(set, audioPlayData)) {
						break;
					}
				}

			}
			// 先从index位置往前找2个
			if (set.size() < 3) {
				for (int i = index - 1; i > 0; i--) {
					Object item = mItems.get(i);
					if (item instanceof AudioPlayData) {
						AudioPlayData audioPlayData = (AudioPlayData) mItems.get(i);
						if (!addRecordModel(set, audioPlayData)) {
							break;
						}
					}
				}
			}
		}
		return set;
	}

	private boolean addRecordModel(Set set, AudioPlayData model) {
		if (set.size() >= 3) {
			return false;
		}
		if (model != null) {
			String tag = ServiceGenerator.URL_IMG_SERVER + model.getUrl();
			if (!DownloadUtil.getInstance().isDownloaded(tag)) {
				set.add(model);
			}
		}
		return true;
	}


	public interface OnVoicePlayListViewListener {

		void onCollapseIconClick();

		void onItemClick(AudioPlayData model);
	}

}
