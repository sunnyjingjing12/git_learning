package com.itingbaby.app.customview;

import android.content.Context;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.SimpleItemAnimator;
import android.util.AttributeSet;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.itingbaby.app.R;
import com.itingbaby.app.model.SimpleTextItem;
import com.itingbaby.app.viewbinder.SimpleTextItemViewBinder;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.views.widget.ItbEmptyViewLayout;
import com.itingbaby.baselib.views.widget.swipeviews.RefreshLoadRecyclerLayout;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.drakeet.multitype.MultiTypeAdapter;

/**
 * 播放列表数据view
 */
public class VoicePlayTimeStopView extends RelativeLayout {


	@BindView(R.id.swipe_refresh_layout)
	RefreshLoadRecyclerLayout swipeRefreshLayout;
	@BindView(R.id.view_empty_layout)
	ItbEmptyViewLayout viewEmptyLayout;
	@BindView(R.id.txt_cancel)
	TextView txtCancel;

	private SwipeRecyclerView recyclerView;

	private MultiTypeAdapter mAdapter;

	private List mItems = new ArrayList<>();

	private OnVoicePlayTimeStopViewListener mOnVoicePlayTimeStopViewListener;

	private SimpleTextItemViewBinder mSimpleTextItemViewBinder;

	private int[] timeIntArray;
	private String[] timeStringArray;


	public void setOnVoicePlayTimeStopViewListener(OnVoicePlayTimeStopViewListener listener) {
		mOnVoicePlayTimeStopViewListener = listener;
	}

	public VoicePlayTimeStopView(Context context) {
		this(context, null);
	}

	public VoicePlayTimeStopView(Context context, @Nullable AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public VoicePlayTimeStopView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initView();
		initData();
	}

	private void initView() {
		inflate(getContext(), R.layout.view_voice_play_time_switch, this);
		ButterKnife.bind(this);
		setBackgroundResource(R.drawable.shape_home_content_bg);

		initRefreshLayout();

		initListener();
	}

	private void initRefreshLayout() {

		viewEmptyLayout.setEmptyViewMarginTopPercentHeight(0.16f);


		recyclerView = swipeRefreshLayout.getSwipeRecyclerView();
		mAdapter = new MultiTypeAdapter(mItems);

		swipeRefreshLayout.setAdapter(mAdapter);
		swipeRefreshLayout.setCanRefresh(false);
		swipeRefreshLayout.setCanLoadMore(false);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
		recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));

		mSimpleTextItemViewBinder = new SimpleTextItemViewBinder();
		mAdapter.register(SimpleTextItem.class, mSimpleTextItemViewBinder);

	}

	private void initListener() {
		mSimpleTextItemViewBinder.setOnItemClickListener(new SimpleTextItemViewBinder.OnItemClickListener() {
			@Override
			public void onItemClick(int position) {
				if (mOnVoicePlayTimeStopViewListener != null) {
					if (position >= 0 && position < timeIntArray.length) {
						mOnVoicePlayTimeStopViewListener.onItemClick(timeIntArray[position]);
					}
					if (position >= 0 && position < mItems.size()) {
						setSelectTime(position);
						mAdapter.notifyDataSetChanged();
					}
				}

			}

			@Override
			public void onRightTextClick() {
				// do nothing
			}
		});

		txtCancel.setOnClickListener(v -> {
			if (mOnVoicePlayTimeStopViewListener != null) {
				mOnVoicePlayTimeStopViewListener.onDismiss();
			}
		});
	}


	private void initData() {
		timeIntArray = getResources().getIntArray(R.array.voice_play_time_stop);
		timeStringArray = getResources().getStringArray(R.array.voice_play_time_stop_desc);

		if (timeIntArray.length == 0 || timeStringArray.length == 0) {
			handleEmpty();
		}

		if (timeStringArray != null && timeStringArray.length > 0) {
			mItems.clear();

			for (int i = 0, size = timeStringArray.length; i < size; i++) {
				SimpleTextItem item = new SimpleTextItem.Builder()
						.title(timeStringArray[i])
						.textSize(15)
						.height(60)
						.build();
				item.isSelect = (i == 0);
				mItems.add(item);
			}
			viewEmptyLayout.hideAllView();
			mAdapter.notifyDataSetChanged();
		}
	}


	/**
	 * 设置选择的时间索引
	 */
	public void setSelectTime(int position) {
		for (int i = 0, size = mItems.size(); i < size; i++) {
			SimpleTextItem item = (SimpleTextItem) mItems.get(i);
			item.isSelect = (i == position);
		}
		mAdapter.notifyDataSetChanged();
	}


	private void handleEmpty() {
		Ln.d("lihb handleEmpty");
		if (mAdapter.getItemCount() > 0) {
			return;
		}

		if (viewEmptyLayout != null) {
			viewEmptyLayout.setEmptyMessage(getContext().getString(R.string.no_voice_record));
			viewEmptyLayout.setEmptyImageRes(R.drawable.empty_data);
			viewEmptyLayout.showEmpty();
		}
	}


	public interface OnVoicePlayTimeStopViewListener {

		void onItemClick(int time);

		void onDismiss();
	}

}
