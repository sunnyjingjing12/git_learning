package com.itingbaby.app.customview;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import androidx.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

import com.itingbaby.app.R;

/**
 * author: rivenlee
 * date: 2018/10/30
 * email: rivenlee0@gmail.com
 */
public class WaveView extends View {

	private short MAX = 300;

	private float mWidth;
	private float mHeight;

	private float space = 1f;
	private float waveStrokeWidth = 4f;

	private Paint wavePaint;		// 波形画笔
	private Paint baseLinePaint;	// 基准线画笔
	private int mWaveColor = Color.BLACK;		// 波形颜色
	private int mBaseLineColor = Color.BLACK;	// 基准线颜色

	private int invalidateTime = 1000 / 100;
	private long drawTime;
	private boolean isMaxConstant = false;

	private short[] points;
	private int pointCount;

	public WaveView(Context context) {
		this(context, null);
	}

	public WaveView(Context context, @Nullable AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public WaveView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		init(attrs, defStyleAttr);
	}

	private void init(AttributeSet attrs, int defStyle) {
		final TypedArray a = getContext().obtainStyledAttributes(
				attrs, R.styleable.WaveView, defStyle, 0);
		mWaveColor = a.getColor(
				R.styleable.WaveView_waveColor,
				mWaveColor);
		mBaseLineColor = a.getColor(
				R.styleable.WaveView_baselineColor,
				mBaseLineColor);

		waveStrokeWidth = a.getDimension(
				R.styleable.WaveView_waveStokeWidth,
				waveStrokeWidth);

		MAX = (short) a.getInt(R.styleable.WaveView_maxValue, MAX);
		invalidateTime = a.getInt(R.styleable.WaveView_invalidateTime, invalidateTime);

		space = a.getDimension(R.styleable.WaveView_space, space);
		a.recycle();
		initPainters();

	}

	private void initPainters() {
		wavePaint = new Paint();
		wavePaint.setColor(mWaveColor);// 画笔为color
		wavePaint.setStrokeWidth(waveStrokeWidth);// 设置画笔粗细
		wavePaint.setAntiAlias(true);
		wavePaint.setFilterBitmap(true);
		wavePaint.setStrokeCap(Paint.Cap.ROUND);
		wavePaint.setStyle(Paint.Style.FILL);

		baseLinePaint = new Paint();
		baseLinePaint.setColor(mBaseLineColor);// 画笔为color
		baseLinePaint.setStrokeWidth(1f);// 设置画笔粗细
		baseLinePaint.setAntiAlias(true);
		baseLinePaint.setFilterBitmap(true);
		baseLinePaint.setStyle(Paint.Style.FILL);
	}

	public float getSpace() {
		return space;
	}

	public void setSpace(float space) {
		this.space = space;
	}

	public int getmWaveColor() {
		return mWaveColor;
	}

	public void setmWaveColor(int mWaveColor) {
		this.mWaveColor = mWaveColor;
		invalidateNow();
	}

	public int getmBaseLineColor() {
		return mBaseLineColor;
	}

	public void setmBaseLineColor(int mBaseLineColor) {
		this.mBaseLineColor = mBaseLineColor;
		invalidateNow();
	}

	public float getWaveStrokeWidth() {
		return waveStrokeWidth;
	}

	public void setWaveStrokeWidth(float waveStrokeWidth) {
		this.waveStrokeWidth = waveStrokeWidth;
		invalidateNow();
	}

	public int getInvalidateTime() {
		return invalidateTime;
	}

	public void setInvalidateTime(int invalidateTime) {
		this.invalidateTime = invalidateTime;
	}

	public boolean isMaxConstant() {
		return isMaxConstant;
	}

	public void setMaxConstant(boolean maxConstant) {
		isMaxConstant = maxConstant;
	}

	/**
	 * 如果改变相应配置  需要刷新相应的paint设置
	 */
	private void invalidateNow() {
		initPainters();
		invalidate();
	}

	public void addData(short val) {
		if (null == points) {
			return;
		}
		//Log.i("iTingBaby", "" + dataList.size());
		if (val < 0) {
			val = (short) -val;
		}
		if (val > MAX && !isMaxConstant) {
			MAX = val;
		}

		stepAheadDataBuf();
		points[pointCount - 1] = val;

		if (System.currentTimeMillis() - drawTime > invalidateTime) {
			invalidate();
			drawTime = System.currentTimeMillis();
		}

	}

	public void clear() {
		//dataList.clear();
		invalidateNow();
	}


	@Override
	protected void onDraw(Canvas canvas) {
		canvas.translate(0, mHeight / 2);
		drawBaseLine(canvas);
		drawWave(canvas);
	}

	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		mWidth = w;
		mHeight = h;

		pointCount = (int)(mWidth / space);
		points = new short[pointCount];
	}

	private void drawWave(Canvas mCanvas) {
		for (int i = 0; i< points.length; i++) {
			float x = i * space;
			float y = ((float) points[i] / MAX) * (mHeight / 2);
			mCanvas.drawLine(x, -y, x, y, wavePaint);
		}
	}

	private void drawBaseLine(Canvas mCanvas) {
		mCanvas.drawLine(0, 0, mWidth, 0, baseLinePaint);
	}

	// 每个元素往前挪一个步长
	private void stepAheadDataBuf() {
		for (int i = 1; i< points.length; ++i) {
			points[i - 1] = points[i];
		}
	}
}
