package com.itingbaby.app.customview;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;

import com.itingbaby.app.R;
import com.itingbaby.baselib.commonutils.DimensionUtil;
import com.itingbaby.baselib.views.widget.CommonDialog;
import com.tencent.smtt.sdk.WebView;
import com.tencent.smtt.sdk.WebViewClient;

public class WebDialog {
	private CommonDialog dialog;
	private X5WebView mWebView;

	private WebDialog(Builder builder) {
		dialog = CommonDialog.createDialog(builder.context);
		mWebView = (X5WebView) View.inflate(builder.context, R.layout.web_dialog_view, null);
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
				DimensionUtil.dipToPx(builder.context, 320));
		initWebView();
		mWebView.loadUrl(builder.url);
		dialog.setTitleText(builder.title)
				.setContentView(mWebView, params)
				.setLeftButtonText("取消")
				.setLeftButtonAction(builder.cancelListener)
				.setRightButtonText("确认")
				.setRightButtonAction(builder.confirmListener)
				.setCancelable(true);
	}

	private void initWebView() {

		mWebView.setWebViewClient(new WebViewClient() {
			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				view.loadUrl(url);
				return true;
			}
		});
	}

	public void show() {
		dialog.show();
	}

	public static class Builder {
		private Context context;
		private String title;
		private String url;
		private CommonDialog.OnActionListener cancelListener;
		private CommonDialog.OnActionListener confirmListener;

		public Builder setContext(@NonNull Context context) {
			this.context = context;
			return this;
		}

		public Builder setTitle(String title) {
			this.title = title;
			return this;
		}

		public Builder setUrl(String url) {
			this.url = url;
			return this;
		}

		public Builder setCancelListener(CommonDialog.OnActionListener cancelListener) {
			this.cancelListener = cancelListener;
			return this;
		}

		public Builder setConfirmListener(CommonDialog.OnActionListener confirmListener) {
			this.confirmListener = confirmListener;
			return this;
		}

		public WebDialog build() {
			WebDialog dialog = new WebDialog(this);
			return dialog;
		}
	}
}
