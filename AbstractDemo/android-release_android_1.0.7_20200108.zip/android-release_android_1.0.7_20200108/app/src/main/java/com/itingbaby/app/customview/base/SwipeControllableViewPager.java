package com.itingbaby.app.customview.base;

/**
 * 不能左右滑动的viewpager
 */

import android.content.Context;
import androidx.viewpager.widget.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;

import com.itingbaby.baselib.commonutils.Ln;


public class SwipeControllableViewPager extends ViewPager {
    private boolean swipeEnabled;

    public SwipeControllableViewPager(Context context) {
        this(context, null);
    }

    public SwipeControllableViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.swipeEnabled = true;
    }

    public void setSwipeEnabled(boolean enabled) {
        this.swipeEnabled = enabled;
    }

    public boolean onInterceptTouchEvent(MotionEvent event) {
        try {
            return this.swipeEnabled && super.onInterceptTouchEvent(event);
        } catch (Throwable t) {
            Ln.e("SwipeViewPager", "onInterceptTouchEvent error", t);
            return false;
        }
    }

    public boolean onTouchEvent(MotionEvent event) {
        try {
            return this.swipeEnabled && super.onTouchEvent(event);
        } catch (Throwable t) {
            Ln.e("SwipeViewPager", "onTouchEvent error", t);
            return false;
        }
    }
}