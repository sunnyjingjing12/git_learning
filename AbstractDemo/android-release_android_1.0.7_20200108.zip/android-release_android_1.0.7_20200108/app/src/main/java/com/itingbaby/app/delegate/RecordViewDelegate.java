package com.itingbaby.app.delegate;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

import com.itingbaby.app.customview.RecordOperationView;
import com.itingbaby.baselib.commonutils.ApplicationUtils;
import com.itingbaby.baselib.commonutils.Ln;

/**
 * 录音按钮操作Delegate
 */
public class RecordViewDelegate {

	private RecordOperationView recordLayout;

	private Activity activity;

	private Runnable enterAnimRunnable;

	private ObjectAnimator exitAnim;
	private ObjectAnimator enterAnim;
	private boolean enterAnimStarted = true;

	public RecordViewDelegate(Activity activity, RecordOperationView recordLayout) {
		this.recordLayout = recordLayout;
		this.activity = activity;
		enterAnimRunnable = () -> startEnterAnimation();
	}

	public void renderRecordStatus(int fragmentType, View.OnClickListener listener1, View.OnClickListener listener2) {
		recordLayout.renderRecordStatus(fragmentType, listener1, listener2);
	}

	/**
	 * 当RecyclerView滑动时，调用
	 * @param newState
	 */
	public void onRecyclerViewScrolled(int newState) {
		ApplicationUtils.mMainHandler.removeCallbacks(enterAnimRunnable);

		if (newState == RecyclerView.SCROLL_STATE_IDLE) {
			ApplicationUtils.mMainHandler.postDelayed(enterAnimRunnable, 600);
		}else {
			startExitAnimation();
		}
	}


	/**
	 * 进入动画
	 */
	private void startEnterAnimation() {
		Ln.d("lihb  start enterAnim");
		if (enterAnim == null) {
			enterAnim = ObjectAnimator.ofFloat(recordLayout, "x", -recordLayout.getWidth(), 0);
			enterAnim.setDuration(400);
		}
		enterAnim.start();
		enterAnimStarted = true;
	}


	/**
	 * 退出动画
	 */
	private void startExitAnimation() {
		if (enterAnimStarted == true) {
			Ln.d("lihb start exitAnim");
			if (exitAnim == null) {
				exitAnim = ObjectAnimator.ofFloat(recordLayout, "x", 0, -recordLayout.getWidth());
				exitAnim.setDuration(400);
			}
			exitAnim.start();
			enterAnimStarted = false;
		}
	}


}
