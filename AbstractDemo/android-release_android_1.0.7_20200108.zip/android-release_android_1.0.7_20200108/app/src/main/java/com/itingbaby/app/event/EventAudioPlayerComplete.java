package com.itingbaby.app.event;

/**
 * 音频文件播放完毕
 */
public class EventAudioPlayerComplete {
}
