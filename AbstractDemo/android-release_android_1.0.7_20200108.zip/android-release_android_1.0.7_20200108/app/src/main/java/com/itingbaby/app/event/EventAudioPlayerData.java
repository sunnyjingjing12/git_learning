package com.itingbaby.app.event;

/**
 * 播放器音频数据回调事件
 */
public class EventAudioPlayerData {

	private short[] audioData;// 为了渲染波形控件回调的16位音频数据

	public EventAudioPlayerData(short[] data) {
		audioData = data;
	}

	public short[] getAudioData() {
		return audioData;
	}

	public void setAudioData(short[] data) {
		audioData = data;
	}
}
