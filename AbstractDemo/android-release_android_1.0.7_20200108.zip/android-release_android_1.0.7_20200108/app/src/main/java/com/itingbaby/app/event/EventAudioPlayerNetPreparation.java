package com.itingbaby.app.event;

/**
 * 播放器网络文件预备事件
 */
public class EventAudioPlayerNetPreparation {

	private int status;// mediaPlayer网络文件预备状态 0空闲 1开始预备 2预备完成

	public EventAudioPlayerNetPreparation(int st) {
		status = st;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int st) {
		status = st;
	}
}
