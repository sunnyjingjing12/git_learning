package com.itingbaby.app.event;

/**
 * 音频播放器进度推送事件
 */
public class EventAudioPlayerProgress {

	private int position;

	public EventAudioPlayerProgress(int pos) {
		position = pos;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int pos) {
		position = pos;
	}
}
