package com.itingbaby.app.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.itingbaby.app.R;
import com.itingbaby.baselib.views.fragment.BaseLazyFragment;

/**
 * Created by lhb on 2019/10/28.
 * 首页-空白界面，用来凑数
 */

public class HomeEmptyFragment extends BaseLazyFragment {

	private static final String TAG = HomeEmptyFragment.class.getSimpleName();

	public static HomeEmptyFragment create() {
		return new HomeEmptyFragment();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		return inflater.inflate(R.layout.fragment_home_emtpy, container, false);
	}


	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
		initView();
		initListener();
	}

	private void initView() {


	}


	private void initListener() {


	}


	@Override
	public void setUserVisibleHint(boolean isVisibleToUser) {
		super.setUserVisibleHint(isVisibleToUser);

	}

	@Override
	public void onResume() {
		super.onResume();

	}

	@Override
	public void onLazyLoad() {
		super.onLazyLoad();

	}


}
