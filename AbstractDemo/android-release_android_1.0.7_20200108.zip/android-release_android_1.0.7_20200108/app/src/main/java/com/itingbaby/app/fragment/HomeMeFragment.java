package com.itingbaby.app.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.zxing.integration.android.IntentIntegrator;
import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.Constant;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.activity.DebugSettingActivity;
import com.itingbaby.app.activity.ScanActivity;
import com.itingbaby.app.activity.SettingActivity;
import com.itingbaby.app.activity.WebViewActivity;
import com.itingbaby.app.customview.CircularImageView;
import com.itingbaby.app.customview.CommonItem;
import com.itingbaby.app.model.User;
import com.itingbaby.baselib.commonutils.ApplicationUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.fragment.BaseLazyFragment;

import java.util.Calendar;

/**
 * Created by lhb on 2017/2/8.
 * 首页-我的 界面
 */

public class HomeMeFragment extends BaseLazyFragment {

	private static final String TAG = HomeMeFragment.class.getSimpleName();

	private CommonItem itemScan;
	private CommonItem itemQuestions;
	private CommonItem itemUserHelp;
	private CommonItem itemUserSetting;
	private CommonItem itemMarket;

	private CircularImageView userAvatarImg;
	private TextView userNameTxt;
	private TextView userHelloTxt;
	RelativeLayout userInfoLayout;
	private Calendar mCalendar;


	public static HomeMeFragment create() {
		return new HomeMeFragment();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		return inflater.inflate(R.layout.fragment_home_me, container, false);
	}


	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
		initView();
		initListener();
	}

	private void initView() {
		itemScan = getView().findViewById(R.id.item_scan);
		itemQuestions = getView().findViewById(R.id.item_question);
		itemUserHelp = getView().findViewById(R.id.item_instruction);
		itemUserSetting = getView().findViewById(R.id.item_setting);
		itemMarket = getView().findViewById(R.id.item_market);


		userAvatarImg = getView().findViewById(R.id.img_user_avatar);
		userNameTxt = getView().findViewById(R.id.txt_user_name);
		userHelloTxt = getView().findViewById(R.id.txt_user_num);
		userInfoLayout = getView().findViewById(R.id.user_info_layout);

		mCalendar = Calendar.getInstance();

		userInfoLayout.setOnClickListener(v -> SettingActivity.navigate(getActivity()));

	}


	private void initListener() {
		itemScan.setOnClickListener(v -> toScanBarCode());

		itemQuestions.setOnClickListener(v ->
				WebViewActivity.navigate(getActivity(), Constant.MY_COMMON_QUESTION, getString(R.string.profile_normal)));


		itemUserHelp.setOnClickListener(v ->
				WebViewActivity.navigate(getActivity(), Constant.USER_HELP, getString(R.string.item_instruction)));

		itemMarket.setOnClickListener(v ->
				WebViewActivity.navigate(getActivity(), Constant.MARKET_WEBSITE, getString(R.string.item_market)));

		itemUserSetting.setOnClickListener(v -> SettingActivity.navigate(getActivity()));

		userAvatarImg.setOnLongClickListener(v -> {
			if (ApplicationUtils.IS_DEBUG) {
				DebugSettingActivity.navigate(getActivity());
			}
			return false;
		});

	}

	/**
	 * 设置个人信息
	 */
	private void initUserInfo() {
		String headIcon = null;
		User userInfo = BabyVoiceApp.mUserInfo;
		if (userInfo != null) {
			headIcon = userInfo.avatar;
			if (headIcon != null && !headIcon.contains("http")) {
				headIcon = ServiceGenerator.URL_IMG_SERVER + headIcon;
			}
			Glide.with(getContext())
					.load(headIcon)
					.placeholder(R.drawable.ic_default_avatar)
					.error(R.drawable.ic_default_avatar)
					.dontAnimate()
					.into(userAvatarImg);
			userNameTxt.setText(userInfo.nickname);
			String strGender = "";
			if (1 == userInfo.gender) {
				strGender = getString(R.string.txt_gender_male);
			} else if (2 == userInfo.gender) {
				strGender = getString(R.string.txt_gender_female);
			}
			renderHelloView(strGender);
		}


	}

	/**
	 * 渲染打招呼信息
	 * @param usersex
	 */
	private void renderHelloView(String usersex) {
		String name = StringUtils.areEqual(usersex, getString(R.string.txt_gender_male)) ? "宝爸" : "宝妈";
		mCalendar= Calendar.getInstance();
		mCalendar.setTimeInMillis(System.currentTimeMillis());
		int currHour = mCalendar.get(Calendar.HOUR_OF_DAY);
		Ln.d("currHour = %d", currHour);
		if (currHour > 0 && currHour < 9) {
			userHelloTxt.setText("早上好，"+ name);
		} else if (currHour < 12) {
			userHelloTxt.setText("上午好，"+ name);
		} else if (currHour < 18) {
			userHelloTxt.setText("下午好，"+ name);
		}else if (currHour < 23) {
			userHelloTxt.setText("晚上好，"+ name);
		}else {
			userHelloTxt.setText("晚安，"+ name);
		}
	}

	@Override
	public void setUserVisibleHint(boolean isVisibleToUser) {
		super.setUserVisibleHint(isVisibleToUser);
		if (isVisibleToUser) {
			initUserInfo();
		}
	}

	@Override
	public void onResume() {
		super.onResume();
		initUserInfo();
	}

	@Override
	public void onLazyLoad() {
		super.onLazyLoad();
		initUserInfo();
	}


	/**
	 * 跳转到扫码页面
	 */
	private void toScanBarCode() {
		IntentIntegrator integrator = IntentIntegrator.forSupportFragment(this);
		integrator.setPrompt("请扫描"); //底部的提示文字，设为""可以置空
		integrator.setCameraId(0); //前置或者后置摄像头
		integrator.setBeepEnabled(true); //扫描成功的「哔哔」声，默认开启
		integrator.setCaptureActivity(ScanActivity.class);
		integrator.initiateScan();
	}

}
