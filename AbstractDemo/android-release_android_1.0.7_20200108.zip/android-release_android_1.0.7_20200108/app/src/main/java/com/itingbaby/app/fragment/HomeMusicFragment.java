package com.itingbaby.app.fragment;

import android.graphics.Rect;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.activity.AddressActivity;
import com.itingbaby.app.components.IHomeMusicComponent;
import com.itingbaby.app.components.presenter.HomeMusicPresenter;
import com.itingbaby.app.event.EventMusicDot;
import com.itingbaby.app.model.AudioType;
import com.itingbaby.app.model.DividerLineEntity;
import com.itingbaby.app.model.MusicCategory;
import com.itingbaby.app.model.MusicGroup;
import com.itingbaby.app.model.SimpleTextItem;
import com.itingbaby.app.model.User;
import com.itingbaby.app.model.UserExtension;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.viewbinder.DividerLineItemViewBinder;
import com.itingbaby.app.viewbinder.MusicTypeViewBinder;
import com.itingbaby.app.viewbinder.SimpleTextItemViewBinder;
import com.itingbaby.baselib.commonutils.DimensionUtil;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.fragment.BaseLazyFragment;
import com.itingbaby.baselib.views.widget.ItbEmptyViewLayout;
import com.itingbaby.baselib.views.widget.swipeviews.RefreshLoadRecyclerLayout;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import me.drakeet.multitype.MultiTypeAdapter;

/**
 * 首页-宝宝音乐 界面
 */

public class HomeMusicFragment extends BaseLazyFragment implements IHomeMusicComponent.IView {

	private static final int SPAN_COUNT = 2;

	private static final int TWO_WEEKS = 14;  // 两周

	@BindView(R.id.swipe_refresh_layout)
	RefreshLoadRecyclerLayout swipeRefreshLayout;
	@BindView(R.id.view_empty_layout)
	ItbEmptyViewLayout viewEmptyLayout;

	private Unbinder unbinder;

	private SwipeRecyclerView recyclerView;
	private MultiTypeAdapter mAdapter;
	private HomeMusicPresenter mHomeMusicPresenter;

	private List mItems = new ArrayList<>();

	private SimpleTextItemViewBinder mSimpleTextItemViewBinder;
	private List<MusicGroup> musicGroupList = new ArrayList<>();
	private MusicTypeViewBinder musicTypeViewBinder;


	public static HomeMusicFragment create() {
		return new HomeMusicFragment();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_home_music, container, false);
		unbinder = ButterKnife.bind(this, view);
		return view;
	}

	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
		initView();

		if(!EventBus.getDefault().isRegistered(this)){
			EventBus.getDefault().register(this);
		}
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if(EventBus.getDefault().isRegistered(this)){
			EventBus.getDefault().unregister(this);
		}
	}

	@Override
	public void onLazyLoad() {
		super.onLazyLoad();
		if (mHomeMusicPresenter != null) {
			mHomeMusicPresenter.getMusicGroupData();
		}
	}

	@Override
	public void setUserVisibleHint(boolean isVisibleToUser) {
		super.setUserVisibleHint(isVisibleToUser);
	}

	private void initView() {
		initRefreshLayout();
		initListener();
		mHomeMusicPresenter = new HomeMusicPresenter(this);
	}

	private void initRefreshLayout() {

		viewEmptyLayout.setEmptyViewMarginTopPercentHeight(0.16f);
		viewEmptyLayout.setOnErrorBtnClickListener(v-> {
			if (mHomeMusicPresenter != null) {
				mHomeMusicPresenter.getMusicGroupData();
			}
		});

		recyclerView = swipeRefreshLayout.getSwipeRecyclerView();
		mAdapter = new MultiTypeAdapter(mItems);
		// 为了不挡住上面的大波浪线
		recyclerView.setBackgroundColor(getResources().getColor(R.color.transparent));

		swipeRefreshLayout.setAdapter(mAdapter);
		swipeRefreshLayout.setCanRefresh(false);
		swipeRefreshLayout.setCanLoadMore(false);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
		final GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), SPAN_COUNT);
		GridLayoutManager.SpanSizeLookup spanSizeLookup = new GridLayoutManager.SpanSizeLookup() {
			@Override
			public int getSpanSize(int position) {
				if (mItems.get(position) instanceof MusicCategory) {
					return 1;
				} else {
					return 2;
				}

			}
		};
		gridLayoutManager.setSpanSizeLookup(spanSizeLookup);

		recyclerView.setLayoutManager(gridLayoutManager);
		recyclerView.addItemDecoration(new RecyclerView.ItemDecoration() {
			@Override
			public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
				int position = parent.getChildLayoutPosition(view);
				if (position <= mItems.size()) {
					Object item = mItems.get(position);
					if (item instanceof MusicCategory) {
						MusicCategory musicCategory = (MusicCategory) item;
						if (MusicCategory.MUSIC_CATEGORY_USER == musicCategory.id || 0 == musicCategory.id % 2) {
							outRect.left = DimensionUtil.dipToPx(getContext(), 16);
							outRect.right = DimensionUtil.dipToPx(getContext(), 4);
						} else {
							outRect.left = DimensionUtil.dipToPx(getContext(), 4);
							outRect.right = DimensionUtil.dipToPx(getContext(), 16);
						}
						outRect.bottom = DimensionUtil.dipToPx(getContext(), 8);
					} else if (item instanceof SimpleTextItem) {
						outRect.bottom = DimensionUtil.dipToPx(getContext(), 8);
					} else if (item instanceof DividerLineEntity) {
						outRect.left = DimensionUtil.dipToPx(getContext(), 16);
						outRect.bottom = DimensionUtil.dipToPx(getContext(), 16);
						outRect.top = DimensionUtil.dipToPx(getContext(), 8);
					}
				}
			}
		});

		// register item
		mSimpleTextItemViewBinder = new SimpleTextItemViewBinder();
		mAdapter.register(SimpleTextItem.class, mSimpleTextItemViewBinder);
		mAdapter.register(DividerLineEntity.class, new DividerLineItemViewBinder());
		musicTypeViewBinder = new MusicTypeViewBinder();
		mAdapter.register(MusicCategory.class, musicTypeViewBinder);
	}

	private void initListener() {
		mSimpleTextItemViewBinder.setOnItemClickListener(new SimpleTextItemViewBinder.OnItemClickListener() {
			@Override
			public void onItemClick(int position) {
				// do nothing
			}

			@Override
			public void onRightTextClick() {
				// 发协议获取用户上传的音乐文件数目
				if (mHomeMusicPresenter != null) {
					long recordType = AudioType.AUDIO_TYPE_BABY | AudioType.AUDIO_TYPE_MOM | AudioType.AUDIO_TYPE_LUNG | AudioType.AUDIO_TYPE_MIXED;
					mHomeMusicPresenter.getUserAudioRecordData(recordType, 1, 10);
				}
			}
		});
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		unbinder.unbind();
	}

	@Override
	public void handleFailed() {
		Ln.d("lihb handleFailed");
		if (mAdapter.getItemCount() > 0) {
			CommonToast.showShortToast(getString(R.string.list_empty_net_error));
			return;
		}

		if (ListUtils.isEmpty(mItems) && viewEmptyLayout != null) {
			viewEmptyLayout.showError();
		}

	}

	@Override
	public void handleEmpty() {
		Ln.d("lihb handleEmpty");
		if (mAdapter.getItemCount() > 0) {
			return;
		}

		if (viewEmptyLayout != null) {
			viewEmptyLayout.setEmptyImageRes(R.drawable.empty_data);
			viewEmptyLayout.showEmpty();
		}
	}

	@Override
	public void updateMusicGroupList(List<MusicGroup> list) {
		mItems.clear();
		musicGroupList = list;
		if (musicTypeViewBinder != null) {
			musicTypeViewBinder.setMusicGroupList(musicGroupList);
		}

		for (MusicGroup group : list) {
			SimpleTextItem.Builder builder = new SimpleTextItem.Builder().title(group.title);
			User user = BabyVoiceApp.mUserInfo;
			if (user != null && MusicGroup.MUSIC_GROUP_ID_MY_VOICE == group.id && StringUtils.differentDays(System.currentTimeMillis(), user.expected_date * 1000) < TWO_WEEKS) {
				if (user.userExtension != null) {
					UserExtension userExtension = user.userExtension;
					builder.rightTextContent(userExtension.custCount > 0 ? "已申请" : "申请定制服务");
					builder.rightTextVisibility(View.VISIBLE);
				}
			} else {
				builder.rightTextVisibility(View.GONE);
			}

			SimpleTextItem simpleTextItem = builder.build();
			mItems.add(simpleTextItem);

			for (MusicCategory category : group.categoryList) {
				category.gid = group.id;
				mItems.add(category);
			}

			DividerLineEntity dividerLineEntity = new DividerLineEntity(R.color.color_f5f5f5, DimensionUtil.dipToPx(getContext(), 1));
			mItems.add(dividerLineEntity);
		}

		if (isAdded() && viewEmptyLayout != null) {
			viewEmptyLayout.hideAllView();
		}

		mAdapter.notifyDataSetChanged();
	}

	@Override
	public void showToast(String msg) {
		CommonToast.showShortToast(msg);
	}

	@Override
	public void handleMusicSize(int size) {
		//先判断size大小
		if (size == 0) {
			CommonToast.showShortToast("请先上传妈妈心音和宝宝心音哦");
		} else {
			User user = BabyVoiceApp.mUserInfo;
			if (user != null && user.userExtension != null) {
				if (user.userExtension.custCount > 0) {
					CommonToast.showShortToast("请勿重复申请");
				} else {
					AddressActivity.navigate(getActivity(), AddressActivity.FROM_TYPE_APPLY_SD);
				}
			}
		}
	}

	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onMusicDotEvent(EventMusicDot event) {
		updateMusicGroupList(musicGroupList);
	}

}
