package com.itingbaby.app.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.components.IHomeTbaiComponent;
import com.itingbaby.app.components.presenter.HomeTbaiPresenter;
import com.itingbaby.app.model.BannerCardListModel;
import com.itingbaby.app.model.EmptyDataModel;
import com.itingbaby.app.model.HomeCardDevice;
import com.itingbaby.app.model.HomeDataListCard;
import com.itingbaby.app.model.HomeDataListCardType;
import com.itingbaby.app.model.ToolsGroupData;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.viewbinder.BannerCardViewBinder;
import com.itingbaby.app.viewbinder.EmptyDataViewBinder;
import com.itingbaby.app.viewbinder.HomeToolsGroupViewBinder;
import com.itingbaby.app.viewbinder.HomeUserDeviceCardViewBinder;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.views.fragment.BaseLazyFragment;
import com.itingbaby.baselib.views.widget.ItbEmptyViewLayout;
import com.itingbaby.baselib.views.widget.swipeviews.RefreshLoadRecyclerLayout;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import me.drakeet.multitype.MultiTypeAdapter;

/**
 * 甜贝首页
 */
public class HomeTbaiFragment extends BaseLazyFragment implements IHomeTbaiComponent.IView {

	@BindView(R.id.swipe_refresh_layout)
	RefreshLoadRecyclerLayout swipeRefreshLayout;
	Unbinder unbinder;
	@BindView(R.id.empty_view_layout)
	ItbEmptyViewLayout viewEmptyLayout;


	private SwipeRecyclerView recyclerView;
	private MultiTypeAdapter mAdapter;

	private HomeTbaiPresenter mHomeTbaiPresenter;

	private List mItems = new ArrayList<>();
	private HomeToolsGroupViewBinder mHomeToolsGroupViewBinder;

	private boolean mIsLastPage;
	private boolean mIsLoadingMore = false;
	private boolean mIsRefreshing = false;


	public static HomeTbaiFragment create() {
		return new HomeTbaiFragment();
	}


	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View inflate = inflater.inflate(R.layout.fragment_home_tbai, container, false);
		unbinder = ButterKnife.bind(this, inflate);
		return inflate;
	}


	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
		initView();
		initListener();
	}

	/**
	 * fragment切换时调用
	 */
	@Override
	public void setUserVisibleHint(boolean isVisibleToUser) {
		super.setUserVisibleHint(isVisibleToUser);
		if (isVisibleToUser) {
			if (mHomeTbaiPresenter != null) {
				mHomeTbaiPresenter.getHomeDataListCard(BabyVoiceApp.mUserInfo.id);
			}
		}
	}


	/**
	 * activity切换时调用
	 */
	@Override
	public void onResume() {
		super.onResume();
		if (mHomeTbaiPresenter != null) {
			mHomeTbaiPresenter.getHomeDataListCard(BabyVoiceApp.mUserInfo.id);
		}
	}

	private void initView() {
		initRefreshLayout();
		initListener();
		mHomeTbaiPresenter = new HomeTbaiPresenter(this);
	}

	private void initRefreshLayout() {

		viewEmptyLayout.setEmptyViewMarginTopPercentHeight(0.16f);
		viewEmptyLayout.setOnErrorBtnClickListener(v -> {
			if (mHomeTbaiPresenter != null) {
				mHomeTbaiPresenter.getHomeDataListCard(BabyVoiceApp.mUserInfo.id);
			}
		});


		recyclerView = swipeRefreshLayout.getSwipeRecyclerView();
		mAdapter = new MultiTypeAdapter(mItems);

		// 为了不挡住上面的大波浪线
		recyclerView.setBackgroundColor(getResources().getColor(R.color.transparent));

		swipeRefreshLayout.setAdapter(mAdapter);
		swipeRefreshLayout.setCanRefresh(true);
		swipeRefreshLayout.setCanLoadMore(false);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);

		recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));

		// register item
		mHomeToolsGroupViewBinder = new HomeToolsGroupViewBinder();
		mAdapter.register(ToolsGroupData.class, mHomeToolsGroupViewBinder);
		mAdapter.register(HomeCardDevice.class, new HomeUserDeviceCardViewBinder());
		mAdapter.register(BannerCardListModel.class, new BannerCardViewBinder());
		mAdapter.register(EmptyDataModel.class, new EmptyDataViewBinder());

	}

	private void initListener() {
		swipeRefreshLayout.setOnRefreshLoadListener(new RefreshLoadRecyclerLayout.OnRefreshLoadListener() {
			@Override
			public boolean isLoading() {
				return mIsLoadingMore | mIsRefreshing;
			}

			@Override
			public boolean isLastPage() {
				return mIsLastPage;
			}

			@Override
			public void onLoadMore() {

			}

			@Override
			public void onRefresh(boolean auto) {
				if (mIsRefreshing) {
					return;
				}

				mIsRefreshing = true;
				if (mHomeTbaiPresenter != null) {
					mHomeTbaiPresenter.getHomeDataListCard(BabyVoiceApp.mUserInfo.id);
				}
			}

			@Override
			public void showResult() {

			}
		});
	}

	public void startRefresh() {
		swipeRefreshLayout.startRefresh(true, true, true);
	}
	@Override
	public void onDestroyView() {
		super.onDestroyView();
		unbinder.unbind();
	}

	// region presenter方法


	@Override
	public void stopRefresh() {
		Ln.d("lihb stopRefresh");
		if (!isAdded()) {
			return;
		}
		mIsRefreshing = false;
		swipeRefreshLayout.stopRefresh();
	}

	@Override
	public void handleFailed() {
		Ln.d("lihb handleFailed");
		if (!isAdded()) {
			return;
		}
		if (mAdapter.getItemCount() > 0) {
			CommonToast.showShortToast(getString(R.string.list_empty_net_error));
			return;
		}

		if (ListUtils.isEmpty(mItems) && viewEmptyLayout != null) {
			viewEmptyLayout.showError();
		}

	}

	@Override
	public void handleEmpty() {
		Ln.d("lihb handleEmpty");
		if (mAdapter.getItemCount() > 0) {
			return;
		}

		if (viewEmptyLayout != null) {
			viewEmptyLayout.setEmptyImageRes(R.drawable.empty_data);
			viewEmptyLayout.showEmpty();
		}
	}

	@Override
	public void updateDataList(List<HomeDataListCard> dataList) {
		mItems.clear();

		for (HomeDataListCard card : dataList) {
			if (card.cardType == HomeDataListCardType.CARD_TYPE_BANNER) {
				BannerCardListModel bannerCardListModel = new BannerCardListModel();
				bannerCardListModel.homeCardBannerList = card.banners;
				mItems.add(bannerCardListModel);
			} else if (card.cardType == HomeDataListCardType.CARD_TYPE_TOOLS) {
				ToolsGroupData toolsGroupData = new ToolsGroupData();
				toolsGroupData.toolsInfoList = card.tools;
				mItems.add(toolsGroupData);
			} else if (card.cardType == HomeDataListCardType.CARD_TYPE_DEVICES) {
				List<HomeCardDevice> homeCardDeviceList = card.devices;

				if (homeCardDeviceList == null || homeCardDeviceList.isEmpty()) {
					EmptyDataModel emptyDataModel = new EmptyDataModel("您还没有设备，快点击上方 + 按钮添加设备吧~", R.drawable.empty_data);
					mItems.add(emptyDataModel);
				} else {
					mItems.addAll(homeCardDeviceList);
				}
			}
		}

		if (isAdded() && viewEmptyLayout != null) {
			viewEmptyLayout.hideAllView();
		}

		mAdapter.notifyDataSetChanged();
	}

	@Override
	public void showToast(String msg) {
		CommonToast.showShortToast(msg);
	}
	// endregion presenter方法
}
