package com.itingbaby.app.fragment;

import android.os.Bundle;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.components.IHomeToolsComponent;
import com.itingbaby.app.components.presenter.HomeToolsPresenter;
import com.itingbaby.app.model.ToolInfo;
import com.itingbaby.app.model.ToolType;
import com.itingbaby.app.model.ToolsGroupData;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.viewbinder.ToolsGroupDataViewBinder;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.views.fragment.BaseLazyFragment;
import com.itingbaby.baselib.views.widget.ItbEmptyViewLayout;
import com.itingbaby.baselib.views.widget.swipeviews.RefreshLoadRecyclerLayout;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import me.drakeet.multitype.MultiTypeAdapter;

public class HomeToolsFragment extends BaseLazyFragment implements IHomeToolsComponent.IView {

	@BindView(R.id.swipe_refresh_layout)
	RefreshLoadRecyclerLayout swipeRefreshLayout;
	@BindView(R.id.view_empty_layout)
	ItbEmptyViewLayout viewEmptyLayout;

	Unbinder unbinder;

	private SwipeRecyclerView recyclerView;
	private MultiTypeAdapter mAdapter;
	private HomeToolsPresenter mHomeToolsPresenter;

	private List mItems = new ArrayList<>();


	public static HomeToolsFragment create() {
		return new HomeToolsFragment();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_home_tools, container, false);
		unbinder = ButterKnife.bind(this, view);
		return view;
	}

	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
		initView();

	}

	@Override
	public void onDestroy() {
		super.onDestroy();

	}

	@Override
	public void onLazyLoad() {
		super.onLazyLoad();
		if (mHomeToolsPresenter != null) {
			mHomeToolsPresenter.getToolListData(BabyVoiceApp.mUserInfo.id);
		}
	}


	@Override
	public void setUserVisibleHint(boolean isVisibleToUser) {
		super.setUserVisibleHint(isVisibleToUser);
	}

	private void initView() {
		initRefreshLayout();
		initListener();
		mHomeToolsPresenter = new HomeToolsPresenter(this);
	}

	private void initRefreshLayout() {

		viewEmptyLayout.setEmptyViewMarginTopPercentHeight(0.16f);
		viewEmptyLayout.setOnErrorBtnClickListener(v -> {
			if (mHomeToolsPresenter != null) {
				mHomeToolsPresenter.getToolListData(BabyVoiceApp.mUserInfo.id);
			}
		});

		recyclerView = swipeRefreshLayout.getSwipeRecyclerView();
		mAdapter = new MultiTypeAdapter(mItems);
		// 为了不挡住上面的大波浪线
		recyclerView.setBackgroundColor(getResources().getColor(R.color.transparent));

		swipeRefreshLayout.setAdapter(mAdapter);
		swipeRefreshLayout.setCanRefresh(false);
		swipeRefreshLayout.setCanLoadMore(false);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);


		recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

		// register item
		mAdapter.register(ToolsGroupData.class, new ToolsGroupDataViewBinder());
	}

	private void initListener() {

	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		unbinder.unbind();
	}

	@Override
	public void handleFailed() {
		Ln.d("lihb handleFailed");
		if (mAdapter.getItemCount() > 0) {
			CommonToast.showShortToast(getString(R.string.list_empty_net_error));
			return;
		}

		if (ListUtils.isEmpty(mItems) && viewEmptyLayout != null) {
			viewEmptyLayout.showError();
		}

	}

	@Override
	public void handleEmpty() {
		Ln.d("lihb handleEmpty");
		if (mAdapter.getItemCount() > 0) {
			return;
		}

		if (viewEmptyLayout != null) {
			viewEmptyLayout.setEmptyImageRes(R.drawable.empty_data);
			viewEmptyLayout.showEmpty();
		}
	}

	@Override
	public void updateDataList(List<ToolInfo> dataList) {

		mItems.clear();

		SparseArray<ToolsGroupData> sparseArray = new SparseArray();
		for (ToolInfo toolInfo : dataList) {
			int toolType = ToolType.TOOL_TYPE_NOT_VALID;
			if (toolInfo.isBabyType()) {
				toolType = ToolType.TOOL_TYPE_BABY;
			} else if (toolInfo.isPregnantType()) {
				toolType = ToolType.TOOL_TYPE_PREGNANT;
			}

			ToolsGroupData toolsGroupData = sparseArray.get(toolType);
			if (toolsGroupData == null) {
				toolsGroupData = new ToolsGroupData();

				if (toolType == ToolType.TOOL_TYPE_PREGNANT) {
					toolsGroupData.name = "孕妈";
				} else if (toolType == ToolType.TOOL_TYPE_BABY) {
					toolsGroupData.name = "育儿";
				}
				sparseArray.put(toolType, toolsGroupData);
				mItems.add(toolsGroupData);
			}
			if (toolType != ToolType.TOOL_TYPE_NOT_VALID) {
				toolsGroupData.toolsInfoList.add(toolInfo);
			}
		}

		if (isAdded() && viewEmptyLayout != null) {
			viewEmptyLayout.hideAllView();
		}

		mAdapter.notifyDataSetChanged();
	}

	@Override
	public void showToast(String msg) {
		CommonToast.showShortToast(msg);
	}

}
