package com.itingbaby.app.fragment;

import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.activity.pelvic.PelvicExamineReportActivity;
import com.itingbaby.app.activity.pelvic.PelvicTrainAdjustActivity;
import com.itingbaby.app.components.IHomeTrainingComponent;
import com.itingbaby.app.components.presenter.HomeTrainingPresenter;
import com.itingbaby.app.customview.SelectOptionView;
import com.itingbaby.app.customview.TrainingOperationView;
import com.itingbaby.app.model.User;
import com.itingbaby.app.model.pelvictrain.PelvicTrainRecord;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.GsonHelper;
import com.itingbaby.app.utils.SharedPreferencesUtil;
import com.itingbaby.app.viewbinder.PelvicModelViewBinder;
import com.itingbaby.baselib.commonutils.DimensionUtil;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.fragment.BaseLazyFragment;
import com.itingbaby.baselib.views.widget.CommonDialog;
import com.itingbaby.baselib.views.widget.ItbEmptyViewLayout;
import com.itingbaby.baselib.views.widget.swipeviews.RefreshLoadRecyclerLayout;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import me.drakeet.multitype.MultiTypeAdapter;

public class HomeTrainingFragment extends BaseLazyFragment implements IHomeTrainingComponent.IView<PelvicTrainRecord> {

	private static final String TAG = HomeTrainingFragment.class.getSimpleName();

	private static final int LIMIT = 10; // 默认获取数量

	@BindView(R.id.swipe_refresh_layout)
	RefreshLoadRecyclerLayout swipeRefreshLayout;
	@BindView(R.id.view_empty_layout)
	ItbEmptyViewLayout viewEmptyLayout;
	Unbinder unbinder;
	@BindView(R.id.training_operation_layout)
	TrainingOperationView trainingOperationView;
	@BindView(R.id.select_record_type_view)
	SelectOptionView selectOptionView;
	@BindView(R.id.home_voice_root_layout)
	RelativeLayout homeVoiceRootLayout;

	private SwipeRecyclerView recyclerView;
	private MultiTypeAdapter mAdapter;
	private HomeTrainingPresenter mHomeTrainingPresenter;

	private List mItems = new ArrayList<>();
	private boolean mIsLastPage;
	private boolean mIsLoadingMore = false;
	private boolean mIsRefreshing = false;

	private Disposable subscribe;


	private BaseFragmentActivity.FragmentTouchListener fragmentTouchListener;
	private PelvicModelViewBinder mPelvicModelViewBinder;

	private PelvicTrainRecord mRecentPelvicRecord; // 最近一次的评估记录
	private int requestPage = 1;
	private int mSelectPos = 1;


	public static HomeTrainingFragment create() {
		return new HomeTrainingFragment();
	}


	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View inflate = inflater.inflate(R.layout.fragment_home_training, container, false);
		unbinder = ButterKnife.bind(this, inflate);
		return inflate;
	}


	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
		initView();
		initListener();
	}

	private void initView() {
		initRefreshLayout();

		mHomeTrainingPresenter = new HomeTrainingPresenter(this);


		viewEmptyLayout.setEmptyViewMarginTopPercentHeight(0.3f);
		viewEmptyLayout.setEmptyMessage(getString(R.string.no_examine_records));
		viewEmptyLayout.setEmptyImageRes(R.drawable.empty_data);

		selectOptionView.initData(new String[]{"评估", "训练"}, new int[]{R.drawable.ic_examine_operation, R.drawable.ic_traning_operation});

	}

	private void initRefreshLayout() {
		viewEmptyLayout.setOnErrorBtnClickListener(v -> {
			if (mHomeTrainingPresenter != null) {
				requestPage = 1;
				mHomeTrainingPresenter.getPelvicExamineData(requestPage, LIMIT);
			}
		});

		recyclerView = swipeRefreshLayout.getSwipeRecyclerView();
		mAdapter = new MultiTypeAdapter(mItems);

		swipeRefreshLayout.setAdapter(mAdapter);
		swipeRefreshLayout.setCanRefresh(true);
		swipeRefreshLayout.setCanLoadMore(true);
		swipeRefreshLayout.setToggleLoadCount(4);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
		recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));


		mPelvicModelViewBinder = new PelvicModelViewBinder();
		mAdapter.register(PelvicTrainRecord.class, mPelvicModelViewBinder);

	}

	private void initListener() {
		swipeRefreshLayout.setOnRefreshLoadListener(new RefreshLoadRecyclerLayout.OnRefreshLoadListener() {
			@Override
			public boolean isLoading() {
				return mIsLoadingMore | mIsRefreshing;
			}

			@Override
			public boolean isLastPage() {
				return mIsLastPage;
			}

			@Override
			public void onLoadMore() {
				if (mIsLoadingMore || mIsRefreshing) {
					return;
				}

				mIsLoadingMore = true;
				if (mHomeTrainingPresenter != null) {
					int count = mAdapter.getItemCount();
					if (count > 0) {
						mHomeTrainingPresenter.getPelvicExamineData(++requestPage, LIMIT);
					}
				}
			}

			@Override
			public void onRefresh(boolean auto) {
				if (mIsRefreshing) {
					return;
				}

				mIsRefreshing = true;
				if (mHomeTrainingPresenter != null) {
					requestPage = 1;
					mHomeTrainingPresenter.getPelvicExamineData(requestPage, LIMIT);
				}
			}

			@Override
			public void showResult() {

			}
		});

		recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
			@Override
			public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
				super.onScrollStateChanged(recyclerView, newState);
				trainingOperationView.onRecyclerViewScrolled(newState);
			}
		});
		trainingOperationView.setOnClickListener(v -> {
			if (selectOptionView.getVisibility() == View.GONE) {
				selectOptionView.setVisibility(View.VISIBLE);
				selectOptionView.enterWithAnim();
			}
		});

		selectOptionView.setListener(pos -> {
			mSelectPos = pos + 1;
			if (0 == BabyVoiceApp.mUserInfo.weight) {
				showUpdateWeightDialog();
			} else {
				jumpToAdjustActivity();
			}
		});


		fragmentTouchListener = event -> {
			int rawX = (int) event.getRawX();
			int rawY = (int) event.getRawY();
			if (event.getAction() == MotionEvent.ACTION_DOWN
					&& selectOptionView != null && selectOptionView.getVisibility() == View.VISIBLE
					&& !DimensionUtil.hitCheckInWindow(selectOptionView, rawX, rawY)
					&& DimensionUtil.hitCheckInWindow(homeVoiceRootLayout, rawX, rawY)) {
				selectOptionView.exitWithAnim();
				return true;
			}
			return false;
		};
		if (getActivity() != null) {
			((BaseFragmentActivity) getActivity()).registerTouchListener(fragmentTouchListener);
		}

		mPelvicModelViewBinder.setOnPelvicModelViewBinderListener(position -> {
			PelvicExamineReportActivity.navigate(getActivity(), GsonHelper.objectToJson(mItems.get(position)));
		});

	}

	// region fragment生命周期函数


	@Override
	public void onDestroyView() {
		super.onDestroyView();
		unbinder.unbind();
		if (getActivity() != null) {
			((BaseFragmentActivity) getActivity()).unRegisterTouchListener(fragmentTouchListener);
		}
	}


	@Override
	public void onDestroy() {
		super.onDestroy();
		if (subscribe != null && !subscribe.isDisposed()) {
			subscribe.dispose();
			subscribe = null;
		}
	}

	@Override
	public void setUserVisibleHint(boolean isVisibleToUser) {
		super.setUserVisibleHint(isVisibleToUser);
		Ln.d("lihb setUserVisibleHint isVisibleToUser = %b", isVisibleToUser);
		if (!isVisibleToUser && selectOptionView != null && selectOptionView.getVisibility() == View.VISIBLE) {
			selectOptionView.exitWithAnim();
		}
		if (isVisibleToUser) {
			Ln.d("lihb data setUserVisibleHint");
			postDelayGetData();
		}
	}

	@Override
	public void onResume() {
		Ln.d("lihb onResume");
		super.onResume();

		if (selectOptionView != null && selectOptionView.getVisibility() == View.VISIBLE) {
			selectOptionView.exitWithAnim();
		}

		postDelayGetData();

	}

	@Override
	public void onPause() {

		super.onPause();
	}

	// endregion

	private void showUpdateWeightDialog() {
		CommonDialog dialog = CommonDialog.createDialog(getActivity())
				.setTitleText("设置体重")
				.setEditHint("请输入您的体重（30kg-200kg）")
				.setLeftButtonText(getString(R.string.btn_txt_cancel))
				.setRightButtonText(getString(R.string.btn_txt_confirm))
				.setCloseOnTouchOutside(false)
				.setCancelable(false);
		dialog.getEditTextView().setInputType(InputType.TYPE_CLASS_NUMBER);
		dialog.setRightButtonAction(v -> {
			String value = dialog.getEditText();
			int weight = Integer.valueOf(value);
			if (!StringUtils.checkUserWeight(weight)) {
				CommonToast.showShortToast("体重值不正确");
			} else {
				User user = new User();
				user.id = BabyVoiceApp.mUserInfo.id;
				user.weight = weight;
				if (mHomeTrainingPresenter != null) {
					mHomeTrainingPresenter.updateProfile(user);
				}
			}
		});
		dialog.show();
	}


	// region mvp view 方法
	@Override
	public void stopRefresh() {
		Ln.d("lihb stopRefresh");
		if (!isAdded()) {
			return;
		}
		mIsRefreshing = false;
		swipeRefreshLayout.stopRefresh();
	}

	@Override
	public void stopLoadMore() {
		Ln.d("lihb stopLoadMore");
		if (!isAdded()) {
			return;
		}
		mIsLoadingMore = false;
		swipeRefreshLayout.stopLoadMore();
	}

	@Override
	public void handleFailed() {
		Ln.d("lihb handleFailed");
		if (!isAdded()) {
			return;
		}
		if (mAdapter.getItemCount() > 0) {
			CommonToast.showShortToast(getString(R.string.list_empty_net_error));
			return;
		}

		if (ListUtils.isEmpty(mItems) && viewEmptyLayout != null) {
			viewEmptyLayout.showError();
		}
	}

	@Override
	public void handleEmpty() {
		Ln.d("lihb handleEmpty");
		if (!isAdded()) {
			return;
		}
		if (mAdapter.getItemCount() > 0) {
			return;
		}

		if (viewEmptyLayout != null) {
			viewEmptyLayout.showEmpty();
		}
	}

	@Override
	public void setIsLastPage(boolean isLastPage) {
		Ln.d("lihb setIsLastPage %b", isLastPage);
		if (!isAdded()) {
			return;
		}
		mIsLastPage = isLastPage;
		swipeRefreshLayout.setCanLoadMore(!isLastPage);
		swipeRefreshLayout.setIsLastPage(isLastPage);
	}

	@Override
	public void updateDataList(List<PelvicTrainRecord> dataList) {
		Ln.d("lihb updateDataList, list size =%d, mIsLastPage=%b", dataList.size(), mIsLastPage);
		if (ListUtils.isEmpty(dataList)) {
			viewEmptyLayout.showEmpty();
			return;
		}
		if (!isAdded()) {
			return;
		}
		mRecentPelvicRecord = dataList.get(0);
		viewEmptyLayout.hideAllView();
		mItems.clear();
		mItems.addAll(dataList);

		mAdapter.notifyDataSetChanged();
	}

	@Override
	public void addMoreDataList(List<PelvicTrainRecord> dataList) {
		Ln.d("lihb addMoreDataList, list size =%d, mIsLastPage=%b", dataList.size(), mIsLastPage);
		if (!isAdded()) {
			return;
		}
		viewEmptyLayout.hideAllView();
		if (!ListUtils.isEmpty(dataList)) {
			mItems.addAll(dataList);
		}
		mAdapter.notifyDataSetChanged();
	}

	@Override
	public void showToast(String msg) {
		CommonToast.showShortToast(msg);
	}

	@Override
	public void updateProfileSuccess(User userInfo) {
		SharedPreferencesUtil.saveToPreferences(getContext(), userInfo);
		BabyVoiceApp.mUserInfo = userInfo;
		// 更新成功跳转到标定界面
		jumpToAdjustActivity();
	}

	// endregion

	private void jumpToAdjustActivity() {
		if (mSelectPos == 1) {
			PelvicTrainAdjustActivity.navigate(getActivity(), mSelectPos, BabyVoiceApp.mUserInfo.weight, GsonHelper.objectToJson(mRecentPelvicRecord));
		} else if (mItems.size() > 0) {
			PelvicTrainAdjustActivity.navigate(getActivity(), mSelectPos, BabyVoiceApp.mUserInfo.weight, GsonHelper.objectToJson(mRecentPelvicRecord));
		} else {
			CommonToast.showShortToast("尚未进行肌力评估，无法进行训练");
		}
	}


	@Override
	public void onLazyLoad() {
		super.onLazyLoad();
		Ln.d("lihb data onLazyLoad");
//		postDelayGetData();
	}

	/**
	 * 延迟拿数据，先让界面展示出来
	 */
	public void postDelayGetData() {
		subscribe = Observable.timer(20, TimeUnit.MILLISECONDS)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(AndroidSchedulers.mainThread())
				.subscribe(new Consumer<Long>() {
					@Override
					public void accept(Long aLong) throws Exception {
						Ln.d("get data");
						if (swipeRefreshLayout != null) {
							swipeRefreshLayout.startRefreshWithAnimation(false, true);
						}
					}
				}, new Consumer<Throwable>() {
					@Override
					public void accept(Throwable throwable) throws Exception {
						Ln.e("Post Delay failed. %s", throwable);
					}
				});
	}


}
