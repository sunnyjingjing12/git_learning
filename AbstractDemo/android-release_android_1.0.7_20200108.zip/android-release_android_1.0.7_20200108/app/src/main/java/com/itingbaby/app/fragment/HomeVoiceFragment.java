package com.itingbaby.app.fragment;

import android.Manifest;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.DataManager;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.activity.BlueToothRecordActivity;
import com.itingbaby.app.activity.CardiographActivity;
import com.itingbaby.app.activity.SearchDevicesActivity;
import com.itingbaby.app.activity.VoicePlayActivity;
import com.itingbaby.app.activity.mix_video.VoiceMixActivity;
import com.itingbaby.app.components.IHomeVoiceComponent;
import com.itingbaby.app.components.presenter.HomeVoicePresenter;
import com.itingbaby.app.customview.RecordOperationView;
import com.itingbaby.app.customview.SelectOptionView;
import com.itingbaby.app.customview.VoiceOperationView;
import com.itingbaby.app.delegate.RecordViewDelegate;
import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.app.model.AudioRecordModelDao;
import com.itingbaby.app.model.AudioType;
import com.itingbaby.app.model.DaoSession;
import com.itingbaby.app.model.HistoryBleDeviceModel;
import com.itingbaby.app.model.HistoryBleDeviceModelDao;
import com.itingbaby.app.model.TabDataModel;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.FileUtils;
import com.itingbaby.app.utils.UploadSoundUtil;
import com.itingbaby.app.viewbinder.AudioRecordModelViewBinder;
import com.itingbaby.app.viewbinder.TabDataViewBinder;
import com.itingbaby.baselib.commonutils.DimensionUtil;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.PermissionCheckUtil;
import com.itingbaby.baselib.commonutils.PopWindowUtils;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.itingbaby.baselib.views.activity.BaseFragmentActivity;
import com.itingbaby.baselib.views.fragment.BaseLazyFragment;
import com.itingbaby.baselib.views.widget.CommonDialog;
import com.itingbaby.baselib.views.widget.ItbEmptyViewLayout;
import com.itingbaby.baselib.views.widget.swipeviews.RefreshLoadRecyclerLayout;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;
import com.itingbaby.dev.events.EventAudioRecordComplete;
import com.itingbaby.dev.events.EventBleDeviceConnectStatus;
import com.itingbaby.dev.events.EventBleRuntimeDetectPowerStatus;
import com.itingbaby.dev.iTingBabyBleDevice;
import com.itingbaby.dev.iTingBabyBleDeviceManager;
import com.tbruyelle.rxpermissions2.RxPermissions;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.greenrobot.greendao.query.Query;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import me.drakeet.multitype.MultiTypeAdapter;

/**
 * 首页-听贝贝界面
 */

public class HomeVoiceFragment extends BaseLazyFragment implements IHomeVoiceComponent.IView {

	private static final String TAG = HomeVoiceFragment.class.getSimpleName();

	private static final String KEY_VOICE_TYPE = "key_voice_type";

	public static final int VOICE_TYPE_RECORD = 0;
	public static final int VOICE_TYPE_MIXED = 1;

	private static final int LIMIT = 20; // 默认获取数量

	@BindView(R.id.swipe_refresh_layout)
	RefreshLoadRecyclerLayout swipeRefreshLayout;
	@BindView(R.id.view_empty_layout)
	ItbEmptyViewLayout viewEmptyLayout;
	Unbinder unbinder;
	@BindView(R.id.record_operation_layout)
	RecordOperationView recordOperationView;
	@BindView(R.id.select_record_type_view)
	SelectOptionView selectRecordTypeView;
	@BindView(R.id.home_voice_root_layout)
	RelativeLayout homeVoiceRootLayout;

	private SwipeRecyclerView recyclerView;
	private MultiTypeAdapter mAdapter;
	private HomeVoicePresenter mHomeVoicePresenter;

	private List mItems = new ArrayList<>();
	private boolean mIsLastPage;
	private boolean mIsLoadingMore = false;
	private boolean mIsRefreshing = false;

	private Disposable subscribe;

	private RecordViewDelegate mRecordViewDelegate;

	private BaseFragmentActivity.FragmentTouchListener fragmentTouchListener;
	private AudioRecordModelViewBinder mAudioRecordModelViewBinder;

	private VoiceOperationView mVoiceOperationView;

	private PopupWindow mVoiceOperationPopWindow;

	private int currentOperatePosition;// 当前正在操作的item下标

	private OnTabSelectListener mOnTabSelectListener;
	private TabDataViewBinder mTabDataViewBinder;
	private int mFragmentType = VOICE_TYPE_RECORD;


	public static HomeVoiceFragment create(int voiceType) {
		HomeVoiceFragment voiceFragment = new HomeVoiceFragment();
		Bundle bundle = new Bundle();
		bundle.putInt(KEY_VOICE_TYPE, voiceType);
		voiceFragment.setArguments(bundle);
		return voiceFragment;
	}


	public void setOnTabSelectListener(OnTabSelectListener onTabSelectListener) {
		this.mOnTabSelectListener = onTabSelectListener;
	}


	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View inflate = inflater.inflate(R.layout.fragment_home_voice, container, false);
		unbinder = ButterKnife.bind(this, inflate);
		return inflate;
	}


	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
		initView();
		initListener();
	}

	private void initView() {
		Bundle bundle = getArguments();
		if (bundle != null) {
			mFragmentType = bundle.getInt(KEY_VOICE_TYPE, VOICE_TYPE_RECORD);
		}

		initRefreshLayout();

		mRecordViewDelegate = new RecordViewDelegate(getActivity(), recordOperationView);
		mHomeVoicePresenter = new HomeVoicePresenter(this);

		mVoiceOperationView = new VoiceOperationView(getActivity());

		viewEmptyLayout.setEmptyViewMarginTopPercentHeight(0.3f);
		viewEmptyLayout.setEmptyMessage(getString(R.string.no_voice_record));
		viewEmptyLayout.setEmptyImageRes(R.drawable.empty_data);

	}

	private void initRefreshLayout() {
		viewEmptyLayout.setOnErrorBtnClickListener(v -> {
			if (mHomeVoicePresenter != null) {
				mHomeVoicePresenter.getVoiceData(mFragmentType, ServiceGenerator.TYPE_FRESH, 0, LIMIT);
			}
		});

		recyclerView = swipeRefreshLayout.getSwipeRecyclerView();
		mAdapter = new MultiTypeAdapter(mItems);

		swipeRefreshLayout.setAdapter(mAdapter);
		swipeRefreshLayout.setCanRefresh(true);
		swipeRefreshLayout.setCanLoadMore(true);
		swipeRefreshLayout.setToggleLoadCount(4);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);
		recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));

		mAudioRecordModelViewBinder = new AudioRecordModelViewBinder(AudioRecordModelViewBinder.SRC_TYPE_HOME_VOICE);
		mAdapter.register(AudioRecordModel.class, mAudioRecordModelViewBinder);

		mTabDataViewBinder = new TabDataViewBinder();
		mAdapter.register(TabDataModel.class, mTabDataViewBinder);

	}

	private void initListener() {
		if (mTabDataViewBinder != null) {
			mTabDataViewBinder.setListener(selectedIndex -> {
				if (mOnTabSelectListener != null) {
					mOnTabSelectListener.onTabSelect(selectedIndex);
				}
			});
		}

		selectRecordTypeView.setListener(pos -> {
			int recordType = 1 << pos;
			DataManager.getInstance().setCurRecordType(recordType);

			long uid = BabyVoiceApp.mUserInfo.id;
			DaoSession daoSession = BabyVoiceApp.getInstance().getDaoSession();
			HistoryBleDeviceModelDao deviceModelDao = daoSession.getHistoryBleDeviceModelDao();
			Query<HistoryBleDeviceModel> dataset = deviceModelDao.queryBuilder()
					.where(HistoryBleDeviceModelDao.Properties.Uid.eq(uid))
					.orderDesc(HistoryBleDeviceModelDao.Properties.Timestamp)
					.build();
			List<HistoryBleDeviceModel> list = dataset.list();

			if (0 == list.size()) {
				SearchDevicesActivity.navigate(getContext(), recordType);
			} else {
				HistoryBleDeviceModel latestDevice = list.get(0);
				iTingBabyBleDevice device = iTingBabyBleDeviceManager.getInstance().createBleDevice(latestDevice.getMac(), latestDevice.getBleType());
				final RxPermissions rxPermissions = new RxPermissions(getActivity());
				rxPermissions.request(Manifest.permission.ACCESS_FINE_LOCATION).subscribe(granted -> {
					if (granted) {
						iTingBabyBleDeviceManager.getInstance().connect(device);
					} else {
						PermissionCheckUtil.showGrantFailDialog(getActivity(), R.string.grant_location_permission);
					}
				});
			}
		});

		swipeRefreshLayout.setOnRefreshLoadListener(new RefreshLoadRecyclerLayout.OnRefreshLoadListener() {
			@Override
			public boolean isLoading() {
				return mIsLoadingMore | mIsRefreshing;
			}

			@Override
			public boolean isLastPage() {
				return mIsLastPage;
			}

			@Override
			public void onLoadMore() {
				if (mIsLoadingMore || mIsRefreshing) {
					return;
				}
				viewEmptyLayout.hideAllView();

				mIsLoadingMore = true;
				if (mHomeVoicePresenter != null) {
					int count = mAdapter.getItemCount();
					if (count > 0) {
						mHomeVoicePresenter.getVoiceData(mFragmentType, ServiceGenerator.TYPE_LOAD_MORE, count - 1, LIMIT);
					}
				}
			}

			@Override
			public void onRefresh(boolean auto) {
				if (mIsRefreshing) {
					return;
				}
				viewEmptyLayout.hideAllView();

				mIsRefreshing = true;
				if (mHomeVoicePresenter != null) {
					mHomeVoicePresenter.getVoiceData(mFragmentType, ServiceGenerator.TYPE_FRESH, 0, LIMIT);
				}
			}

			@Override
			public void showResult() {

			}
		});

		recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
			@Override
			public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
				super.onScrollStateChanged(recyclerView, newState);
				mRecordViewDelegate.onRecyclerViewScrolled(newState);
			}
		});

		mAudioRecordModelViewBinder.setOnAudioRecordModelViewBinderListener(new AudioRecordModelViewBinder.OnAudioRecordModelViewBinderListener() {
			@Override
			public void onItemClick(int pos) {  // 跳转到播放页
				if (pos < 0 || pos >= mItems.size()) {
					return;
				}
				Object item = mItems.get(pos);
				if (item instanceof AudioRecordModel) {
					AudioRecordModel model = (AudioRecordModel) item;
					VoicePlayActivity.navigate(getActivity(), model, null);
				}
			}

			@Override
			public void onItemMoreOperClick(int position) {
				currentOperatePosition = position;
				Object o = mItems.get(position);
				if (o instanceof AudioRecordModel) {
					AudioRecordModel model = (AudioRecordModel) o;
					mVoiceOperationView.renderView(model);
				}
				showVoiceOperationView();
			}

			@Override
			public void onPlayImgClick(int position) {

			}

			@Override
			public void onPlaySvgaClick(int position) {

			}
		});

		mVoiceOperationView.setOnVoiceOperationViewListener(new VoiceOperationView.OnVoiceOperationViewListener() {
			@Override
			public void onCollapseIconClick() {
				if (mVoiceOperationPopWindow != null && mVoiceOperationPopWindow.isShowing()) {
					mVoiceOperationPopWindow.dismiss();
				}
			}

			@Override
			public void onUploadVoice(AudioRecordModel model) {
				if (mVoiceOperationPopWindow != null && mVoiceOperationPopWindow.isShowing()) {
					mVoiceOperationPopWindow.dismiss();
				}
				if (model.getServerFileId() != null) {
					CommonToast.showShortToast(getString(R.string.txt_uploaded));
				} else {
					uploadAudioRecord(model);
				}
			}

			@Override
			public void onRenameVoice(AudioRecordModel model) {
				if (mVoiceOperationPopWindow != null && mVoiceOperationPopWindow.isShowing()) {
					mVoiceOperationPopWindow.dismiss();
				}

				String oldFileName = model.getName();
				CommonDialog dialog = CommonDialog.createDialog(getContext())
						.setTitleText(getString(R.string.voice_rename))
						.setEditText(oldFileName)
						.setEditHint(R.string.txt_input_file_name)
						.setLeftButtonText(getString(R.string.btn_txt_cancel))
						.setLeftButtonAction(v -> {
							// 取消
						})
						.setRightButtonText(getString(R.string.btn_txt_confirm))
						.setCloseOnTouchOutside(false)
						.setCancelable(false);

				dialog.setRightButtonAction(v -> {
					String newFileName = dialog.getEditText().trim();
					if (StringUtils.isEmpty(newFileName)) {
						CommonToast.showShortToast("文件名称不能为空");
						return;
					}
					if (newFileName.contains(".")) {
						newFileName = newFileName.substring(0, newFileName.indexOf("."));
					}

					String newFilePath = FileUtils.getVoiceFilePath(newFileName);
					if (model.getType() == AudioType.AUDIO_TYPE_MIXED) {
						newFilePath += ".wav";
					}
					String oldFilePath = model.getUrl();
					FileUtils.renameFile(oldFilePath, newFilePath);

					model.setName(newFileName);
					model.setUrl(newFilePath);
					// 保存到本地数据库
					DaoSession daoSession = BabyVoiceApp.getInstance().getDaoSession();
					AudioRecordModelDao audioRecordModelDao = daoSession.getAudioRecordModelDao();
					audioRecordModelDao.insertOrReplaceInTx(model);

					CommonToast.showShortToast(getString(R.string.save_success_tips));
					mAdapter.notifyItemChanged(currentOperatePosition);
				});

				dialog.show();
			}

			@Override
			public void onDeleteVoice(AudioRecordModel model) {
				if (mVoiceOperationPopWindow != null && mVoiceOperationPopWindow.isShowing()) {
					mVoiceOperationPopWindow.dismiss();
				}
				showDeleteFileDialog(model);

			}
		});
		fragmentTouchListener = event -> {
			int rawX = (int) event.getRawX();
			int rawY = (int) event.getRawY();
			if (event.getAction() == MotionEvent.ACTION_DOWN
					&& selectRecordTypeView != null && selectRecordTypeView.getVisibility() == View.VISIBLE
					&& !DimensionUtil.hitCheckInWindow(selectRecordTypeView, rawX, rawY)
					&& DimensionUtil.hitCheckInWindow(homeVoiceRootLayout, rawX, rawY)) {
				selectRecordTypeView.exitWithAnim();
				return true;
			}
			return false;
		};
		if (getActivity() != null) {
			((BaseFragmentActivity) getActivity()).registerTouchListener(fragmentTouchListener);
		}

	}

	/**
	 * 上传AudioRecord到服务端
	 */
	private void uploadAudioRecord(AudioRecordModel model) {
		if (getActivity() != null) {
			((BaseFragmentActivity)getActivity()).showProgressDialog(getString(R.string.txt_uploading), true, null);
		}

		UploadSoundUtil.uploadSound(model, new UploadSoundUtil.OnUploadListener() {
			@Override
			public void onSuccess(String msg, long serverFileId, String url) {
				if (getActivity() != null) {
					((BaseFragmentActivity)getActivity()).dismissProgressDialog();
				}
				CommonToast.showShortToast(msg);

				model.setServerFileId(serverFileId);
				DaoSession daoSession = BabyVoiceApp.getInstance().getDaoSession();
				AudioRecordModelDao audioRecordModelDao = daoSession.getAudioRecordModelDao();
				audioRecordModelDao.insertOrReplaceInTx(model);
			}

			@Override
			public void onFailed(String msg) {
				if (getActivity() != null) {
					((BaseFragmentActivity)getActivity()).dismissProgressDialog();
				}
				CommonToast.showShortToast("上传失败，请稍后重试！");
			}
		});
	}

	// region fragment生命周期函数


	@Override
	public void onDestroyView() {
		super.onDestroyView();
		unbinder.unbind();
		if (getActivity() != null) {
			((BaseFragmentActivity) getActivity()).unRegisterTouchListener(fragmentTouchListener);
		}
	}


	@Override
	public void onDestroy() {
		super.onDestroy();
		if (subscribe != null && !subscribe.isDisposed()) {
			subscribe.dispose();
			subscribe = null;
		}
	}

	@Override
	public void setUserVisibleHint(boolean isVisibleToUser) {
		super.setUserVisibleHint(isVisibleToUser);
		Ln.d("lihb setUserVisibleHint isVisibleToUser = %b", isVisibleToUser);
		if (!isVisibleToUser && selectRecordTypeView != null && selectRecordTypeView.getVisibility()== View.VISIBLE) {
			selectRecordTypeView.exitWithAnim();
		}
		if (isVisibleToUser) {
			postDelayGetData();
		}
	}

	@Override
	public void onResume() {
		Ln.d("lihb onResume");
		super.onResume();
		if (mFragmentType == VOICE_TYPE_RECORD) {
			EventBus.getDefault().register(this);
		}

		if (selectRecordTypeView != null && selectRecordTypeView.getVisibility()== View.VISIBLE) {
			selectRecordTypeView.exitWithAnim();
		}
		postDelayGetData();

		handleRecordViewDelegate();
	}

	@Override
	public void onPause() {
		if (mFragmentType == VOICE_TYPE_RECORD) {
			EventBus.getDefault().unregister(this);
		}
		super.onPause();
	}

	// endregion


	private void handleRecordViewDelegate() {
		if (mRecordViewDelegate != null) {
			// 听贝贝页面吸附组件"录制心音"的点击事件
			mRecordViewDelegate.renderRecordStatus(mFragmentType, v -> {
				selectRecordTypeView.setVisibility(View.VISIBLE);
				selectRecordTypeView.enterWithAnim();
			}, v -> {
				if (mFragmentType == VOICE_TYPE_RECORD) {
					BlueToothRecordActivity.navigate(getContext(), DataManager.getInstance().getCurRecordType());
				} else {
					// 跳转到混音界面
					VoiceMixActivity.navigate(getContext());
				}
			});
		}
	}


	// region EventBus事件

	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onBluetoothPowerStatus(EventBleRuntimeDetectPowerStatus event) {
		DaoSession daoSession = BabyVoiceApp.getInstance().getDaoSession();
		HistoryBleDeviceModelDao deviceModelDao = daoSession.getHistoryBleDeviceModelDao();
		deviceModelDao.deleteAll();// 因为蓝牙开关关闭后，所有之前临时保存的设备信息都清空了
	}

	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onAudioRecordComplete(EventAudioRecordComplete event) {
		Ln.d("录音完成了伙计!");
		handleRecordViewDelegate();
	}

	@Subscribe(threadMode = ThreadMode.MAIN)
	public void onBleDeviceConnectionStatus(EventBleDeviceConnectStatus event) {
		Ln.d("lihb onBleDeviceConnectionStatus ,event=%s", event);

		BaseFragmentActivity activity = (BaseFragmentActivity) getActivity();

		int status = event.getStatus();
		if (EventBleDeviceConnectStatus.CONNECTION_STATUS_CONNECTING == status) {
			activity.showProgressDialog(getString(R.string.txt_ble_connecting), true, () -> {
				iTingBabyBleDeviceManager.getInstance().disconnect();
			});
		} else if (EventBleDeviceConnectStatus.CONNECTION_STATUS_CONNECTED == status) {
			activity.dismissProgressDialog();
			if (-1 == event.getDevType()) {
				CardiographActivity.navigate(activity);
			} else {
				BlueToothRecordActivity.navigate(activity, DataManager.getInstance().getCurRecordType());

				//activity.saveHistoryBleDevice(event);
				//activity.postConnectedEvent(event.getDevType(), event.getDevMac());// 打点
			}
		} else if (EventBleDeviceConnectStatus.CONNECTION_STATUS_DISCONNECTED == status) {
			activity.dismissProgressDialog();
			CommonToast.showLongToast(getString(R.string.txt_ble_disconnect));
			int recordType = DataManager.getInstance().getCurRecordType();
			SearchDevicesActivity.navigate(activity, recordType);
		}
	}

	// endregion EventBus事件


	// region mvp view 方法
	@Override
	public void stopRefresh() {
		Ln.d("lihb stopRefresh");
		mIsRefreshing = false;
		swipeRefreshLayout.stopRefresh();
	}

	@Override
	public void stopLoadMore() {
		Ln.d("lihb stopLoadMore");
		mIsLoadingMore = false;
		swipeRefreshLayout.stopLoadMore();
	}

	@Override
	public void handleFailed() {
		Ln.d("lihb handleFailed");
		if (mAdapter.getItemCount() > 0) {
			CommonToast.showShortToast(getString(R.string.list_empty_net_error));
			return;
		}

		if (ListUtils.isEmpty(mItems) && viewEmptyLayout != null) {
			viewEmptyLayout.showError();
		}
	}

	@Override
	public void handleEmpty() {
		Ln.d("lihb handleEmpty");
//		AudioRecordModel model = new AudioRecordModel();
//		model.setName("测试测试");
//		model.setDuration(40L);
//		model.setType(0);
//		model.setTimestamp(1566974366758L);
//		model.setUid(11085L);
//		model.setIsUploaded(false);
//		model.isRemote = false;
//		mItems.add(model);
//		mAdapter.notifyDataSetChanged();

		if (viewEmptyLayout != null) {
			viewEmptyLayout.showEmpty();
		}
		refreshDataList(null);
	}

	@Override
	public void setIsLastPage(boolean isLastPage) {
		Ln.d("lihb setIsLastPage %b", isLastPage);
		mIsLastPage = isLastPage;
		swipeRefreshLayout.setCanLoadMore(!isLastPage);
		swipeRefreshLayout.setIsLastPage(isLastPage);
	}

	@Override
	public void updateDataList(List list) {
		Ln.d("lihb updateDataList, list size =%d, mIsLastPage=%b", list.size(), mIsLastPage);
		if (ListUtils.isEmpty(list)) {
			viewEmptyLayout.showEmpty();
			return;
		}

		viewEmptyLayout.hideAllView();
		refreshDataList(list);
	}

	@Override
	public void addMoreDataList(List list) {
		Ln.d("lihb addMoreDataList, list size =%d, mIsLastPage=%b", list.size(), mIsLastPage);
		viewEmptyLayout.hideAllView();
		if (!ListUtils.isEmpty(list)) {
			mItems.addAll(list);
		}

		mAdapter.notifyDataSetChanged();
	}

	@Override
	public void showToast(String msg) {
		CommonToast.showShortToast(msg);
	}

	// endregion



	@Override
	public void onLazyLoad() {
		super.onLazyLoad();
		postDelayGetData();
	}

	/**
	 * 更新数据，刷新列表
	 *
	 * @param list
	 */
	private void refreshDataList(List list) {
		mItems.clear();

		mItems.add(new TabDataModel("我的录制", "我的摇篮曲", mFragmentType));
		if (!ListUtils.isEmpty(list)) {
			mItems.addAll(list);
		}

		mAdapter.notifyDataSetChanged();
	}

	/**
	 * 延迟拿数据，先让界面展示出来
	 */
	public void postDelayGetData() {
		subscribe = Observable.timer(20, TimeUnit.MILLISECONDS)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(AndroidSchedulers.mainThread())
				.subscribe(new Consumer<Long>() {
					@Override
					public void accept(Long aLong) throws Exception {
						Ln.d("get data");
						if (mHomeVoicePresenter != null) {
							mHomeVoicePresenter.getVoiceData(mFragmentType, ServiceGenerator.TYPE_FRESH, 0, LIMIT);
						}
					}
				}, new Consumer<Throwable>() {
					@Override
					public void accept(Throwable throwable) throws Exception {
						Ln.e("Post Delay failed. %s", throwable);
					}
				});
	}

	/**
	 * 保存文件弹窗
	 */
	private void showDeleteFileDialog(AudioRecordModel model) {

		CommonDialog.createDialog(getContext())
				.setTitleText(getString(R.string.title_tips))
				.setText(getActivity().getResources().getString(R.string.txt_del_confirm_tips, model.getName()))
				.setIconVisible(CommonDialog.Visible.Gone)
				.setLeftButtonText(getString(R.string.btn_txt_cancel))
				.setRightButtonText(getString(R.string.btn_txt_confirm))
				.setRightButtonAction(v->{
					delAudioRecord(model);
				})
				.setCancelable(true)
				.show();
	}


	/**
	 * 删除文件
	 * @param model
	 */
	private void delAudioRecord(AudioRecordModel model) {
		if (model == null) {
			return;
		}
		int position = -1;
		for (int i = 1; i < mItems.size(); i++) {
			AudioRecordModel obj = (AudioRecordModel) mItems.get(i);
			if (obj == model) {
				position = i;
				break;
			}
		}
		 // 1、删除数据库记录
		if (mHomeVoicePresenter != null) {
			mHomeVoicePresenter.delVoiceData(model);
		}
		// 2、刷新列表
		mItems.remove(position);
		mAdapter.notifyItemRemoved(position);
		if (position != mItems.size()) {
			mAdapter.notifyItemRangeChanged(position, mItems.size() - position);
		} else {
			if (position == 1) {
				mItems.remove(0);
				mAdapter.notifyItemRemoved(0);
				viewEmptyLayout.showEmpty();
			}
		}
	}

	/**
	 * 弹出更多选项弹窗
	 */
	private void showVoiceOperationView() {
		if (mVoiceOperationPopWindow == null) {
			mVoiceOperationPopWindow = PopWindowUtils.popView((BaseFragmentActivity) getActivity(), mVoiceOperationView, DimensionUtil.getScreenWidth(getContext()), DimensionUtil.dipToPx(getContext(), 350), Gravity.BOTTOM);
		}
		if (!mVoiceOperationPopWindow.isShowing()) {
			PopWindowUtils.popWindow((BaseFragmentActivity) getActivity(), mVoiceOperationPopWindow, Gravity.BOTTOM);
		}

	}


	public interface OnTabSelectListener {
		void onTabSelect(int index);
	}
}
