package com.itingbaby.app.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.activity.EditTodoGoodsActivity;
import com.itingbaby.app.components.IWaitPregnancyComponent;
import com.itingbaby.app.components.presenter.WaitPregnancyPresenter;
import com.itingbaby.app.model.SimpleTextItem;
import com.itingbaby.app.model.TabDataModel;
import com.itingbaby.app.model.ToDoGoodsProgressEntity;
import com.itingbaby.app.model.WaitTodoGoods;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.GsonHelper;
import com.itingbaby.app.viewbinder.SimpleTextItemViewBinder;
import com.itingbaby.app.viewbinder.TabDataViewBinder;
import com.itingbaby.app.viewbinder.WaitTodoGoodsProgressViewBinder;
import com.itingbaby.app.viewbinder.WaitTodoGoodsViewBinder;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.views.fragment.BaseLazyFragment;
import com.itingbaby.baselib.views.widget.ItbEmptyViewLayout;
import com.itingbaby.baselib.views.widget.swipeviews.RefreshLoadRecyclerLayout;
import com.itingbaby.baselib.views.widget.swipeviews.SwipeRecyclerView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import me.drakeet.multitype.MultiTypeAdapter;

public class WaitPregnancyFragment extends BaseLazyFragment implements IWaitPregnancyComponent.IView {

	private static final String KEY_GOODS_TYPE = "key_goods_type";
	@BindView(R.id.swipe_refresh_layout)
	RefreshLoadRecyclerLayout swipeRefreshLayout;
	@BindView(R.id.view_empty_layout)
	ItbEmptyViewLayout viewEmptyLayout;

	Unbinder unbinder;

	private SwipeRecyclerView recyclerView;
	private MultiTypeAdapter mAdapter;
	private WaitPregnancyPresenter mPresenter;

	private List mItems = new ArrayList<>();

	private List<WaitTodoGoods> optionList = new ArrayList<>();
	private List<WaitTodoGoods> mWaitTodoGoodsList = new ArrayList<>();

	private int mGoodsType;
	private TabDataViewBinder mTabDataViewBinder;
	private OnTabSelectListener mOnTabSelectListener;
	private WaitTodoGoodsViewBinder mWaitTodoGoodsViewBinder;
	private WaitTodoGoodsProgressViewBinder mProgressViewBinder;

	public void setOnTabSelectListener(OnTabSelectListener onTabSelectListener) {
		this.mOnTabSelectListener = onTabSelectListener;
	}

	public static WaitPregnancyFragment create(int goodsType) {
		WaitPregnancyFragment waitPregnancyFragment = new WaitPregnancyFragment();
		Bundle bundle = new Bundle();
		bundle.putInt(KEY_GOODS_TYPE, goodsType);
		waitPregnancyFragment.setArguments(bundle);
		return waitPregnancyFragment;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_wait_pregnancy, container, false);
		unbinder = ButterKnife.bind(this, view);
		return view;
	}

	@Override
	public void onViewCreated(View view, Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
		initView();

	}

	@Override
	public void onDestroy() {
		super.onDestroy();

	}

	@Override
	public void onLazyLoad() {
		super.onLazyLoad();
		Ln.d("lihb onLazyLoad");
//		if (mPresenter != null) {
//			mPresenter.getAllTodoGoods(BabyVoiceApp.mUserInfo.id, mGoodsType);
//		}
	}


	@Override
	public void setUserVisibleHint(boolean isVisibleToUser) {
		super.setUserVisibleHint(isVisibleToUser);
		Ln.d("lihb setUserVisibleHint");
	}

	@Override
	public void onResume() {
		super.onResume();
		Ln.d("lihb onResume");
		if (mPresenter != null) {
			mPresenter.getAllTodoGoods(BabyVoiceApp.mUserInfo.id, mGoodsType);
		}
	}

	private void initView() {
		mGoodsType = getArguments().getInt(KEY_GOODS_TYPE, WaitTodoGoods.GOODS_TYPE_MOM);

		initRefreshLayout();
		initListener();
		mPresenter = new WaitPregnancyPresenter(this);
	}

	private void initRefreshLayout() {

		viewEmptyLayout.setEmptyViewMarginTopPercentHeight(0.16f);
		viewEmptyLayout.setOnErrorBtnClickListener(v -> {
			if (mPresenter != null) {
				mPresenter.getAllTodoGoods(BabyVoiceApp.mUserInfo.id, mGoodsType);
			}
		});

		recyclerView = swipeRefreshLayout.getSwipeRecyclerView();
		mAdapter = new MultiTypeAdapter(mItems);

		swipeRefreshLayout.setAdapter(mAdapter);
		swipeRefreshLayout.setCanRefresh(false);
		swipeRefreshLayout.setCanLoadMore(false);

		recyclerView.setHasFixedSize(true);
		recyclerView.setNestedScrollingEnabled(false);
		((SimpleItemAnimator) recyclerView.getItemAnimator()).setSupportsChangeAnimations(false);


		recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

		// register item
		mAdapter.register(SimpleTextItem.class, new SimpleTextItemViewBinder());
		mWaitTodoGoodsViewBinder = new WaitTodoGoodsViewBinder(WaitTodoGoodsViewBinder.SRC_FROM_WAIT);
		mAdapter.register(WaitTodoGoods.class, mWaitTodoGoodsViewBinder);
		mTabDataViewBinder = new TabDataViewBinder();
		mAdapter.register(TabDataModel.class, mTabDataViewBinder);
		mProgressViewBinder = new WaitTodoGoodsProgressViewBinder();
		mAdapter.register(ToDoGoodsProgressEntity.class, mProgressViewBinder);
	}

	private void initListener() {
		if (mTabDataViewBinder != null) {
			mTabDataViewBinder.setListener(selectedIndex -> {
				if (mOnTabSelectListener != null) {
					mOnTabSelectListener.onTabSelect(selectedIndex);
				}
			});
		}

		if (mWaitTodoGoodsViewBinder != null) {
			mWaitTodoGoodsViewBinder.setListener(new WaitTodoGoodsViewBinder.OnWaitTodoGoodsBinderListener() {
				@Override
				public void onItemClick(int pos, WaitTodoGoods goods) {
					goods.expanded = !goods.expanded;
					mAdapter.notifyDataSetChanged();
				}

				@Override
				public void onItemStatusClicked(int pos, WaitTodoGoods goods) {
					goods.flag ^= WaitTodoGoods.FLAG_FINISHED;
					goods.expanded = false;
					int index = mWaitTodoGoodsList.indexOf(goods);
					if (index >= 0 && index < mWaitTodoGoodsList.size()) {
						mWaitTodoGoodsList.set(index, goods);
						updateDataList(mWaitTodoGoodsList);
						// 更新flag数据
						mPresenter.updateTodoGoods(BabyVoiceApp.mUserInfo.id, goods);
					}
				}
			});
		}

		if (mProgressViewBinder != null) {
			mProgressViewBinder.setListener(() -> {
				EditTodoGoodsActivity.navigate(getActivity(), GsonHelper.objectToJson(optionList));
			});
		}
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
		unbinder.unbind();
	}

	@Override
	public void handleFailed() {
		Ln.d("lihb handleFailed");
		if (mAdapter.getItemCount() > 0) {
			CommonToast.showShortToast(getString(R.string.list_empty_net_error));
			return;
		}

		if (ListUtils.isEmpty(mItems) && viewEmptyLayout != null) {
			viewEmptyLayout.showError();
		}

	}

	@Override
	public void handleEmpty() {
		Ln.d("lihb handleEmpty");
		if (mAdapter.getItemCount() > 0) {
			return;
		}

		if (viewEmptyLayout != null) {
			viewEmptyLayout.setEmptyImageRes(R.drawable.empty_data);
			viewEmptyLayout.showEmpty();
		}
	}

	@Override
	public void updateDataList(List<WaitTodoGoods> dataList) {
		mWaitTodoGoodsList = dataList;
		mItems.clear();
		optionList.clear();
		mItems.add(new TabDataModel("待产妈妈", "新生宝宝", mGoodsType));

		List<WaitTodoGoods> unFinishedList = new ArrayList<>();
		List<WaitTodoGoods> finishedList = new ArrayList<>();

		for (WaitTodoGoods good : dataList) {
			if ((good.flag & WaitTodoGoods.FLAG_FINISHED) == WaitTodoGoods.FLAG_FINISHED) {
				finishedList.add(good);
			} else if ((good.flag & WaitTodoGoods.FLAG_ADD) == WaitTodoGoods.FLAG_ADD) {
				unFinishedList.add(good);
			}
			if ((good.flag & WaitTodoGoods.FLAG_REQUIRE) != WaitTodoGoods.FLAG_REQUIRE) {
				optionList.add(good);
			}

		}
		int unFinishedListSize = unFinishedList.size();
		int finishedListSize = finishedList.size();
		int totalSize = unFinishedListSize + finishedListSize;
		ToDoGoodsProgressEntity progressEntity = new ToDoGoodsProgressEntity();
		progressEntity.progress = totalSize > 0 ? finishedListSize / (totalSize * 1.0f) : 0f;

		mItems.add(progressEntity);

		if (unFinishedListSize > 0) {
			SimpleTextItem simpleTextItem = new SimpleTextItem.Builder().title("未完成").build();
			mItems.add(simpleTextItem);
			mItems.addAll(unFinishedList);
		}

		if (finishedListSize > 0) {
			SimpleTextItem simpleTextItem = new SimpleTextItem.Builder().title("已完成").build();
			mItems.add(simpleTextItem);
			mItems.addAll(finishedList);
		}

		if (isAdded() && viewEmptyLayout != null) {
			viewEmptyLayout.hideAllView();
		}

		mAdapter.notifyDataSetChanged();
	}

	@Override
	public void showToast(String msg) {
		CommonToast.showShortToast(msg);
	}

	public interface OnTabSelectListener {
		void onTabSelect(int index);
	}
}
