package com.itingbaby.app.fragment;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.itingbaby.app.Constant;
import com.itingbaby.app.R;
import com.itingbaby.app.customview.TitleBar;
import com.itingbaby.app.customview.X5WebView;
import com.itingbaby.baselib.views.fragment.BaseLazyFragment;
import com.tencent.smtt.sdk.WebChromeClient;
import com.tencent.smtt.sdk.WebView;
import com.tencent.smtt.sdk.WebViewClient;
import com.umeng.analytics.MobclickAgent;


public class WebViewFragment extends BaseLazyFragment {

    private static final String TAG = "WebViewFragment";
    private ProgressBar mProgressBar = null;
    private X5WebView mWebView = null;
    private String mUrl = "about:blank";

    public static WebViewFragment create() {
        return new WebViewFragment();
    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart(TAG);
        MobclickAgent.onResume(getContext());
    }

    @Override
    public void onPause() {
        super.onPause();
        MobclickAgent.onPageEnd(TAG);
        MobclickAgent.onPause(getContext());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_webview, container, false);
        return view;
    }



    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews();
    }

    @Override
    public void onLazyLoad() {
        super.onLazyLoad();
        if (mWebView != null) {
            mWebView.loadUrl(mUrl);
        }
    }

    private void initViews() {

        mProgressBar = getView().findViewById(R.id.showAdvProgressBar);
        mProgressBar.setProgress(0);

        mWebView = getView().findViewById(R.id.showAdvWebView);

        mWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                mProgressBar.setProgress(newProgress);
                if (newProgress == 100) {
                    mProgressBar.setVisibility(View.GONE);
                } else {
                    mProgressBar.setVisibility(View.VISIBLE);
                }
                super.onProgressChanged(view, newProgress);
            }

//            @Override
//            public void onReceivedTitle(WebView view, String title) {
//                super.onReceivedTitle(view, title);
//                if (TextUtils.isEmpty(getIntent().getStringExtra("title"))) { // 如果没给标题，就从网页中获取标题
//                    mTitleTextView.setText(title);
//                }
//            }
        });
        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
        });
        mUrl = Constant.MARKET_WEBSITE;

        TitleBar titleBar = getView().findViewById(R.id.title_bar);
        titleBar.setLeftVisible(false);
        titleBar.setTitle("小主商城");
        titleBar.setVisibility(View.GONE);

        mWebView.setOnKeyListener(new View.OnKeyListener() {

            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) {
                    if (keyCode == KeyEvent.KEYCODE_BACK && mWebView.canGoBack()) {  //表示按返回键时的操作
                        mWebView.goBack();   //后退
                        //webview.goForward();//前进
                        return true;    //已处理
                    }
                }
                return false;
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ViewGroup viewGroup = (ViewGroup) getActivity().getWindow().getDecorView();
        if (viewGroup != null) {
            // Bug: Activity has leaked window android.widget.ZoomButtonsController that was originally added here android.view.WindowLeaked
            // 移除所有控件，防止关闭该activity时，内存泄漏的问题
            viewGroup.removeAllViews();
        }
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (hidden == false) {
            showBottomTab();
        }
    }

    private void showBottomTab() {
        if (getActivity() == null) {
            return;
        }
        // 隐藏底部的导航栏和分割线
        (getActivity().findViewById(R.id.tab_layout)).setVisibility(View.VISIBLE);
        (getActivity().findViewById(R.id.main_divider_line)).setVisibility(View.VISIBLE);
    }
}
