package com.itingbaby.app.model;

import android.content.ContentValues;
import android.database.Cursor;

public class AlarmEntity {


	public static final String ID = "id";
	public static final String TYPE = "type";
	public static final String HOUR = "hour";
	public static final String MINUTE = "minute";
	public static final String SWITCH = "switch";


	public int id;                // 序号
	public Integer type;            // 类型，前xx天
	public Integer hour;            // 小时
	public Integer minute;          // 分钟
	public Integer switchs;         // 开关


	public static AlarmEntity parseCursorToBean(Cursor cursor) {

		AlarmEntity alarmEntity = new AlarmEntity();
		alarmEntity.id = cursor.getInt(cursor.getColumnIndex(ID));
		alarmEntity.type = cursor.getInt(cursor.getColumnIndex(TYPE));
		alarmEntity.hour = cursor.getInt(cursor.getColumnIndex(HOUR));
		alarmEntity.minute = cursor.getInt(cursor.getColumnIndex(MINUTE));
		alarmEntity.switchs = cursor.getInt(cursor.getColumnIndex(SWITCH));

		return alarmEntity;
	}

	public static ContentValues buildContentValues(AlarmEntity alarmEntity) {
		ContentValues values = new ContentValues();
		values.put(ID, alarmEntity.id);
		if (alarmEntity.type != null) {
			values.put(TYPE, alarmEntity.type);
		}
		if (alarmEntity.hour != null) {
			values.put(HOUR, alarmEntity.hour);
		}
		if (alarmEntity.minute != null) {
			values.put(MINUTE, alarmEntity.minute);
		}
		if (alarmEntity.switchs != null) {
			values.put(SWITCH, alarmEntity.switchs);
		}
		return values;
	}


}
