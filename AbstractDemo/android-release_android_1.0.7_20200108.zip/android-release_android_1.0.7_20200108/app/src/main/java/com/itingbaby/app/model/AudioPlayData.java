package com.itingbaby.app.model;

public abstract class AudioPlayData {


	public boolean isPlaying;      // 是否正在播放

	public int musicSelectStatus;   // 选择状态标记，候选歌曲,可以多首

	public float downloadProgress;   // 下载进度

	public int mixMusicSelectStatus;   // 选择状态标记，混音歌曲，心音一首，宝贝音乐一首


	public abstract Long getId();

	public abstract String getTitle();

	public abstract String getUrl();

	public abstract Integer getDuration();

	public abstract String getAuthor();

	public abstract boolean isPlaying();

	public abstract Integer getType();

	public abstract Long getTimestamp();

	public abstract boolean isRemote();

	public abstract void setPlaying(boolean b);
}
