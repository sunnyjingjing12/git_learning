package com.itingbaby.app.model;

import com.google.gson.annotations.SerializedName;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.NotNull;
import org.greenrobot.greendao.annotation.Transient;

import java.io.Serializable;

/**
 * 本地录音记录类
 */
@Entity(nameInDb="t_audio_record")
public class AudioRecordModel extends AudioPlayData implements Serializable {

	public static final long serialVersionUID = 1L;

	@SerializedName("id")
	private Long serverFileId;       // 上传成功后的文件id

	@NotNull
	@SerializedName("uid")
	private Long uid;			    // 用户ID(对应后台服务器uid)

	@NotNull
	@SerializedName("title")
	private String name;            // 文件名

	@SerializedName("type")
	private Integer type;		    // 文件类型: 0宝宝心音 1妈妈心音 2肺音

	@SerializedName("duration")
	private Integer duration;       // 录音时长

	@SerializedName("file_url")
	private String url;  		    // 文件下载地址（本地文件：路径；服务端文件：下载地址）

	@Id
	@NotNull
	@SerializedName("create_timestamp")
	private Long timestamp;         // 录音文件时间戳

	@SerializedName("remote")
	@Transient
	private boolean remote;         // 文件是否存放在远程，不存数据库

	private boolean isUploaded = false;    // 是否已上传， 本地录音文件使用，为兼容旧版，保留

	@Generated(hash = 940120993)
	public AudioRecordModel(Long serverFileId, @NotNull Long uid,
							@NotNull String name, Integer type, Integer duration, String url,
							@NotNull Long timestamp, boolean isUploaded) {
		this.serverFileId = serverFileId;
		this.uid = uid;
		this.name = name;
		this.type = type;
		this.duration = duration;
		this.url = url;
		this.timestamp = timestamp;
		this.isUploaded = isUploaded;
	}

	@Generated(hash = 872208603)
	public AudioRecordModel() {
	}

	// region 继承自AudioPlayData
	@Override
	public Long getId() {
		return this.serverFileId;
	}

	@Override
	public String getTitle() {
		return name;
	}

	@Override
	public String getUrl() {
		return this.url;
	}

	@Override
	public Integer getDuration() {
		return this.duration;
	}

	@Override
	public String getAuthor() {
		return "";
	}

	@Override
	public Integer getType() {
		return this.type;
	}

	@Override
	public Long getTimestamp() {
		return this.timestamp;
	}

	@Override
	public boolean isRemote() {
		return this.remote;
	}

	@Override
	public void setPlaying(boolean playing) {
		isPlaying = playing;
	}

	@Override
	public boolean isPlaying() {
		return isPlaying;
	}

	// endregion 继承自AudioPlayData

	// region 数据库
	public Long getServerFileId() {
		return this.serverFileId;
	}

	public void setServerFileId(Long serverFileId) {
		this.serverFileId = serverFileId;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public void setId(Long serverFileId) {
		this.serverFileId = serverFileId;
	}

	public Long getUid() {
		return this.uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public void setTitle(String name) {
		this.name = name;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}


	public void setRemote(boolean remote) {
		this.remote = remote;
	}

	public boolean getIsUploaded() {
		return this.isUploaded;
	}

	public void setIsUploaded(boolean isUploaded) {
		this.isUploaded = isUploaded;
	}

	// endregion 数据库

}
