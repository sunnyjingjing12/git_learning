package com.itingbaby.app.model;


import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import static com.itingbaby.app.model.AudioType.AUDIO_TYPE_BABY;
import static com.itingbaby.app.model.AudioType.AUDIO_TYPE_LUNG;
import static com.itingbaby.app.model.AudioType.AUDIO_TYPE_MIXED;
import static com.itingbaby.app.model.AudioType.AUDIO_TYPE_MOM;
import static com.itingbaby.app.model.AudioType.AUDIO_TYPE_OTHER;

/**
 * 听贝贝胎心音录制类型
 */
@Retention(RetentionPolicy.SOURCE)
@IntDef({AUDIO_TYPE_BABY, AUDIO_TYPE_MOM, AUDIO_TYPE_LUNG, AUDIO_TYPE_MIXED, AUDIO_TYPE_OTHER})
public @interface AudioType {
	int AUDIO_TYPE_OTHER = 0x00;    // 其他声音
	int AUDIO_TYPE_BABY = 0x01;    // 胎心音（默认）
	int AUDIO_TYPE_MOM = 0x02;    // 妈妈心音
	int AUDIO_TYPE_LUNG = 0x04;    // 肺音
	int AUDIO_TYPE_MIXED = 0x08;    // 混音

}
