package com.itingbaby.app.model;

import java.util.ArrayList;
import java.util.List;

public class BannerCardListModel {

	public List<HomeCardBanner> homeCardBannerList = new ArrayList<>();
}
