package com.itingbaby.app.model;

import com.itingbaby.dev.iTingBabyBleDevice;
import com.itingbaby.dev.iTingBabyBleDeviceManager;

/**
 * 蓝牙设备（BlueToothDevice），和历史设备HistoryBleDeviceModel的包装类
 * 互斥关系，二者只能存在一个
 */
public class BleDeviceWrapper {

	public iTingBabyBleDevice bleDevice;
	public HistoryBleDeviceModel historyBleDeviceModel;

	// 名称
	public String name;

	// 类型
	public int deviceType;

	public BleDeviceWrapper() {
	}

	public BleDeviceWrapper(String name, int deviceType) {
		this.name = name;
		this.deviceType = deviceType;
	}

	/**
	 * 获取设备名称
	 * @return
	 */
	public String getDeviceName() {
		if (bleDevice != null) {
			return bleDevice.getName();
		} else if (historyBleDeviceModel != null) {
			return historyBleDeviceModel.getName();
		}
		return name;
	}


	/**
	 * 获取设备mac地址
	 * @return
	 */
	public String getDeviceAddress() {
		if (bleDevice != null) {
			return bleDevice.getAddress();
		} else if (historyBleDeviceModel != null) {
			return historyBleDeviceModel.getMac();
		}
		return "00:00:00:00:00";
	}


	/**
	 * 获取设备类型
	 * @return
	 */
	public int getDeviceType() {
		if (bleDevice != null) {
			return -1;
		} else if (historyBleDeviceModel != null) {
			return historyBleDeviceModel.getType();
		}
		return deviceType;
	}

	/**
	 * 获取设备BLE模块类型
	 * @return
	 */
	public int getDeviceBleType() {
		if (null == bleDevice) {
			return iTingBabyBleDeviceManager.BLE_TYPE_UNKNOWN;
		}
		return bleDevice.getBleType();
	}

}
