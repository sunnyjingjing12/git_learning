package com.itingbaby.app.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class DeviceInfo implements Serializable {

	@SerializedName("type")
	public int deviceType;                            // 设备类型:<br> 0x01：听贝贝 <br> 0x02：EHG设备 <br> 0x1000：凯格尔训练仪

	public String name;                             // 设备名称

	@SerializedName("url")
	public String iconUrl;                          // 设备图片url

	@SerializedName("mac")
	public String deviceMac;                        // 设备mac地址

}
