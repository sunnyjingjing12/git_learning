package com.itingbaby.app.model;

import androidx.annotation.ColorRes;

/**
 * 分割线，用在recyclerview列表中
 */
public class DividerLineEntity {

	@ColorRes
	public int lineColor;

	public int lineHeight;

	public DividerLineEntity(int lineColor, int lineHeight) {
		this.lineColor = lineColor;
		this.lineHeight = lineHeight;

	}

	@Override
	public String toString() {
		return "DividerLineEntity{" +
				"lineColor=" + lineColor +
				", lineHeight=" + lineHeight +
				'}';
	}
}
