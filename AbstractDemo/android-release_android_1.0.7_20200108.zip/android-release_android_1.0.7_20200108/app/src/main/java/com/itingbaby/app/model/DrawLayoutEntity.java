package com.itingbaby.app.model;

/**
 * Created by Administrator on 2017/9/23.
 */

public class DrawLayoutEntity {

    public String itemUrl;
    public String title;
    public String detail;
    public String icon;
}
