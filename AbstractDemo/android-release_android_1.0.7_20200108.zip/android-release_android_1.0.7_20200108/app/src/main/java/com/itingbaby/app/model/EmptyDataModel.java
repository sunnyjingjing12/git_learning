package com.itingbaby.app.model;

/**
 * 无数据页面数据类型
 */
public class EmptyDataModel {

	public String hintTxt;  // 无数据提示文字

	public int drawableResId; // 无数据显示图片

	public EmptyDataModel(String hintTxt, int drawableResId) {
		this.hintTxt = hintTxt;
		this.drawableResId = drawableResId;
	}
}
