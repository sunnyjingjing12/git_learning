package com.itingbaby.app.model;

import com.google.gson.annotations.SerializedName;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.NotNull;
import org.greenrobot.greendao.annotation.Unique;

/**
 * 用户使用过的历史设备列表
 */
@Entity(nameInDb="t_history_ble_device")
public class HistoryBleDeviceModel {

	@NotNull
	private Long uid;		    // 用户ID(对应后台服务器uid)

	private Integer type;		// 设备类型 0听诊 1EHG etc...

	@SerializedName("ble_type")
	private Integer bleType;    // BLE模块类型 0未知 1飞易通 2信驰达 3爱听贝
	
	@NotNull
	private String name;	    // 设备名
	@Unique
	private String mac;		    // 设备MAC
	private Long timestamp;	    // 最后一次使用的时间

	@Generated(hash = 755567734)
	public HistoryBleDeviceModel(@NotNull Long uid, Integer type, Integer bleType,
			@NotNull String name, String mac, Long timestamp) {
		this.uid = uid;
		this.type = type;
		this.bleType = bleType;
		this.name = name;
		this.mac = mac;
		this.timestamp = timestamp;
	}
	@Generated(hash = 1502622098)
	public HistoryBleDeviceModel() {
	}
	public Long getUid() {
		return this.uid;
	}
	public void setUid(Long uid) {
		this.uid = uid;
	}
	public Integer getType() {
		return this.type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Integer getBleType() {
		return this.bleType;
	}
	public void setBleType(Integer bleType) {
		this.bleType = bleType;
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMac() {
		return this.mac;
	}
	public void setMac(String mac) {
		this.mac = mac;
	}
	public Long getTimestamp() {
		return this.timestamp;
	}
	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}
}
