package com.itingbaby.app.model;

/**
 * banner实体
 */
public class HomeCardBanner {

	public String title;         // 标题
	public String url;             // banner预览图地址
	public String action;        // 跳转action

}
