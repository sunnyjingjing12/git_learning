package com.itingbaby.app.model;

import com.google.gson.annotations.SerializedName;
import com.itingbaby.app.model.pelvictrain.PelvicTrainRecord;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class HomeCardDevice implements Serializable {

	public static final long serialVersionUID = 1L;


	@SerializedName("device_info")
	public DeviceInfo deviceInfo;

	@SerializedName("records")
	public List<PelvicTrainRecord> recordsList = new ArrayList<>();// deviceType=0x1000时，解析

}
