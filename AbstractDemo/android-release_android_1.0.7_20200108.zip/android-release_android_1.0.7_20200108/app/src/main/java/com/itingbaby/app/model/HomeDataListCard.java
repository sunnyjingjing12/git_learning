package com.itingbaby.app.model;


import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

/**
 * 用户首页卡片数据结构
 */
public class HomeDataListCard implements Serializable {

	@SerializedName("card_type")
	public int cardType;           // 类型:0为非法类型 0x01：banner列表 0x02：常用工具 0x03：我的设备
	public int      sort;           // 卡片排序
	public String   title;          // 标题
	public String   url;            // 图标url

	public List<HomeCardBanner> banners;       // banner列表，  cardType=0x01时解析
	public List<ToolInfo> tools;         // 常用工具列表，cardType=0x02时解析
	public List<HomeCardDevice> devices;       // 用户设备列表，cardType=0x03时解析

}
