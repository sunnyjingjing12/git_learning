package com.itingbaby.app.model;


import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import static com.itingbaby.app.model.HomeDataListCardType.CARD_TYPE_BANNER;
import static com.itingbaby.app.model.HomeDataListCardType.CARD_TYPE_DEVICES;
import static com.itingbaby.app.model.HomeDataListCardType.CARD_TYPE_TOOLS;

/**
 * 首页数据卡片类型
 */
@Retention(RetentionPolicy.SOURCE)
@IntDef({CARD_TYPE_TOOLS, CARD_TYPE_DEVICES, CARD_TYPE_BANNER})
public @interface HomeDataListCardType {

	int CARD_TYPE_BANNER = 0x01;        // banner
	int CARD_TYPE_TOOLS = 0x02;         // 常用工具
	int CARD_TYPE_DEVICES = 0x03;       // 用户设备

}
