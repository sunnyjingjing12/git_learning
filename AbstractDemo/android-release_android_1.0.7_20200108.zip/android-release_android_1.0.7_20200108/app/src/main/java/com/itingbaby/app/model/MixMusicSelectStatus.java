package com.itingbaby.app.model;

public class MixMusicSelectStatus {

	public static final int MUSIC_MIX_UN_SELECTED = 0;  // 未选择去mix
	public static final int MUSIC_MIX_SELECTED = 1;    // 已选择去mix
}
