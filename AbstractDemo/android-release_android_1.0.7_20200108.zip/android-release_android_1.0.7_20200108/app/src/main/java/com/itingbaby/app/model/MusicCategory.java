package com.itingbaby.app.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * 音乐类别
 */
public class MusicCategory implements Serializable {

	public static final long serialVersionUID = 1L;

	public static final int MUSIC_CATEGORY_USER = 1;

	@SerializedName("id")
	public int id;// 1胎教音乐 2哄睡专家 3摇篮乐曲 4美妙叫声 5益智声乐 6自然声音

	@SerializedName("title")
	public String title;// 标题

	@SerializedName("description")
	public String description;// 描述

	public int gid;// 所属音乐组的ID

	public boolean sharable;    // 该类别音乐是否能分享


	@Override
	public String toString() {
		return "MusicCategory{" +
			"id=" + id +
			", title='" + title + '\'' +
			", description='" + description + '\'' +
		'}';
	}
}
