package com.itingbaby.app.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * 音乐条目
 */
public class MusicClause extends AudioPlayData implements Serializable {

	public static final long serialVersionUID = 1L;

	@SerializedName("id")
	private long id;

	@SerializedName("title")
	private String title;// 标题

	@SerializedName("img_url")
	private String imgUrl;// 图标URL（如果有）

	@SerializedName("file_url")
	private String fileUrl;// 具体音乐文件在服务端的URL

	@SerializedName("duration")
	private int duration;// 音乐文件时长

	@SerializedName("author")
	private String author;// 作者

	@Override
	public Long getId() {
		return id;
	}

	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public String getUrl() {
		return fileUrl;
	}

	@Override
	public Integer getDuration() {
		return duration;
	}

	@Override
	public String getAuthor() {
		return author;
	}

	@Override
	public Integer getType() {
		return -1000;
	}

	@Override
	public Long getTimestamp() {
		return 0L;
	}

	@Override
	public boolean isRemote() {
		return true;
	}

	@Override
	public void setPlaying(boolean playing) {
		isPlaying = playing;
	}

	@Override
	public boolean isPlaying() {
		return isPlaying;
	}


	public void setId(long id) {
		this.id = id;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setFileUrl(String fileUrl) {
		this.fileUrl = fileUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public void setAuthor(String author) {
		this.author = author;
	}



	@Override
	public String toString() {
		return "MusicClause{" +
			"id=" + id +
			", title='" + title + '\'' +
			", imgUrl='" + imgUrl + '\'' +
			", fileUrl='" + fileUrl + '\'' +
			", duration=" + duration +
			", author='" + author + '\'' +
		'}';
	}
}
