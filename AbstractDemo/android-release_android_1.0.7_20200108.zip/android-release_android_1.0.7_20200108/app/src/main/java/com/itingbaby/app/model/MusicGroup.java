package com.itingbaby.app.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

/**
 * 音乐组
 */
public class MusicGroup implements Serializable {

	public static final long serialVersionUID = 1L;

	// 我的音乐组
	public static final int MUSIC_GROUP_ID_MY_VOICE = 1;
	// 精选音乐组
	public static final int MUSIC_GROUP_ID_COMMON = 2;

	@SerializedName("id")
	public int id;          // 音乐组ID

	@SerializedName("title")
	public String title;    // 音乐组标题

	@SerializedName("categories")
	public List<MusicCategory> categoryList;

	@Override
	public String toString() {
		return "MusicGroup{" +
			"id=" + id +
			", title='" + title + '\'' +
		'}';
	}
}
