package com.itingbaby.app.model;

public class MusicSelectStatus {

	public static final int MUSIC_STATUS_UN_KNOWN = 0;  // 未知状态
	public static final int MUSIC_STATUS_NOT_DOWNLOAD = 1;  // 未下载
	public static final int MUSIC_STATUS_DOWNLOADING = 2;  // 下载中
	public static final int MUSIC_STATUS_DOWNLOAD_PAUSE = 3;  // 暂停下载
	public static final int MUSIC_STATUS_DOWNLOAD_FAILED = 4;  // 下载失败
	public static final int MUSIC_STATUS_UN_SELECTED = 5;  // 已下载，未选择
	public static final int MUSIC_STATUS_SELECTED = 6;  //  已下载，已选择
}
