package com.itingbaby.app.model;


import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import static com.itingbaby.app.model.PlayStatus.PLAY_STATUS_INIT;
import static com.itingbaby.app.model.PlayStatus.PLAY_STATUS_PLAYING;
import static com.itingbaby.app.model.PlayStatus.PLAY_STATUS_START_PLAY;


/**
 * 播放器状态
 */
@Retention(RetentionPolicy.SOURCE)
@IntDef({PLAY_STATUS_INIT, PLAY_STATUS_START_PLAY, PLAY_STATUS_PLAYING})
public @interface PlayStatus {
	int PLAY_STATUS_INIT = 0;    // 初始态，和暂停态
	int PLAY_STATUS_START_PLAY = 1;    // 开始播放，缓冲
	int PLAY_STATUS_PLAYING = 2;    // 播放中

}
