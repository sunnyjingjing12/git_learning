package com.itingbaby.app.model;

import android.view.View;

import com.itingbaby.app.R;

/**
 * Created by lihb on 2018/06/09.
 * 首页recrclerview的标题item
 */

public class SimpleTextItem {

    private static final int DEFAULT_HEIGHT = 40;
    private static final int DEFAULT_TEXT_COLOR = R.color.black;
    private static final int DEFAULT_TEXT_SIZE = 16; // 单位sp


    public String title;    // 内容
    public int textColor;   // 字体颜色
    public int textSize;   // 字体颜色
    public int background;  // 背景
    public int height;      // 高度

    public String rightTextContent;  // 右侧文字内容
    public int rightTextVisibility;  // 右侧文字是否显示

    public boolean isSelect;

	public boolean isHorizontalCenter;

    private SimpleTextItem(Builder builder) {
        title = builder.title;
        textColor = builder.textColor;
        textSize = builder.textSize;
        background = builder.background;
        height = builder.height;
        isSelect = builder.isSelect;
        rightTextContent = builder.rightTextContent;
        rightTextVisibility = builder.rightTextVisibility;
		isHorizontalCenter = builder.isHorizontalCenter;
    }


    public static final class Builder {
        private String title;
        private int textColor = DEFAULT_TEXT_COLOR;
        private int textSize = DEFAULT_TEXT_SIZE;   // 字体颜色
        private int background;
        private int height = DEFAULT_HEIGHT;
        private boolean isSelect;
        private String rightTextContent;
        private int rightTextVisibility = View.GONE;
		private boolean isHorizontalCenter = false;

        public Builder() {
        }

        public Builder title(String val) {
            title = val;
            return this;
        }

        public Builder textColor(int val) {
            textColor = val;
            return this;
        }
        public Builder textSize(int val) {
            textSize = val;
            return this;
        }

        public Builder background(int val) {
            background = val;
            return this;
        }

        public Builder height(int val) {
            height = val;
            return this;
        }

        public Builder isSelect(boolean val) {
            isSelect = val;
            return this;
        }
        public Builder rightTextContent(String val) {
            rightTextContent = val;
            return this;
        }
        public Builder rightTextVisibility(int val) {
            rightTextVisibility = val;
            return this;
        }

		public Builder isHorizontalCenter(boolean val) {
			isHorizontalCenter = val;
			return this;
		}

        public SimpleTextItem build() {
            return new SimpleTextItem(this);
        }
    }
}
