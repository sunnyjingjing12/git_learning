package com.itingbaby.app.model;

public class TabDataModel {
	public String tabName1;
	public String tabName2;

	public int selectIndex;

	public TabDataModel(String tabName1, String tabName2, int selectIndex) {
		this.tabName1 = tabName1;
		this.tabName2 = tabName2;
		this.selectIndex = selectIndex;
	}
}
