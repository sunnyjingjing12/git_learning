package com.itingbaby.app.model;

public class ToDoGoodsProgressEntity {
	public float progress;  // 进度
}
