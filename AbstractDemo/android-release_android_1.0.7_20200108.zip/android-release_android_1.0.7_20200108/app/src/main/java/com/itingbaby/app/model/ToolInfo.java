package com.itingbaby.app.model;

import java.io.Serializable;

public class ToolInfo implements Serializable {

	public static final long serialVersionUID = 1L;

	public String name;
	public String url;
	public int type;

	public String action;


	/**
	 * 是否育儿工具
	 *
	 * @return
	 */
	public boolean isBabyType() {
		return (type & ToolType.TOOL_TYPE_BABY) == ToolType.TOOL_TYPE_BABY;
	}

	/**
	 * 是否孕妈工具
	 *
	 * @return
	 */
	public boolean isPregnantType() {
		return (type & ToolType.TOOL_TYPE_PREGNANT) == ToolType.TOOL_TYPE_PREGNANT;
	}

	/**
	 * 是否常用工具
	 *
	 * @return
	 */
	public boolean isRecommendType() {
		return (type & ToolType.TOOL_TYPE_RECOMMEND) == ToolType.TOOL_TYPE_RECOMMEND;
	}

}
