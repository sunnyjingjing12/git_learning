package com.itingbaby.app.model;


import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import static com.itingbaby.app.model.ToolType.TOOL_TYPE_BABY;
import static com.itingbaby.app.model.ToolType.TOOL_TYPE_NOT_VALID;
import static com.itingbaby.app.model.ToolType.TOOL_TYPE_PREGNANT;
import static com.itingbaby.app.model.ToolType.TOOL_TYPE_RECOMMEND;


/**
 * 听贝贝胎心音录制类型
 */
@Retention(RetentionPolicy.SOURCE)
@IntDef({TOOL_TYPE_NOT_VALID, TOOL_TYPE_RECOMMEND, TOOL_TYPE_PREGNANT, TOOL_TYPE_BABY})
public @interface ToolType {
	int TOOL_TYPE_NOT_VALID = 0x00;    //不合法类型
	int TOOL_TYPE_RECOMMEND = 0x01;    //常用
	int TOOL_TYPE_PREGNANT = 0x02;    // 怀孕
	int TOOL_TYPE_BABY = 0x04;    // 育儿


}
