package com.itingbaby.app.model;

/**
 * Created by lihb on 2017/6/28.
 */

public class UpdateInfo {

	public int platform;            // 平台标识 0-未知 1-安卓 2-苹果
	public String version;          // app版本
	public String url;              // 下载链接
	public String description;      // 升级的描述语
	public boolean flag;            // 是否强制升级
	public int gray;                // 灰度比例

}
