package com.itingbaby.app.model;

import com.google.gson.annotations.SerializedName;
import com.itingbaby.baselib.commonutils.StringUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 * Created by lihb on 2018/4/7.
 * 用户信息
 */

public class User implements Serializable {

	public static final long serialVersionUID = 1L;


	public long id;
	public String username;
	public String nickname;
	public String realname;
	public String email;
	public String mobile;
	public String qq;
	public String address;
	public String avatar;
	public Long birthday;
	public long expected_date;
	public Integer gender;
	public Integer height;
	public Integer weight;

	@SerializedName("ext")
	public UserExtension userExtension;

	public String getTelephoneNum(){
		if (null == mobile) {
			return null;
		}
		if (!StringUtils.isEmpty(mobile)) {
			return mobile;
		} else if (StringUtils.checkPhoneNumber(username)) {
			return username;
		}
		return "";
	}

	@Override
	public String toString() {
		return "User{" +
				"  id=" + id +
				", username='" + username + '\'' +
				", nickname='" + nickname + '\'' +
				", realname='" + realname + '\'' +
				", mobile='" + mobile + '\'' +
				", gender=" + gender +
				", email='" + email + '\'' +
				", address='" + address + '\'' +
				", birthday=" + birthday +
				", expected_date=" + expected_date +
				", qq='" + qq + '\'' +
				", avatar='" + avatar + '\'' +
				", height=" + height +
				", weight=" + weight +
				", userExtension=" + userExtension +
				'}';
	}

	public static <T> T cloneObject(T obj) {
		T result = null;
		ByteArrayOutputStream byteArrayOutputStream = null;
		ByteArrayInputStream byteArrayInputStream = null;
		ObjectOutputStream outputStream = null;
		ObjectInputStream inputStream = null;
		try {
			// 对象写到内存中
			byteArrayOutputStream = new ByteArrayOutputStream();
			outputStream = new ObjectOutputStream(byteArrayOutputStream);
			outputStream.writeObject(obj);

			// 从内存中再读出来
			byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
			inputStream = new ObjectInputStream(byteArrayInputStream);
			result = (T) inputStream.readObject();

		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				if (outputStream != null)
					outputStream.close();
				if (inputStream != null)
					inputStream.close();
				if (byteArrayOutputStream != null)
					byteArrayOutputStream.close();
				if (byteArrayInputStream != null)
					byteArrayInputStream.close();

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
}
