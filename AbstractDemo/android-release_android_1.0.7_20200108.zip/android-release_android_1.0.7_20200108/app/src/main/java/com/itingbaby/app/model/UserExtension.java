package com.itingbaby.app.model;


import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class UserExtension implements Serializable {

	@SerializedName("cust_count")
	public Integer custCount;

	@SerializedName("has_pwd")
	public Boolean hasPwd;

	@Override
	public String toString() {
		return "UserExtension{" +
				"custCount=" + custCount +
				", hasPwd=" + hasPwd +
				'}';
	}
}
