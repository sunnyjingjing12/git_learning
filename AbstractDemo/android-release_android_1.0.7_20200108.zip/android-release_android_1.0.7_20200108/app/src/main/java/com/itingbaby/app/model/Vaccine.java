package com.itingbaby.app.model;

import android.content.ContentValues;
import android.database.Cursor;

public class Vaccine {


	public static final String ID = "id";
	public static final String SORT = "sort";
	public static final String TIME = "v_time";
	public static final String NUM = "v_num";
	public static final String NAME = "v_name";
	public static final String INTRO = "v_intro";
	public static final String STATUS = "v_status";
	public static final String TYPE = "v_type";
	public static final String CONTEXT = "v_context";

	public static final String NURSE = "v_nurse";
	public static final String REALTIME = "v_real_time";


	public int id;                     // 序号
	public int sort;                 // 排序
	public int time;                 // 时间，单位为：月
	public String num;                 // 第x次
	public String name;                 // 疫苗名称
	public String intro;             // 预防xxx疾病
	public int status;                 // 是否已经打过，1为没打过，2为已经打过
	public int type;                 // 是否必打针,  1为必打，2为非必打
	public String context;             // 详细介绍，h5格式
	public String nurse;             // 注射的护士
	public String realTime;             // 注射的时间

	public static Vaccine parseCursorToBean(Cursor cursor) {

		Vaccine vaccine = new Vaccine();
		vaccine.id = cursor.getInt(cursor.getColumnIndex(ID));
		vaccine.sort = cursor.getInt(cursor.getColumnIndex(SORT));
		vaccine.time = cursor.getInt(cursor.getColumnIndex(TIME));
		vaccine.num = cursor.getString(cursor.getColumnIndex(NUM));
		vaccine.name = cursor.getString(cursor.getColumnIndex(NAME));
		vaccine.intro = cursor.getString(cursor.getColumnIndex(INTRO));
		vaccine.status = cursor.getInt(cursor.getColumnIndex(STATUS));
		vaccine.type = cursor.getInt(cursor.getColumnIndex(TYPE));
		vaccine.context = cursor.getString(cursor.getColumnIndex(CONTEXT));
		vaccine.nurse = cursor.getString(cursor.getColumnIndex(NURSE));
		vaccine.realTime = cursor.getString(cursor.getColumnIndex(REALTIME));
		return vaccine;
	}

	public static ContentValues buildContentValues(Vaccine vaccine) {
		ContentValues values = new ContentValues();
		values.put(ID, vaccine.id);
		values.put(SORT, vaccine.sort);
		values.put(TIME, vaccine.time);
		values.put(NUM, vaccine.num);
		values.put(NAME, vaccine.name);
		values.put(INTRO, vaccine.intro);
		values.put(STATUS, vaccine.status);
		values.put(TYPE, vaccine.type);
		values.put(CONTEXT, vaccine.context);
		values.put(NURSE, vaccine.nurse);
		values.put(REALTIME, vaccine.realTime);
		return values;
	}


}
