package com.itingbaby.app.model;

import java.util.ArrayList;
import java.util.List;

public class VaccineGroupDataModel {

	public String compInjectDate;   // 计算的注射日期

	public String injectAge;    // 多大，xx月龄

	public String injectNurse;  // 注射护士

	public String realInjectDate;   // 实际的注射日期

	public List<Vaccine> vaccineList = new ArrayList<>();

	// 下次要打的疫苗组
	public boolean isNextInject = false;

}
