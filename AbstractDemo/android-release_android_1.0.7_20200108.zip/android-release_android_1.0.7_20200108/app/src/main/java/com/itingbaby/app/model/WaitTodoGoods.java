package com.itingbaby.app.model;

/**
 * 待产所需物品实体类
 */
public class WaitTodoGoods {

	public static final int FLAG_ADD        = 1 << 0;        // 是否添加
	public static final int FLAG_REQUIRE    = 1 << 1;        // 是否必须
	public static final int FLAG_FINISHED   = 1 << 2;        // 是否完成

	public static final int GOODS_TYPE_MOM = 0;
	public static final int GOODS_TYPE_BABY = 1;


	/***************************************
	 *    flag取值介绍，只能取以下值
	 *    规则：1，必备一定是已添加。 2，非必备未添加，一定是未完成

	 111 ：准备完成，必备，已添加       7
	 101 ：准备完成，非必备，已添加     5
	 001 ：准备未完成，非必备，已添加   1
	 011 ：准备未完成，必备，已添加     3
	 000 ：准备未完成，非必备，未添加   0
	 ******************************************/

	public int id;        // id
	public String name;    // 名称
	public String count;    // 所需个数
	public String intro;    // 介绍

	public int type;        // 物品类型，0x00 宝妈，0x01 宝宝

	public int flag;           // 完成， 必备，添加标记

	public boolean expanded;       // 内容是否展开，客户端本地使用

	@Override
	public String toString() {
		return "WaitTodoGoods{" +
			//"name='" + name + '\'' +
			", flag=" + flag +
		'}';
	}
}
