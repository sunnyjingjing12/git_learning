package com.itingbaby.app.model.action;


import android.text.TextUtils;

import com.itingbaby.baselib.commonutils.Ln;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

public class Action implements Serializable {

	public static final int TYPE_URL_EXTERNAL = 1;       // 外部浏览器
	public static final int TYPE_URL_INTERNAL = 2;       // 内部浏览器

	public static final int TYPE_BABY_MUSIC = 3;       // 宝宝音乐
	public static final int TYPE_EXAMINATION = 4;       // 产检助手
	public static final int TYPE_VACCINE = 5;       // 疫苗助手
	public static final int TYPE_WAIT_GOODS = 6;       // 待产包
	public static final int TYPE_MIX_VOICE = 7;       // 混音


	public long id;
	public int type;
	public String url;
	public String title;
	public boolean urlShareable = true;
	public JSONObject extraData;

	public boolean isFull = false; // 默认false, 不全屏。
	public boolean isLight = false; // 默认false，显示深色icon。


	/**
	 * 解析JSON.
	 *
	 * @param json JSONObject
	 * @return Action
	 * @throws JSONException JSONException
	 */
	public static Action parseJson(JSONObject json) throws JSONException {
		Action action = new Action();
		Ln.d("Action parseJson =%s", json.toString());
		try {
			if (json.has("id")) {
				String id = json.getString("id");
				if (!TextUtils.isEmpty(id)) {
					action.id = Long.parseLong(id.trim());
				}
			}
		} catch (Exception e) {
			Ln.e(e);
		}
		if (json.has("type")) {
			action.type = json.getInt("type");
		}
		if (json.has("url")) {
			action.url = json.getString("url");
		}

		if (json.has("urlShareable")) {
			action.urlShareable = json.getBoolean("urlShareable");
		}

		if (json.has("title")) {
			action.title = json.getString("title");
		}

		if (json.has("extraData")) {
			action.extraData = json.getJSONObject("extraData");
		}

		if (json.has("isFull")) {
			action.isFull = json.getBoolean("isFull");
		}

		if (json.has("isLight")) {
			action.isLight = json.getBoolean("isLight");
		}

		return action;
	}


	public JSONObject toJson() {
		JSONObject json = new JSONObject();
		try {
			json.put("id", id);
			json.put("type", type);
			if (url != null) {
				json.put("url", url);
			}
			json.put("urlShareable", urlShareable);
			json.put("isFull", isFull);
			json.put("isLight", isLight);
			json.put("title", title);

			if (extraData != null) {
				json.put("extraData", extraData);
			}

		} catch (Exception e) {
			Ln.e(e);
		}
		return json;
	}

	public String toJsonString() {
		return toJson().toString();
	}
}
