package com.itingbaby.app.model.action;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.webkit.URLUtil;

import com.itingbaby.app.R;
import com.itingbaby.app.activity.MusicActivity;
import com.itingbaby.app.activity.PregnancyCheckActivity;
import com.itingbaby.app.activity.VaccineActivity;
import com.itingbaby.app.activity.WaitPregnancyActivity;
import com.itingbaby.app.activity.WebViewActivity;
import com.itingbaby.app.activity.mix_video.VoiceMixActivity;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.baselib.commonutils.Ln;

/**
 * Author : lihb
 * Date : 2019/11/19.
 * version : v1.0
 */

public class ActionEngine {

	public static volatile ActionEngine singleton = null;

	private ActionEngine() {

	}

	public static ActionEngine getInstance() {
		if (singleton == null) {
			synchronized (ActionEngine.class) {
				if (singleton == null) {
					singleton = new ActionEngine();
				}
			}
		}
		return singleton;
	}

	public Intent getActionIntent(Action action, Context context, String title, int source, int subSource) {
		return getActionIntent(action, context, title, source, subSource, false);
	}

	/**
	 * 获取Action跳转intent.
	 *
	 * @param context             Context
	 * @param title               title
	 * @param source              source
	 * @param subSource           subSource
	 * @param isInNotificationMsg 是否在NotificationMessage的action
	 * @return Intent
	 */
	public Intent getActionIntent(Action action, Context context, String title, int source, int subSource, boolean isInNotificationMsg) {
		Intent intent = null;
		switch (action.type) {
			case Action.TYPE_URL_EXTERNAL:
				// 外部浏览器
				try {
					if (!TextUtils.isEmpty(action.url) && URLUtil.isValidUrl(action.url)) {
						intent = new Intent(Intent.ACTION_VIEW, Uri.parse(action.url));
					}
				} catch (Exception e) {
					Ln.e(e);
				}
				break;
			case Action.TYPE_URL_INTERNAL:
				// 内部浏览器
				WebViewActivity.navigate(context, action.url, action.title);
				break;
			case Action.TYPE_BABY_MUSIC:
				// 宝宝音乐
				intent = new Intent(context, MusicActivity.class);
				break;
			case Action.TYPE_EXAMINATION:
				// 产检
				intent = new Intent(context, PregnancyCheckActivity.class);
				break;
			case Action.TYPE_VACCINE:
				// 疫苗
				intent = new Intent(context, VaccineActivity.class);
				break;
			case Action.TYPE_WAIT_GOODS:
				// 待产包
				intent = new Intent(context, WaitPregnancyActivity.class);
				break;
			case Action.TYPE_MIX_VOICE:
				// 跳转到混音界面
				intent = new Intent(context, VoiceMixActivity.class);
				break;

			default:
				break;
		}
		return intent;
	}

	private void setOverridePendingTransition(Context context) {
	}


	public boolean action(Action action, Context context, String title) {
		return action(action, context, title, 0, 0);
	}

	/**
	 * 带来源的action跳转.(from outside of an Activity)
	 *
	 * @param applicationContext Context
	 * @return boolean
	 */
	public boolean action(Action action, Context applicationContext) {
		Intent intent = getActionIntent(action, applicationContext, "", 0, 0);
		if (intent != null) {
			try {
				intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				applicationContext.startActivity(intent);
				setOverridePendingTransition(applicationContext);
				return true;
			} catch (Exception e) {
				Ln.e(e, "Action.action type=%s ,title=%s, id=%s, extraData=%s", action.type, "", action.id, action.extraData);
			}
		}
		if (!isValid(action.type)) {
			CommonToast.showShortToast(applicationContext.getResources().getString(R.string.action_not_avalid));
		}
		return false;
	}

	/**
	 * 带来源的action跳转.
	 *
	 * @param context   Context
	 * @param title     title
	 * @param source    source
	 * @param subSource subSource
	 * @return boolean
	 */
	public boolean action(Action action, Context context, String title, int source, int subSource) {
		Intent intent = getActionIntent(action, context, title, source, subSource);
		if (intent != null) {
			try {
				if (!(context instanceof Activity)) {
					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				}

				context.startActivity(intent);
				setOverridePendingTransition(context);
				return true;
			} catch (Exception e) {
				Ln.e(e, "Action.action type=%s ,title=%s, id=%s, extraData=%s", action.type, title, action.id, action.extraData);
			}
		}
		if (!isValid(action.type)) {
			CommonToast.showShortToast(context.getResources().getString(R.string.action_not_avalid));
		}
		return false;
	}


	/**
	 * 是否为有效类型.
	 *
	 * @param type
	 * @return boolean
	 */
	public boolean isValid(int type) {
		if (type == Action.TYPE_URL_EXTERNAL
				|| type == Action.TYPE_URL_INTERNAL
				|| type == Action.TYPE_BABY_MUSIC
				|| type == Action.TYPE_EXAMINATION
				|| type == Action.TYPE_VACCINE
				|| type == Action.TYPE_WAIT_GOODS
				|| type == Action.TYPE_MIX_VOICE) {
			return true;
		}
		return false;
	}


}
