package com.itingbaby.app.model.httpmodel;

public class BaseHttpResponse {

	public int code;
	public String msg;

	@Override
	public String toString() {
		return "BaseHttpResponse{" +
				"code=" + code +
				", msg='" + msg + '\'' +
				'}';
	}
}
