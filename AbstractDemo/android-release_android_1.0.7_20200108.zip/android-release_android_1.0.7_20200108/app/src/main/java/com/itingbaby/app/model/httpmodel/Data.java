package com.itingbaby.app.model.httpmodel;

import com.google.gson.annotations.SerializedName;
import com.itingbaby.app.model.pelvictrain.Page;
import com.itingbaby.app.model.pelvictrain.PelvicTrainRecord;

import java.io.Serializable;

public class Data implements Serializable {

	public Page page;

	@SerializedName("mstest")
	public PelvicTrainRecord pelvicTrainRecord;
}
