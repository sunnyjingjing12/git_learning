package com.itingbaby.app.model.httpmodel;

/**
 * Created by lhb on 2017/2/22.
 */

public class HttpPageResponse<T> extends HttpResponse<T> {


    public int pages;
    public int returnpage;  //返回的页码
    public int nextpage;
    public int requestpage; //请求的页码

    public void setPages(int pages) {
        this.pages = pages;
    }

    public void setReturnpage(int returnpage) {
        this.returnpage = returnpage;
    }

    public void setNextpage(int nextpage) {
        this.nextpage = nextpage;
    }

    public void setRequestpage(int requestpage) {
        this.requestpage = requestpage;
    }


}
