package com.itingbaby.app.model.pelvictrain;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * 肌力数值
 */
public class MuscleForceData implements Serializable {

	public static final long serialVersionUID = 1L;

	// 慢肌数值
	@SerializedName("muscle_lv1")
	public int cOneMuscle;

	// 快肌数值
	@SerializedName("muscle_lv2")
	public int cTwoMuscle;

	@Override
	public String toString() {
		return "MuscleForceData{" +
			"cOneMuscle=" + cOneMuscle +
			", cTwoMuscle=" + cTwoMuscle +
		'}';
	}
}
