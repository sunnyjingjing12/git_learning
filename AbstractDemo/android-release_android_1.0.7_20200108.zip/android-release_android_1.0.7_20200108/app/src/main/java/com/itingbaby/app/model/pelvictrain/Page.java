package com.itingbaby.app.model.pelvictrain;

import java.util.List;

public class Page {

	public int endRow;
	public int firstPage;
	public boolean hasNextPage;
	public boolean hasPreviousPage;
	public boolean isFirstPage;
	public boolean isLastPage;
	public int lastPage;
	public List<PelvicTrainRecord> list;
	public int navigatePages;
	public List<Integer> navigatepageNums;
	public int nextPage;
	public int pageNum;
	public int pageSize;
	public int pages;
	public int prePage;
	public int size;
	public int startRow;
	public int total;
}
