package com.itingbaby.app.model.pelvictrain;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 肌力测试，训练记录实体类
 */
public class PelvicTrainRecord implements Serializable {

	public static final long serialVersionUID = 1L;

	// 此次训练方案id
	@SerializedName("id")
	public long id;

	// 训练方案名称
	@SerializedName("case_name")
	public String caseName;

	// 一类肌力
	@SerializedName("muscle_lv1")
	public int oneMuscle;

	// 二类肌力
	@SerializedName("muscle_lv2")
	public int twoMuscle;

	// 最大收缩力
	@SerializedName("max_power")
	public float maxPower;

	// 训练日期
	@SerializedName("timestamp")
	public long recordTimeStamp;

	public List<MuscleForceData> child = new ArrayList<>();

	// 测试，训练后的评价
	public String tester;

	@Override
	public String toString() {
		return "PelvicTrainRecord{" +
				"id=" + id +
				", caseName='" + caseName + '\'' +
				", oneMuscle=" + oneMuscle +
				", twoMuscle=" + twoMuscle +
				", maxPower=" + maxPower +
				", recordTimeStamp=" + recordTimeStamp +
				", tester='" + tester + '\'' +
				'}';
	}

}
