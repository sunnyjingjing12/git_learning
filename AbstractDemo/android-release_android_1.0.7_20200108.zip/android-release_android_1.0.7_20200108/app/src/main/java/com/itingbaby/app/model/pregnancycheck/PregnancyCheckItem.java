package com.itingbaby.app.model.pregnancycheck;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PregnancyCheckItem implements Serializable {

	public static final long serialVersionUID = 1L;

	@SerializedName("title")
	public String title;

	@SerializedName("time")
	public String time;

	@SerializedName("tips")
	public String tips;

	@SerializedName("items")
	public List<PregnancyCheckSubItem> subItemList = new ArrayList<>();

	@SerializedName("images")
	public List<PregnancyCheckReportImg> reportImgList = new ArrayList<>();

}
