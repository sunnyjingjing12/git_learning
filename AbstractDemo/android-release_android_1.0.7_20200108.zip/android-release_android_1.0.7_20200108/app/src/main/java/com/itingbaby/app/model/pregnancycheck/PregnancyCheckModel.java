package com.itingbaby.app.model.pregnancycheck;

import android.content.ContentValues;
import android.database.Cursor;

public class PregnancyCheckModel {

	public static final int SHOW_FLAG_EXPIRED = 0x00; //已过期
	public static final int SHOW_FLAG_NEXT_REMIND = 0x01; //下一次产检
	public static final int SHOW_FLAG_NOT_EXPIRE = 0x02; //未过期

	public static final String ID = "_id";
	public static final String AN_NAME = "an_name";
	public static final String AN_WEEK = "an_week";
	public static final String AN_FLAG = "an_flag";
	public static final String AN_SUMMERY = "an_summery";
	public static final String AN_CONTENT = "an_content";
	public static final String AN_DATE = "an_date";
	public static final String AN_INTERVAL = "an_interval";

	public int id;
	public String name;
	public String week;
	public int flag;
	public String summery;
	public String content;
	public String date;
	public int interval;

	public int showFlag = SHOW_FLAG_NOT_EXPIRE; // 默认为未过期， 本地使用，不存数据库


	public static PregnancyCheckModel parseCursorToBean(Cursor cursor) {

		PregnancyCheckModel model = new PregnancyCheckModel();
		model.id = cursor.getInt(cursor.getColumnIndex(ID));
		model.name = cursor.getString(cursor.getColumnIndex(AN_NAME));
		model.week = cursor.getString(cursor.getColumnIndex(AN_WEEK));
		model.flag = cursor.getInt(cursor.getColumnIndex(AN_FLAG));
		model.summery = cursor.getString(cursor.getColumnIndex(AN_SUMMERY));
		model.content = cursor.getString(cursor.getColumnIndex(AN_CONTENT));
		model.date = cursor.getString(cursor.getColumnIndex(AN_DATE));
		model.interval = cursor.getInt(cursor.getColumnIndex(AN_INTERVAL));
		return model;
	}

	public static ContentValues buildContentValues(PregnancyCheckModel model) {
		ContentValues values = new ContentValues();
		values.put(ID, model.id);
		values.put(AN_NAME, model.name);
		values.put(AN_WEEK, model.week);
		values.put(AN_FLAG, model.flag);
		values.put(AN_SUMMERY, model.summery);
		values.put(AN_CONTENT, model.content);
		values.put(AN_DATE, model.date);
		values.put(AN_INTERVAL, model.interval);
		return values;
	}

	public static ContentValues buildUpdateContentValues(PregnancyCheckModel model) {
		ContentValues values = new ContentValues();
		values.put(AN_FLAG, model.flag);
		return values;
	}

	/**
	 * 是否过期
	 *
	 * @return
	 */
	public boolean isExpired() {
		return showFlag == SHOW_FLAG_EXPIRED;
	}

	/**
	 * 是否下一个产检项目
	 *
	 * @return
	 */
	public boolean isNextRemind() {
		return showFlag == SHOW_FLAG_NEXT_REMIND;
	}
}
