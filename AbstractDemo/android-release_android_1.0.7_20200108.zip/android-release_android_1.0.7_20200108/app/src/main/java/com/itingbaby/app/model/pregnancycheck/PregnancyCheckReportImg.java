package com.itingbaby.app.model.pregnancycheck;

public class PregnancyCheckReportImg {
	public int id;
	public String url;
}
