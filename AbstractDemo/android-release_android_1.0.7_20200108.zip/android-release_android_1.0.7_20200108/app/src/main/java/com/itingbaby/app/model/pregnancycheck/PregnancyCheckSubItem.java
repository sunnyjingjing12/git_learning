package com.itingbaby.app.model.pregnancycheck;

public class PregnancyCheckSubItem {

	public String title;
	public String content;

}
