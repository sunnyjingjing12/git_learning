package com.itingbaby.app.observer;

import android.bluetooth.BluetoothDevice;

public interface Observable {

    void addObserver(Observer obj);

    void deleteObserver(Observer obj);

    void notifyObserver(BluetoothDevice bleDevice);
}
