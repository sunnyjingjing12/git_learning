package com.itingbaby.app.observer;

import android.bluetooth.BluetoothDevice;

public interface Observer {

    void disConnected(BluetoothDevice bleDevice);
}
