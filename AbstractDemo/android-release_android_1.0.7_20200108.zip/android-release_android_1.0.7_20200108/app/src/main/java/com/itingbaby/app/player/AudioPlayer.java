package com.itingbaby.app.player;

public interface AudioPlayer {

	public static final int AUDIO_NET_STATUS_ERROR = -1;
	public static final int AUDIO_NET_STATUS_IDLE = 0;
	public static final int AUDIO_NET_STATUS_BEGIN = 1;
	public static final int AUDIO_NET_STATUS_PLAYING = 2;

	void play(String url);

	void pause();

	void stop();

	void release();
}
