package com.itingbaby.app.player;

import android.content.Context;

public class AudioPlayerFactory {
	public static final int PLAYER_AUDIO_TRACK = 1;
	public static final int PLAYER_MEDIA_PLAYER = 2;

	public static AudioPlayer getAudioPlayer(int type, Context context) {

		AudioPlayer player;
		if (type == PLAYER_AUDIO_TRACK) {
			player = new ItbAudioTrackPlayer();
		} else {
			player = new ItbMediaPlayer(context);
		}
		return player;
	}
}
