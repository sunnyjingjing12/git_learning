package com.itingbaby.app.player;

import android.media.AudioManager;
import android.media.AudioTrack;

import com.itingbaby.app.event.EventAudioPlayerComplete;
import com.itingbaby.app.event.EventAudioPlayerData;
import com.itingbaby.app.event.EventAudioPlayerProgress;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.dev.iTingBabyBleDeviceManager;

import org.greenrobot.eventbus.EventBus;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.util.Timer;
import java.util.TimerTask;

public class ItbAudioTrackPlayer implements AudioPlayer {

	private final int BYTES_PER_SEC = iTingBabyBleDeviceManager.MY_SAMPLE_RATE * iTingBabyBleDeviceManager.BITS_PER_SAMPLE * iTingBabyBleDeviceManager.NUM_CHANNELS / iTingBabyBleDeviceManager.BITS_PER_BYTE;

	private AudioTrack audioTrack;
	private boolean running;
	private FileInputStream fileInputStream;
	private DataInputStream dataInputStream;// 本地录音文件数据输入流对象
	private int bytesCount;// 累计从PCM文件取了多少字节
	private int totalSize;// 本地录音文件总字节数

	private String fileUrl; // 当前播放文件地址

	private Timer timer;
	private TimerTask timerTask;

	public ItbAudioTrackPlayer() {
		int bufferSize = AudioTrack.getMinBufferSize(
				iTingBabyBleDeviceManager.MY_SAMPLE_RATE,
				iTingBabyBleDeviceManager.MY_CHANNEL_CONFIG,
				iTingBabyBleDeviceManager.MY_AUDIO_FORMAT);
		//Log.i("SampleRate:" + iTingBabyBleDeviceManager.MY_SAMPLE_RATE + " min buffer size:" + bufferSize);
		if (audioTrack == null) {
			audioTrack = new AudioTrack(AudioManager.STREAM_MUSIC,
					iTingBabyBleDeviceManager.MY_SAMPLE_RATE,
					iTingBabyBleDeviceManager.MY_CHANNEL_CONFIG,
					iTingBabyBleDeviceManager.MY_AUDIO_FORMAT,
					bufferSize * 3, AudioTrack.MODE_STREAM);
		}
		if (!running) {
			initAudioTrackPlayThread();
		}
	}

	@Override
	public void play(String url) {
		if (null == url || 0 == url.length()) {
			return;
		}
		Ln.d("lihb url =%s, fileUrl=%s", url, fileUrl);
		try {
			fileInputStream = new FileInputStream(url);
			totalSize = fileInputStream.available();
			dataInputStream = new DataInputStream(new BufferedInputStream(fileInputStream));
			bytesCount = 0;

			if (AudioTrack.PLAYSTATE_PLAYING != audioTrack.getPlayState()) {
				audioTrack.play();
			}
			fileUrl = url;

			// 先停止老的计时器，在开启一个新的
			stopProgressTimer();
			startProgressTimer();

		} catch (Exception e) {
			Ln.e(e);
		}


	}

	@Override
	public void pause() {
		if (AudioTrack.PLAYSTATE_PLAYING == audioTrack.getPlayState()) {
			audioTrack.pause();
		}
	}

	@Override
	public void stop() {
		audioTrack.stop();
	}

	@Override
	public void release() {
		running = false;
		if (audioTrack != null) {
			audioTrack.release();
		}
		stopProgressTimer();
		fileUrl = null;
	}


	private void initAudioTrackPlayThread() {
		// 创建PCM播放线程
		new Thread(new Runnable() {
			@Override
			public void run() {
				byte[] audioData = new byte[400];
				short[] audioData16 = new short[200];
				running = true;
				try {
					while (running) {
						int playState = audioTrack.getPlayState();
						if (AudioTrack.PLAYSTATE_PAUSED == playState || AudioTrack.PLAYSTATE_STOPPED == playState) {
							continue;
						}

						if (null != dataInputStream) {
							int len = dataInputStream.read(audioData);
							if (-1 != len) {
								bytesCount += len;
								audioTrack.write(audioData, 0, len);
								toShortArray(audioData, len, audioData16);
								EventBus.getDefault().post(new EventAudioPlayerData(audioData16));
							} else {
								bytesCount = 0;
								audioTrack.stop();
								EventBus.getDefault().post(new EventAudioPlayerComplete());
							}
						}
					}

					if (null != dataInputStream) {
						dataInputStream.close();
						dataInputStream = null;
					}

					audioTrack.stop();
					//audioTrack.release();
					//audioTrack = null;
				} catch (Exception e) {
					Ln.e(e.getMessage());
				}
			}
		}).start();
	}


	private void startProgressTimer() {
		if (null != timer) {
			return;
		}
		timer = new Timer();
		timerTask = new TimerTask() {
			@Override
			public void run() {

				int pos = bytesCount / BYTES_PER_SEC;
				Ln.i("lihb 当前本地播放进度是" + pos);
				EventBus.getDefault().post(new EventAudioPlayerProgress(pos));


			}
		};
		timer.schedule(timerTask, 0, 1000);
	}

	private void stopProgressTimer() {
		if (null != timer) {
			timer.cancel();
			timer = null;
		}
		if (null != timerTask) {
			timerTask.cancel();
			timerTask = null;
		}
	}


	// 字节数组转16位整型数组
	private static void toShortArray(byte[] src, int len, short[] dest) {
		int count = len >> 1;
		for (int i = 0; i < count; i++) {
			dest[i] = (short) (src[i * 2] << 8 | src[2 * i + 1] & 0xff);
		}
	}

	// 16位整型数组转字节数组
	private static byte[] toByteArray(short[] src) {
		int count = src.length;
		byte[] dest = new byte[count << 1];
		for (int i = 0; i < count; i++) {
			dest[i * 2] = (byte) (src[i] >> 8);
			dest[i * 2 + 1] = (byte) (src[i] >> 0);
		}

		return dest;
	}

}
