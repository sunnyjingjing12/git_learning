package com.itingbaby.app.player;

import android.content.Context;
import android.net.Uri;

import androidx.annotation.Nullable;

import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.database.DatabaseProvider;
import com.google.android.exoplayer2.database.ExoDatabaseProvider;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;
import com.google.android.exoplayer2.upstream.FileDataSourceFactory;
import com.google.android.exoplayer2.upstream.HttpDataSource;
import com.google.android.exoplayer2.upstream.cache.Cache;
import com.google.android.exoplayer2.upstream.cache.CacheDataSource;
import com.google.android.exoplayer2.upstream.cache.CacheDataSourceFactory;
import com.google.android.exoplayer2.upstream.cache.NoOpCacheEvictor;
import com.google.android.exoplayer2.upstream.cache.SimpleCache;
import com.google.android.exoplayer2.util.Util;
import com.itingbaby.app.event.EventAudioPlayerComplete;
import com.itingbaby.app.event.EventAudioPlayerNetPreparation;
import com.itingbaby.app.event.EventAudioPlayerProgress;
import com.itingbaby.baselib.commonutils.ApplicationUtils;
import com.itingbaby.baselib.commonutils.Ln;

import org.greenrobot.eventbus.EventBus;

import java.io.File;
import java.util.Timer;
import java.util.TimerTask;

public class ItbMediaPlayer implements AudioPlayer, Player.EventListener {

	private DataSource.Factory dataSourceFactory;
	private SimpleExoPlayer player;
	private MediaSource mediaSource;

	private DatabaseProvider databaseProvider;
	private File downloadDirectory;
	private Cache downloadCache;

	private String fileUrl;

	private Timer timer;            // 远程文件播放进度定时刷新
	private TimerTask timerTask;

	public ItbMediaPlayer(Context context) {
		if (dataSourceFactory == null) {
			dataSourceFactory = buildDataSourceFactory(context);
		}
		if (player == null) {
			player = ExoPlayerFactory.newSimpleInstance(context);
			player.addListener(this);
			player.setPlayWhenReady(true);
		}
	}

	@Override
	public void play(String url) {
		if (null == url || 0 == url.length()) {
			return;
		}
		try {
			Ln.d("lihb url =%s, fileUrl=%s", url, fileUrl);
			if (!url.equals(this.fileUrl)) {
				mediaSource = new ProgressiveMediaSource.Factory(dataSourceFactory).createMediaSource(Uri.parse(url));
				player.prepare(mediaSource);
				player.setPlayWhenReady(true);
				fileUrl = url;
			} else {
				player.setPlayWhenReady(true);
			}

			stopProgressTimer();
			startProgressTimer();

		} catch (Exception e) {
			Ln.e(e);
		}
	}

	@Override
	public void pause() {
		if (player != null) {
			player.setPlayWhenReady(false);
		}
	}

	@Override
	public void stop() {
		if (player != null) {
			player.stop();
		}
	}

	@Override
	public void release() {
		if (player != null) {
			player.stop();
			player.release();
			player = null;
			dataSourceFactory = null;
			databaseProvider = null;
			mediaSource = null;
			downloadCache.release();
			downloadCache = null;
			downloadDirectory = null;

		}
		stopProgressTimer();
		fileUrl = null;
	}


	private void startProgressTimer() {
		if (null != timer) {
			return;
		}
		timer = new Timer();
		timerTask = new TimerTask() {
			@Override
			public void run() {
				ApplicationUtils.mMainHandler.post(() -> {
					if (player != null) {
						int pos = (int) (player.getCurrentPosition() / 1000);
						Ln.i("lihb 当前远程播放进度是" + pos);
						EventBus.getDefault().post(new EventAudioPlayerProgress(pos));
					}
				});


			}
		};
		timer.schedule(timerTask, 0, 1000);
	}

	private void stopProgressTimer() {
		if (null != timer) {
			timer.cancel();
			timer = null;
		}
		if (null != timerTask) {
			timerTask.cancel();
			timerTask = null;
		}
	}

	private DataSource.Factory buildDataSourceFactory(Context ctx) {
		DefaultDataSourceFactory upstreamFactory = new DefaultDataSourceFactory(ctx, buildHttpDataSourceFactory(ctx));
		return buildReadOnlyCacheDataSource(upstreamFactory, getDownloadCache(ctx));
	}

	private HttpDataSource.Factory buildHttpDataSourceFactory(Context ctx) {
		return new DefaultHttpDataSourceFactory(Util.getUserAgent(ctx, "TBAI"));
	}

	private static CacheDataSourceFactory buildReadOnlyCacheDataSource(DataSource.Factory upstreamFactory, Cache cache) {
		return new CacheDataSourceFactory(
				cache,
				upstreamFactory,
				new FileDataSourceFactory(),
				/* cacheWriteDataSinkFactory= */ null,
				CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR,
				/* eventListener= */ null);
	}

	private synchronized Cache getDownloadCache(Context ctx) {
		if (downloadCache == null) {
			File downloadContentDirectory = new File(getDownloadDirectory(ctx), "donwloads");
			downloadCache = new SimpleCache(downloadContentDirectory, new NoOpCacheEvictor(), getDatabaseProvider(ctx));
		}
		return downloadCache;
	}

	private File getDownloadDirectory(Context ctx) {
		if (downloadDirectory == null) {
			downloadDirectory = ctx.getExternalFilesDir(null);
			if (downloadDirectory == null) {
				downloadDirectory = ctx.getFilesDir();
			}
		}
		return downloadDirectory;
	}

	private DatabaseProvider getDatabaseProvider(Context ctx) {
		if (databaseProvider == null) {
			databaseProvider = new ExoDatabaseProvider(ctx);
		}
		return databaseProvider;
	}


	// region Exo播放器回调
	@Override
	public void onTimelineChanged(Timeline timeline, @Nullable Object manifest, int reason) {
		Ln.i("onTimelineChanged, timeline =%s ,reason = %d", timeline, reason);
	}

	@Override
	public void onTracksChanged(TrackGroupArray trackGroups, TrackSelectionArray trackSelections) {
		Ln.i("onTracksChanged , trackGroups =%s ,trackSelections = %s", trackGroups, trackSelections);
	}

	@Override
	public void onLoadingChanged(boolean isLoading) {
		Ln.i("onLoadingChanged isLoading = %b", isLoading);
	}

	@Override
	public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {
		switch (playbackState) {
			case ExoPlayer.STATE_ENDED:
				Ln.i("Playback ended!");
				// Stop playback and return to start position

				this.fileUrl = null;
				EventBus.getDefault().post(new EventAudioPlayerComplete());
				break;
			case ExoPlayer.STATE_READY:// 播放器准备好了
				long pos = player.getCurrentPosition();
				long duration = player.getDuration();
				Ln.i("ExoPlayer ready! pos: %s, duration: %s", pos, duration);
				Ln.d("[ExoPlayer] AUDIO_NET_STATUS_PLAYING playWhenReady=%b, playbackState =%d", playWhenReady, playbackState);
				if (playWhenReady) {
					EventBus.getDefault().post(new EventAudioPlayerNetPreparation(AUDIO_NET_STATUS_PLAYING));
				}
				break;
			case ExoPlayer.STATE_BUFFERING:// 开始缓冲
				Ln.i("Playback buffering!");
				//mProgressBar.setVisibility(View.VISIBLE);
				EventBus.getDefault().post(new EventAudioPlayerNetPreparation(AUDIO_NET_STATUS_BEGIN));
				break;
			case ExoPlayer.STATE_IDLE:
				Ln.i("ExoPlayer idle!");
				break;
		}
	}

	@Override
	public void onRepeatModeChanged(int repeatMode) {
		Ln.i("onRepeatModeChanged %d", repeatMode);
	}

	@Override
	public void onShuffleModeEnabledChanged(boolean shuffleModeEnabled) {
		Ln.i("onShuffleModeEnabledChanged %b", shuffleModeEnabled);
	}

	@Override
	public void onPlayerError(ExoPlaybackException error) {
		Ln.i("onPlayerError %s", error.getMessage());
	}

	@Override
	public void onPositionDiscontinuity(int reason) {
		Ln.i("onPositionDiscontinuity %d", reason);
	}

	@Override
	public void onPlaybackParametersChanged(PlaybackParameters playbackParameters) {
		Ln.i("onPlaybackParametersChanged %s", playbackParameters);
	}

	@Override
	public void onSeekProcessed() {
		Ln.i("onSeekProcessed");
	}
	// endregion
}
