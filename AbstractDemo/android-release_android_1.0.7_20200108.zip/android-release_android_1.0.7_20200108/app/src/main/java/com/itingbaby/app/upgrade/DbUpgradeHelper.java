package com.itingbaby.app.upgrade;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase.CursorFactory;

import com.itingbaby.app.model.DaoMaster;

import org.greenrobot.greendao.database.Database;

public class DbUpgradeHelper extends DaoMaster.DevOpenHelper {
	/**
	 * 数据库修改记录
	 * <p>
	 * DB version：1
	 * 1、新增t_audio_record表
	 * 2、新增t_history_ble_device表
	 * <p>
	 * DB version：2
	 * 1、t_history_ble_device表新增字段“BLE_TYPE”
	 */

	private static final String TAG = DbUpgradeHelper.class.getSimpleName();

	public DbUpgradeHelper(Context context, String name) {
		super(context, name);
	}

	public DbUpgradeHelper(Context context, String name, CursorFactory factory) {
		super(context, name, factory);
	}

	@Override
	public void onUpgrade(Database db, int oldVersion, int newVersion) {
		//Log.i(TAG, "本地数据库升级回调函数调用");
		if (oldVersion <= 1 && newVersion >= 2) {
			updateToNewVersion_2(db);
		}
	}

	private void updateToNewVersion_2(Database db) {
		// 把2改成3，把1改成2,把0改成1
		db.execSQL("UPDATE t_audio_record SET type = 3 WHERE type = 2");
		db.execSQL("UPDATE t_audio_record SET type = 2 WHERE type = 1");
		db.execSQL("UPDATE t_audio_record SET type = 1 WHERE type = 0");
		db.execSQL("ALTER TABLE t_history_ble_device ADD COLUMN BLE_TYPE INT DEFAULT 0");
	}

}
