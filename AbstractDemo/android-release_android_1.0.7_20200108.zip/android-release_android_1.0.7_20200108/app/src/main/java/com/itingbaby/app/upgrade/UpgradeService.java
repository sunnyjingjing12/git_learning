package com.itingbaby.app.upgrade;

import android.content.Intent;
import android.os.IBinder;

import com.allenliu.versionchecklib.AVersionService;
import com.itingbaby.app.R;
import com.itingbaby.app.model.UpdateInfo;
import com.itingbaby.app.utils.CommonToast;
import com.itingbaby.app.utils.GsonHelper;
import com.itingbaby.app.utils.SharedPreferencesUtil;
import com.itingbaby.baselib.commonutils.Ln;

public class UpgradeService extends AVersionService {

    public final static long CHECK_VERSION_DURATION_3_DAY = 3 * 24 * 60 * 60000L;// 3天
    public final static long CHECK_VERSION_DURATION_14_DAY = 14 * 24 * 60 * 60000L;// 14天

    private int mFrom;
    private long time;
    private int times;

    public UpgradeService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            mFrom = intent.getIntExtra(UpgradeUtil.FROM, UpgradeUtil.FROM_MAIN_ACTIVITY);
        }
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onResponses(AVersionService service, String response) {
        Ln.e("UpgradeService", response);
        UpdateInfo info = GsonHelper.jsonToObject(response, UpdateInfo.class);
        if (info != null) {
//            info.url = "https://www.itingbaby.com/upload/app/app-debug-1.0.apk";
            boolean showDialog = canShowVersionDialog(info.version);
            if (showDialog) {
                if (UpgradeUtil.compareVersion(UpgradeUtil.getVersionName(service), info.version) == -1) {
                    times++;
                    SharedPreferencesUtil.setCheckVersionTimes(this, times);
                    SharedPreferencesUtil.setLastCheckVersionTime(this, System.currentTimeMillis());
                    SharedPreferencesUtil.setNewestVersion(this, info.version);

                    service.showVersionDialog(info.url, getString(R.string.checked_new_version, info.version), info.description, info.flag);
                } else {
                    if (mFrom == UpgradeUtil.FROM_ME_FRAGMENT) {
                        CommonToast.showShortToast(R.string.already_newest_version);
                    }
                }
            }
        }
    }

    private boolean canShowVersionDialog(String version) {
        boolean showDialog = false;
        time = SharedPreferencesUtil.getLastCheckVersionTime(this);
        times = SharedPreferencesUtil.getCheckVersionTimes(this);

        String newestVersion = SharedPreferencesUtil.getNewestVersion(this);
        if (version != null && !version.equals(newestVersion)) {
            SharedPreferencesUtil.setLastCheckVersionTime(this, 0L);
            SharedPreferencesUtil.setCheckVersionTimes(this, 0);
            SharedPreferencesUtil.setNewestVersion(this, "");
        }

        if (times < 3) {
            if (System.currentTimeMillis() - time > CHECK_VERSION_DURATION_3_DAY) {
                showDialog = true;
            }
        } else {
            if (System.currentTimeMillis() - time > CHECK_VERSION_DURATION_14_DAY) {
                showDialog = true;
            }
        }
        return showDialog;
    }
}
