package com.itingbaby.app.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.itingbaby.app.R;
import com.itingbaby.baselib.commonutils.Ln;


public class AlarmReceiver extends BroadcastReceiver {
	@Override
	public void onReceive(Context context, Intent intent) {
		if (intent.getAction().equals(AlarmTimerUtil.TIMER_ACTION_REPEATING)) {
			Ln.d("alarm_receiver 周期闹钟");

		} else if (intent.getAction().equals(AlarmTimerUtil.TIMER_ACTION_VACCINE)) {
			Ln.d("alarm_receiver 定时闹钟-疫苗");
			String date = intent.getStringExtra(AlarmTimerUtil.ALARM_INTENT_EXTRA);
			CommonNotificationUtils.showRemindNotification(context, CommonNotificationUtils.NOTIFY_REMIND_VACCINE_ID, String.format(context.getString(R.string.txt_remind_vaccine_tips), date));
		} else if (intent.getAction().equals(AlarmTimerUtil.TIMER_ACTION_EXAMINATION)) {
			Ln.d("alarm_receiver 定时闹钟-产检");

			CommonNotificationUtils.showRemindNotification(context, CommonNotificationUtils.NOTIFY_REMIND_EXAMINATION_ID, context.getString(R.string.txt_remind_examination_tips));
		}
	}
}