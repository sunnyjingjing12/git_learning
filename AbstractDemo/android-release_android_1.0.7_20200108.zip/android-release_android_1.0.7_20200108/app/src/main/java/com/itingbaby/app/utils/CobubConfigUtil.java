package com.itingbaby.app.utils;

import android.content.Context;

import com.umeng.analytics.MobclickAgent;

import java.util.Map;

public class CobubConfigUtil {

    // 设备连接成功
    public static final String EVENT_CONNECTED_DEVICE = "EVENT_CONNECTED_DEVICE";

    //点击录音按钮
    public static final String EVENT_RECORD_BTN_CLICKED = "EVENT_RECORD_BTN_CLICKED";

    // 录音文件时长
    public static final String EVENT_RECORD_DURATION = "EVENT_RECORD_DURATION";


}
