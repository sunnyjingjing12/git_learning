package com.itingbaby.app.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.activity.EntryPointActivity;
import com.itingbaby.app.activity.PregnancyCheckActivity;
import com.itingbaby.app.activity.VaccineActivity;
import com.itingbaby.baselib.commonutils.ApplicationContext;
import com.itingbaby.baselib.commonutils.Ln;

import java.util.ArrayList;
import java.util.List;


public class CommonNotificationUtils {

	public static final int NOTIFY_REMIND_VACCINE_ID = 0x1000;
	public static final int NOTIFY_REMIND_EXAMINATION_ID = 0x1001;
	private static final String CHANNEL_ID = "tbai";

	public static List<Integer> mChatNotifyIdList = new ArrayList<>();
	public static List<Integer> mCommentNotifyIdList = new ArrayList<>();
	private static NotificationChannel mChannel = null;


	private static final void notify(Context context, int id, Notification notification) {
		notify(context, null, id, notification);
	}

	private static final void notify(Context context, String tag, int id,
									 Notification notification) {
		NotificationManager nm = (NotificationManager) context
				.getSystemService(Context.NOTIFICATION_SERVICE);

		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
			if (mChannel == null) {
				mChannel = new NotificationChannel(CHANNEL_ID, "tbai", NotificationManager.IMPORTANCE_HIGH);
				// 配置通知渠道的属性
				mChannel.setDescription("甜贝通知");
				//闪光灯
				mChannel.enableLights(true);
				//锁屏显示通知
				mChannel.setLockscreenVisibility(Notification.VISIBILITY_SECRET);
				//闪关灯的灯光颜色
				mChannel.setLightColor(Color.WHITE);
				//桌面launcher的消息角标
				mChannel.canShowBadge();
				mChannel.setShowBadge(true);
				//是否允许震动
				mChannel.enableVibration(true);
				//获取系统通知响铃声音的配置
				mChannel.getAudioAttributes();
				//获取通知取到组
				mChannel.getGroup();
				//设置可绕过  请勿打扰模式
				mChannel.setBypassDnd(true);
				//设置震动模式
				mChannel.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});
				//是否会有灯光
				mChannel.shouldShowLights();

				nm.createNotificationChannel(mChannel);
			}
		}

		nm.notify(tag, id, notification);

	}


	/**
	 * 显示提醒通知
	 *
	 * @param context
	 */
	public static void showRemindNotification(Context context, int id, String content) {
		NotificationManagerProxy.getInstance().getHandler().post(() -> {
			Notification notification = getRemindNotification(context, id, content);

			notify(context, id, notification);
		});
	}

	public static final NotificationCompat.Builder createBuilder(Context context,
																 int defaults,
																 CharSequence tickerText,
																 CharSequence text,
																 long when,
																 int smallIcon,
																 boolean autoCancel,
																 CharSequence title,
																 PendingIntent intent) {
		NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID);
//		builder.setDefaults(defaults);
		builder.setTicker(tickerText);
		builder.setContentText(text);
		builder.setWhen(when);
		builder.setSmallIcon(smallIcon);
		builder.setAutoCancel(autoCancel);
		builder.setContentTitle(title);
		builder.setContentIntent(intent);

		return builder;
	}


	public static Notification getRemindNotification(Context context, int id, String content) {
		Intent intent = new Intent(context, EntryPointActivity.class);
		ComponentName toComponentName = new ComponentName(context, id == NOTIFY_REMIND_EXAMINATION_ID ?
				PregnancyCheckActivity.class : VaccineActivity.class);
		intent.putExtra(EntryPointActivity.KEY_COMPONENT_NAME, toComponentName);
		intent.putExtra(EntryPointActivity.KEY_NEED_LOGIN, true);
		if (!(context instanceof Activity)) {
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		}
		// 首次收到通知打开app，需带上这些参数
		if (BabyVoiceApp.mUserInfo == null) {
			intent.setAction(Intent.ACTION_MAIN);
			intent.addCategory(Intent.CATEGORY_LAUNCHER);
		}
		Ln.d("[notify] remind intent=%s", IntentPrintUtil.intentToString(intent));

		NotificationCompat.Builder builder = createBuilder(context,
				Notification.DEFAULT_ALL,
				"甜贝",
				content,
				System.currentTimeMillis(),
				R.drawable.logo,
				true,
				context.getResources().getString(R.string.app_name),
				PendingIntent.getActivity(context,
						id,
						intent,
						PendingIntent.FLAG_UPDATE_CURRENT));
		return builder.build();
	}

	/**
	 * 清除所有通知栏通知
	 */
	public static void clearNotification() {
		NotificationManagerProxy.getInstance().getHandler().post(new Runnable() {
			@Override
			public void run() {
				NotificationManager nm = (NotificationManager) ApplicationContext.getContext().getSystemService(Context.NOTIFICATION_SERVICE);
				nm.cancelAll();
				mChatNotifyIdList.clear();
				mCommentNotifyIdList.clear();
			}
		});
	}


	/**
	 * 检查通知权限是否打开
	 *
	 * @param context
	 * @return
	 */
	@SuppressLint("NewApi")
	public static boolean isNotificationEnabled(Context context) {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
			return NotificationManagerCompat.from(context).areNotificationsEnabled();
		}
		return true;
	}

	/**
	 * 请求通知栏权限，跳转到相应的系统设置界面
	 *
	 * @param activity
	 */
	public static boolean requestPermission(Activity activity) {
		if (activity == null) {
			return false;
		}
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			Intent intent = new Intent();
			intent.setAction(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
			intent.putExtra(Settings.EXTRA_APP_PACKAGE, activity.getPackageName());
			return checkAndStartActivity(activity, intent);
		} else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			Intent intent = new Intent();
			intent.setAction("android.settings.APP_NOTIFICATION_SETTINGS");
			intent.putExtra("app_package", activity.getPackageName());
			intent.putExtra("app_uid", activity.getApplicationInfo().uid);
			return checkAndStartActivity(activity, intent);
		} else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
			Intent intent = new Intent();
			intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
			intent.addCategory(Intent.CATEGORY_DEFAULT);
			intent.setData(Uri.parse("package:" + activity.getPackageName()));
			return checkAndStartActivity(activity, intent);
		} else {
			Intent localIntent = new Intent();
			localIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			if (Build.VERSION.SDK_INT >= 9) {
				localIntent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
				localIntent.setData(Uri.fromParts("package", activity.getPackageName(), null));
			} else if (Build.VERSION.SDK_INT <= 8) {
				localIntent.setAction(Intent.ACTION_VIEW);
				localIntent.setClassName("com.android.settings", "com.android.settings.InstalledAppDetails");
				localIntent.putExtra("com.android.settings.ApplicationPkgName", activity.getPackageName());
			}
			return checkAndStartActivity(activity, localIntent);
		}

	}

	private static boolean checkAndStartActivity(Context context, Intent intent) {
		List<ResolveInfo> resolveInfos = context.getPackageManager().queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
		if (resolveInfos.size() > 0) {
			context.startActivity(intent);
			return true;
		} else {
			Toast.makeText(context, context.getString(R.string.notification_permission_setting), Toast.LENGTH_SHORT).show();
			return false;
		}
	}

}
