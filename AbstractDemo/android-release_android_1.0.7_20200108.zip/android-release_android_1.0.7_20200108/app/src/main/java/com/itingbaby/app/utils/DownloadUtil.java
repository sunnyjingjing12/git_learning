package com.itingbaby.app.utils;


import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.lzy.okgo.OkGo;
import com.lzy.okgo.db.DownloadManager;
import com.lzy.okgo.model.Progress;
import com.lzy.okgo.request.GetRequest;
import com.lzy.okserver.OkDownload;
import com.lzy.okserver.download.DownloadListener;
import com.lzy.okserver.download.DownloadTask;

import java.io.File;

public class DownloadUtil {

	private DownloadUtil() {
		OkDownload.getInstance().setFolder(BabyVoiceApp.getInstance().getCacheMusicPath());
		OkDownload.getInstance().getThreadPool().setCorePoolSize(3);
	}

	private static class Holder {
		private static final DownloadUtil INSTANCE = new DownloadUtil();
	}

	public static DownloadUtil getInstance() {
		return DownloadUtil.Holder.INSTANCE;
	}

	public void downloadFile(String url) {
		downloadFile(url, new FileDownloadListener("okgo"));

	}

	public void downloadFile(String url, DownloadListener listener) {

		Progress progress = DownloadManager.getInstance().get(url);
		if (progress != null) {
			OkDownload.restore(progress);
			OkDownload.getInstance().getTask(url).register(listener).start();
			Ln.d("okgo restore, progress=%s", progress);
		} else {
			Ln.d("okgo progress == null");

			GetRequest<File> request = OkGo.<File>get(url);

			//这里第一个参数是tag，代表下载任务的唯一标识，传任意字符串都行，需要保证唯一,我这里用url作为了tag
			OkDownload.request(url, request)//
					.fileName(StringUtils.stringToMd5(url))
					.save()
					.register(listener)
					.start();
		}

	}

	public void pauseAllDownload() {
		OkDownload.getInstance().pauseAll();
	}

	public void pauseDownload(String tag) {
		if (OkDownload.getInstance().hasTask(tag)) {
			DownloadTask task = OkDownload.getInstance().getTask(tag);
			task.pause();
		}
	}

	public boolean isDownloaded(String tag) {
		Progress progress = DownloadManager.getInstance().get(tag);
		if (progress != null) {
			return (progress.status == Progress.FINISH);
		}
		return false;
	}


	public class FileDownloadListener extends DownloadListener {

		public FileDownloadListener(Object tag) {
			super(tag);
		}

		@Override
		public void onStart(Progress progress) {
			Ln.d("okgo onStart, progress = %s", progress);
		}

		@Override
		public void onProgress(Progress progress) {
			Ln.d("okgo onProgress, progress = %s", progress);
		}

		@Override
		public void onError(Progress progress) {
			Ln.e("okgo onError, progress = %s", progress);
		}

		@Override
		public void onFinish(File file, Progress progress) {
			Ln.d("okgo onFinish, file name = %s, progress = %s", file.getName(), progress);
		}


		@Override
		public void onRemove(Progress progress) {
			Ln.d("okgo onRemove, progress = %s", progress);
		}

	}
}
