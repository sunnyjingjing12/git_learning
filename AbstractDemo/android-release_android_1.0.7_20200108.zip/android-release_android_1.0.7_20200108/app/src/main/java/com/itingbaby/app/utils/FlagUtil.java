package com.itingbaby.app.utils;

public class FlagUtil {

	/**
	 * 获取第一个为1的位置的索引，通过左移多少位 来处理 有flag这个位是否为1
	 *
	 * @param flag
	 * @return
	 */
	public static int getFirstOneIndexFromBits(int flag) {
		int index = -1;
		for (int i = 0; i < 64; i++) {
			int value = 1 << i;
			if ((flag & value) == value) {
				index = i;
				break;
			}
		}
		return index;
	}

	/**
	 * 得到一个二进制数中1的个数
	 *
	 * @param flag
	 * @return
	 */
	public static int getOneCountFromBits(int flag) {
		int count = 0;
		while (flag != 0) {
			count++;
			flag = flag & (flag - 1);
		}
		return count;

	}
}
