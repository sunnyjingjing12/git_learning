package com.itingbaby.app.utils;

import android.text.TextPaint;
import android.text.style.ClickableSpan;
import android.view.View;

public class ItbClickSpannable extends ClickableSpan implements View.OnClickListener {
	private final View.OnClickListener mListener;
	private final int color;

	public ItbClickSpannable(View.OnClickListener mListener, int color) {
		this.mListener = mListener;
		this.color = color;
	}

	@Override
	public void onClick(View v) {
		mListener.onClick(v);
	}

	@Override
	public void updateDrawState(TextPaint ds) {
		ds.setColor(color);
		ds.setUnderlineText(false);    //去除超链接的下划线
	}
}
