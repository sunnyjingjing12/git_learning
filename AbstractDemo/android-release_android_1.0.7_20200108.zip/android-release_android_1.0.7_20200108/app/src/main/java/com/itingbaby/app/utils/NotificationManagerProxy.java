package com.itingbaby.app.utils;

import android.app.NotificationManager;
import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;

import com.itingbaby.baselib.commonutils.ApplicationContext;
import com.itingbaby.baselib.commonutils.Ln;


public class NotificationManagerProxy extends HandlerThread {

	private static NotificationManagerProxy mInstance;

	private NotificationManager mNoticeManager;
	private Handler mHandler;

	public static final synchronized NotificationManagerProxy getInstance() {
		if (mInstance == null) {
			mInstance = new NotificationManagerProxy();
			mInstance.start();
			mInstance.init();
		}
		return mInstance;
	}

	private NotificationManagerProxy() {
		super(NotificationManagerProxy.class.getCanonicalName());
	}

	/**
	 * 要求初始化后立即当且仅当调用一次
	 */
	private void init() {
		mNoticeManager = (NotificationManager) ApplicationContext
				.getContext()
				.getSystemService(Context.NOTIFICATION_SERVICE);
		mHandler = new Handler(getLooper());
		Ln.d("method:init() finish");
	}

	public Handler getHandler() {
		return mHandler;
	}
}