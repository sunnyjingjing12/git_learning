package com.itingbaby.app.utils;

import android.app.AlarmManager;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.model.AlarmEntity;
import com.itingbaby.app.model.User;
import com.itingbaby.app.model.Vaccine;
import com.itingbaby.app.model.pregnancycheck.PregnancyCheckModel;
import com.itingbaby.app.utils.db.ExaminationAlarmManager;
import com.itingbaby.app.utils.db.PregnancyExamineManager;
import com.itingbaby.app.utils.db.VaccineAlarmManager;
import com.itingbaby.app.utils.db.VaccineManager;
import com.itingbaby.baselib.commonutils.ApplicationContext;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class RemindNotificationUtil {

	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日", Locale.getDefault());

	private static class Holder {
		private static final RemindNotificationUtil INSTANCE = new RemindNotificationUtil();
	}

	public static RemindNotificationUtil getInstance() {
		return Holder.INSTANCE;
	}


	/**
	 * app启动设置疫苗提醒
	 */
	public void setNextVaccineNotification() {
		AlarmEntity alarm = VaccineAlarmManager.getInstance().getAlarm();
		User user = BabyVoiceApp.mUserInfo;
		if (alarm != null && alarm.switchs == 1 && user != null) {
			long dueDateMillis = user.expected_date * 1000;
			List<Vaccine> allVaccine = VaccineManager.getInstance().getAllVaccine();
			for (Vaccine vaccine : allVaccine) {

				Calendar calendar = getInjectDate(vaccine.time, dueDateMillis);
				if (calendar != null) {
					long timeInMillis = StringUtils.getYearMonthDay(calendar.getTimeInMillis());
					long currTimeMillis = StringUtils.getYearMonthDay(System.currentTimeMillis());
					int diffDay = StringUtils.differentDays(currTimeMillis, timeInMillis);

					if (diffDay >= 0) {
						Calendar remindCalendar = getRemindCalendar(calendar, alarm);
						String action = AlarmTimerUtil.TIMER_ACTION_VACCINE;
						serAlarmTimer(remindCalendar, action, AlarmManager.RTC_WAKEUP);

						break;
					}
				}
			}
		}
	}


	/**
	 * app启动设置产检提醒
	 */
	public void setNextExaminationNotification() {
		AlarmEntity alarm = ExaminationAlarmManager.getInstance().getAlarm();
		Ln.d("[alarm] alarm is null %b", alarm == null);
		if (alarm != null && alarm.switchs == 1) {
			List<PregnancyCheckModel> allPregnancyCheckData = PregnancyExamineManager.getInstance().getAllPregnancyCheckData();

			int minDiff = Integer.MAX_VALUE;  // 最近一次产检项目天数
			Calendar tmpCalendar = null;
			for (int i = 0, size = allPregnancyCheckData.size(); i < size; i++) {
				PregnancyCheckModel model = allPregnancyCheckData.get(i);
				Calendar calendar = getExamineDate(model.date);
				if (calendar != null) {
					long timeInMillis = StringUtils.getYearMonthDay(calendar.getTimeInMillis());
					long currTimeMillis = StringUtils.getYearMonthDay(System.currentTimeMillis());
					int diffDay = StringUtils.differentDays(currTimeMillis, timeInMillis);
					if (diffDay >= 0) {
						if (diffDay < minDiff) {
							minDiff = diffDay;
							tmpCalendar = calendar;
						}
					}
				}
			}
			Calendar remindCalendar = getRemindCalendar(tmpCalendar, alarm);
			String action = AlarmTimerUtil.TIMER_ACTION_EXAMINATION;
			serAlarmTimer(remindCalendar, action, AlarmManager.RTC_WAKEUP);

		}
	}


	/**
	 * 设置闹钟
	 *
	 * @param remindCalendar
	 * @param action
	 * @param alarmType
	 */
	public void serAlarmTimer(Calendar remindCalendar, String action, int alarmType) {
		// 先取消之前的
		AlarmTimerUtil.cancelAlarmTimer(ApplicationContext.getContext(), action);
		if (remindCalendar != null && remindCalendar.getTimeInMillis() > System.currentTimeMillis()) {
			String extra = (remindCalendar.get(Calendar.MONTH) + 1) + "月" + remindCalendar.get(Calendar.DAY_OF_MONTH) + "日";
			if (!CommonNotificationUtils.isNotificationEnabled(ApplicationContext.getContext())) {
				Ln.e("通知栏权限已关闭，无法设置提醒");
			} else {
				AlarmTimerUtil.setAlarmTimer(ApplicationContext.getContext(), remindCalendar.getTimeInMillis(), action, extra, alarmType);
			}
		}
	}


	/**
	 * 获得疫苗需要注射日期
	 *
	 * @param time
	 * @param dueDateMillis 预产期，也就是宝宝生日
	 * @return
	 */
	private Calendar getInjectDate(int time, long dueDateMillis) {
		Calendar calendar = Calendar.getInstance(Locale.getDefault());
		calendar.setTimeInMillis(dueDateMillis);
		if (time < 12) {
			calendar.add(Calendar.MONTH, time);
		} else {
			int year = time / 12;
			int month = time % 12;
			calendar.add(Calendar.YEAR, year);
			calendar.add(Calendar.MONTH, month);
		}
		return calendar;

	}


	/**
	 * 获得需要提醒的疫苗日期
	 *
	 * @return
	 */
	private Calendar getRemindCalendar(Calendar nextCalendar, AlarmEntity alarm) {
		if (nextCalendar != null) {
			int day = 0;
			if (alarm.type == 0) {
				day = -3;
			} else if (alarm.type == 1) {
				day = -1;
			} else if (alarm.type == 2) {
				day = 0;
			}
			Calendar calendar = Calendar.getInstance();
			calendar.setTimeInMillis(nextCalendar.getTimeInMillis());
			calendar.add(Calendar.DAY_OF_MONTH, day);
			calendar.set(Calendar.HOUR, alarm.hour);
			calendar.set(Calendar.MINUTE, alarm.minute);
			return calendar;
		}
		return null;

	}

	/**
	 * 获得需要提醒的产检日期
	 *
	 * @return
	 */
	private Calendar getExamineDate(String nowTime) {
		try {
			Date date = sdf.parse(nowTime);
			Calendar calendar = Calendar.getInstance(Locale.getDefault());
			calendar.setTime(date);
			return calendar;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

}
