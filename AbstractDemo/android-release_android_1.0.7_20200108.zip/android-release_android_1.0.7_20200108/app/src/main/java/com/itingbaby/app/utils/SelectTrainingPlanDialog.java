package com.itingbaby.app.utils;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.itingbaby.app.R;
import com.itingbaby.baselib.views.widget.CommonDialog;

public class SelectTrainingPlanDialog implements SeekBar.OnSeekBarChangeListener {
	private CommonDialog dialog;
	private LinearLayout contentView;
	private int trainLevel;
	private int trainTime;
	private String title;


	private SeekBar skTrainLevel = null;    //训练等级滑动条
	private TextView tvTrainLevel = null;
	private TextView tvTitle = null;
	private SeekBar skTrainTime;            //训练时间滑动条
	private TextView tvTrainTime;


	public int getTrainLevel() {
		return trainLevel;
	}

	public int getTrainTime() {
		return trainTime;
	}

	private SelectTrainingPlanDialog(SelectTrainingPlanDialog.Builder builder) {
		dialog = CommonDialog.createDialog(builder.context);
//		dialog.setWrapContentWidth();

		contentView = (LinearLayout) View.inflate(builder.context, R.layout.view_select_training_plan, null);

		skTrainLevel = (SeekBar) contentView.findViewById(R.id.sk_recover_dailog_trainlevel);
		skTrainLevel.setOnSeekBarChangeListener(this);
		tvTrainLevel = (TextView) contentView.findViewById(R.id.tv_recover_dailog_trainlevel);
		skTrainTime = (SeekBar) contentView.findViewById(R.id.sk_recover_dailog_traintime);
		skTrainTime.setOnSeekBarChangeListener(this);
		tvTrainTime = (TextView) contentView.findViewById(R.id.tv_recover_dailog_traintime);
		skTrainLevel.setMax(10);
		skTrainLevel.setProgress(builder.trainLevel);
		skTrainTime.setMax(25);
		skTrainTime.setProgress(builder.trainTime);

		dialog.setTitleText(builder.title)
				.setContentView(contentView)
				.setLeftButtonText(R.string.cancel)
				.setLeftButtonAction(builder.cancelListener)
				.setRightButtonText("训练")
				.setRightButtonAction(builder.confirmListener)
				.setCancelable(true);

	}

	public void show() {
		dialog.show();
	}

	@Override
	public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
		switch (seekBar.getId()) {
			case R.id.sk_recover_dailog_trainlevel:
				if (progress == 0) {
					progress = 1;
					skTrainLevel.setProgress(progress);
				}
				if (progress == 11) {
					progress = 10;
					skTrainLevel.setProgress(progress);
				}
				skTrainLevel.setSecondaryProgress(progress);
				tvTrainLevel.setText("当前数值:" + progress);
				trainLevel = progress;
				break;
			case R.id.sk_recover_dailog_traintime:
				if (progress <= 5) {
					progress = 5;
					skTrainTime.setProgress(progress);

				} else if (progress <= 10) {
					progress = 10;
					skTrainTime.setProgress(progress);
				} else if (progress <= 15) {
					progress = 15;
					skTrainTime.setProgress(progress);
				} else if (progress <= 20) {
					progress = 20;
					skTrainTime.setProgress(progress);
				} else if (progress <= 25) {
					progress = 25;
					skTrainTime.setProgress(progress);
				}
				skTrainTime.setSecondaryProgress(progress);
				tvTrainTime.setText("当前数值:" + progress);
				trainTime = progress;
				break;
			default:
				break;
		}
	}

	@Override
	public void onStartTrackingTouch(SeekBar seekBar) {

	}

	@Override
	public void onStopTrackingTouch(SeekBar seekBar) {

	}

	public static class Builder {
		private Context context;
		private int trainLevel;
		private int trainTime;
		private String title;
		private CommonDialog.OnActionListener cancelListener;
		private CommonDialog.OnActionListener confirmListener;


		public SelectTrainingPlanDialog.Builder setContext(@NonNull Context context) {
			this.context = context;
			return this;
		}

		public SelectTrainingPlanDialog.Builder setTitle(String title) {
			this.title = title;
			return this;
		}

		public SelectTrainingPlanDialog.Builder setTrainLevel(int trainLevel) {
			this.trainLevel = trainLevel;
			return this;
		}

		public SelectTrainingPlanDialog.Builder setTrainTime(int trainTime) {
			this.trainTime = trainTime;
			return this;
		}

		public SelectTrainingPlanDialog.Builder setCancelListener(CommonDialog.OnActionListener cancelListener) {
			this.cancelListener = cancelListener;
			return this;
		}

		public SelectTrainingPlanDialog.Builder setConfirmListener(CommonDialog.OnActionListener confirmListener) {
			this.confirmListener = confirmListener;
			return this;
		}

		public SelectTrainingPlanDialog build() {
			SelectTrainingPlanDialog dialog = new SelectTrainingPlanDialog(this);
			return dialog;
		}
	}
}
