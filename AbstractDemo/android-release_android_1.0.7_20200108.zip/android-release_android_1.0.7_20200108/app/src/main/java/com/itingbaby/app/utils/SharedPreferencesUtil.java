package com.itingbaby.app.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.itingbaby.app.model.User;
import com.itingbaby.baselib.commonutils.Ln;

/**
 * Created by Administrator on 2017/4/9.
 */

public class SharedPreferencesUtil {
	public static final String USER_INFO_SHARED_PREFERENCES_FILE = "userinfo1.0.6";         // userinfo文件

	public static final String USER_INFO_DATA = "user";         // userinfo文件

	private final static String SET_COOKIE_KEY = "SET_COOKIE_KEY";

	private final static String ISFIRST_LAUNCH_KEY = "isfirst_launch_pref_key1.0.6";

	private static final String LAST_CHECK_VERSION_TIME = "last_check_version_time";
	private static final String CHECK_VERSION_TIMES = "check_version_times";
	private static final String NEWEST_VERSION = "newest_version";

	private static final String CURRENT_GUIDE_KEY = "current_guide_key_pelvic_training";

	private static final String CURRENT_SERVER_URL = "current_server_url";

	private static final String LAST_SHOW_MUSIC_DOT_TIME = "last_show_music_dot_time"; // 上一次显示的时间戳
	private static final String MUSIC_DOT_SHOW_COUNT = "music_dot_show_count";         // 音乐红点显示次数

	private static final String SHOW_TRAIN_TIPS_DIALOG_BY_UID = "show_train_tips_dialog_by_uid_";// 是否显示方法提示Dialog


	private static final String ENABLE_SHOW_NETWORK = "enable_show_network";         // 流量弹窗提醒

	private static final String IS_NEED_SET_EXAMINE_DATE = "is_set_examine_date";         // 是否设置过产检日期

	private static final String IS_NEED_SHOW_PRIVACY_DIALOG = "is_need_show_privacy_dialog";         // 是否显示隐私弹窗

	private static final String IS_PROCESSED_OLD_VOICE_DATA = "is_processed_old_voice_data1.0.8";         // 是否处理过旧数据


	public static boolean isFirstLaunch(Context context) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		return preferences.getBoolean(ISFIRST_LAUNCH_KEY, true);
	}

	public static void setFirstLaunch(Context context, boolean firstLaunch) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		preferences.edit().putBoolean(ISFIRST_LAUNCH_KEY, firstLaunch).apply();
	}

	public static String getCookie(Context context) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		return preferences.getString(SET_COOKIE_KEY, "");
	}

	public static void setCookie(Context context, String cookieValue) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		preferences.edit().putString(SET_COOKIE_KEY, cookieValue).apply();
	}

	/**
	 * 获取最后检查更新时间
	 */
	public static long getLastCheckVersionTime(Context context) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		return preferences.getLong(LAST_CHECK_VERSION_TIME, 0);
	}

	public static void setLastCheckVersionTime(Context context, long time) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		preferences.edit().putLong(LAST_CHECK_VERSION_TIME, time).apply();
	}

	/**
	 * 获取检查更新时间次数
	 */
	public static int getCheckVersionTimes(Context context) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		return preferences.getInt(CHECK_VERSION_TIMES, 0);
	}

	public static void setCheckVersionTimes(Context context, int times) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		preferences.edit().putInt(CHECK_VERSION_TIMES, times).apply();
	}


	/**
	 * 获取最新版本号
	 */
	public static String getNewestVersion(Context context) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		return preferences.getString(NEWEST_VERSION, "");
	}

	public static void setNewestVersion(Context context, String version) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		preferences.edit().putString(NEWEST_VERSION, version).apply();
	}

	/**
	 * 此引导动画时候已经展示过
	 *
	 * @return
	 */
	public static boolean isCurrentGuideShowed(Context context) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		boolean value = preferences.getBoolean(CURRENT_GUIDE_KEY, false);
		Ln.d("method:isCurrentGuideShowed CURRENT_GUIDE_KEY=%s value=%s", CURRENT_GUIDE_KEY, value);
		return value;
	}


	public static void setCurrentGuideShowed(Context context, boolean value) {
		Ln.d("method:setCurrentGuideShowed CURRENT_GUIDE_KEY=%s value=%s", CURRENT_GUIDE_KEY, value);
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		preferences.edit().putBoolean(CURRENT_GUIDE_KEY, value).apply();
	}

	/**
	 * 获取当前服务器地址
	 */
	public static String getCurrentServerURL(Context context) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		return preferences.getString(CURRENT_SERVER_URL, "http://app.itingbaby.com/");
	}

	public static void setCurrentServerURL(Context context, String url) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		preferences.edit().putString(CURRENT_SERVER_URL, url).apply();
	}


	/**
	 * 获取上次音乐tab红点显示时间戳
	 */
	public static long getLastShowMusicDotTime(Context context) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		return preferences.getLong(LAST_SHOW_MUSIC_DOT_TIME, 0);
	}

	public static void setLastShowMusicDotTime(Context context, long time) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		preferences.edit().putLong(LAST_SHOW_MUSIC_DOT_TIME, time).apply();
	}

	/**
	 * 获取音乐tab红点显示次数
	 */
	public static int getMusicDotShowCount(Context context) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		return preferences.getInt(MUSIC_DOT_SHOW_COUNT, 0);
	}

	public static void setMusicDotShowCount(Context context, int times) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		preferences.edit().putInt(MUSIC_DOT_SHOW_COUNT, times).apply();
	}

	/**
	 * 是否显示过训练方法dialog
	 */
	public static boolean isTrainTipsDialogShowed(Context context, long uid) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		return preferences.getBoolean(SHOW_TRAIN_TIPS_DIALOG_BY_UID + uid, false);
	}

	public static void setTrainTipsDialogShowed(Context context, long uid, boolean flag) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		preferences.edit().putBoolean(SHOW_TRAIN_TIPS_DIALOG_BY_UID + uid, flag).apply();
	}


	/**
	 * 是否设置过产检日期数据
	 *
	 * @return
	 */
	public static boolean isNeedSetExamineDate(Context context) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		return preferences.getBoolean(IS_NEED_SET_EXAMINE_DATE, true);
	}


	public static void setExamineDate(Context context, boolean value) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		preferences.edit().putBoolean(IS_NEED_SET_EXAMINE_DATE, value).apply();
	}


	/**
	 * 是否展示流量提醒弹窗，默认为true
	 *
	 * @return
	 */
	public static boolean isEnableShowNetwork(Context context) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		return preferences.getBoolean(ENABLE_SHOW_NETWORK, true);
	}


	public static void setEnableShowNetwork(Context context, boolean value) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		preferences.edit().putBoolean(ENABLE_SHOW_NETWORK, value).apply();
	}

	/**
	 * 是否展示隐私弹窗，默认为true
	 *
	 * @return
	 */
	public static boolean isNeedShowPrivacyDialog(Context context) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		return preferences.getBoolean(IS_NEED_SHOW_PRIVACY_DIALOG, true);
	}


	public static void setShowPrivacyDialog(Context context, boolean value) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		preferences.edit().putBoolean(IS_NEED_SHOW_PRIVACY_DIALOG, value).apply();
	}

	/**
	 * 是否处理过旧数据，默认为false
	 *
	 * @return
	 */
	public static boolean isProcessOldVoiceData(Context context) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		return preferences.getBoolean(IS_PROCESSED_OLD_VOICE_DATA, false);
	}


	public static void setProcessOldVoiceData(Context context, boolean value) {
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
		preferences.edit().putBoolean(IS_PROCESSED_OLD_VOICE_DATA, value).apply();
	}

	/**
	 * 简单保存到SharedPreferences中
	 *
	 */
	public static void saveToPreferences(Context context, User userInfo) {
		//创建sharedPreference对象，info表示文件名，MODE_PRIVATE表示访问权限为私有的
		SharedPreferences sp = context.getSharedPreferences(USER_INFO_SHARED_PREFERENCES_FILE, Context.MODE_PRIVATE);

		//获得sp的编辑器
		SharedPreferences.Editor ed = sp.edit();

		//以键值对的显示将用户名和密码保存到sp中
		ed.putString(USER_INFO_DATA, GsonHelper.objectToJson(userInfo));

		//提交用户名和密码
		ed.apply();
	}
}
