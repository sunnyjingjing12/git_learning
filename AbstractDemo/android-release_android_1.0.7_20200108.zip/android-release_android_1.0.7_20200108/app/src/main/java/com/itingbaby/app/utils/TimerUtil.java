package com.itingbaby.app.utils;


import com.itingbaby.baselib.commonutils.Ln;

import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.schedulers.Schedulers;

/**
 * 计时器工具类
 */
public class TimerUtil {

	private  CompositeDisposable mCompositeDisposable;

	private TimerUtil() {
		mCompositeDisposable = new CompositeDisposable();
	}

	private static class Holder {
		private static final TimerUtil INSTANCE = new TimerUtil();
	}

	public static TimerUtil getInstance() {
		return TimerUtil.Holder.INSTANCE;
	}

	/**
	 * 开启一个定时器
	 * @param time 总时长
	 * @param timeUnit 时长单位
	 * @param disposableObserver 计时期间的处理函数
	 * @return
	 */
	public DisposableObserver startTimer(long time, TimeUnit timeUnit, DisposableObserver disposableObserver) {
		Ln.d("TimerUtil lihb startTimer");
		DisposableObserver timerDisposableObserver = Observable.interval(1, timeUnit)
				.take(time, timeUnit)
				.subscribeOn(Schedulers.io())
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeWith(disposableObserver);

		mCompositeDisposable.add(timerDisposableObserver);

		return timerDisposableObserver;
	}



	/**
	 * 停止一个定时器
	 */
	public void stopTimer(DisposableObserver disposableObserver) {
		Ln.d("TimerUtil lihb stopTimer");
		if (disposableObserver != null && !disposableObserver.isDisposed()) {
			disposableObserver.dispose();
			mCompositeDisposable.remove(disposableObserver);
			disposableObserver = null;
		}
	}


	/**
	 * 停止所有定时器
	 */
	public void stopAllTimer() {
		mCompositeDisposable.clear();
	}

}
