package com.itingbaby.app.utils;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.action.ApiManager;
import com.itingbaby.app.action.ResponseCode;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StringUtils;

import java.io.File;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class UploadSoundUtil {

	public static void uploadSound(AudioRecordModel audioRecord, OnUploadListener listener) {

		MultipartBody body = filesToMultipartBody(audioRecord.getUrl(), audioRecord.getType(), audioRecord.getTimestamp());

		ServiceGenerator.createService(ApiManager.class)
				.uploadVoiceFile(body)
				.observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(httpResponse -> {
					if (ResponseCode.RESPONSE_OK == httpResponse.code) {
						if (listener != null) {
							listener.onSuccess(httpResponse.msg, httpResponse.data.getServerFileId(), httpResponse.data.getUrl());
						}
					} else {
						if (listener != null) {
							listener.onFailed(httpResponse.msg);
						}
					}
				}, throwable -> {
					if (listener != null) {
						listener.onFailed(throwable.getMessage());
					}
				});
	}


	private static MultipartBody filesToMultipartBody(String url, Integer type, Long t) {

		File file = null;
		if (!StringUtils.isBlank(url)) {
			file = new File(url);
		}

		if (file == null || !file.exists()) {
			Ln.i("no pic to upload!!");
			return null;
		}

		MultipartBody.Builder builder = new MultipartBody.Builder();

		RequestBody requestBody = RequestBody.create(MediaType.parse(""), file);
		builder.addFormDataPart("uid", Long.toString(BabyVoiceApp.mUserInfo.id));
		builder.addFormDataPart("type", type.toString());
		builder.addFormDataPart("create_timestamp", t.toString());
		builder.addFormDataPart("file", file.getName(), requestBody);
		builder.setType(MultipartBody.FORM);

		return builder.build();
	}

	public interface OnUploadListener {
		void onSuccess(String msg, long serverFileID, String url);

		void onFailed(String msg);
	}

}
