package com.itingbaby.app.utils.db;

import android.content.Context;

import com.itingbaby.baselib.commonutils.Ln;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

/**
 * 把db文件从asset文件夹拷贝到app私有目录
 */
public class AssetsDBUtil {

	public static final String packageBame = "com.itingbaby.app";
	public static final String db_vaccine = "vaccine.db";
	public static final String db_examination = "examination.db";

	public static final String vaccineFilePath = "data/data/" + packageBame + "/databases/" + db_vaccine;
	public static final String examinationFilePath = "data/data/" + packageBame + "/databases/" + db_examination;

	public static final String pathStr = "data/data/" + packageBame + "/databases";

	public static void getPath(Context context) {
		String[] pathArray = new String[]{vaccineFilePath, examinationFilePath};
		String[] dbNameArray = new String[]{db_vaccine, db_examination};
		for (int i = 0; i < pathArray.length; i++) {
			String filePath = pathArray[i];
			String dbName = dbNameArray[i];
			Ln.d("filePath:%s, dbName:%s", filePath, dbName);
			File dbFile = new File(filePath);
			if (!dbFile.exists()) {
				File path = new File(pathStr);
				path.mkdir();
				try {
					InputStream is = Objects.requireNonNull(context.getClass().getClassLoader()).getResourceAsStream("assets/" + dbName);

					FileOutputStream fos = new FileOutputStream(dbFile);
					byte[] buffer = new byte[10240];
					int count = 0;
					while ((count = is.read(buffer)) > 0) {
						fos.write(buffer, 0, count);
					}
					fos.flush();
					fos.close();
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}
}