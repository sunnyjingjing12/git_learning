package com.itingbaby.app.utils.db;

import android.content.ContentValues;
import android.database.Cursor;

import com.itingbaby.app.model.AlarmEntity;
import com.itingbaby.baselib.commonutils.ApplicationContext;


public class ExaminationAlarmManager extends BaseDao<AlarmEntity> {

	public static final String DB_NAME = "examination.db";

	private ExaminationAlarmManager() {
		super(new ItbDbHelper(ApplicationContext.getContext(), DB_NAME));
	}

	public static ExaminationAlarmManager getInstance() {
		return VaccineManagerHolder.instance;
	}

	private static class VaccineManagerHolder {
		private static final ExaminationAlarmManager instance = new ExaminationAlarmManager();
	}


	@Override
	public String getTableName() {
		return "examination_alarm";
	}

	@Override
	public void unInit() {

	}

	@Override
	public AlarmEntity parseCursorToBean(Cursor cursor) {
		return AlarmEntity.parseCursorToBean(cursor);
	}

	@Override
	public ContentValues getContentValues(AlarmEntity alarmEntity) {
		return AlarmEntity.buildContentValues(alarmEntity);
	}

	/**
	 * 获取之前设置的时间
	 */
	public AlarmEntity getAlarm() {
		return queryOne(AlarmEntity.ID + "=?", new String[]{"1"});
	}

	/**
	 * 更新数据
	 *
	 * @param entity
	 * @return
	 */
	public boolean update(AlarmEntity entity) {
		return update(entity, AlarmEntity.ID + "=?", new String[]{"1"});
	}

}
