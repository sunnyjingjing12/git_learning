package com.itingbaby.app.utils.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.itingbaby.baselib.commonutils.Ln;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ItbDbHelper extends SQLiteOpenHelper {

	static final Lock lock = new ReentrantLock();

	ItbDbHelper(Context context, String dbName) {
		super(context, dbName, null, 1);
	}


	@Override
	public void onCreate(SQLiteDatabase db) {
		Ln.d("ItbDbHelper onCreate, version=%d, path=%s", db.getVersion(), db.getPath());
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		Ln.d("ItbDbHelper onUpgrade, oldVersion=%d, newVersion=%d, path=%s", oldVersion, newVersion, db.getPath());
	}
}
