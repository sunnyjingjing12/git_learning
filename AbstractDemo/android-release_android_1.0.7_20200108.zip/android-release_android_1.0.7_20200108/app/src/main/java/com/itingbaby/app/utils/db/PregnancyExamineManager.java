package com.itingbaby.app.utils.db;

import android.content.ContentValues;
import android.database.Cursor;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.model.pregnancycheck.PregnancyCheckModel;
import com.itingbaby.app.utils.SharedPreferencesUtil;
import com.itingbaby.baselib.commonutils.ApplicationContext;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;


public class PregnancyExamineManager extends BaseDao<PregnancyCheckModel> {

	public static final String DB_NAME = "examination.db";

	private PregnancyExamineManager() {
		super(new ItbDbHelper(ApplicationContext.getContext(), DB_NAME));
	}

	public static PregnancyExamineManager getInstance() {
		return VaccineManagerHolder.instance;
	}

	private static class VaccineManagerHolder {
		private static final PregnancyExamineManager instance = new PregnancyExamineManager();
	}


	@Override
	public String getTableName() {
		return "examination";
	}

	@Override
	public void unInit() {

	}

	@Override
	public PregnancyCheckModel parseCursorToBean(Cursor cursor) {
		return PregnancyCheckModel.parseCursorToBean(cursor);
	}

	@Override
	public ContentValues getContentValues(PregnancyCheckModel model) {
		return PregnancyCheckModel.buildContentValues(model);
	}


	/**
	 * 第一次打开app，或者用户修改了预产期后，需要更新每个产检项目的日期
	 */
	private void checkExamineDate(List<PregnancyCheckModel> modelList) {
		if (SharedPreferencesUtil.isNeedSetExamineDate(ApplicationContext.getContext()) && BabyVoiceApp.mUserInfo != null) {
			// 得到预产期时间
			long dueDateMillis = BabyVoiceApp.mUserInfo.expected_date * 1000;
			Calendar calendar = Calendar.getInstance(Locale.getDefault());

			if (modelList != null && !modelList.isEmpty()) {
				for (PregnancyCheckModel model : modelList) {
					calendar.setTimeInMillis(dueDateMillis);
					calendar.add(Calendar.DAY_OF_YEAR, -model.interval);
					model.date = String.format(Locale.getDefault(), "%04d年%02d月%02d日", calendar.get(Calendar.YEAR),
							(calendar.get(Calendar.MONTH) + 1), calendar.get(Calendar.DAY_OF_MONTH));
				}
				boolean flag = batchReplace(modelList);
				if (flag) {
					SharedPreferencesUtil.setExamineDate(ApplicationContext.getContext(), false);
				}
			}
		}
	}

	/**
	 * 获取所有产检信息
	 */
	public List<PregnancyCheckModel> getAllPregnancyCheckData() {
		List<PregnancyCheckModel> modelList;
		modelList = query(null, null, null, null, null, null, null);
		checkExamineDate(modelList);
		return modelList;
	}


	/**
	 * 更新数据
	 *
	 * @param entity
	 * @return
	 */
	public boolean update(PregnancyCheckModel entity) {
		return update(entity, PregnancyCheckModel.ID + "=?", new String[]{String.valueOf(entity.id)});
	}


	/**
	 * 批量更新数据
	 *
	 * @param modelList
	 * @return
	 */
	public boolean batchReplace(List<PregnancyCheckModel> modelList) {
		return replace(modelList);
	}


}
