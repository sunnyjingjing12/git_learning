package com.itingbaby.app.utils.db;

import android.content.ContentValues;
import android.database.Cursor;

import com.itingbaby.app.model.AlarmEntity;
import com.itingbaby.baselib.commonutils.ApplicationContext;


public class VaccineAlarmManager extends BaseDao<AlarmEntity> {

	public static final String DB_NAME = "vaccine.db";

	private VaccineAlarmManager() {
		super(new ItbDbHelper(ApplicationContext.getContext(), DB_NAME));
	}

	public static VaccineAlarmManager getInstance() {
		return VaccineManagerHolder.instance;
	}

	private static class VaccineManagerHolder {
		private static final VaccineAlarmManager instance = new VaccineAlarmManager();
	}


	@Override
	public String getTableName() {
		return "vaccine_alarm";
	}

	@Override
	public void unInit() {

	}

	@Override
	public AlarmEntity parseCursorToBean(Cursor cursor) {
		return AlarmEntity.parseCursorToBean(cursor);
	}

	@Override
	public ContentValues getContentValues(AlarmEntity alarmEntity) {
		return AlarmEntity.buildContentValues(alarmEntity);
	}

	/**
	 * 获取之前设置的时间
	 */
	public AlarmEntity getAlarm() {
		return queryOne(AlarmEntity.ID + "=?", new String[]{"1"});
	}

	/**
	 * 更新数据
	 *
	 * @param entity
	 * @return
	 */
	public boolean update(AlarmEntity entity) {
		return update(entity, AlarmEntity.ID + "=?", new String[]{"1"});
	}


}
