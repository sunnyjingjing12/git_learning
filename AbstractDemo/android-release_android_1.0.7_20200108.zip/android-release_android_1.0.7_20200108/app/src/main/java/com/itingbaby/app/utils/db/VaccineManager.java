package com.itingbaby.app.utils.db;

import android.content.ContentValues;
import android.database.Cursor;

import com.itingbaby.app.model.Vaccine;
import com.itingbaby.baselib.commonutils.ApplicationContext;

import java.util.List;


public class VaccineManager extends BaseDao<Vaccine> {

	public static final String DB_NAME = "vaccine.db";

	private VaccineManager() {
		super(new ItbDbHelper(ApplicationContext.getContext(), DB_NAME));
	}

	public static VaccineManager getInstance() {
		return VaccineManagerHolder.instance;
	}

	private static class VaccineManagerHolder {
		private static final VaccineManager instance = new VaccineManager();
	}


	@Override
	public String getTableName() {
		return "vaccine";
	}

	@Override
	public void unInit() {

	}

	@Override
	public Vaccine parseCursorToBean(Cursor cursor) {
		return Vaccine.parseCursorToBean(cursor);
	}

	@Override
	public ContentValues getContentValues(Vaccine vaccine) {
		return Vaccine.buildContentValues(vaccine);
	}

	/**
	 * 获取所有疫苗信息
	 */
	public List<Vaccine> getAllVaccine() {
		return query(null, null, null, null, null, Vaccine.SORT + " ASC", null);
	}

	/**
	 * 更新数据
	 *
	 * @param entity
	 * @return
	 */
	public boolean update(Vaccine entity) {
		return update(entity, Vaccine.ID + "=?", new String[]{String.valueOf(entity.id)});
	}


	/**
	 * 更新数据
	 *
	 * @param vaccineList
	 * @return
	 */
	public boolean batchReplace(List<Vaccine> vaccineList) {
		return replace(vaccineList);
	}


}
