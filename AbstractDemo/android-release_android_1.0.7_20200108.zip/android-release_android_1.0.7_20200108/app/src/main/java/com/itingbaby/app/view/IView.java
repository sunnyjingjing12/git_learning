package com.itingbaby.app.view;

/**
 * Created by Administrator on 2017/9/16.
 */

public interface IView {
    void onError(String message);
}
