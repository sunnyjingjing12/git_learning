package com.itingbaby.app.view;

import android.content.Context;

import java.util.List;

/**
 * Created by Jelly on 2016/9/3.
 */
public interface ImageBrowseView {

    void setImageBrowse(List<String> images, int position);

    Context getMyContext();
}
