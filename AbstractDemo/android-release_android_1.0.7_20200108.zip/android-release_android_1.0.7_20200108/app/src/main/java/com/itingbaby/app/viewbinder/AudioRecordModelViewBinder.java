package com.itingbaby.app.viewbinder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.itingbaby.app.BabyVoiceApp;
import com.itingbaby.app.R;
import com.itingbaby.app.model.AudioPlayData;
import com.itingbaby.app.model.AudioRecordModel;
import com.itingbaby.app.model.AudioType;
import com.itingbaby.app.model.MixMusicSelectStatus;
import com.itingbaby.app.model.MusicSelectStatus;
import com.itingbaby.app.utils.FlagUtil;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.jakewharton.rxbinding3.view.RxView;
import com.opensource.svgaplayer.SVGAImageView;

import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.drakeet.multitype.ItemViewBinder;

/**
 * 听贝贝-数据列表item
 */

public class AudioRecordModelViewBinder extends ItemViewBinder<AudioRecordModel, AudioRecordModelViewBinder.ViewHolder> {

	public static final int SRC_TYPE_HOME_VOICE = 0;   // 来自听贝贝页面
	public static final int SRC_TYPE_PLAY = 1;         // 来自播放页面
	public static final int SRC_TYPE_MUSIC_LIST = 2;   // 来自音乐列表
	public static final int SRC_TYPE_HOME_TBAI = 3;    // 来自甜贝首页
	public static final int SRC_TYPE_MUSIC_SELECT = 4;    // 来自选择音乐页面
	public static final int SRC_TYPE_MUSIC_MIX = 5;    // 来自混音页面

	private int[] musicSelectIds = {0, R.drawable.ic_to_download, R.drawable.ic_downloading, R.drawable.ic_download_pause, R.drawable.ic_download_failed,
			R.drawable.ic_music_unselected, R.drawable.ic_music_selected};

	private int[] voiceTypeIds = {R.drawable.ic_baby_voice, R.drawable.ic_mother_voice, R.drawable.ic_lung_voice, R.drawable.ic_mixed_voice};


	private OnAudioRecordModelViewBinderListener listener;

	private int srcType = SRC_TYPE_HOME_VOICE;

	public void setOnAudioRecordModelViewBinderListener(OnAudioRecordModelViewBinderListener listener) {
		this.listener = listener;
	}

	public AudioRecordModelViewBinder(int srcType) {
		this.srcType = srcType;
	}

	@NonNull
	@Override
	protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
		View root = inflater.inflate(R.layout.heart_voice_list_item, parent, false);
		return new ViewHolder(root);
	}

	@Override
	protected void onBindViewHolder(@NonNull ViewHolder holder, @NonNull AudioRecordModel recordModel) {
		holder.bindData(recordModel);
	}

	class ViewHolder extends RecyclerView.ViewHolder {

		@BindView(R.id.voice_category_img)
		ImageView voiceCategoryImg;
		@BindView(R.id.voice_title_txt)
		TextView voiceTitleTxt;

		@BindView(R.id.voice_duration_txt)
		TextView voiceDurationTxt;
		@BindView(R.id.voice_pregnancy_date_txt)
		TextView voicePregnancyDateTxt;
		@BindView(R.id.voice_date_txt)
		TextView voiceDateTxt;
		@BindView(R.id.voice_layout)
		RelativeLayout voiceLayout;
		@BindView(R.id.img_more_operation)
		ImageView imgMoreOperation;
		@BindView(R.id.img_play_icon)
		ImageView imgPlayIcon;
		@BindView(R.id.play_status_img)
		ImageView playStatusImg;
		@BindView(R.id.play_status_svga)
		SVGAImageView playStatusSvga;
		@BindView(R.id.play_status_layout)
		FrameLayout playStatusLayout;

		@BindView(R.id.tv_download_progress)
		TextView tvDownloadProgress;


		ViewHolder(View itemView) {
			super(itemView);
			ButterKnife.bind(this, itemView);
			initListener();
		}

		public void bindData(AudioRecordModel recordModel) {
			if (recordModel == null) {
				return;
			}
			String durationText = recordModel.getDuration() + "s";
			long t = recordModel.getTimestamp();
			String str = srcType == SRC_TYPE_MUSIC_SELECT ? "" : StringUtils.TimeStamp2Date(t, "yyyy-MM-dd HH:mm:ss");

			voiceTitleTxt.setText(recordModel.getName());
			voiceDurationTxt.setText(durationText);
			voiceDateTxt.setText(str);

			// 孕周显示规则：
			// 只在录制妈妈心音和宝宝心音时显示，而且是要在预产期之前
			if (recordModel.getType() == AudioType.AUDIO_TYPE_BABY || recordModel.getType() == AudioType.AUDIO_TYPE_MOM) {
				if (recordModel.getTimestamp() < BabyVoiceApp.mUserInfo.expected_date) {
					voicePregnancyDateTxt.setVisibility(View.VISIBLE);
					String gestationalWeeks = StringUtils.gestationalWeeks(recordModel.getTimestamp(), BabyVoiceApp.mUserInfo.expected_date);
					voicePregnancyDateTxt.setText(gestationalWeeks);
				} else {
					voicePregnancyDateTxt.setVisibility(View.GONE);
				}
			} else {
				voicePregnancyDateTxt.setVisibility(View.GONE);
			}

			setCategoryImg(recordModel.getType());

			renderPlayingStatus(recordModel);

			imgMoreOperation.setVisibility(srcType == SRC_TYPE_HOME_VOICE ? View.VISIBLE : View.GONE);

			renderImgSelectStatus(recordModel);
		}

		private void renderPlayingStatus(AudioPlayData audioPlayData) {
			// 显示条件：1、在播放器页面 2、正在被播放
			imgPlayIcon.setVisibility((srcType == SRC_TYPE_PLAY && audioPlayData.isPlaying()) ? View.VISIBLE : View.GONE);
			if (srcType != SRC_TYPE_MUSIC_MIX) {
				playStatusLayout.setVisibility(View.GONE);
				playStatusImg.setVisibility(View.GONE);
				playStatusSvga.setVisibility(View.GONE);
			} else {
				playStatusLayout.setVisibility(View.VISIBLE);
				playStatusSvga.setVisibility(audioPlayData.isPlaying() ? View.VISIBLE : View.GONE);
				playStatusImg.setVisibility(audioPlayData.isPlaying() ? View.GONE : View.VISIBLE);
			}
			if (playStatusSvga.getVisibility() == View.GONE) {
				playStatusSvga.clearAnimation();
			} else {
				playStatusSvga.startAnimation();
			}
		}

		private void renderImgSelectStatus(AudioPlayData audioPlayData) {
			Ln.d("xxxxxx, musicSelectType=%d, progress=%f", audioPlayData.musicSelectStatus, audioPlayData.downloadProgress);
			tvDownloadProgress.setVisibility(View.GONE);
			if (srcType == SRC_TYPE_MUSIC_SELECT) {
				if (audioPlayData.musicSelectStatus == MusicSelectStatus.MUSIC_STATUS_DOWNLOADING) {
					imgPlayIcon.setVisibility(View.GONE);
					tvDownloadProgress.setVisibility(View.VISIBLE);
					tvDownloadProgress.setText(String.valueOf((int) (audioPlayData.downloadProgress * 100)));

				} else {
					imgPlayIcon.setVisibility(View.VISIBLE);
					tvDownloadProgress.setVisibility(View.GONE);
					imgPlayIcon.setImageResource(musicSelectIds[audioPlayData.musicSelectStatus]);
				}
			} else if (srcType == SRC_TYPE_MUSIC_MIX) {
				tvDownloadProgress.setVisibility(View.GONE);
				imgPlayIcon.setVisibility(View.VISIBLE);
				imgPlayIcon.setImageResource(audioPlayData.mixMusicSelectStatus == MixMusicSelectStatus.MUSIC_MIX_UN_SELECTED ? R.drawable.ic_music_mix_unselected : R.drawable.ic_music_mix_selected);
			}
		}


		/**
		 * 点击事件
		 */
		private void initListener() {
			RxView.clicks(itemView)
					.throttleFirst(500, TimeUnit.MILLISECONDS)
					.subscribe(aVoid -> {
						if (listener != null) {
							listener.onItemClick(getLayoutPosition());
						}
					});


			RxView.clicks(imgMoreOperation)
					.throttleFirst(500, TimeUnit.MILLISECONDS)
					.subscribe(aVoid -> {
						if (listener != null) {
							listener.onItemMoreOperClick(getLayoutPosition());
						}
					});

			RxView.clicks(playStatusImg)
					.throttleFirst(500, TimeUnit.MILLISECONDS)
					.subscribe(aVoid -> {
						if (listener != null) {
							listener.onPlayImgClick(getLayoutPosition());
						}
					});
			RxView.clicks(playStatusSvga)
					.throttleFirst(500, TimeUnit.MILLISECONDS)
					.subscribe(aVoid -> {
						if (listener != null) {
							listener.onPlaySvgaClick(getLayoutPosition());
						}
					});

		}

		/**
		 * 设置录音类型
		 *
		 * @param type
		 */
		private void setCategoryImg(int type) {
			int index = FlagUtil.getFirstOneIndexFromBits(type);
			if (index >= 0) {
				voiceCategoryImg.setImageResource(voiceTypeIds[index]);
			}
		}
	}

	/**
	 * 处理点击事件
	 */
	public interface OnAudioRecordModelViewBinderListener {

		void onItemClick(int position);

		void onItemMoreOperClick(int position);

		void onPlayImgClick(int position);

		void onPlaySvgaClick(int position);
	}

}
