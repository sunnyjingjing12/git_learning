package com.itingbaby.app.viewbinder;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.customview.HomeBannerLayout;
import com.itingbaby.app.model.BannerCardListModel;
import com.itingbaby.app.model.HomeCardBanner;
import com.itingbaby.app.model.action.Action;
import com.itingbaby.app.model.action.ActionEngine;
import com.itingbaby.baselib.commonutils.Ln;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import me.drakeet.multitype.ItemViewBinder;

public class BannerCardViewBinder extends ItemViewBinder<BannerCardListModel, BannerCardViewBinder.ViewHolder> {


	@NonNull
	@Override
	protected BannerCardViewBinder.ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
		return new BannerCardViewBinder.ViewHolder(new HomeBannerLayout(parent.getContext()));
	}

	@Override
	protected void onBindViewHolder(@NonNull BannerCardViewBinder.ViewHolder viewHolder, @NonNull BannerCardListModel model) {
		viewHolder.bindData(model);
	}

	public class ViewHolder extends RecyclerView.ViewHolder {
		private HomeBannerLayout homeBannerLayout;
		private BannerCardListModel mModel;

		public ViewHolder(@NonNull View itemView) {
			super(itemView);
			homeBannerLayout = (HomeBannerLayout) itemView;
			homeBannerLayout.setOnBannerClickListener(position -> {
				if (mModel != null) {
					if (position >= 0 && position < mModel.homeCardBannerList.size()) {
						String actionStr = mModel.homeCardBannerList.get(position).action;
						Action action;
						try {
							if (!TextUtils.isEmpty(actionStr)) {
								action = Action.parseJson(new JSONObject(actionStr));
								ActionEngine.getInstance().action(action, itemView.getContext());
							}
						} catch (Exception e) {
							Ln.e(e);
						}
					}

				}
			});
		}

		public void bindData(BannerCardListModel model) {
			mModel = model;
			List<String> imgUrls = new ArrayList<>();
			for (HomeCardBanner homeCardBanner : model.homeCardBannerList) {
				imgUrls.add(ServiceGenerator.URL_IMG_SERVER + homeCardBanner.url);
			}
			homeBannerLayout.updateImgs(imgUrls);
		}
	}
}
