package com.itingbaby.app.viewbinder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.itingbaby.app.R;
import com.itingbaby.app.activity.pelvic.HomePelvicTrainActivity;
import com.itingbaby.app.model.BleDeviceWrapper;
import com.itingbaby.dev.DeviceType;
import com.itingbaby.dev.iTingBabyBleDevice;
import com.itingbaby.dev.iTingBabyBleDeviceManager;
import com.jakewharton.rxbinding3.view.RxView;

import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.drakeet.multitype.ItemViewBinder;

public class BluetoothDeviceViewBinder extends ItemViewBinder<BleDeviceWrapper, BluetoothDeviceViewBinder.ViewHolder> {


	private OnDeviceClickListener mListener;

	public void setOnDeviceClickListener(OnDeviceClickListener listener) {
		mListener = listener;
	}

	@NonNull
	@Override
	protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
		View root = inflater.inflate(R.layout.item_device_view, parent, false);
		return new ViewHolder(root);
	}

	@Override
	protected void onBindViewHolder(@NonNull ViewHolder holder, @NonNull BleDeviceWrapper bleDeviceWrapper) {
		holder.bindData(bleDeviceWrapper);
	}

	class ViewHolder extends RecyclerView.ViewHolder {

		@BindView(R.id.txt_device_title)
		TextView txtDeviceTitle;
		@BindView(R.id.txt_device_mac)
		TextView txtDeviceMac;
		@BindView(R.id.txt_connect)
		TextView txtConnect;
		@BindView(R.id.img_device)
		ImageView imgDevice;

		private BleDeviceWrapper mBleDeviceWrapper;

		ViewHolder(View itemView) {
			super(itemView);
			ButterKnife.bind(this, itemView);
			RxView.clicks(itemView)
					.throttleFirst(1, TimeUnit.SECONDS)
					.subscribe(aVoid -> {
						if (mListener != null && mBleDeviceWrapper != null) {
							if (mBleDeviceWrapper.getDeviceType() == DeviceType.DEVICE_TYPE_KEGEL) {
								HomePelvicTrainActivity.navigate(itemView.getContext());
							} else {
								String mac = mBleDeviceWrapper.getDeviceAddress();
								int bleType = mBleDeviceWrapper.getDeviceBleType();
								iTingBabyBleDevice device = iTingBabyBleDeviceManager.getInstance().createBleDevice(mac, bleType);
								mListener.onConnect(device);
							}
						}
					});
		}

		public void bindData(BleDeviceWrapper bleDeviceWrapper) {
			mBleDeviceWrapper = bleDeviceWrapper;
			if (mBleDeviceWrapper == null) {
				return;
			}

			txtDeviceTitle.setText(bleDeviceWrapper.getDeviceName());
			txtDeviceMac.setText(bleDeviceWrapper.getDeviceAddress());
			imgDevice.setImageResource(bleDeviceWrapper.getDeviceType() == DeviceType.DEVICE_TYPE_KEGEL ? R.drawable.ic_device_kegel : R.drawable.ic_device_tbb);

		}
	}

	public interface OnDeviceClickListener {
		void onConnect(iTingBabyBleDevice device);

		void onDisConnect(String mac);

		void onDetail(String mac);
	}

}
