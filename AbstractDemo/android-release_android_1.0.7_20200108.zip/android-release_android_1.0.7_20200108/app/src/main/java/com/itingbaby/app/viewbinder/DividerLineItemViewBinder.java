package com.itingbaby.app.viewbinder;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.itingbaby.app.R;
import com.itingbaby.app.model.DividerLineEntity;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.drakeet.multitype.ItemViewBinder;


/**
 * 分割线item
 */
public class DividerLineItemViewBinder extends ItemViewBinder<DividerLineEntity, DividerLineItemViewBinder.ViewHolder> {


	@NonNull
	@Override
	protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
		View root = inflater.inflate(R.layout.item_divider_line, parent, false);
		return new ViewHolder(root);
	}

	@Override
	protected void onBindViewHolder(@NonNull ViewHolder holder, @NonNull DividerLineEntity dividerLineEntity) {
		holder.bindData(dividerLineEntity);
	}

	static class ViewHolder extends RecyclerView.ViewHolder {

		@BindView(R.id.view_divider)
		View dividerLine;

		public ViewHolder(View itemView) {
			super(itemView);
			ButterKnife.bind(this, itemView);
		}

		public void bindData(DividerLineEntity dividerLineEntity) {
			if (dividerLineEntity != null) {

				dividerLine.setBackgroundColor(itemView.getContext().getResources().getColor(dividerLineEntity.lineColor));
				ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) dividerLine.getLayoutParams();
				layoutParams.height = dividerLineEntity.lineHeight;
				dividerLine.setLayoutParams(layoutParams);
			}
		}

	}
}
