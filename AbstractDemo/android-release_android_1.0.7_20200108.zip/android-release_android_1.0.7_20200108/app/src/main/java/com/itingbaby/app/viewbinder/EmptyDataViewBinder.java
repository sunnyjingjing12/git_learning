package com.itingbaby.app.viewbinder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.itingbaby.app.model.EmptyDataModel;
import com.itingbaby.baselib.views.widget.ItbEmptyViewLayout;

import me.drakeet.multitype.ItemViewBinder;

public class EmptyDataViewBinder extends ItemViewBinder<EmptyDataModel, EmptyDataViewBinder.ViewHolder> {


	@NonNull
	@Override
	protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
		return new ViewHolder(new ItbEmptyViewLayout(parent.getContext()));
	}

	@Override
	protected void onBindViewHolder(@NonNull ViewHolder viewHolder, @NonNull EmptyDataModel emptyDataModel) {
		viewHolder.bindData(emptyDataModel);
	}

	public class ViewHolder extends RecyclerView.ViewHolder {
		private ItbEmptyViewLayout mItbEmptyViewLayout;

		public ViewHolder(@NonNull View itemView) {
			super(itemView);
			mItbEmptyViewLayout = (ItbEmptyViewLayout) itemView;
			RecyclerView.LayoutParams layoutParams = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			mItbEmptyViewLayout.setLayoutParams(layoutParams);

			mItbEmptyViewLayout.setEmptyViewMarginTopPercentHeight(0.2f);

		}

		public void bindData(EmptyDataModel emptyDataModel) {
			if (emptyDataModel == null) {
				return;
			}
			mItbEmptyViewLayout.setEmptyImageRes(emptyDataModel.drawableResId);
			mItbEmptyViewLayout.setEmptyMessage(emptyDataModel.hintTxt);
			mItbEmptyViewLayout.showEmpty();
		}
	}
}
