package com.itingbaby.app.viewbinder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.itingbaby.app.customview.ToolsGroupLayout;
import com.itingbaby.app.model.ToolsGroupData;

import me.drakeet.multitype.ItemViewBinder;

public class HomeToolsGroupViewBinder extends ItemViewBinder<ToolsGroupData, HomeToolsGroupViewBinder.ViewHolder> {


	@NonNull
	@Override
	protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
		return new ViewHolder(new ToolsGroupLayout(parent.getContext()));
	}

	@Override
	protected void onBindViewHolder(@NonNull ViewHolder viewHolder, @NonNull ToolsGroupData toolsGroup) {
		viewHolder.bindData(toolsGroup);
	}

	public class ViewHolder extends RecyclerView.ViewHolder {
		private ToolsGroupLayout mToolsGroupLayout;

		public ViewHolder(@NonNull View itemView) {
			super(itemView);
			mToolsGroupLayout = (ToolsGroupLayout) itemView;
		}

		public void bindData(ToolsGroupData toolsGroup) {
			mToolsGroupLayout.renderData(toolsGroup);
		}
	}
}
