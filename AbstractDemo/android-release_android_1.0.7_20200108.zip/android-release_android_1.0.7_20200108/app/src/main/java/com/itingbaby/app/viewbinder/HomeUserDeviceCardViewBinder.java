package com.itingbaby.app.viewbinder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.itingbaby.app.activity.HomeVoiceActivity;
import com.itingbaby.app.activity.pelvic.HomePelvicTrainActivity;
import com.itingbaby.app.customview.UserDeviceCardLayout;
import com.itingbaby.app.model.HomeCardDevice;
import com.itingbaby.dev.DeviceType;
import com.jakewharton.rxbinding3.view.RxView;

import java.util.concurrent.TimeUnit;

import me.drakeet.multitype.ItemViewBinder;

public class HomeUserDeviceCardViewBinder extends ItemViewBinder<HomeCardDevice, HomeUserDeviceCardViewBinder.ViewHolder> {


	@NonNull
	@Override
	protected HomeUserDeviceCardViewBinder.ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
		return new HomeUserDeviceCardViewBinder.ViewHolder(new UserDeviceCardLayout(parent.getContext()));
	}

	@Override
	protected void onBindViewHolder(@NonNull HomeUserDeviceCardViewBinder.ViewHolder viewHolder, @NonNull HomeCardDevice homeCardDevice) {
		viewHolder.bindData(homeCardDevice);
	}

	public class ViewHolder extends RecyclerView.ViewHolder {
		private UserDeviceCardLayout mUserDeviceCardLayout;
		private HomeCardDevice mHomeCardDevice;

		public ViewHolder(@NonNull View itemView) {
			super(itemView);
			mUserDeviceCardLayout = (UserDeviceCardLayout) itemView;
			RxView.clicks(itemView)
					.throttleFirst(1, TimeUnit.SECONDS)
					.subscribe(aVoid -> {
						if (mHomeCardDevice != null) {
							switch (mHomeCardDevice.deviceInfo.deviceType) {
							case DeviceType.DEVICE_TYPE_TBB:
								HomeVoiceActivity.navigate(itemView.getContext());
							break;
							case DeviceType.DEVICE_TYPE_KEGEL:
								HomePelvicTrainActivity.navigate(itemView.getContext());
							break;
							}
						}
					});
		}

		public void bindData(HomeCardDevice homeCardDevice) {
			mHomeCardDevice = homeCardDevice;
			mUserDeviceCardLayout.renderData(homeCardDevice);
		}
	}

}
