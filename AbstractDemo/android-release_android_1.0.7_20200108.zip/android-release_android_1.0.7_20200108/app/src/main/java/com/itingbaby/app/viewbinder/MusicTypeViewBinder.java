package com.itingbaby.app.viewbinder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.itingbaby.app.R;
import com.itingbaby.app.activity.MusicListActivity;
import com.itingbaby.app.model.MusicCategory;
import com.itingbaby.app.model.MusicGroup;
import com.itingbaby.app.utils.GsonHelper;
import com.itingbaby.baselib.commonutils.ListUtils;
import com.jakewharton.rxbinding3.view.RxView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.drakeet.multitype.ItemViewBinder;

/**
 * 宝宝音乐-数据列表item
 */
public class MusicTypeViewBinder extends ItemViewBinder<MusicCategory, MusicTypeViewBinder.ViewHolder> {

	private int[] ids = {R.drawable.home_music_shape_bg_1, R.drawable.home_music_shape_bg_2, R.drawable.home_music_shape_bg_3,
			R.drawable.home_music_shape_bg_4, R.drawable.home_music_shape_bg_5, R.drawable.home_music_shape_bg_6};
	private List<MusicGroup> musicGroupList = new ArrayList<>();

	@NonNull
	@Override
	protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
		View root = inflater.inflate(R.layout.home_music_type_item, parent, false);
		return new ViewHolder(root);
	}

	@Override
	protected void onBindViewHolder(@NonNull ViewHolder holder, @NonNull MusicCategory category) {
		holder.bindData(category);
	}

	public void setMusicGroupList(List<MusicGroup> musicTypeGroupList) {
		this.musicGroupList = musicTypeGroupList;
	}

	class ViewHolder extends RecyclerView.ViewHolder {

		@BindView(R.id.txt_music_type_title)
		TextView txtMusicTypeTitle;
		@BindView(R.id.txt_music_type_desc)
		TextView txtMusicTypeDesc;
		@BindView(R.id.home_music_type_root)
		RelativeLayout homeMusicTypeRoot;

		private MusicCategory musicCategory;
		private int index;

		ViewHolder(View itemView) {
			super(itemView);
			ButterKnife.bind(this, itemView);

			RxView.clicks(itemView)
					.throttleFirst(1, TimeUnit.SECONDS)
					.subscribe(aVoid -> {
						String str = GsonHelper.objectToJson(musicCategory);
						MusicListActivity.navigate(itemView.getContext(), str, index);
					});
		}

		public void bindData(MusicCategory category) {
			musicCategory = category;
			txtMusicTypeTitle.setText(category.title);
			txtMusicTypeDesc.setText(category.description);

			index = getIndexFromMusicGroup(musicCategory, musicGroupList);
			index = index % ids.length;
			if (index >= 0) {
				homeMusicTypeRoot.setBackgroundResource(ids[index]);
			}

		}

		/**
		 * 获取组内索引
		 *
		 * @param musicCategory
		 * @param musicGroupList
		 * @return
		 */
		private int getIndexFromMusicGroup(MusicCategory musicCategory, List<MusicGroup> musicGroupList) {
			if (ListUtils.isEmpty(musicGroupList)) {
				return -1;
			}
			for (MusicGroup musicGroup : musicGroupList) {
				List<MusicCategory> musicCategoryList = musicGroup.categoryList;
				for (int i = 0, size = musicCategoryList.size(); i < size; i++) {
					MusicCategory category = musicCategoryList.get(i);
					if (category.id == musicCategory.id) {
						return i;
					}
				}
			}
			return -1;
		}
	}
}
