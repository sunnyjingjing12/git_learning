package com.itingbaby.app.viewbinder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.model.AudioPlayData;
import com.itingbaby.app.model.MixMusicSelectStatus;
import com.itingbaby.app.model.MusicClause;
import com.itingbaby.app.model.MusicSelectStatus;
import com.itingbaby.baselib.commonutils.Ln;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.jakewharton.rxbinding3.view.RxView;
import com.opensource.svgaplayer.SVGAImageView;

import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.drakeet.multitype.ItemViewBinder;

/**
 * 宝宝音乐-数据列表item
 */

public class MusicViewBinder extends ItemViewBinder<MusicClause, MusicViewBinder.ViewHolder> {

	public static final int SRC_TYPE_DEFAULT = 0;   // 来自其他页面
	public static final int SRC_TYPE_MIX_MUSIC = 1;   // 来自混音页面
	public static final int SRC_TYPE_SELECT_MUSIC = 2;   // 来自选择音乐页面

	private int[] ids = {0, R.drawable.ic_to_download, R.drawable.ic_downloading, R.drawable.ic_download_pause, R.drawable.ic_download_failed,
			R.drawable.ic_music_unselected, R.drawable.ic_music_selected};

	private int srcType;
	private OnMusicViewBinderListener listener;

	public void setListener(OnMusicViewBinderListener listener) {
		this.listener = listener;
	}

	public MusicViewBinder(int srcType) {
		this.srcType = srcType;
	}

	@NonNull
	@Override
	protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
		View root = inflater.inflate(R.layout.item_music_view, parent, false);
		return new ViewHolder(root);
	}

	@Override
	protected void onBindViewHolder(@NonNull ViewHolder holder, @NonNull MusicClause music) {
		holder.bindData(music);
	}

	class ViewHolder extends RecyclerView.ViewHolder {

		@BindView(R.id.txt_music_name)
		TextView txtMusicName;
		@BindView(R.id.txt_music_singer)
		TextView txtMusicSinger;

		@BindView(R.id.txt_time)
		TextView txtTime;
		@BindView(R.id.img_play)
		ImageView imgPlay;
		@BindView(R.id.img_select_status)
		ImageView imgSelectStatus;
		@BindView(R.id.img_cover)
		ImageView imgCover;
		@BindView(R.id.tv_download_progress)
		TextView tvDownloadProgress;
		@BindView(R.id.music_play_status_img)
		ImageView musicPlayStatusImg;
		@BindView(R.id.music_play_status_svga)
		SVGAImageView musicPlayStatusSvga;
		@BindView(R.id.music_play_status_layout)
		FrameLayout musicPlayStatusLayout;


		ViewHolder(View itemView) {
			super(itemView);
			ButterKnife.bind(this, itemView);

			RxView.clicks(itemView)
					.throttleFirst(500, TimeUnit.MILLISECONDS)
					.subscribe(aVoid -> {
						if (listener != null) {
							listener.onItemClick(getLayoutPosition());
						}
					});
			RxView.clicks(musicPlayStatusImg)
					.throttleFirst(500, TimeUnit.MILLISECONDS)
					.subscribe(aVoid -> {
						if (listener != null) {
							listener.onMusicPlayImgClick(getLayoutPosition());
						}
					});
			RxView.clicks(musicPlayStatusSvga)
					.throttleFirst(500, TimeUnit.MILLISECONDS)
					.subscribe(aVoid -> {
						if (listener != null) {
							listener.onMusicPlaySvgaClick(getLayoutPosition());
						}
					});
		}


		public void bindData(MusicClause music) {

			txtMusicName.setText(music.getTitle());
			txtMusicSinger.setText(music.getAuthor());
			txtTime.setText(StringUtils.formatTime2(music.getDuration()));

			renderPlayingStatus(music);

			renderImgSelectStatus(music);

			Glide.with(itemView.getContext())
					.load(ServiceGenerator.URL_IMG_SERVER + music.getImgUrl())
					.dontAnimate()
					.into(imgCover);
		}

		private void renderPlayingStatus(MusicClause music) {
			if (srcType != SRC_TYPE_DEFAULT) {
				imgPlay.setVisibility(View.GONE);
			} else {
				imgPlay.setVisibility(music.isPlaying() ? View.VISIBLE : View.GONE);
			}
			if (srcType != SRC_TYPE_MIX_MUSIC) {
				musicPlayStatusLayout.setVisibility(View.GONE);
				musicPlayStatusImg.setVisibility(View.GONE);
				musicPlayStatusSvga.setVisibility(View.GONE);
			} else {
				musicPlayStatusLayout.setVisibility(View.VISIBLE);
				musicPlayStatusSvga.setVisibility(music.isPlaying() ? View.VISIBLE : View.GONE);
				musicPlayStatusImg.setVisibility(music.isPlaying() ? View.GONE : View.VISIBLE);
			}
			if (musicPlayStatusSvga.getVisibility() == View.GONE) {
				musicPlayStatusSvga.clearAnimation();
			} else {
				musicPlayStatusSvga.startAnimation();
			}
		}

		private void renderImgSelectStatus(AudioPlayData audioPlayData) {
			Ln.d("xxxxxx, musicSelectType=%d, progress=%f", audioPlayData.musicSelectStatus, audioPlayData.downloadProgress);
			tvDownloadProgress.setVisibility(View.GONE);
			if (srcType == SRC_TYPE_SELECT_MUSIC) {
				if (audioPlayData.musicSelectStatus == MusicSelectStatus.MUSIC_STATUS_DOWNLOADING) {
					imgSelectStatus.setVisibility(View.GONE);
					tvDownloadProgress.setVisibility(View.VISIBLE);
					tvDownloadProgress.setText(String.valueOf((int) (audioPlayData.downloadProgress * 100)));

				} else {
					imgSelectStatus.setVisibility(View.VISIBLE);
					tvDownloadProgress.setVisibility(View.GONE);
					imgSelectStatus.setImageResource(ids[audioPlayData.musicSelectStatus]);
				}
			} else if (srcType == SRC_TYPE_MIX_MUSIC) {
				tvDownloadProgress.setVisibility(View.GONE);
				imgSelectStatus.setVisibility(View.VISIBLE);
				imgSelectStatus.setImageResource(audioPlayData.mixMusicSelectStatus == MixMusicSelectStatus.MUSIC_MIX_UN_SELECTED ? R.drawable.ic_music_mix_unselected : R.drawable.ic_music_mix_selected);
			}

		}
	}

	/**
	 * 处理点击事件
	 */
	public interface OnMusicViewBinderListener {

		void onItemClick(int position);

		void onMusicPlayImgClick(int position);

		void onMusicPlaySvgaClick(int position);

	}
}
