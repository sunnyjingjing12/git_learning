package com.itingbaby.app.viewbinder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.itingbaby.app.R;
import com.itingbaby.app.customview.PelvicSubView;
import com.itingbaby.app.model.pelvictrain.PelvicTrainRecord;
import com.itingbaby.baselib.commonutils.DimensionUtil;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.jakewharton.rxbinding3.view.RxView;

import java.util.Locale;
import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.drakeet.multitype.ItemViewBinder;

public class PelvicModelViewBinder extends ItemViewBinder<PelvicTrainRecord, PelvicModelViewBinder.ViewHolder> {

	private OnPelvicModelViewBinderListener listener;

	public void setOnPelvicModelViewBinderListener(OnPelvicModelViewBinderListener listener) {
		this.listener = listener;
	}

	@NonNull
	@Override
	protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
		View root = inflater.inflate(R.layout.item_pelvic_view, parent, false);
		return new ViewHolder(root);
	}

	@Override
	protected void onBindViewHolder(@NonNull ViewHolder holder, @NonNull PelvicTrainRecord record) {
		holder.bindData(record);
	}


	class ViewHolder extends RecyclerView.ViewHolder {

		@BindView(R.id.txt_date_time)
		TextView txtDateTime;
		@BindView(R.id.sub_max_power_view)
		PelvicSubView subMaxPowerView;
		@BindView(R.id.sub_muscle_view)
		PelvicSubView subMuscleView;
		@BindView(R.id.sub_examine_view)
		PelvicSubView subExamineView;

		private PelvicTrainRecord record;

		public ViewHolder(@NonNull View itemView) {
			super(itemView);
			ButterKnife.bind(this, itemView);

			RxView.clicks(itemView)
					.throttleFirst(1, TimeUnit.SECONDS)
					.subscribe(aVoid -> {
						if (listener != null) {
							listener.onItemClick(getLayoutPosition());
						}
					});
		}

		public void bindData(PelvicTrainRecord record) {
			this.record = record;

			String str = StringUtils.TimeStamp2Date(record.recordTimeStamp, "yyyy-MM-dd HH:mm:ss");
			txtDateTime.setText(str);
			ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) txtDateTime.getLayoutParams();
			layoutParams.topMargin = (getLayoutPosition() == 0 ? 0 : DimensionUtil.dipToPx(16));
			itemView.setBackgroundResource(getLayoutPosition() == 0 ? 0 : R.drawable.shape_home_training_item_bg);

			subMaxPowerView.initData(String.format(Locale.getDefault(), "%.1f", record.maxPower), "N");
			subMuscleView.initData(String.format(Locale.getDefault(), "I类%d级 II类%d级", record.oneMuscle, record.twoMuscle), "");
			subExamineView.initData(String.format("%s方案", record.caseName), "");

		}
	}

	/**
	 * 处理点击事件
	 */
	public interface OnPelvicModelViewBinderListener {

		void onItemClick(int position);

	}
}
