package com.itingbaby.app.viewbinder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.itingbaby.app.R;
import com.itingbaby.app.activity.PregnancyCheckDetailActivity;
import com.itingbaby.app.model.pregnancycheck.PregnancyCheckModel;
import com.itingbaby.app.utils.SimpleDatePickerDialog;
import com.jakewharton.rxbinding3.view.RxView;

import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import me.drakeet.multitype.ItemViewBinder;

public class PregnancyCheckModelViewBinder extends ItemViewBinder<PregnancyCheckModel, PregnancyCheckModelViewBinder.ViewHolder> {


	private OnPregnancyCheckBinderListener mListener;

	public void setListener(OnPregnancyCheckBinderListener l) {
		this.mListener = l;
	}

	@NonNull
	@Override
	protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
		View root = inflater.inflate(R.layout.item_pregnancy_view, parent, false);
		return new ViewHolder(root);
	}

	@Override
	protected void onBindViewHolder(@NonNull ViewHolder holder, @NonNull PregnancyCheckModel pregnancyCheckModel) {
		holder.bindData(pregnancyCheckModel);
	}


	class ViewHolder extends RecyclerView.ViewHolder {

		@BindView(R.id.txt_pc_num_and_week)
		TextView txtPcNumAndWeek;
		@BindView(R.id.txt_pc_expire)
		TextView txtPcExpire;
		@BindView(R.id.img_pc_status)
		ImageView imgPcStatus;
		@BindView(R.id.txt_pc_key_point)
		TextView txtPcKeyPoint;
		@BindView(R.id.img_pc_time)
		ImageView imgPcTime;
		@BindView(R.id.txt_pc_time)
		TextView txtPcTime;
		@BindView(R.id.txt_pc_modify)
		TextView txtPcModify;

		private PregnancyCheckModel mPregnancyCheckModel;

		private SimpleDatePickerDialog datePickerDialog;


		public ViewHolder(View itemView) {
			super(itemView);
			ButterKnife.bind(this, itemView);

			RxView.clicks(itemView)
					.throttleFirst(1, TimeUnit.SECONDS)
					.subscribe(aVoid -> {
						if (mPregnancyCheckModel != null) {
							PregnancyCheckDetailActivity.navigate(itemView.getContext(), mPregnancyCheckModel.id, mPregnancyCheckModel.name);
						}
					});
		}

		public void bindData(PregnancyCheckModel model) {
			mPregnancyCheckModel = model;
			txtPcNumAndWeek.setText(String.format("%s %s", model.name, model.week));
			imgPcStatus.setImageResource(model.flag == 0 ? R.drawable.ic_wp_unselected : R.drawable.ic_wp_selected);
			txtPcKeyPoint.setText(String.format("重点：%s", model.summery));
			txtPcTime.setText(model.date);

			txtPcExpire.setVisibility(model.isExpired() ? View.VISIBLE : View.GONE);

			txtPcNumAndWeek.setTextColor(model.isNextRemind() ?
					itemView.getResources().getColor(R.color.color_00bed7) : itemView.getResources().getColor(R.color.color_b3b3b3));

			txtPcModify.setTextColor(model.isNextRemind() ?
					itemView.getResources().getColor(R.color.color_00bed7) : itemView.getResources().getColor(R.color.color_b3b3b3));

			txtPcKeyPoint.setTextColor(model.isNextRemind() ?
					itemView.getResources().getColor(R.color.black) : itemView.getResources().getColor(R.color.color_b3b3b3));

			txtPcTime.setTextColor(model.isNextRemind() ?
					itemView.getResources().getColor(R.color.black) : itemView.getResources().getColor(R.color.color_b3b3b3));

			imgPcTime.setImageResource(model.isNextRemind() ? R.drawable.ic_vc_time_current : R.drawable.ic_vc_time_not_current);
		}


		@OnClick({R.id.img_pc_status, R.id.txt_pc_modify})
		public void onViewClicked(View view) {
			switch (view.getId()) {
				case R.id.img_pc_status:
					if (mListener != null && mPregnancyCheckModel != null) {
						mListener.onUpdateStatus(getLayoutPosition(), mPregnancyCheckModel);
					}
					break;
				case R.id.txt_pc_modify:
					if (mPregnancyCheckModel != null) {
						showSelectDate(mPregnancyCheckModel.date);
					}

					break;
			}
		}

		private void showSelectDate(String currDate) {
			datePickerDialog = new SimpleDatePickerDialog.Builder()
					.setContext(itemView.getContext())
					.setTitleId(R.string.txt_select_date)
					.setYYYYMMDD(currDate, "yyyy年MM月dd日")
					.setConfirmListener(which -> {
						mPregnancyCheckModel.date = datePickerDialog.getYYYYMMDD("%04d年%02d月%02d日");
						if (mListener != null && mPregnancyCheckModel != null) {
							mListener.onUpdateDate(getLayoutPosition(), mPregnancyCheckModel);
						}

					})
					.build();
			datePickerDialog.show();
		}


	}

	public interface OnPregnancyCheckBinderListener {
		void onUpdateStatus(int pos, PregnancyCheckModel model);

		void onUpdateDate(int pos, PregnancyCheckModel model);
	}


}
