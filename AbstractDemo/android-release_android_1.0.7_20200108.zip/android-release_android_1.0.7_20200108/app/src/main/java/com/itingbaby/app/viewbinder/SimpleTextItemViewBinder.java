package com.itingbaby.app.viewbinder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.itingbaby.app.R;
import com.itingbaby.app.model.SimpleTextItem;
import com.itingbaby.baselib.commonutils.DimensionUtil;
import com.itingbaby.baselib.commonutils.StringUtils;
import com.jakewharton.rxbinding3.view.RxView;

import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.drakeet.multitype.ItemViewBinder;


/**
 * 标题item
 */
public class SimpleTextItemViewBinder extends ItemViewBinder<SimpleTextItem, SimpleTextItemViewBinder.ViewHolder> {

	@NonNull
	@Override
	protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
		View root = inflater.inflate(R.layout.item_simple_text, parent, false);
		return new ViewHolder(root);
	}

	@Override
	protected void onBindViewHolder(@NonNull ViewHolder holder, @NonNull SimpleTextItem simpleTextItem) {
		holder.bindData(simpleTextItem);
	}

	private OnItemClickListener mOnItemClickListener;

	public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
		this.mOnItemClickListener = onItemClickListener;
	}

	class ViewHolder extends RecyclerView.ViewHolder {

		@BindView(R.id.txt_title)
		TextView txtTitle;

		@BindView(R.id.img_right)
		ImageView imgRight;

		@BindView(R.id.txt_right)
		TextView txtRight;

		public ViewHolder(View itemView) {
			super(itemView);
			ButterKnife.bind(this, itemView);

			RxView.clicks(itemView)
					.throttleFirst(1, TimeUnit.SECONDS)
					.subscribe(aVoid -> {
						if (mOnItemClickListener != null) {
							mOnItemClickListener.onItemClick(getLayoutPosition());
						}
					});

			RxView.clicks(txtRight)
					.throttleFirst(1, TimeUnit.SECONDS)
					.subscribe(aVoid -> {
						if (mOnItemClickListener != null) {
							mOnItemClickListener.onRightTextClick();
						}
					});
		}

		public void bindData(SimpleTextItem simpleTextItem) {
			if (simpleTextItem != null) {
				if (!StringUtils.isEmpty(simpleTextItem.title)) {
					txtTitle.setText(simpleTextItem.title);
				}
				if (simpleTextItem.textColor != 0) {
					txtTitle.setTextColor(itemView.getContext().getResources().getColor(simpleTextItem.textColor));
				}

				if (simpleTextItem.textSize != 0) {
					txtTitle.setTextSize(simpleTextItem.textSize);
				}

				if (simpleTextItem.isHorizontalCenter) {
					ConstraintLayout.LayoutParams titleParams = new ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
					titleParams.topToTop = ConstraintLayout.LayoutParams.PARENT_ID;
					titleParams.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID;
					titleParams.leftToLeft = ConstraintLayout.LayoutParams.PARENT_ID;
					titleParams.rightToRight = ConstraintLayout.LayoutParams.PARENT_ID;
					txtTitle.setLayoutParams(titleParams);
				}

				if (simpleTextItem.background != 0) {
					itemView.setBackground(itemView.getContext().getResources().getDrawable(simpleTextItem.background));
				} else {
					itemView.setBackgroundResource(0);
				}
				imgRight.setVisibility(simpleTextItem.isSelect ? View.VISIBLE : View.GONE);

				if (!StringUtils.isEmpty(simpleTextItem.rightTextContent)) {
					txtRight.setText(simpleTextItem.rightTextContent);
				}
				txtRight.setVisibility(simpleTextItem.rightTextVisibility);

				ViewGroup.LayoutParams layoutParams = itemView.getLayoutParams();
				layoutParams.height = DimensionUtil.dipToPx(simpleTextItem.height);
				itemView.setLayoutParams(layoutParams);

			}
		}
	}

	public interface OnItemClickListener {
		void onItemClick(int position);

		void onRightTextClick();

	}
}
