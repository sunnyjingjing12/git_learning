package com.itingbaby.app.viewbinder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.itingbaby.app.R;
import com.itingbaby.app.model.TabDataModel;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import me.drakeet.multitype.ItemViewBinder;

public class TabDataViewBinder extends ItemViewBinder<TabDataModel, TabDataViewBinder.ViewHolder> {

	private OnGoodsTabListener mListener;

	public void setListener(OnGoodsTabListener mListener) {
		this.mListener = mListener;
	}

	@NonNull
	@Override
	protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
		View root = inflater.inflate(R.layout.item_goods_tab_view, parent, false);
		return new ViewHolder(root);
	}

	@Override
	protected void onBindViewHolder(@NonNull ViewHolder holder, @NonNull TabDataModel model) {
		holder.bindData(model);
	}


	class ViewHolder extends RecyclerView.ViewHolder {
		@BindView(R.id.txt_wp_mom)
		TextView txtWpMom;
		@BindView(R.id.txt_wp_baby)
		TextView txtWpBaby;
		private TabDataModel model;

		public ViewHolder(View itemView) {
			super(itemView);
			ButterKnife.bind(this, itemView);

		}

		public void bindData(TabDataModel model) {
			this.model = model;
			txtWpMom.setText(model.tabName1);
			txtWpBaby.setText(model.tabName2);

			txtWpMom.setSelected(model.selectIndex == 0);
			txtWpBaby.setSelected(model.selectIndex == 1);
		}

		@OnClick({R.id.txt_wp_mom, R.id.txt_wp_baby})
		public void onViewClicked(View view) {
			switch (view.getId()) {
				case R.id.txt_wp_mom:
					if (model.selectIndex != 0) {
						if (mListener != null) {
							mListener.onTabSelected(0);
						}
					}
					break;
				case R.id.txt_wp_baby:
					if (model.selectIndex != 1) {
						if (mListener != null) {
							mListener.onTabSelected(1);
						}
					}
					break;
			}
		}
	}

	public interface OnGoodsTabListener {
		void onTabSelected(int selectedIndex);
	}
}
