package com.itingbaby.app.viewbinder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.itingbaby.app.customview.ToolsGroupFragmentLayout;
import com.itingbaby.app.model.ToolsGroupData;

import butterknife.ButterKnife;
import me.drakeet.multitype.ItemViewBinder;

public class ToolsGroupDataViewBinder extends ItemViewBinder<ToolsGroupData, ToolsGroupDataViewBinder.ViewHolder> {


	@NonNull
	@Override
	protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
		return new ViewHolder(new ToolsGroupFragmentLayout(parent.getContext()));
	}

	@Override
	protected void onBindViewHolder(@NonNull ViewHolder holder, @NonNull ToolsGroupData toolsGroupData) {
		holder.bindData(toolsGroupData);
	}


	class ViewHolder extends RecyclerView.ViewHolder {
		private ToolsGroupFragmentLayout toolsGroupFragmentLayout;

		public ViewHolder(View itemView) {
			super(itemView);
			ButterKnife.bind(this, itemView);
			toolsGroupFragmentLayout = (ToolsGroupFragmentLayout) itemView;
		}

		public void bindData(ToolsGroupData toolsGroupData) {
			toolsGroupFragmentLayout.renderData(toolsGroupData);
		}
	}
}
