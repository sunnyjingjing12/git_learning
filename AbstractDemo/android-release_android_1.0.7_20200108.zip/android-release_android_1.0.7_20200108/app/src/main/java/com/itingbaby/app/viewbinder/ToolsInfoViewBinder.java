package com.itingbaby.app.viewbinder;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.itingbaby.app.R;
import com.itingbaby.app.action.ServiceGenerator;
import com.itingbaby.app.model.ToolInfo;
import com.itingbaby.app.model.action.Action;
import com.itingbaby.app.model.action.ActionEngine;
import com.itingbaby.baselib.commonutils.Ln;
import com.jakewharton.rxbinding3.view.RxView;

import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.drakeet.multitype.ItemViewBinder;

public class ToolsInfoViewBinder extends ItemViewBinder<ToolInfo, ToolsInfoViewBinder.ViewHolder> {

	@NonNull
	@Override
	protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
		View root = inflater.inflate(R.layout.item_tools_info_view, parent, false);
		return new ViewHolder(root);
	}

	@Override
	protected void onBindViewHolder(@NonNull ViewHolder holder, @NonNull ToolInfo toolInfo) {
		holder.bindData(toolInfo);
	}


	class ViewHolder extends RecyclerView.ViewHolder {

		@BindView(R.id.img_tools)
		ImageView imgTools;
		@BindView(R.id.txt_tools)
		TextView txtTools;

		private ToolInfo mToolInfo;

		public ViewHolder(View itemView) {
			super(itemView);
			ButterKnife.bind(this, itemView);
			RxView.clicks(itemView)
					.throttleFirst(1, TimeUnit.SECONDS)
					.subscribe(aVoid -> {
						if (!TextUtils.isEmpty(mToolInfo.action)) {
							Action action = Action.parseJson(new JSONObject(mToolInfo.action));
							ActionEngine.getInstance().action(action, itemView.getContext());
						}
					}, throwable -> {
						Ln.e(throwable.toString());
					});
		}

		public void bindData(ToolInfo toolInfo) {
			if (toolInfo != null) {
				mToolInfo = toolInfo;
				Glide.with(itemView.getContext())
						.load(ServiceGenerator.URL_IMG_SERVER + toolInfo.url)
						.dontAnimate()
						.into(imgTools);
				txtTools.setText(toolInfo.name);
			}
		}
	}

}
