package com.itingbaby.app.viewbinder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.itingbaby.app.customview.VaccineGroupDataLayout;
import com.itingbaby.app.model.VaccineGroupDataModel;

import butterknife.ButterKnife;
import me.drakeet.multitype.ItemViewBinder;

public class VaccineGroupDataViewBinder extends ItemViewBinder<VaccineGroupDataModel, VaccineGroupDataViewBinder.ViewHolder> {


	@NonNull
	@Override
	protected VaccineGroupDataViewBinder.ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
		return new VaccineGroupDataViewBinder.ViewHolder(new VaccineGroupDataLayout(parent.getContext()));
	}

	@Override
	protected void onBindViewHolder(@NonNull VaccineGroupDataViewBinder.ViewHolder holder, @NonNull VaccineGroupDataModel vaccineGroupDataModel) {
		holder.bindData(vaccineGroupDataModel);
	}


	class ViewHolder extends RecyclerView.ViewHolder {
		private VaccineGroupDataLayout vaccineGroupDataLayout;

		public ViewHolder(View itemView) {
			super(itemView);
			ButterKnife.bind(this, itemView);
			vaccineGroupDataLayout = (VaccineGroupDataLayout) itemView;
		}

		public void bindData(VaccineGroupDataModel vaccineGroupDataModel) {
			vaccineGroupDataLayout.renderData(vaccineGroupDataModel);
		}
	}
}
