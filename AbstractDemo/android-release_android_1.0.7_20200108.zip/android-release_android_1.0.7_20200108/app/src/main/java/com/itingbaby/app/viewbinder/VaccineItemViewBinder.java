package com.itingbaby.app.viewbinder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.itingbaby.app.R;
import com.itingbaby.app.activity.HtmlActivity;
import com.itingbaby.app.customview.DividerLine;
import com.itingbaby.app.model.Vaccine;
import com.jakewharton.rxbinding3.view.RxView;

import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import me.drakeet.multitype.ItemViewBinder;

public class VaccineItemViewBinder extends ItemViewBinder<Vaccine, VaccineItemViewBinder.ViewHolder> {

	private OnVaccineItemBinderListener mListener;

	public void setListener(OnVaccineItemBinderListener l) {
		this.mListener = l;
	}

	@NonNull
	@Override
	protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
		View root = inflater.inflate(R.layout.item_vaccine_sub_view, parent, false);
		return new ViewHolder(root);
	}

	@Override
	protected void onBindViewHolder(@NonNull ViewHolder holder, @NonNull Vaccine vaccine) {
		holder.bindData(vaccine);
	}


	class ViewHolder extends RecyclerView.ViewHolder {

		@BindView(R.id.img_vc_status)
		ImageView imgVcStatus;
		@BindView(R.id.txt_vc_name)
		TextView txtVcName;
		@BindView(R.id.txt_vc_num)
		TextView txtVcNum;
		@BindView(R.id.txt_vc_intro)
		TextView txtVcIntro;
		@BindView(R.id.img_vc_type)
		ImageView imgVcType;
		@BindView(R.id.vc_divider_line)
		DividerLine vcDividerLine;
		private Vaccine mVaccine;

		public ViewHolder(View itemView) {
			super(itemView);
			ButterKnife.bind(this, itemView);

			RxView.clicks(itemView)
					.throttleFirst(1, TimeUnit.SECONDS)
					.subscribe(aVoid -> {
						if (mVaccine != null) {
							HtmlActivity.navigate(itemView.getContext(), mVaccine.name, mVaccine.context);
						}
					});
		}

		@OnClick(R.id.img_vc_status)
		public void onViewClicked() {
			if (mListener != null && mVaccine != null) {
				mListener.onStatusClicked(getLayoutPosition(), mVaccine);
			}
		}

		public void bindData(Vaccine vaccine) {
			mVaccine = vaccine;
			txtVcName.setText(vaccine.name);
			txtVcNum.setText(vaccine.num);
			txtVcIntro.setText(vaccine.intro);
			imgVcType.setVisibility(vaccine.type == 1 ? View.VISIBLE : View.GONE);
			imgVcStatus.setImageResource(vaccine.status == 1 ? R.drawable.ic_vc_unselect : R.drawable.ic_vc_selected);
			vcDividerLine.setVisibility((getLayoutPosition() == getAdapter().getItemCount() - 1) ? View.GONE : View.VISIBLE);
		}
	}

	public interface OnVaccineItemBinderListener {
		void onStatusClicked(int pos, Vaccine vaccine);
	}
}
