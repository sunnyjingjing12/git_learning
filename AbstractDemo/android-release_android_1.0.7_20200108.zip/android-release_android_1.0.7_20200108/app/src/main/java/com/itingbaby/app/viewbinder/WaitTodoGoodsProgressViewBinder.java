package com.itingbaby.app.viewbinder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.itingbaby.app.R;
import com.itingbaby.app.model.ToDoGoodsProgressEntity;

import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import me.drakeet.multitype.ItemViewBinder;

public class WaitTodoGoodsProgressViewBinder extends ItemViewBinder<ToDoGoodsProgressEntity, WaitTodoGoodsProgressViewBinder.ViewHolder> {

	private OnWaitTodoGoodsProgressBinderListener mListener;

	public void setListener(OnWaitTodoGoodsProgressBinderListener listener) {
		this.mListener = listener;
	}

	@NonNull
	@Override
	protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
		View root = inflater.inflate(R.layout.item_wait_goods_progress_view, parent, false);
		return new ViewHolder(root);
	}

	@Override
	protected void onBindViewHolder(@NonNull ViewHolder holder, @NonNull ToDoGoodsProgressEntity entity) {
		holder.bindData(entity);
	}


	class ViewHolder extends RecyclerView.ViewHolder {
		@BindView(R.id.tv_wgp_value)
		TextView tvWgpValue;
		@BindView(R.id.pb_wgp)
		ProgressBar pbWgp;

		public ViewHolder(View itemView) {
			super(itemView);
			ButterKnife.bind(this, itemView);

		}

		public void bindData(ToDoGoodsProgressEntity entity) {
			int progress = (int) (entity.progress * 100);
			pbWgp.setProgress(progress);
			tvWgpValue.setText(String.format(Locale.getDefault(), "%d%%", progress));

			tvWgpValue.post(() -> {
				int pbWidth = pbWgp.getWidth();
				int tvWidth = tvWgpValue.getWidth();
				RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) tvWgpValue.getLayoutParams();
				int leftMargin = (int) (entity.progress * pbWidth) - tvWidth / 2;
				params.setMarginStart(leftMargin > 0 ? leftMargin : 0);
				tvWgpValue.setLayoutParams(params);
			});
		}

		@OnClick(R.id.tv_wgp_add)
		public void onViewClicked() {
			if (mListener != null) {
				mListener.onEditAddClicked();
			}
		}


	}

	public interface OnWaitTodoGoodsProgressBinderListener {
		void onEditAddClicked();
	}

}
