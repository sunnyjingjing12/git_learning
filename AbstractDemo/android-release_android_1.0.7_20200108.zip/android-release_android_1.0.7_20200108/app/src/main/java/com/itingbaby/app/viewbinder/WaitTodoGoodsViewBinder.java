package com.itingbaby.app.viewbinder;

import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.itingbaby.app.R;
import com.itingbaby.app.model.WaitTodoGoods;
import com.jakewharton.rxbinding3.view.RxView;

import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import me.drakeet.multitype.ItemViewBinder;

public class WaitTodoGoodsViewBinder extends ItemViewBinder<WaitTodoGoods, WaitTodoGoodsViewBinder.ViewHolder> {

	public static final int SRC_FROM_WAIT = 0;
	public static final int SRC_FROM_EDIT = 1;

	private OnWaitTodoGoodsBinderListener mListener;

	public void setListener(OnWaitTodoGoodsBinderListener listener) {
		this.mListener = listener;
	}

	private int showType;

	public WaitTodoGoodsViewBinder(int showType) {
		this.showType = showType;
	}

	@NonNull
	@Override
	protected ViewHolder onCreateViewHolder(@NonNull LayoutInflater inflater, @NonNull ViewGroup parent) {
		View root = inflater.inflate(R.layout.item_wait_goods_view, parent, false);
		return new ViewHolder(root);
	}

	@Override
	protected void onBindViewHolder(@NonNull ViewHolder holder, @NonNull WaitTodoGoods goods) {
		holder.bindData(goods);
	}


	class ViewHolder extends RecyclerView.ViewHolder {

		@BindView(R.id.img_wg_status)
		ImageView imgWgStatus;
		@BindView(R.id.img_wg_require)
		ImageView imgWgRequire;
		@BindView(R.id.img_wg_detail)
		ImageView imgWgDetail;
		@BindView(R.id.tv_wg_name)
		TextView tvWgName;
		@BindView(R.id.tv_wg_count)
		TextView tvWgCount;
		@BindView(R.id.tv_wg_content)
		TextView tvWgContent;

		private WaitTodoGoods mGoods;

		public ViewHolder(View itemView) {
			super(itemView);
			ButterKnife.bind(this, itemView);

			RxView.clicks(itemView)
					.throttleFirst(1, TimeUnit.SECONDS)
					.subscribe(aVoid -> {
						if (mGoods != null && mListener != null) {
							mListener.onItemClick(getLayoutPosition(), mGoods);
						}
					});
		}

		public void bindData(WaitTodoGoods goods) {
			mGoods = goods;
			if (showType == SRC_FROM_WAIT) {
				imgWgStatus.setImageResource((goods.flag & WaitTodoGoods.FLAG_FINISHED) == WaitTodoGoods.FLAG_FINISHED ?
						R.drawable.ic_wp_selected : R.drawable.ic_wp_unselected);
			} else if (showType == SRC_FROM_EDIT) {
				imgWgStatus.setImageResource((goods.flag & WaitTodoGoods.FLAG_ADD) == WaitTodoGoods.FLAG_ADD ?
						R.drawable.ic_wp_sub : R.drawable.ic_wp_add);
			}
			imgWgRequire.setVisibility((goods.flag & WaitTodoGoods.FLAG_REQUIRE) == WaitTodoGoods.FLAG_REQUIRE ?
					View.VISIBLE : View.GONE);
			tvWgName.setText(goods.name);
			tvWgCount.setText(goods.count);
			tvWgContent.setText(Html.fromHtml(goods.intro));
			tvWgContent.setVisibility(goods.expanded ? View.VISIBLE : View.GONE);
			imgWgDetail.setImageResource(goods.expanded ? R.drawable.ic_wp_arrow_up : R.drawable.ic_wp_detail);
		}


		@OnClick(R.id.img_wg_status)
		public void onViewClicked() {
			if (mGoods != null && mListener != null) {
				mListener.onItemStatusClicked(getLayoutPosition(), mGoods);
			}
		}

	}

	public interface OnWaitTodoGoodsBinderListener {
		void onItemClick(int pos, WaitTodoGoods goods);

		void onItemStatusClicked(int pos, WaitTodoGoods goods);
	}
}
